
/* =====================================================================
 *  APP — موتور برنامه (بدون هیچ وابستگی خارجی)
 *  ذخیره سازی: localStorage (با fallback حافظه ای) + خروجی/ورودی JSON
 * ===================================================================== */
(function () {
  'use strict';

  /* ---------- ثابت ها -------------------------------------------------- */
  const STORE_KEY = 'packpolymer-marketplace-roadmap-v2';
  const CONTENT_VERSION = '2.0';
  const APP_VERSION = '1.0.3';
  const COLORS = ['#38bdf8', '#a78bfa', '#34d399', '#f59e0b', '#f472b6', '#22d3ee', '#facc15', '#fb7185', '#4ade80', '#94a3b8', '#c084fc'];
  const META_SRC = (typeof PLAN_META !== 'undefined') ? PLAN_META : {};
  const DEF_TITLE = 'پک پلیمر (Packpolymer) — نقشه راه ساخت بازارگاه B2B و فروشگاه B2C پلیمر و سیلیکون';
  const DEF_SUB = 'استک پروژه: Woodmart + Elementor + WooCommerce + Dokan Pro + Rank Math Pro + Wordfence · قابل ویرایش، با یادداشت برای هر مرحله و زیرمرحله';
  const STACK = (META_SRC.stack && META_SRC.stack.length) ? META_SRC.stack.slice() : [];
  const BRAND = META_SRC.brand || 'Packpolymer — پک پلیمر';

  /* ---------- ابزارهای کمکی -------------------------------------------- */
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.prototype.slice.call((r || document).querySelectorAll(s));
  const esc = (s) => String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  const uid = (p) => p + '-' + Math.random().toString(36).slice(2, 8);
  /* آیکون SVG داخلی (بدون وابستگی بیرونی) — نام ها در انتهای فایل به صورت <symbol> تعریف شده اند */
  const I = (n, cls) => '<svg class="ic ' + (cls || '') + '" aria-hidden="true"><use href="#i-' + n + '" xlink:href="#i-' + n + '"></use></svg>';
  /* آیکون های آماده برای فازها؛ در حالت ویرایش، جای آیکون می توانی نام یکی از این ها را بنویسی:
     compass, server, cart, palette, building, package, flask, zap, megaphone, rocket, paperclip, more … */
  const KNOWN_ICONS = ['compass','server','cart','palette','building','package','flask','zap','megaphone','rocket','paperclip','more','tools','chart','phases','target','bulb','check'];
  const iconOf = (v, cls) => (KNOWN_ICONS.indexOf(String(v).trim()) !== -1)
      ? I(String(v).trim(), 'big ' + (cls || ''))
      : '<span class="em">' + esc(v) + '</span>';
  const clone = (o) => JSON.parse(JSON.stringify(o));
  const FA_DIGITS = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  const fa = (n) => String(n).replace(/[0-9]/g, (d) => FA_DIGITS[+d]);
  const pct = (d, t) => (t ? Math.round((d / t) * 100) : 0);
  const SIDEBAR_LAYOUTS = ['dual-right','single-right','dual-left'];
  function validSidebarLayout(v) { return SIDEBAR_LAYOUTS.indexOf(v) !== -1 ? v : 'dual-right'; }
  function clampScale(v, fallback) {
    const n = Number(v);
    if (!Number.isFinite(n)) return fallback == null ? 1 : fallback;
    return Math.min(1.5, Math.max(.8, Math.round(n * 100) / 100));
  }
  function clampNbWidth(v, fallback) { const n=Number(v); return Number.isFinite(n)?Math.max(50,Math.min(100,Math.round(n*10)/10)):(fallback==null?75:fallback); }
  function clampNbBodyRatio(v, fallback) { const n=Number(v); return Number.isFinite(n)?Math.max(.2,Math.min(.8,Math.round(n*100)/100)):(fallback == null ? 0.5 : fallback); }
  function clampNbSplit(v, fallback) { const n=Number(v); return Number.isFinite(n)?Math.max(.2,Math.min(.8,Math.round(n*100)/100)):(fallback == null ? 0.5 : fallback); }
  const SIDEBAR_MIN_WIDTH = 230, SIDEBAR_MAX_WIDTH = 420;
  function clampSidebarWidth(v, fallback) {
    const n=Number(v),f=Number(fallback);
    return Number.isFinite(n)?Math.max(SIDEBAR_MIN_WIDTH,Math.min(SIDEBAR_MAX_WIDTH,Math.round(n))):(Number.isFinite(f)?Math.max(SIDEBAR_MIN_WIDTH,Math.min(SIDEBAR_MAX_WIDTH,Math.round(f))):300);
  }
  function clampSidebarPairRatio(v, fallback) {
    const n=Number(v),f=Number(fallback);
    return Number.isFinite(n)?Math.max(.38,Math.min(.62,Math.round(n*100)/100)):(Number.isFinite(f)?Math.max(.38,Math.min(.62,Math.round(f*100)/100)):.5);
  }
  const TEXT_DIRECTIONS = ['auto','rtl','ltr'];
  function normalizeTextDirection(value) { return TEXT_DIRECTIONS.includes(value) ? value : 'auto'; }
  function nextTextDirection(value) { const mode=normalizeTextDirection(value); return TEXT_DIRECTIONS[(TEXT_DIRECTIONS.indexOf(mode)+1)%TEXT_DIRECTIONS.length]; }
  function textDirectionName(value) { return ({auto:'پیش‌فرض',rtl:'RTL',ltr:'LTR'})[normalizeTextDirection(value)]; }
  function textDirectionTitle(value) { const mode=normalizeTextDirection(value),next=textDirectionName(nextTextDirection(mode)); return 'LTR/RTL — حالت فعلی: '+textDirectionName(mode)+'؛ کلیک برای '+next; }
  function textDirectionAttrs(value) { const mode=normalizeTextDirection(value); return 'dir="'+(mode==='auto'?'auto':mode)+'" data-text-direction="'+mode+'"'; }
  function updateDirectionButton(button, value) {
    if(!button)return;
    const mode=normalizeTextDirection(value),title=textDirectionTitle(mode),label=mode==='auto'?'AUTO':mode.toUpperCase();
    const indicator=button.querySelector('[data-direction-label]');
    if(indicator)indicator.textContent=label;
    button.dataset.directionMode=mode;button.title=title;button.setAttribute('aria-label',title);button.setAttribute('aria-pressed',mode==='auto'?'false':'true');button.classList.toggle('on',mode!=='auto');
  }

  /* ---------- نرمال سازی متن برای جست وجو -------------------------------
   * اعداد فارسی/عربی → انگلیسی، ي/ك عربی → ی/ک، حذف نیم فاصله و اعراب،
   * یکدست سازی فاصله ها. بهاین ترتیب «فاز 1» == «فاز ۱» و «می شود» == «میشود».
   * ------------------------------------------------------------------- */
  const DIGIT_MAP = { '\u06f0':'0','\u06f1':'1','\u06f2':'2','\u06f3':'3','\u06f4':'4','\u06f5':'5','\u06f6':'6','\u06f7':'7','\u06f8':'8','\u06f9':'9',
                      '\u0660':'0','\u0661':'1','\u0662':'2','\u0663':'3','\u0664':'4','\u0665':'5','\u0666':'6','\u0667':'7','\u0668':'8','\u0669':'9' };
  function norm(s) {
    return String(s == null ? '' : s).toLowerCase()
      .replace(/[\u06f0-\u06f9\u0660-\u0669]/g, (d) => DIGIT_MAP[d])
      .replace(/[\u064a\u0649]/g, '\u06cc')      // ي / ى → ی
      .replace(/\u0643/g, '\u06a9')                // ك → ک
      .replace(/[\u0623\u0625\u0622\u0671]/g, '\u0627') // أ إ آ ٱ → ا
      .replace(/\u0629/g, '\u0647')                // ة → ه
      .replace(/[\u064b-\u0652\u0640]/g, '')      // اعراب و کشیده
      .replace(/[\u200c\u200d\u200e\u200f]/g, ' ') // کنترل های قدیمی را به فاصله معمولی تبدیل کن
      .replace(/[\u00a0\t\r\n]+/g, ' ')
      .replace(/\s{2,}/g, ' ')
      .trim();
  }
  /* کش متنِ نرمال شده هر مرحله (WeakMap → در JSON ذخیره نمی شود) */
  const HAY = new WeakMap();
  function invalidateHay(stepObj) { HAY.delete(stepObj); }

  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t._tm);
    t._tm = setTimeout(() => t.classList.remove('show'), 2600);
  }
  let activeInlineConfirm=null;
  function showInlineConfirm(message,yesLabel,hostOverride) {
    if(activeInlineConfirm)activeInlineConfirm(false);
    return new Promise(resolve=>{
      const panel=document.createElement('section');panel.className='inline-confirm';panel.setAttribute('role','group');
      panel.innerHTML='<div class="inline-confirm-message">'+esc(String(message||'')).replace(/\n/g,'<br>')+'</div><div class="inline-confirm-actions"><button type="button" class="btn" data-confirm-no>لغو</button><button type="button" class="btn pri" data-confirm-yes>'+(yesLabel||'تایید')+'</button></div>';
      const top=$('.topbar'),host=hostOverride&&hostOverride.isConnected?hostOverride:(top&&top.parentElement?top.parentElement:$('#app'));
      if(hostOverride&&hostOverride.isConnected){const anchor=hostOverride.classList.contains('nb')?$('.nb-head',hostOverride):null;if(anchor)anchor.insertAdjacentElement('afterend',panel);else host.prepend(panel);}
      else if(top&&top.parentElement)top.insertAdjacentElement('afterend',panel);else if(host)host.prepend(panel);else document.body.appendChild(panel);
      let done=false;
      const finish=value=>{if(done)return;done=true;panel.remove();if(activeInlineConfirm===finish)activeInlineConfirm=null;resolve(!!value);};
      activeInlineConfirm=finish;
      panel.addEventListener('click',e=>{if(e.target.closest('[data-confirm-yes]'))finish(true);else if(e.target.closest('[data-confirm-no]'))finish(false);});
      requestAnimationFrame(()=>{const r=panel.getBoundingClientRect();if(r.top<0||r.bottom>innerHeight)panel.scrollIntoView({block:'center',behavior:'smooth'});const cancel=panel.querySelector('[data-confirm-no]');if(cancel)try{cancel.focus({preventScroll:true});}catch(_){cancel.focus();}});
    });
  }

  /* ---------- ذخیره سازی (با fallback برای iframe سندباکس) -------------- */
  const store = (function () {
    let ok = true, mem = null;
    try {
      window.localStorage.setItem('__t', '1');
      window.localStorage.removeItem('__t');
    } catch (e) { ok = false; }
    return {
      get available() { return ok; },
      get() {
        try { return ok ? window.localStorage.getItem(STORE_KEY) : mem; } catch (e) { return mem; }
      },
      set(v) {
        if (ok) { try { window.localStorage.setItem(STORE_KEY, v); } catch (e) { ok = false; mem = v; } }
        else mem = v;
      },
      del() {
        if (ok) { try { window.localStorage.removeItem(STORE_KEY); } catch (e) { } }
        mem = null;
      }
    };
  })();

  /* ---------- فایل کناری پاسخ ها (answers-roadmap.json) ------------------
   * هدف: همه پاسخ ها (تیک ها، یادداشت ها و دفترچه) به صورت پیش فرض در فایل
   * «answers-roadmap.json» که کنار همین فایل HTML است ذخیره شود.
   *  · اگر مرورگر از File System Access API پشتیبانی کند (کروم/اج/اُپرا):
   *    یک بار فایل را انتخاب می کنی و از آن به بعد ذخیره خودکار در همان فایل است.
   *  · اگر فایل از طریق http(s) باز شده باشد، در شروع کار همان فایل خوانده
   *    می شود (بارگذاری خودکار پاسخ ها).
   *  · در غیر این صورت (یا در پیش نمایش داخل برنامه) ذخیره سازی روی
   *    localStorage انجام می شود و همه چیز بدون خطا کار می کند.
   * ------------------------------------------------------------------- */
  const SIDECAR = 'answers-roadmap.json';
  const APP_ID = 'packpolymer-marketplace-roadmap';

  const idb = (function () {
    let db = null;
    function open() {
      return new Promise((res) => {
        try {
          if (!window.indexedDB) return res(null);
          const rq = indexedDB.open('packpolymer-roadmap', 1);
          rq.onupgradeneeded = () => { try { rq.result.createObjectStore('kv'); } catch (e) { } };
          rq.onsuccess = () => res(rq.result);
          rq.onerror = () => res(null);
        } catch (e) { res(null); }
      });
    }
    return {
      async set(k, v) {
        const d = await open(); if (!d) return false;
        return new Promise((res) => {
          try {
            const tx = d.transaction('kv', 'readwrite'); tx.objectStore('kv').put(v, k);
            tx.oncomplete = () => res(true); tx.onerror = () => res(false);
          } catch (e) { res(false); }
        });
      },
      async get(k) {
        const d = await open(); if (!d) return null;
        return new Promise((res) => {
          try {
            const tx = d.transaction('kv', 'readonly'); const rq = tx.objectStore('kv').get(k);
            rq.onsuccess = () => res(rq.result || null); rq.onerror = () => res(null);
          } catch (e) { res(null); }
        });
      },
      async del(k) {
        const d = await open(); if (!d) return false;
        return new Promise((res) => {
          try {
            const tx = d.transaction('kv', 'readwrite'); tx.objectStore('kv').delete(k);
            tx.oncomplete = () => res(true); tx.onerror = () => res(false);
          } catch (e) { res(false); }
        });
      }
    };
  })();

  const ATTACHMENT_BLOB_PREFIX = 'roadmap-attachment:';
  const attachmentStore = {
    parentHandle: null,
    dirHandle: null,
    selectedKind: 'parent', // parent = folder containing HTML; directory = the attachments folder itself
    mode: 'none', // filesystem | permission | indexeddb
    index: new Set(), // IndexedDB fallback/legacy attachment names; migrated when a real folder is connected
    objectUrls: new Map(),
    pendingUrls: new Map(),
    userSelected: false,
    supported() { return !!(window.isSecureContext && typeof window.showDirectoryPicker === 'function'); },
    guidanceHtml(scope) {
      const button = scope === 'notebook' ? 'data-nb="attachment-connect"' : 'data-act="attachment-connect"';
      if (this.mode === 'filesystem' && this.dirHandle) return '';
      if (!this.supported() || this.mode === 'indexeddb') {
        return '<span class="attachment-guidance-icon" aria-hidden="true">ⓘ</span><span class="attachment-guidance-copy"><b>ذخیره پیوست در حافظه مرورگر</b><span>این مرورگر انتخاب پوشه را پشتیبانی نمی‌کند؛ پیوست‌ها در IndexedDB همین مرورگر ذخیره می‌شوند. برای انتقال، خروجی Markdown را به‌صورت ZIP دانلود کن.</span></span><button type="button" class="iact attachment-guidance-close" data-act="attachment-notice-close" title="بستن این پیام" aria-label="بستن پیام راهنمای پیوست">' + I('x') + '</button>';
      }
      return '<span class="attachment-guidance-icon" aria-hidden="true">ⓘ</span><span class="attachment-guidance-copy"><b>پیش از Paste یا افزودن پیوست</b><span>برای ذخیرهٔ واقعی، پوشهٔ حاوی HTML یا خود پوشهٔ attachments را انتخاب و اجازهٔ نوشتن بده. تا انتخاب پوشه، ارجاعی درج نمی‌شود.</span></span><button type="button" class="iact attachment-connect-button" ' + button + '>انتخاب پوشه attachments</button><button type="button" class="iact attachment-guidance-close" data-act="attachment-notice-close" title="بستن این پیام" aria-label="بستن پیام راهنمای پیوست">' + I('x') + '</button>';
    },
    updateGuidance(root) {
      const host = root && root.querySelectorAll ? root : document;
      const htmlByScope = new Map();
      host.querySelectorAll('[data-attachment-guidance]').forEach(node => {
        const scope = node.dataset.guidanceScope || 'main';
        if (!htmlByScope.has(scope)) htmlByScope.set(scope, this.guidanceHtml(scope));
        const html = htmlByScope.get(scope), signature = this.mode + '|' + (this.dirHandle ? 'connected' : 'disconnected') + '|' + (this.supported() ? 'supported' : 'fallback');
        node.dataset.guidanceMode = this.mode; node.dataset.guidanceSupported = this.supported() ? 'true' : 'false';
        node.hidden = !html || (typeof state !== 'undefined' && state.ui && !!state.ui.attachmentNoticeDismissed);
        if (node.dataset.guidanceSignature !== signature) {
          node.innerHTML = html;
          node.dataset.guidanceSignature = signature;
        }
      });
    },
    async init() {
      try {
        const index = await idb.get('attachmentIndex');
        if (Array.isArray(index)) this.index = new Set(index.filter(x => typeof x === 'string'));
        if (!this.supported()) { this.mode = 'indexeddb'; this.updateGuidance(); return; }
        const parent = await idb.get('attachmentParentHandle');
        const storedKind = await idb.get('attachmentHandleKind');
        if (!parent) { this.mode = 'permission'; this.updateGuidance(); return; }
        this.parentHandle = parent;
        this.selectedKind = storedKind === 'directory' || String(parent.name || '').toLowerCase() === 'attachments' ? 'directory' : 'parent';
        let permission = 'prompt';
        try { permission = await parent.queryPermission({ mode: 'readwrite' }); } catch (_) { }
        if (permission === 'granted') {
          try {
            this.dirHandle = this.selectedKind === 'directory' ? parent : await parent.getDirectoryHandle('attachments');
            this.mode = 'filesystem';
          } catch (_) { this.mode = 'permission'; }
        } else this.mode = 'permission';
      } catch (_) { this.mode = this.supported() ? 'permission' : 'indexeddb'; }
      this.updateGuidance();
    },
    async hasPermission() {
      if (!this.dirHandle) return false;
      const handle = this.parentHandle || this.dirHandle;
      if (!handle || typeof handle.queryPermission !== 'function') return true;
      try { return await handle.queryPermission({ mode: 'readwrite' }) === 'granted'; } catch (_) { return false; }
    },
    async connectFromUser() {
      if (!this.supported()) {
        this.mode = 'indexeddb'; this.updateGuidance();
        toast('این مرورگر انتخاب پوشه را پشتیبانی نمی‌کند؛ پیوست‌ها در IndexedDB همین مرورگر ذخیره می‌شوند.');
        return 'ready';
      }
      try {
        let parent = this.parentHandle;
        if (!parent) {
          parent = await window.showDirectoryPicker({ mode: 'readwrite', id: 'packpolymer-attachments', startIn: 'documents' });
        }
        const result = await this.connectParent(parent);
        const note = result.migrated.remaining ? '؛ ' + result.migrated.remaining + ' فایل قدیمی به‌دلیل خطا در IndexedDB حفظ شد' : '';
        toast((result.migrated.moved ? result.migrated.moved + ' پیوست قدیمی منتقل شد؛ ' : '') + 'پوشهٔ attachments آماده است' + note + '.');
        this.updateGuidance();
        this.resolve(document.body);
        return 'ready';
      } catch (error) {
        if (error && error.name === 'AbortError') { toast('انتخاب پوشه لغو شد؛ فایل یا ارجاعی درج نشد.'); return 'cancelled'; }
        this.mode = 'permission'; this.updateGuidance();
        toast('اتصال پوشه attachments ناموفق بود؛ فایل ذخیره یا درج نشد. پوشهٔ حاوی HTML یا خود attachments را انتخاب و اجازهٔ نوشتن را تایید کن.');
        return 'blocked';
      }
    },
    async ensureForToolbar() {
      if (this.mode === 'indexeddb' && !this.supported()) return 'ready';
      if (this.mode === 'filesystem' && this.dirHandle && await this.hasPermission()) return 'ready';
      return this.connectFromUser();
    },
    async ensureForPaste() {
      if (this.mode === 'indexeddb' && !this.supported()) return true;
      if (!this.supported()) { this.mode = 'indexeddb'; this.updateGuidance(); return true; }
      if (this.mode === 'filesystem' && this.dirHandle && await this.hasPermission()) return true;
      return (await this.connectFromUser()) === 'ready';
    },

    async migrateLegacyAttachments(dir) {
      const names = Array.from(this.index), remaining = [];
      let moved = 0;
      for (const name of names) {
        if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,150}$/.test(name)) continue;
        const key = ATTACHMENT_BLOB_PREFIX + name;
        let blob = null;
        try { blob = await idb.get(key); } catch (_) { remaining.push(name); continue; }
        if (blob == null) continue;
        if (!(blob instanceof Blob)) { remaining.push(name); continue; }
        try {
          const handle = await dir.getFileHandle(name, { create: true });
          const writable = await handle.createWritable();
          try { await writable.write(blob); await writable.close(); }
          catch (error) { try { await writable.abort(); } catch (_) { } throw error; }
          if (!await idb.del(key)) throw new Error('legacy blob cleanup failed');
          moved++;
        } catch (_) { remaining.push(name); }
      }
      this.index = new Set(remaining);
      if (remaining.length) await idb.set('attachmentIndex', remaining);
      else await idb.del('attachmentIndex');
      return { moved, remaining: remaining.length };
    },
    async connectParent(parent) {
      if (!parent || typeof parent.getDirectoryHandle !== 'function' && String(parent.name || '').toLowerCase() !== 'attachments') throw new Error('folder handle unavailable');
      let permission = 'granted';
      try { permission = await parent.queryPermission({ mode: 'readwrite' }); } catch (_) { permission = 'prompt'; }
      if (permission !== 'granted' && typeof parent.requestPermission === 'function') permission = await parent.requestPermission({ mode: 'readwrite' });
      if (permission !== 'granted') throw new Error('write permission was not granted');
      const selectedKind = String(parent.name || '').toLowerCase() === 'attachments' ? 'directory' : 'parent';
      const dir = selectedKind === 'directory' ? parent : await parent.getDirectoryHandle('attachments', { create: true });
      this.parentHandle = parent; this.dirHandle = dir; this.selectedKind = selectedKind; this.mode = 'filesystem'; this.userSelected = true;
      try { await idb.set('attachmentParentHandle', parent); await idb.set('attachmentHandleKind', selectedKind); } catch (_) { }
      const migrated = await this.migrateLegacyAttachments(dir);
      this.updateGuidance();
      return { dir, migrated, selectedKind };
    },
    fileName(file, mime) {
      const raw = String(file && file.name || '').replace(/\\/g, '/').split('/').pop() || '';
      let ext = (raw.match(/\.([a-z0-9]{1,12})$/i) || [,''])[1].toLowerCase();
      const byMime = { 'image/png':'png','image/jpeg':'jpg','image/gif':'gif','image/webp':'webp','image/avif':'avif','image/svg+xml':'svg','audio/mpeg':'mp3','audio/wav':'wav','audio/ogg':'ogg','audio/opus':'opus','video/mp4':'mp4','video/webm':'webm','video/quicktime':'mov' };
      if (!ext) ext = byMime[mime] || 'bin';
      let stem = raw.replace(/\.[^.]*$/, '').normalize ? raw.replace(/\.[^.]*$/, '').normalize('NFKD') : raw.replace(/\.[^.]*$/, '');
      stem = stem.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 34) || String(mime || 'file').split('/')[0] || 'file';
      const unique = Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
      return stem + '-' + unique + '.' + ext;
    },
    async save(file, mime) {
      const name = this.fileName(file, mime), path = 'attachments/' + name;
      if (this.mode === 'indexeddb' && !this.supported()) {
        const blob = file instanceof Blob ? file : new Blob([file], { type: mime || 'application/octet-stream' });
        if (!await idb.set(ATTACHMENT_BLOB_PREFIX + name, blob)) throw new Error('IndexedDB write failed');
        this.index.add(name);
        if (!await idb.set('attachmentIndex', Array.from(this.index))) {
          this.index.delete(name); await idb.del(ATTACHMENT_BLOB_PREFIX + name);
          throw new Error('attachment index write failed');
        }
        return path;
      }
      if (this.mode !== 'filesystem' || !this.dirHandle) throw new Error('attachments folder is not connected');
      try {
        const handle = await this.dirHandle.getFileHandle(name, { create: true });
        const writable = await handle.createWritable();
        try { await writable.write(file); await writable.close(); }
        catch (error) { try { await writable.abort(); } catch (_) { } throw error; }
        return path;
      } catch (error) {
        this.dirHandle = null; this.mode = 'permission'; this.updateGuidance();
        throw error;
      }
    },
    async blobFor(path) {
      const safe = mdAttachmentPath(path); if (!safe) return null;
      const name = safe.slice('attachments/'.length);
      if (this.dirHandle) {
        try { const handle = await this.dirHandle.getFileHandle(name); return await handle.getFile(); } catch (_) { }
      }
      // Read legacy and unsupported-browser fallback attachments; successful migration removes them safely.
      try { return await idb.get(ATTACHMENT_BLOB_PREFIX + name); } catch (_) { return null; }
    },

    async urlFor(path) {
      if (this.objectUrls.has(path)) return this.objectUrls.get(path);
      if (this.pendingUrls.has(path)) return this.pendingUrls.get(path);
      const pending = (async () => {
        const blob = await this.blobFor(path);
        if (!(blob instanceof Blob)) return null;
        const url = URL.createObjectURL(blob); this.objectUrls.set(path, url); return url;
      })();
      this.pendingUrls.set(path, pending);
      try { return await pending; } finally { this.pendingUrls.delete(path); }
    },
    resolve(root) {
      if (!root || !root.querySelectorAll) return;
      root.querySelectorAll('[data-attachment-path]').forEach(node => {
        const path = mdAttachmentPath(node.dataset.attachmentPath); if (!path || node.dataset.attachmentResolved === 'true') return;
        const current = node.tagName === 'A' ? node.getAttribute('href') : (node.querySelector('source') ? node.querySelector('source').getAttribute('src') : node.getAttribute('src'));
        if (current && current.startsWith('blob:')) { node.dataset.attachmentResolved = 'true'; return; }
        this.urlFor(path).then(url => {
          if (!url || !node.isConnected) return;
          if (node.tagName === 'A') node.href = url;
          else {
            const media = node.matches('audio,video') ? (node.querySelector('source') || node) : node;
            media.src = url;
            const mime = mdAttachmentMime(path); if (media.tagName === 'SOURCE' && mime) media.type = mime;
          }
          node.dataset.attachmentResolved = 'true';
        }).catch(() => { });
      });
    }
  };

  const fileStore = {
    handle: null,
    connected: false,
    status: 'idle',      // idle | connected | error | busy
    lastSaved: '',
    supported() { return typeof window.showOpenFilePicker === 'function'; },
    answerPayload() {
      return {
        app: APP_ID, kind: 'answers', version: 2,
        savedAt: new Date().toISOString(),
        appVersion: APP_VERSION,
        checks: state.checks, notes: state.notes, marks: state.marks,
        notebook: nbAllText(),
        nbNotes: state.nbNotes || [], nbFolders:state.nbFolders||[], nbTags:state.nbTags||[], nbCategories:state.nbCategories||[],
        nbBrowseMode:state.nbBrowseMode||'all',nbBrowseValue:state.nbBrowseValue||'',nbSort:state.nbSort||'updated',
        openNotes:state.openNotes||{},noteModes:state.noteModes||{},noteDirections:state.noteDirections||{},
        nbActiveId: state.nbActiveId || '',
        nbSecondaryId: state.nbSecondaryId || '',
        nbSplit: !!state.nbSplit,
        nbMode: state.nbMode || 'edit',
        nbSecondaryMode: state.nbSecondaryMode || 'edit',
        nbView: state.nbView || 'list',
        sidebarLayout: validSidebarLayout(state.ui.sidebarLayout),
        sidebarLeftWidth: clampSidebarWidth(state.ui.sidebarLeftWidth, 300),
        sidebarRightWidth: clampSidebarWidth(state.ui.sidebarRightWidth, 300),
        sidebarPairRatio: clampSidebarPairRatio(state.ui.sidebarPairRatio, .5),
        uiFontScale: clampScale(state.ui.fontScale, 1),
        nbFontScale: clampScale(state.nbFontScale, 1),
        nbWidthPct: clampNbWidth(state.nbWidthPct,75), nbSplitRatio: clampNbSplit(state.nbSplitRatio,.5),
        nbBodyRatio: clampNbBodyRatio(state.nbBodyRatio,.5), nbBodyRatioSecondary: clampNbBodyRatio(state.nbBodyRatioSecondary,.5),
        attachmentNoticeDismissed: !!state.ui.attachmentNoticeDismissed,
        customized: !!state.customized
      };
    },
    async connect() {
      if (!this.supported()) {
        toast('این مرورگر اتصال مستقیم فایل را پشتیبانی نمی کند؛ از «خروجی JSON» استفاده کن.');
        return false;
      }
      try {
        const [h] = await window.showOpenFilePicker({
          multiple: false, id: 'packpolymer-answers', startIn: 'documents',
          types: [{ description: 'فایل پاسخ های پک پلیمر (JSON)', accept: { 'application/json': ['.json'] } }]
        });
        if (!h) return false;
        this.handle = h; this.connected = true; this.status = 'connected';
        try { await idb.set('answersHandle', h); } catch (e) { }
        const data = await this.read();
        if (data) applyAnswers(data, true);
        await this.write();
        saveNow(); render();
        toast('فایل پاسخ ها متصل شد: ' + h.name + ' — از این پس ذخیره خودکار در همین فایل است.');
        return true;
      } catch (e) {
        if (e && e.name === 'AbortError') return false;
        this.status = 'error';
        toast('اتصال فایل ناموفق بود: ' + (e && e.message ? e.message : 'خطای نامشخص'));
        return false;
      }
    },
    async restoreFromIdb() {
      if (!this.supported()) return false;
      try {
        const h = await idb.get('answersHandle');
        if (!h) return false;
        let perm = 'granted';
        try { perm = await h.queryPermission({ mode: 'readwrite' }); } catch (e) { perm = 'prompt'; }
        if (perm !== 'granted') { this.handle = h; this.status = 'need-permission'; return false; }
        this.handle = h; this.connected = true; this.status = 'connected';
        const data = await this.read();
        if (data) applyAnswers(data, true);
        return true;
      } catch (e) { return false; }
    },
    async regrant() {
      try {
        if (!this.handle) return this.connect();
        const p = await this.handle.requestPermission({ mode: 'readwrite' });
        if (p === 'granted') { this.connected = true; this.status = 'connected'; const d = await this.read(); if (d) applyAnswers(d, true); saveNow(); render(); return true; }
      } catch (e) { }
      return this.connect();
    },
    async read() {
      if (!this.handle) return null;
      try {
        const f = await this.handle.getFile();
        const t = (await f.text()).replace(/^\uFEFF/, '').trim();
        if (!t) return null;
        const d = JSON.parse(t);
        return d && typeof d === 'object' ? (d.state && !d.checks ? d.state : d) : null;
      } catch (e) { return null; }
    },
    async write() {
      if (!this.handle || !this.connected) return false;
      try {
        this.status = 'busy';
        const w = await this.handle.createWritable();
        await w.write(JSON.stringify(this.answerPayload(), null, 2));
        await w.close();
        this.status = 'connected';
        this.lastSaved = new Date().toLocaleTimeString('fa-IR');
        const el = document.querySelector('[data-store-state]'); if (el) el.textContent = 'ذخیره شد · ' + this.lastSaved;
        return true;
      } catch (e) { this.status = 'error'; return false; }
    },
    async save() {
      if (!this.connected) return false;
      clearTimeout(this._t);
      this._t = setTimeout(() => { this.write().then(ok => { if (!ok) toast('ذخیره در فایل ناموفق بود (دسترسی فایل را بررسی کن).'); }); }, 700);
      return true;
    },
    async disconnect() {
      this.handle = null; this.connected = false; this.status = 'idle';
      await idb.del('answersHandle');
      saveNow(); render();
      toast('اتصال فایل قطع شد؛ از این پس ذخیره سازی در حافظه مرورگر است.');
    },
    async fetchSidecar() {
      if (location.protocol === 'file:') return null;   // fetch روی file:// مسدود است
      try {
        const r = await fetch(SIDECAR + '?t=' + Date.now(), { cache: 'no-store' });
        if (!r.ok) return null;
        const t = (await r.text()).replace(/^\uFEFF/, '').trim();
        if (!t) return null;
        const d = JSON.parse(t);
        return (d && typeof d === 'object') ? (d.state && !d.checks ? d.state : d) : null;
      } catch (e) { return null; }
    }
  };

  function answersEmpty(a) {
    if (!a) return true;
    const hasChecks = a.checks && Object.keys(a.checks).length > 0;
    const hasNotes = a.notes && Object.keys(a.notes).length > 0;
    const hasMarks = a.marks && ((a.marks.archived && Object.keys(a.marks.archived).length) || (a.marks.review && Object.keys(a.marks.review).length));
    const hasDirections = (a.noteDirections && Object.values(a.noteDirections).some(value => normalizeTextDirection(value) !== 'auto')) ||
      (Array.isArray(a.nbNotes) && a.nbNotes.some(note => note && normalizeTextDirection(note.direction) !== 'auto'));
    const hasNb = (a.notebook && String(a.notebook).trim().length > 0) ||
      (Array.isArray(a.nbNotes) && a.nbNotes.some(n => n && (String(n.body||'').trim()||String(n.title||'').trim()||n.category||(n.tags||[]).length||n.folderId||normalizeTextDirection(n.direction)!=='auto')));
    return !hasChecks && !hasNotes && !hasNb && !hasMarks && !hasDirections;
  }

  /* ---------- دفترچه چندیادداشتی: مدل داده --------------------------------
   * منبع اصلی: state.nbNotes = [{id,title,body,createdAt,updatedAt}]
   * state.nbActiveId آخرین یادداشت بازشده است تا با بازکردن دوباره دفترچه
   * دقیقاً همان یادداشت (Last Note) ادامه پیدا کند.
   * state.notebook فقط برای سازگاری با فرمت قدیمی/گزارش نگه داشته می شود.
   * --------------------------------------------------------------------- */
  function nbParseTags(value) {
    const raw=Array.isArray(value)?value:String(value||'').split(/[;,،]+/);
    const seen=new Set();
    return raw.map(x=>String(x||'').trim().replace(/^#+/,'').trim()).filter(x=>{
      const k=norm(x);if(!k||seen.has(k))return false;seen.add(k);return true;
    }).slice(0,32);
  }
  function nbNormalizeNote(n) {
    if (!n || typeof n !== 'object') return null;
    const now = new Date().toISOString();
    return {
      id: n.id || uid('nb'),
      title: typeof n.title === 'string' ? n.title : '',
      body: typeof n.body === 'string' ? n.body : '',
      folderId: typeof n.folderId==='string'?n.folderId:(typeof n.folder==='string'?n.folder:''),
      category: typeof n.category==='string'?n.category.trim():'',
      tags: nbParseTags(n.tags),
      direction: normalizeTextDirection(n.direction),
      createdAt: n.createdAt || now,
      updatedAt: n.updatedAt || n.createdAt || now
    };
  }
  function nbNormalizeFolders(list) {
    const seen=new Set();
    return (Array.isArray(list)?list:[]).map(f=>{
      if(typeof f==='string')f={name:f};
      if(!f||typeof f!=='object')return null;
      const name=String(f.name||'').trim().slice(0,60),key=norm(name);
      if(!name||seen.has(key))return null;seen.add(key);
      return{id:String(f.id||uid('folder')),name,createdAt:f.createdAt||new Date().toISOString()};
    }).filter(Boolean);
  }
  function nbNormalizeValues(list) {
    const seen=new Set();
    return (Array.isArray(list)?list:[]).map(v=>String(v==null?'':v).trim().replace(/^#+/,'').trim().slice(0,60)).filter(v=>{
      const key=norm(v);if(!key||seen.has(key))return false;seen.add(key);return true;
    });
  }
  function nbTitleFromBody(body) {
    const lines = String(body || '').split('\n').map(x => x.trim()).filter(Boolean);
    if (!lines.length) return 'یادداشت بدون عنوان';
    const h = lines[0].replace(/^#{1,6}\s*/, '').replace(/[*_`>]/g, '').trim();
    return (h || 'یادداشت بدون عنوان').slice(0, 60);
  }
  function nbAllText() {
    const list = (state.nbNotes || []).filter(n => n && (String(n.title || '').trim() || String(n.body || '').trim()));
    if (!list.length) return state.notebook && !(state.nbNotes && state.nbNotes.length) ? state.notebook : '';
    return list.map(n => '# ' + (String(n.title || '').trim() || nbTitleFromBody(n.body)) + '\n\n' + String(n.body || '').trim()).join('\n\n---\n\n');
  }
  let nbLegacyDirty = false;
  function nbSyncLegacy() { state.notebook = nbAllText(); nbLegacyDirty = false; }
  function nbMigrate() {
    if (!Array.isArray(state.nbNotes)) state.nbNotes = [];
    if (!Array.isArray(state.nbFolders)) state.nbFolders = [];
    if (!Array.isArray(state.nbTags)) state.nbTags = [];
    if (!Array.isArray(state.nbCategories)) state.nbCategories = [];
    state.nbWidthPct = clampNbWidth(state.nbWidthPct,75); state.nbSplitRatio = clampNbSplit(state.nbSplitRatio,.5);
    state.nbBodyRatio = clampNbBodyRatio(state.nbBodyRatio,.5); state.nbBodyRatioSecondary = clampNbBodyRatio(state.nbBodyRatioSecondary,.5);
    state.nbFolders=nbNormalizeFolders(state.nbFolders);
    state.nbNotes = state.nbNotes.map(nbNormalizeNote).filter(Boolean);
    state.nbTags=nbNormalizeValues(state.nbTags.concat(state.nbNotes.flatMap(n=>n.tags||[])));
    state.nbCategories=nbNormalizeValues(state.nbCategories.concat(state.nbNotes.map(n=>n.category||'')));
    const folderIds=new Set(state.nbFolders.map(f=>f.id));
    state.nbNotes.forEach(n=>{if(n.folderId&&!folderIds.has(n.folderId))n.folderId='';});
    state.nbBrowseMode=['all','folders','tags','categories'].includes(state.nbBrowseMode)?state.nbBrowseMode:'all';
    state.nbBrowseValue=String(state.nbBrowseValue||'');
    state.nbSort=['updated','created','title'].includes(state.nbSort)?state.nbSort:'updated';
    if(!state.noteModes||typeof state.noteModes!=='object')state.noteModes={};
    if(!state.noteDirections||typeof state.noteDirections!=='object')state.noteDirections={};
    Object.keys(state.noteDirections).forEach(key=>state.noteDirections[key]=normalizeTextDirection(state.noteDirections[key]));
    if(!state.openNotes||typeof state.openNotes!=='object')state.openNotes={};
    // مهاجرت از فرمت تک یادداشتی قدیمی
    if (!state.nbNotes.length && typeof state.notebook === 'string' && state.notebook.trim()) {
      const now = new Date().toISOString();
      state.nbNotes = [nbNormalizeNote({ id: uid('nb'), title: nbTitleFromBody(state.notebook), body: state.notebook, createdAt: now, updatedAt: now })];
    }
    if (state.nbNotes.length) {
      const ok = state.nbNotes.some(n => n.id === state.nbActiveId);
      if (!ok) {
        const sorted = state.nbNotes.slice().sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt)));
        state.nbActiveId = sorted[0].id;
      }
    } else state.nbActiveId = '';
    if (!state.nbNotes.some(n => n.id === state.nbSecondaryId) || state.nbSecondaryId === state.nbActiveId) {
      const other = state.nbNotes.find(n => n.id !== state.nbActiveId);
      state.nbSecondaryId = other ? other.id : '';
    }
    state.nbSplit = !!state.nbSplit && !!state.nbSecondaryId;
    state.nbMode = ['edit','read','both'].includes(state.nbMode) ? state.nbMode : 'edit';
    state.nbSecondaryMode = ['edit','read','both'].includes(state.nbSecondaryMode) ? state.nbSecondaryMode : 'edit';
    if (state.nbView !== 'note') state.nbView = 'list';
    if (state.nbView === 'note' && !state.nbActiveId) state.nbView = 'list';
    nbSyncLegacy();
  }
  function nbActive(side) {
    const id = side === 'secondary' ? state.nbSecondaryId : state.nbActiveId;
    return (state.nbNotes || []).find(n => n.id === id) || null;
  }
  function nbFolder(id) { return (state.nbFolders||[]).find(f=>f.id===id)||null; }
  function nbFolderName(note) { const f=note&&nbFolder(note.folderId);return f?f.name:''; }
  const NB_SEARCH_CACHE = new WeakMap();
  function nbSearchText(note) { return [note.title,note.body,note.category,nbFolderName(note),(note.tags||[]).join(' ')].join(' '); }
  function nbSearchNormalized(note) {
    const title=String(note.title||''),body=String(note.body||''),category=String(note.category||''),folder=nbFolderName(note),tags=(note.tags||[]).join(' '),cached=NB_SEARCH_CACHE.get(note);
    if(cached&&cached.title===title&&cached.body===body&&cached.category===category&&cached.folder===folder&&cached.tags===tags)return cached.normalized;
    const normalized=norm([title,body,category,folder,tags].join(' '));
    NB_SEARCH_CACHE.set(note,{title,body,category,folder,tags,normalized});
    return normalized;
  }
  function nbSorted(list) {
    const mode=state.nbSort||'updated';
    return (list || state.nbNotes || []).slice().sort((a,b)=>{
      if(mode==='title')return norm((a.title||'')||nbTitleFromBody(a.body)).localeCompare(norm((b.title||'')||nbTitleFromBody(b.body)));
      if(mode==='created')return String(b.createdAt||'').localeCompare(String(a.createdAt||''));
      return String(b.updatedAt||'').localeCompare(String(a.updatedAt||''));
    });
  }

  /* اعمال «پاسخ ها» روی وضعیت فعلی (بدون دست زدن به ساختار مراحل پیش فرض) */
  function applyAnswers(a, silent) {
    if (!a) return false;
    state.checks = a.checks || {};
    state.notes = a.notes || {};
    if(a.openNotes&&typeof a.openNotes==='object')state.openNotes=a.openNotes;
    if(a.noteModes&&typeof a.noteModes==='object')state.noteModes=a.noteModes;
    if(a.noteDirections&&typeof a.noteDirections==='object')state.noteDirections=Object.fromEntries(Object.entries(a.noteDirections).map(([key,value])=>[key,normalizeTextDirection(value)]));
    if(Array.isArray(a.nbFolders))state.nbFolders=nbNormalizeFolders(a.nbFolders);
    if(Array.isArray(a.nbTags))state.nbTags=nbNormalizeValues(a.nbTags);
    if(Array.isArray(a.nbCategories))state.nbCategories=nbNormalizeValues(a.nbCategories);
    if(a.nbBrowseMode)state.nbBrowseMode=a.nbBrowseMode;
    if(a.nbBrowseValue!=null)state.nbBrowseValue=String(a.nbBrowseValue);
    if(a.nbSort)state.nbSort=a.nbSort;
    if (a.marks) state.marks = { archived: a.marks.archived || {}, review: a.marks.review || {} };
    state.ui.sidebarLayout = validSidebarLayout(a.sidebarLayout);
    if (a.sidebarLeftWidth != null) state.ui.sidebarLeftWidth = clampSidebarWidth(a.sidebarLeftWidth, state.ui.sidebarLeftWidth);
    if (a.sidebarRightWidth != null) state.ui.sidebarRightWidth = clampSidebarWidth(a.sidebarRightWidth, state.ui.sidebarRightWidth);
    if (a.sidebarPairRatio != null) state.ui.sidebarPairRatio = clampSidebarPairRatio(a.sidebarPairRatio, state.ui.sidebarPairRatio);
    if (a.uiFontScale != null) state.ui.fontScale = clampScale(a.uiFontScale, state.ui.fontScale);
    if (a.attachmentNoticeDismissed != null) state.ui.attachmentNoticeDismissed = !!a.attachmentNoticeDismissed;
    if (a.nbFontScale != null) state.nbFontScale = clampScale(a.nbFontScale, state.nbFontScale);
    if (a.nbWidthPct != null) state.nbWidthPct = clampNbWidth(Number(a.nbWidthPct)===78?75:a.nbWidthPct,state.nbWidthPct);
    if (a.nbSplitRatio != null) state.nbSplitRatio = clampNbSplit(a.nbSplitRatio,state.nbSplitRatio);
    if (a.nbBodyRatio != null) state.nbBodyRatio = clampNbBodyRatio(a.nbBodyRatio,state.nbBodyRatio);
    if (a.nbBodyRatioSecondary != null) state.nbBodyRatioSecondary = clampNbBodyRatio(a.nbBodyRatioSecondary,state.nbBodyRatioSecondary);
    if (Array.isArray(a.nbNotes)) {
      state.nbNotes = a.nbNotes.map(nbNormalizeNote).filter(Boolean);
      state.nbActiveId = a.nbActiveId || '';
      state.nbSecondaryId = a.nbSecondaryId || '';
      state.nbSplit = !!a.nbSplit;
      state.nbMode = ['edit','read','both'].includes(a.nbMode) ? a.nbMode : 'edit';
      state.nbSecondaryMode = ['edit','read','both'].includes(a.nbSecondaryMode) ? a.nbSecondaryMode : 'edit';
      state.nbView = a.nbView || 'list';
      if (!state.nbNotes.length) { state.nbActiveId=''; state.nbSecondaryId=''; state.nbSplit=false; state.nbView='list'; }
      nbMigrate();
    } else if (typeof a.notebook === 'string') { state.notebook = a.notebook; nbMigrate(); }
    if (a.customized !== undefined) state.customized = !!a.customized;
    if (a.meta && a.meta.title && !state.customized) state.meta = Object.assign(state.meta, a.meta);
    if (a.savedAt) state.savedAt = a.savedAt;
    nbMigrate();
    if (!silent) { render(); if(nbEls)nbRender(); }
    return true;
  }

  /* ---------- نرمال سازی داده پیش فرض ----------------------------------- */
  function normalizePhase(p, pi) {
    const ph = {
      id: p.id || 'phase-' + pi,
      icon: p.icon || '📌',
      title: p.title || ('فاز ' + (pi + 1)),
      goal: p.goal || '',
      dod: p.dod || '',
      steps: (p.steps || []).map((s, si) => {
        const sid = s.id || ('s-' + pi + '-' + si);
        return {
          id: sid,
          title: s.title || ('مرحله ' + (si + 1)),
          meta: s.meta || '',
          tip: s.tip || '',
          stack: s.stack || '',
          subs: (s.subs || []).map((x, i) => {
            if (typeof x === 'string') return { id: sid + '-' + (i + 1), title: x };
            return { id: x.id || (sid + '-' + (i + 1)), title: x.title || '' };
          })
        };
      })
    };
    return ph;
  }

  const DEFAULT_PLAN = (function () {
    const src = (typeof PLAN_PARTS !== 'undefined' && Array.isArray(PLAN_PARTS)) ? PLAN_PARTS.flat() : [];
    return src.map(normalizePhase);
  })();

  /* ---------- وضعیت ---------------------------------------------------- */
  let state = {
    v: 1, contentVersion: CONTENT_VERSION,
    meta: { title: DEF_TITLE, sub: DEF_SUB },
    plan: clone(DEFAULT_PLAN),
    checks: {}, notes: {}, marks: { archived: {}, review: {} },
    notebook: '',      // (سازگاری قدیمی) متن تجمیعی دفترچه — منبع اصلی nbNotes است
    nbNotes: [],       // دفترچه چندیادداشتی: [{id,title,body,folderId,category,tags,createdAt,updatedAt}]
    nbFolders: [],     // فولدرهای اختصاصی دفترچه
    nbTags: [], nbCategories: [], // فهرست ویژگی ها مستقل از یادداشت ها
    nbBrowseMode:'all',nbBrowseValue:'',nbSort:'updated',nbCardEditorId:'',nbCardEditorType:'',
    nbActiveId: '',    // آخرین یادداشت بازشده (Last Note)
    nbSecondaryId: '', // یادداشت دوم برای Split View
    nbSplit: false,    // Split View خاموش است مگر کاربر روشن کند
    nbMode: 'edit',    // چرخه Edit/Read/خواندن و ویرایش یادداشت اصلی
    nbSecondaryMode: 'edit', // حالت مستقل یادداشت دوم در Split View
    nbView: 'list',    // نمای دفترچه: list | note
    nbQuery: '',
    nbFontScale: 1,
    nbWidthPct: 75, nbSplitRatio: .5, nbBodyRatio: .5, nbBodyRatioSecondary: .5,
    savedAt: '',
    open: {},          // فازهای باز
    openNotes: {},     // پنل یادداشت های باز
    noteModes:{},      // حالت مستقل Edit/Read یادداشت های Phase/Step/Sub-step
    noteDirections:{}, // جهت متن انتخابی برای یادداشت های Phase/Step/Sub-step
    ui: { q: '', filter: 'all', stack: '', editing: false, stale: false, nbOpen: false, nbPreview: true, reportMode: 'full', phaseNavOpen: true, sidebarLayout: 'dual-right', sidebarLeftWidth: 300, sidebarRightWidth: 300, sidebarPairRatio: .5, phaseDrawerOpen: false, phaseDrawerQuery: '', fontScale: 1, sideOpen: {}, sideStepOpen: {}, sideClosed: { dev: true }, markFilters: [], attachmentNoticeDismissed: false, menuDrawerOpen: false }
  };

  function load() {
    const raw = store.get();
    if (!raw) return;
    try {
      const d = JSON.parse(raw);
      if (!d || typeof d !== 'object') return;
      if (d.meta) state.meta = Object.assign(state.meta, d.meta);
      if (Array.isArray(d.plan) && d.plan.length) state.plan = d.plan.map(normalizePhase);
      state.checks = d.checks || {};
      state.notes = d.notes || {};
      if (d.marks) state.marks = { archived: d.marks.archived || {}, review: d.marks.review || {} };
      state.open = d.open || {};
      state.openNotes = d.openNotes || {};
      state.notebook = typeof d.notebook === 'string' ? d.notebook : '';
      if (Array.isArray(d.nbNotes)) state.nbNotes = d.nbNotes.map(nbNormalizeNote).filter(Boolean);
      if (Array.isArray(d.nbFolders)) state.nbFolders=nbNormalizeFolders(d.nbFolders);
      if (Array.isArray(d.nbTags)) state.nbTags=nbNormalizeValues(d.nbTags);
      if (Array.isArray(d.nbCategories)) state.nbCategories=nbNormalizeValues(d.nbCategories);
      state.nbBrowseMode=d.nbBrowseMode||'all';state.nbBrowseValue=d.nbBrowseValue||'';state.nbSort=d.nbSort||'updated';
      state.noteModes=d.noteModes||{};
      state.noteDirections=d.noteDirections&&typeof d.noteDirections==='object'?Object.fromEntries(Object.entries(d.noteDirections).map(([key,value])=>[key,normalizeTextDirection(value)])):{};
      state.nbActiveId = d.nbActiveId || '';
      state.nbSecondaryId = d.nbSecondaryId || '';
      state.nbSplit = !!d.nbSplit;
      state.nbMode = ['edit','read','both'].includes(d.nbMode) ? d.nbMode : 'edit';
      state.nbSecondaryMode = ['edit','read','both'].includes(d.nbSecondaryMode) ? d.nbSecondaryMode : 'edit';
      state.nbView = d.nbView || 'list';
      state.nbQuery = d.nbQuery || '';
      state.nbFontScale = clampScale(d.nbFontScale, 1);
      state.nbWidthPct = clampNbWidth(Number(d.nbWidthPct)===78?75:d.nbWidthPct,75); state.nbSplitRatio = clampNbSplit(d.nbSplitRatio,.5);
      state.nbBodyRatio = clampNbBodyRatio(d.nbBodyRatio,.5); state.nbBodyRatioSecondary = clampNbBodyRatio(d.nbBodyRatioSecondary,.5);
      state.ui.fontScale = clampScale(d.ui && d.ui.fontScale, 1);
      state.ui.sidebarLayout = validSidebarLayout(d.ui && d.ui.sidebarLayout);
      state.ui.phaseDrawerOpen = false;
      state.ui.menuDrawerOpen = false;
      state.savedAt = d.savedAt || '';
      state.ui.editing = false;
      if (d.ui) {
        state.ui.nbOpen = !!d.ui.nbOpen; state.ui.nbPreview = d.ui.nbPreview !== false; state.ui.reportMode = d.ui.reportMode || 'full';
        state.ui.phaseNavOpen = d.ui.phaseNavOpen !== false;
        state.ui.phaseNavScroll = Number(d.ui.phaseNavScroll) || 0;
        state.ui.sidebarLayout = validSidebarLayout(d.ui.sidebarLayout);
        state.ui.sidebarLeftWidth = clampSidebarWidth(d.ui.sidebarLeftWidth, state.ui.sidebarLeftWidth);
        state.ui.sidebarRightWidth = clampSidebarWidth(d.ui.sidebarRightWidth, state.ui.sidebarRightWidth);
        state.ui.sidebarPairRatio = clampSidebarPairRatio(d.ui.sidebarPairRatio, state.ui.sidebarPairRatio);
        state.ui.phaseDrawerQuery = typeof d.ui.phaseDrawerQuery === 'string' ? d.ui.phaseDrawerQuery : '';
        state.ui.fontScale = clampScale(d.ui.fontScale, 1);
        state.ui.sideOpen = d.ui.sideOpen || {};
        state.ui.sideStepOpen = d.ui.sideStepOpen || {};
        if (Array.isArray(d.ui.markFilters)) state.ui.markFilters = d.ui.markFilters.filter(x => x === 'archived' || x === 'review');
        state.ui.sideClosed = Object.assign({ dev: true }, d.ui.sideClosed || {});
        state.ui.attachmentNoticeDismissed = !!d.ui.attachmentNoticeDismissed;
      }
      nbMigrate();
      state.ui.stale = !!(d.contentVersion && d.contentVersion !== CONTENT_VERSION);
      // اگر محتوا به روز شده و کاربر ساختار را دست کاری نکرده، خودکار به روزرسانی کن
      if (state.ui.stale && !d.customized) {
        state.plan = clone(DEFAULT_PLAN);
        state.contentVersion = CONTENT_VERSION;
        state.ui.stale = false;
      }
    } catch (e) { /* داده خراب → پیش فرض */ }
  }

  let saveTimer = null;
  function saveNow() {
    // Keep the legacy aggregate in sync at persistence boundaries, not on every keystroke.
    if (nbLegacyDirty && Array.isArray(state.nbNotes)) nbSyncLegacy();
    state.contentVersion = CONTENT_VERSION;
    state.savedAt = new Date().toISOString();
    try {
      const storageWasAvailable = store.available;
      store.set(JSON.stringify(state));
      if (storageWasAvailable && !store.available && !fileStore.connected)
        toast('حافظه مرورگر پر شد؛ تغییرات فعلاً در این نشست می ماند. رسانه را کوچک کن یا خروجی JSON بگیر.');
    } catch (e) { }
    if (fileStore.connected) fileStore.save();   // ذخیره خودکار در answers-roadmap.json
  }
  function save(delay) { clearTimeout(saveTimer); saveTimer = setTimeout(saveNow, Number.isFinite(delay) ? Math.max(0, delay) : 280); }
  window.addEventListener('beforeunload', saveNow);
  window.addEventListener('scroll', updateHeaderCompact, { passive: true });

  /* ---------- شمارش ها -------------------------------------------------- */
  function stepDone(s) {
    if (!s.subs.length) return !!state.checks[s.id];
    return s.subs.every(x => !!state.checks[x.id]) && !!state.checks[s.id];
  }
  function stepPartial(s) {
    return s.subs.some(x => !!state.checks[x.id]) && !stepDone(s);
  }
  function hasNote(s, ph) {
    return !!(ph && state.notes['n:' + ph.id]) || !!state.notes['n:' + s.id] || s.subs.some(x => !!state.notes['n:' + x.id]);
  }
  function counts(phase) {
    let d = 0, t = 0, notes = 0;
    (phase ? [phase] : state.plan).forEach(ph => {
      if (state.notes['n:' + ph.id]) notes++;
      if (!ph.steps.length) { t++; if (state.checks[ph.id]) d++; }
      ph.steps.forEach(s => { 
        t++; if (state.checks[s.id]) d++;
        if (state.notes['n:' + s.id]) notes++;
        s.subs.forEach(x => {
          t++; if (state.checks[x.id]) d++;
          if (state.notes['n:' + x.id]) notes++;
        });
      });
    });
    return { d, t, notes, p: pct(d, t) };
  }
  function phaseDone(ph, c) {
    if (!ph) return false;
    if (!ph.steps.length) return !!state.checks[ph.id];
    const n = c || counts(ph);
    return n.t > 0 && n.d === n.t;
  }
  function phasePartial(ph, c) {
    if (!ph || !ph.steps.length) return false;
    const n = c || counts(ph);
    return n.d > 0 && n.d < n.t;
  }

  /* ---------- به روزرسانی سبک (بدون رندر کامل) ------------------------- */
  function refreshStep(sid, opts) {
    const f = findStep(sid); if (!f) return;
    const el = document.getElementById(sid);
    if (el) {
      const done = stepDone(f.s), part = stepPartial(f.s);
      el.classList.toggle('done', done);
      const cb = el.querySelector('.st-head input[data-ck]'); if (cb) cb.checked = done;
      const tag = el.querySelector('[data-subcount]');
      if (tag) tag.textContent = fa(f.s.subs.filter(x => state.checks[x.id]).length) + ' از ' + fa(f.s.subs.length) + ' زیرمرحله';
      const pt = el.querySelector('[data-partial]'); if (pt) pt.style.display = part ? '' : 'none';
      if (!opts || opts.subs !== false) {
        f.s.subs.forEach(x => {
          const li = document.getElementById(x.id);
          if (!li) return;
          li.classList.toggle('done', !!state.checks[x.id]);
          const c = li.querySelector('input[data-ck]');
          if (c) c.checked = !!state.checks[x.id];
        });
      }
    }
    if (!(opts && opts.skipPhaseStats)) refreshPhase(f.ph.id);
  }
  function refreshPhase(phId, skipGlobal) {
    const ph = findPhase(phId); if (!ph) return;
    const c = counts(ph);
    $$('[data-pbar="' + phId + '"]').forEach(e => e.style.width = c.p + '%');
    $$('[data-ppct="' + phId + '"]').forEach(e => e.innerHTML = fa(c.p) + '٪ <small>پیشرفت</small>');
    $$('[data-nav="' + phId + '"]').forEach(e => e.textContent = fa(c.d) + '/' + fa(c.t));
    const b = document.querySelector('[data-phbadge="' + phId + '"]');
    const done = phaseDone(ph, c), partial = phasePartial(ph, c);
    if (b) {
      b.className = 'ph-badge' + (done ? ' ok' : '');
      b.textContent = done ? 'کامل شد ✓' : fa(c.d) + '/' + fa(c.t);
    }
    const sect = document.getElementById(phId);
    if (sect) {
      sect.classList.toggle('done', done);
      const phaseBox = sect.querySelector('.ph-ck input[data-ck]');
      if (phaseBox) {
        phaseBox.checked = done;
        phaseBox.indeterminate = partial;
      }
    }
    if (!skipGlobal) updateStats();
  }

  /* ---------- نشان ها: آرشیو و نیازمند بررسی ------------------------------
   * state.marks = { archived: {entityId: true}, review: {entityId: true} }
   * entityId می تواند شناسه فاز، مرحله یا زیرمرحله باشد.
   * آرشیو شده ها در نمای اصلی دیده نمی شوند؛ با فیلتر «آرشیو» برمی گردند.
   * نیازمند بررسی در صفحه اصلی می ماند و فقط با نشان مشخص می شود.
   * --------------------------------------------------------------------- */
  function isArchived(id) { return !!(state.marks && state.marks.archived && state.marks.archived[id]); }
  function needsReview(id) { return !!(state.marks && state.marks.review && state.marks.review[id]); }
  function markFiltersOn() { return Array.isArray(state.ui.markFilters) && state.ui.markFilters.length > 0; }
  function archivedFilterOn() { return Array.isArray(state.ui.markFilters) && state.ui.markFilters.indexOf('archived') !== -1; }
  function entityHasFilterMark(ph, s, x) {
    if (!markFiltersOn()) return true;
    return state.ui.markFilters.some(kind => {
      const bag = state.marks && state.marks[kind];
      if (!bag) return false;
      return !!(bag[ph.id] || (s && bag[s.id]) || (x && bag[x.id]) || (s && !x && s.subs.some(z => bag[z.id])));
    });
  }
  function stepArchivedHidden(ph, s) {
    if (state.ui.editing) return false;
    if (!isArchived(ph.id) && !isArchived(s.id)) return false;
    return !archivedFilterOn();
  }
  function subArchivedHidden(ph, s, x) {
    if (state.ui.editing) return false;
    if (!isArchived(ph.id) && !isArchived(s.id) && !isArchived(x.id)) return false;
    return !archivedFilterOn();
  }
  function subShown(ph, s, x) {
    if (state.ui.editing) return true;
    if (subArchivedHidden(ph, s, x)) return false;
    if (!markFiltersOn()) return true;
    return entityHasFilterMark(ph, s, x);
  }
  function markCount(kind) {
    const bag = (state.marks && state.marks[kind]) || {};
    let n = 0;
    state.plan.forEach(ph => {
      if (bag[ph.id]) n++;
      ph.steps.forEach(s => { if (bag[s.id]) n++; s.subs.forEach(x => { if (bag[x.id]) n++; }); });
    });
    return n;
  }
  function markBadges(id) {
    let h = '';
    if (needsReview(id)) h += '<span class="tag review-tag" title="در فهرست نیازمند بررسی است">' + I('flag') + ' نیازمند بررسی</span>';
    if (isArchived(id)) h += '<span class="tag arch-tag" title="آرشیو شده است">' + I('archive') + ' آرشیو شده</span>';
    return h;
  }
  function entityBtn(etype, eid) {
    return '<button class="iact ent-btn" data-act="entity-menu" data-etype="' + etype + '" data-eid="' + esc(eid) + '" title="منوی عملیات: آرشیو، نیازمند بررسی، اشتراک و دفترچه" aria-label="باز کردن منوی عملیات">' + I('more') + '</button>';
  }
  function findEntity(etype, eid) {
    if (etype === 'phase') { const ph = findPhase(eid); return ph ? { type: 'phase', ph: ph, label: phaseNumLabel(ph) + ' — ' + stripPhasePrefix(ph.title) } : null; }
    if (etype === 'step') { const f = findStep(eid); return f ? { type: 'step', ph: f.ph, s: f.s, label: stepNumLabel(f.ph, f.ph.steps.indexOf(f.s)) + ' — ' + stripStepPrefix(f.s.title) } : null; }
    if (etype === 'sub') {
      const f = findStepOfSub(eid);
      if (!f) return null;
      const x = f.s.subs.filter(z => z.id === eid)[0];
      return x ? { type: 'sub', ph: f.ph, s: f.s, x: x, label: subNumLabel(f.ph, f.ph.steps.indexOf(f.s), f.s.subs.indexOf(x)) + ' — ' + x.title } : null;
    }
    // تشخیص خودکار بر اساس شناسه
    return findEntity('phase', eid) || findEntity('step', eid) || findEntity('sub', eid);
  }

  /* ---------- جست وجو و فیلتر ------------------------------------------- */
  function hayOf(ph, s) {
    const si = ph.steps.indexOf(s);
    const sig = ph.id + ':' + si + ':' + state.plan.indexOf(ph);
    let h = HAY.get(s);
    if (h == null || h.phId !== sig) {
      const parts = [phaseNumLabel(ph), stripPhasePrefix(ph.title), ph.goal, stepNumLabel(ph, si), stripStepPrefix(s.title), s.meta, s.tip, s.stack || ''];
      s.subs.forEach((x, i) => { parts.push(subNumLabel(ph, si, i)); parts.push(x.title); });
      h = norm(parts.join(' \u00b6 '));
      HAY.set(s, { phId: sig, t: h });
      return h;
    }
    return h.t;
  }
  function hitObj(ph, s) {
    const q = norm(state.ui.q);
    if (!q) return true;
    return hayOf(ph, s).indexOf(q) !== -1;
  }
  function hitStack(ph, s) {
    const st = norm(state.ui.stack);
    if (!st) return true;
    return hayOf(ph, s).indexOf(st) !== -1;
  }
  function visible(s, ph) {
    const f = state.ui.filter;
    if (f === 'todo') return !stepDone(s);
    if (f === 'done') return stepDone(s);
    if (f === 'notes') return hasNote(s, ph);
    return true;
  }
  function matchesAll(ph, s) {
    if (stepArchivedHidden(ph, s)) return false;
    if (markFiltersOn() && !entityHasFilterMark(ph, s, null)) return false;
    return visible(s, ph) && hitObj(ph, s) && hitStack(ph, s);
  }
  function isFiltering() { return !!state.ui.q.trim() || state.ui.filter !== 'all' || !!state.ui.stack || markFiltersOn(); }
  function stackCount(st) {
    let n = 0;
    const t = norm(st);
    state.plan.forEach(ph => ph.steps.forEach(s => { if (hayOf(ph, s).indexOf(t) !== -1) n++; }));
    return n;
  }

  /* ---------- هایلایت استک فعال + شماره گذاری خودکار ----------------------
   * وقتی فیلتر استک فعال است، خودِ کلمه استک در عنوان/نکته/زیرمرحله ها با
   * <mark class="hl-stack"> برجسته می شود تا کاربر دلیل نمایش هر مرحله را ببیند.
   * شماره فاز/مرحله/زیرمرحله «محاسباتی» است (از روی جایگاه فعلی در آرایه)؛
   * پس با افزودن، حذف یا جابه جایی، همه شماره ها خودکار اصلاح می شوند و
   * هیچ شماره ای داخل متن عنوان به صورت دستی ذخیره نمی شود.
   * --------------------------------------------------------------------- */
  function hiStack(text) {
    const raw = String(text == null ? '' : text);
    const term = String(state.ui.stack || '').trim();
    if (!term || state.ui.editing) return esc(raw);
    const low = raw.toLowerCase(), tl = term.toLowerCase();
    let out = '', i = 0, j = low.indexOf(tl);
    if (j === -1) return esc(raw);
    while (j !== -1) {
      out += esc(raw.slice(i, j)) + '<mark class="hl-stack">' + esc(raw.slice(j, j + term.length)) + '</mark>';
      i = j + term.length; j = low.indexOf(tl, i);
    }
    return out + esc(raw.slice(i));
  }
  function isAppendixPhase(ph) {
    return !!ph && (ph.id === 'ap' || /^\s*پیوست/.test(String(ph.title || '')));
  }
  function phaseOrdinal(ph) {
    let n = 0;
    for (const p of state.plan) {
      if (isAppendixPhase(p)) continue;
      n++;
      if (p.id === ph.id) return n;
    }
    return null;
  }
  function phaseNumLabel(ph) {
    if (isAppendixPhase(ph)) return 'پیوست';
    const n = phaseOrdinal(ph);
    return 'فاز ' + fa(n == null ? 0 : n);
  }
  function stripPhasePrefix(title) {
    return String(title || '').replace(/^\s*فاز\s*[۰-۹0-9]+\s*[—\-–:]\s*/, '').replace(/^\s*پیوست ها\s*[—\-–:]\s*/, '');
  }
  function stripStepPrefix(title) {
    return String(title || '').replace(/^\s*(پیوست|مرحله|گام)\s*[۰-۹0-9]+\s*[—\-–:]\s*/, '');
  }
  function stepNumLabel(ph, si) {
    if (isAppendixPhase(ph)) return fa(si + 1);
    const n = phaseOrdinal(ph);
    return fa(n == null ? 0 : n) + '.' + fa(si + 1);
  }
  function subNumLabel(ph, si, i) {
    if (isAppendixPhase(ph)) return fa(i + 1);
    const n = phaseOrdinal(ph);
    return fa(n == null ? 0 : n) + '.' + fa(si + 1) + '.' + fa(i + 1);
  }


  /* ---------- منوی عملیات هر مورد و ناوبری مطمئن -------------------------
   * برای شلوغ نشدن صفحه، هر فاز و مرحله و زیرمرحله فقط یک دکمه کوچک «...»
   * دارد و چهار عمل در یک منوی شناور باز می شود:
   * آرشیو | نیازمند بررسی | اشتراک با URL | اضافه کردن به دفترچه
   * --------------------------------------------------------------------- */
  let entCtx = null;
  let entityMenuEl = null;
  function entMenuMount() {
    if (entityMenuEl) return;
    const d = document.createElement('div');
    d.id = 'entityMenu';
    d.className = 'entity-menu';
    d.hidden = true;
    document.body.appendChild(d);
    entityMenuEl = d;
    d.addEventListener('click', (e) => {
      const b = e.target.closest('[data-entact]'); if (!b || !entCtx) return;
      const act = b.dataset.entact, ctx = entCtx;
      closeEntityMenu();
      if (act === 'archive') toggleEntityMark('archived', ctx);
      else if (act === 'review') toggleEntityMark('review', ctx);
      else if (act === 'share') shareEntity(ctx);
      else if (act === 'notebook') addEntityToNotebook(ctx);
    });
    document.addEventListener('click', (e) => {
      if (entityMenuEl && !entityMenuEl.hidden && !e.target.closest('#entityMenu') && !e.target.closest('[data-act="entity-menu"]')) closeEntityMenu();
    });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeEntityMenu(); });
    window.addEventListener('resize', closeEntityMenu);
  }
  function closeEntityMenu() { if (entityMenuEl) entityMenuEl.hidden = true; entCtx = null; }
  function openEntityMenu(btn, etype, eid) {
    entMenuMount();
    const ent = findEntity(etype, eid);
    if (!ent) { toast('این مورد پیدا نشد.'); return; }
    entCtx = { type: etype, id: eid };
    const arch = isArchived(eid), rev = needsReview(eid);
    entityMenuEl.innerHTML =
      '<div class="em-head"><b>' + esc(ent.label) + '</b><span>' + (etype === 'phase' ? 'فاز' : (etype === 'step' ? 'مرحله' : 'زیرمرحله')) + '</span></div>' +
      '<button data-entact="archive">' + I('archive') + (arch ? ' خروج از آرشیو' : ' آرشیو') + (arch ? '<b>فعال است</b>' : '') + '</button>' +
      '<button data-entact="review">' + I('flag') + (rev ? ' حذف از نیازمند بررسی' : ' نیازمند بررسی') + (rev ? '<b>فعال است</b>' : '') + '</button>' +
      '<button data-entact="share">' + I('share') + ' اشتراک با URL</button>' +
      '<button data-entact="notebook">' + I('note') + ' اضافه کردن به دفترچه</button>';
    entityMenuEl.hidden = false;
    const r = btn.getBoundingClientRect();
    const w = 264;
    let left = r.right - w;
    if (left < 8) left = 8;
    if (left + w > window.innerWidth - 8) left = window.innerWidth - w - 8;
    let top = r.bottom + 6;
    if (top + 250 > window.innerHeight) top = Math.max(8, r.top - 256);
    entityMenuEl.style.left = left + 'px';
    entityMenuEl.style.top = top + 'px';
  }
  function toggleEntityMark(kind, ctx) {
    if (!state.marks) state.marks = { archived: {}, review: {} };
    if (!state.marks[kind]) state.marks[kind] = {};
    const on = !!state.marks[kind][ctx.id];
    if (on) delete state.marks[kind][ctx.id]; else state.marks[kind][ctx.id] = true;
    saveNow(); render();
    if (kind === 'archived') toast(on ? 'از آرشیو خارج شد و در صفحه اصلی دیده می شود.' : 'آرشیو شد؛ با فیلتر «آرشیو» در هدر یا سایدبار دوباره دیده می شود.');
    else toast(on ? 'از فهرست نیازمند بررسی حذف شد.' : 'به فهرست نیازمند بررسی اضافه شد.');
  }
  function entityShareUrl(ctx) {
    const base = String(location.href || '').split('#')[0];
    return base + '#item=' + encodeURIComponent(ctx.type + ':' + ctx.id);
  }
  function shareEntity(ctx) {
    const ent = findEntity(ctx.type, ctx.id); if (!ent) return;
    const url = entityShareUrl(ctx);
    try { history.replaceState(null, '', '#item=' + encodeURIComponent(ctx.type + ':' + ctx.id)); } catch (e) { }
    const title = ent.label;
    const done = () => toast('لینک اشتراک کپی شد: ' + url);
    const copyIt = () => {
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(url).then(done, () => fallbackCopy(url, done));
      else fallbackCopy(url, done);
    };
    try {
      if (navigator.share) {
        navigator.share({ title: title, text: title, url: url }).then(() => toast('اشتراک گذاری انجام شد.'), (e) => { if (!e || e.name !== 'AbortError') copyIt(); });
        return;
      }
    } catch (e) { }
    copyIt();
  }
  function addEntityToNotebook(ctx) {
    const ent = findEntity(ctx.type, ctx.id); if (!ent) return;
    nbMigrate();
    const lines = [];
    let title = ent.label;
    if (ent.type === 'phase') {
      lines.push('# ' + ent.label, '');
      if (ent.ph.goal) lines.push('> ' + ent.ph.goal, '');
      if (ent.ph.dod) lines.push('**شرط اتمام فاز:** ' + ent.ph.dod, '');
      ent.ph.steps.forEach((s, si) => {
        lines.push('## ' + stepNumLabel(ent.ph, si) + ' — ' + stripStepPrefix(s.title));
        s.subs.forEach((x, i) => lines.push('- [' + (state.checks[x.id] ? 'x' : ' ') + '] ' + subNumLabel(ent.ph, si, i) + ' ' + x.title));
        lines.push('');
      });
    } else if (ent.type === 'step') {
      const s = ent.s, si = ent.ph.steps.indexOf(s);
      lines.push('# ' + ent.label, '', '**فاز:** ' + phaseNumLabel(ent.ph) + ' — ' + stripPhasePrefix(ent.ph.title));
      if (s.meta) lines.push('**مشخصات:** ' + s.meta);
      if (s.stack) lines.push('**استک:** ' + s.stack);
      if (s.tip) lines.push('', '> نکته: ' + s.tip);
      lines.push('', '## زیرمرحله ها');
      s.subs.forEach((x, i) => lines.push('- [' + (state.checks[x.id] ? 'x' : ' ') + '] ' + subNumLabel(ent.ph, si, i) + ' ' + x.title));
      const n = state.notes['n:' + s.id];
      if (n) lines.push('', '## یادداشت فعلی مرحله', n);
    } else {
      const s = ent.s, x = ent.x, si = ent.ph.steps.indexOf(s);
      lines.push('# ' + ent.label, '', '**فاز:** ' + phaseNumLabel(ent.ph) + ' — ' + stripPhasePrefix(ent.ph.title));
      lines.push('**مرحله:** ' + stepNumLabel(ent.ph, si) + ' — ' + stripStepPrefix(s.title));
      lines.push('**وضعیت:** ' + (state.checks[x.id] ? 'انجام شده' : 'باقی مانده'));
      const n = state.notes['n:' + x.id];
      if (n) lines.push('', '## یادداشت فعلی زیرمرحله', n);
    }
    lines.push('', '---', 'لینک این مورد: ' + entityShareUrl(ctx));
    const now = new Date().toISOString();
    const note = { id: uid('nb'), title: title.slice(0, 80), body: lines.join('\n'), createdAt: now, updatedAt: now };
    state.nbNotes.push(note);
    state.nbActiveId = note.id;
    state.nbView = 'note';
    state.nbMode = 'edit';
    nbSyncLegacy(); saveNow();
    if (!state.ui.nbOpen) nbToggle(true); else nbRender();
    toast('به دفترچه اضافه شد و به صورت یک نوشته جدید باز شد.');
  }

  /* ناوبری مطمئن سایدبار و لینک مستقیم: حتی بعد از چند جستجو و فیلتر،
   * اگر مورد با فیلتر فعلی پنهان باشد فیلتر ها پاک می شوند و مورد باز می شود. */
  function scrollToId(id, waitForLayout) {
    let highlighted = null;
    const doScroll = () => {
      const el = document.getElementById(id);
      if (!el) return false;
      const ph = el.closest ? el.closest('.phase') : null;
      if (ph) ph.classList.add('open');
      const r = el.getBoundingClientRect();
      const offset = el.classList.contains('phase') ? 106 : (el.classList.contains('step') ? 128 : 150);
      const target = Math.max(0, window.scrollY + r.top - offset);
      // jump is deliberate for long pages: a very long smooth animation looked like a failed nav
      const root = document.documentElement, old = root.style.scrollBehavior;
      root.style.scrollBehavior = 'auto';
      try { window.scrollTo(0, target); } catch (e) { try { el.scrollIntoView({ behavior: 'instant', block: 'start' }); } catch (_) { if (el.scrollIntoView) el.scrollIntoView(); } }
      root.style.scrollBehavior = old;
      if (highlighted !== el) {
        if (highlighted) highlighted.classList.remove('hit');
        highlighted = el; el.classList.add('hit');
        setTimeout(() => { if (highlighted === el) el.classList.remove('hit'); }, 1800);
      }
      // اگر هنوز هدف دقیقا در جای درست نیست (جابه جایی دیرهنگام لایه اوت)، تلاش مجدد می شود
      const r2 = el.getBoundingClientRect();
      return Math.abs(r2.top - offset) <= 40;
    };
    if (waitForLayout) {
      [0, 90, 260, 620, 1100].forEach(delay => setTimeout(() => requestAnimationFrame(doScroll), delay));
    } else if (!doScroll()) { setTimeout(doScroll, 80); setTimeout(doScroll, 260); setTimeout(doScroll, 620); }
    else { requestAnimationFrame(() => requestAnimationFrame(doScroll)); }
  }
  function navigateToEntity(etype, eid, waitForLayout) {
    const ent = findEntity(etype, eid);
    if (!ent) { toast('این مورد در نقشه راه پیدا نشد.'); return false; }
    const targetId = eid;
    const arch = isArchived(ent.ph.id) || (ent.s && isArchived(ent.s.id)) || (ent.x && isArchived(ent.x.id));
    // پاک کردن فیلتر هایی که مورد را پنهان می کنند
    state.ui.q = '';
    state.ui.filter = 'all';
    state.ui.stack = '';
    state.ui.markFilters = arch ? ['archived'] : [];
    state.open[ent.ph.id] = true;
    if (!state.ui.sideOpen) state.ui.sideOpen = {};
    state.ui.sideOpen[ent.ph.id] = true;
    save(); render();
    scrollToId(targetId, !!waitForLayout);
    return true;
  }
  function handleDeepLink() {
    const raw = String(location.hash || '').replace(/^#/, '');
    if (!raw) return;
    let m = null;
    try { m = decodeURIComponent(raw).match(/item=(phase|step|sub):(.+)$/); } catch (e) { }
    if (m) { navigateToEntity(m[1], m[2], true); return; }
    if (document.getElementById(raw)) navigateToEntity('auto', raw, true);
  }


  /* ---------- رندر ------------------------------------------------------ */
  const ED = () => state.ui.editing ? 'contenteditable="true" spellcheck="false" dir="auto"' : '';

  function renderEditableDirectionLines(value, forceMarkdownBlocks) {
    const lines = String(value == null ? '' : value).replace(/\r\n?/g,'\n').split('\n');
    let inFence=false, fenceMarker='';
    return lines.map(line => {
      const fence=line.match(/^\s*(```|~~~)/);
      let forceLtr=inFence||!!fence;
      if(fence){if(inFence&&fence[1]===fenceMarker){forceLtr=true;inFence=false;fenceMarker='';}else if(!inFence){inFence=true;fenceMarker=fence[1];}}
      const dir=markdownLineDirection(line,forceLtr);
      return '<span class="md-line edit-md-line" dir="'+dir+'">'+esc(line)+'</span>';
    }).join('<br>');
  }
  function renderInlineText(text, allowBlockCode) {
    const value = String(text == null ? '' : text);
    if (state.ui.editing) return renderEditableDirectionLines(value, allowBlockCode);
    if (allowBlockCode && /(?:^|\n)\s*(```|~~~)/.test(value)) return mdToHtml(value);
    return value.split(/\r?\n/).map(line => '<span class="md-line" dir="'+markdownLineDirection(line)+'">'+mdInline(line)+'</span>').join('<br>');
  }
  function renderBlockText(text) {
    if (state.ui.editing) return renderEditableDirectionLines(text, true);
    return mdToHtml(String(text == null ? '' : text));
  }

  function metaTags(meta) {
    if (!meta) return '';
    const parts = String(meta).split('·').map(x => x.trim()).filter(Boolean);
    return parts.map((p, i) => '<span class="tag ' + (i === 0 ? 'time' : 'owner') + '">' + esc(p) + '</span>').join('');
  }

  function insertPositionControl(kind, max) {
    const labels = { phase:'فاز', step:'مرحله', sub:'زیرمرحله' };
    const label = labels[kind] || 'مورد';
    return '<label class="insert-position" title="شماره محل درج از ۱ تا ' + fa(max) + '؛ خالی یعنی افزودن عادی">' +
      '<span>محل درج</span><input type="text" inputmode="numeric" pattern="[0-9۰-۹٠-٩]*" maxlength="6" data-insert-position="' + kind + '" aria-label="محل درج ' + label + '" placeholder="خالی" autocomplete="off" autocapitalize="off"></label>';
  }

  function notePanel(key, value, ph, small, entityKind) {
    const noteKey='n:'+key,open=!!state.openNotes[noteKey],mode=state.noteModes[noteKey]==='read'?'read':'edit',direction=normalizeTextDirection(state.noteDirections[noteKey]);
    const label=small?'زیرمرحله':entityKind==='phase'?'فاز':'مرحله';
    const preview=open&&mode==='read'?mdToHtml(value||'',direction):'';
    return '<div class="note-wrap things-note ' + (small ? 'subnote ' : '') + (entityKind==='phase'?'phase-note ':'') + (open ? 'show' : '') + '" data-note-wrap="' + esc(noteKey) + '">' +
      '<div class="note-head"><span class="note-heading">' + (small ? 'یادداشت این زیرمرحله' : 'یادداشت این ' + label) + '</span>' +
      '<span class="cnt">' + (value ? 'ذخیره شد ✍️' : 'خالی') + '</span><span class="note-head-actions">' +
      '<button type="button" class="iact tiny note-mode-btn" data-act="note-mode" data-key="' + esc(noteKey) + '" aria-pressed="' + (mode==='read'?'true':'false') + '" title="سوییچ Edit/Read Mode">' + (mode==='read'?'✎ ویرایش':'◉ خواندن') + '</button>' +
      '<button type="button" class="iact tiny note-direction-btn" data-act="note-direction" data-key="' + esc(noteKey) + '" data-direction-mode="' + direction + '" aria-pressed="' + (direction==='auto'?'false':'true') + '" title="' + esc(textDirectionTitle(direction)) + '" aria-label="' + esc(textDirectionTitle(direction)) + '">' + I('direction') + '<span data-direction-label>' + (direction==='auto'?'AUTO':direction.toUpperCase()) + '</span></button>' +
      '<button type="button" class="iact tiny note-media-btn" data-act="note-media" data-key="' + esc(noteKey) + '" title="افزودن فایل پیوست" aria-label="افزودن فایل پیوست" ' + (mode==='read'?'hidden':'') + '>' + I('paperclip') + '</button>' +
      '<button type="button" class="iact tiny note-copy-btn" data-act="note-copy" data-key="' + esc(noteKey) + '" title="کپی یادداشت" ' + (!String(value||'').trim()?'disabled':'') + '>' + I('copy') + '</button>' +
      '</span></div>' +
      '<div class="attachment-guidance" data-attachment-guidance data-guidance-scope="main" role="status" aria-live="polite" hidden></div>' +
      '<textarea ' + textDirectionAttrs(direction) + ' class="note note-editor ' + (value ? 'has' : '') + '" data-note="' + esc(noteKey) + '" ' + (mode==='read'?'hidden':'') + ' placeholder="' +
      (small ? 'Markdown بنویس: **مهم**، `کد`، # عنوان…' : entityKind==='phase'?'Markdown بنویس: هدف ها، تصمیم ها و نکته های این فاز…':'Markdown بنویس: تصمیم ها، لینک ها، `کد` و نکته های اجرایی…') + '">' + esc(value || '') + '</textarea>' +
      '<div class="note-read md things-markdown" ' + textDirectionAttrs(direction) + ' data-note-preview="' + esc(noteKey) + '" ' + (mode!=='read'?'hidden':'') + '>' + preview + '</div>' +
      '</div>';
  }

  function subHTML(ph, s, x, i, si) {
    const done = !!state.checks[x.id];
    const nk = 'n:' + x.id;
    const nv = state.notes[nk] || '';
    const noteUi = state.openNotes[nk] ? notePanel(x.id,nv,ph,true) : '<div class="note-wrap things-note subnote" data-note-wrap="' + esc(nk) + '" data-note-lazy="true"></div>';
    const stepIdx = (typeof si === 'number') ? si : ph.steps.indexOf(s);
    return '<li class="sub ' + (done ? 'done' : '') + (isArchived(x.id) ? ' is-archived' : '') + (needsReview(x.id) ? ' needs-review' : '') + '" id="' + esc(x.id) + '">' +
      '<div class="sub-row">' +
      '<label class="ck sm"><input type="checkbox" data-ck="' + esc(x.id) + '" ' + (done ? 'checked' : '') + '><span class="box"></span></label>' +
      '<span class="sub-num" title="شماره خودکار زیرمرحله">' + subNumLabel(ph, stepIdx, i) + '</span>' +
      '<button type="button" class="iact tiny note-ind ' + (nv ? 'note-on' : '') + '" data-act="note-toggle" data-key="' + esc(nk) + '" title="باز کردن یادداشت این زیرمرحله" aria-label="باز کردن یادداشت این زیرمرحله">' + I('note') + '</button>' +
      '<div class="sub-t" data-field="sub" data-id="' + esc(s.id) + '" data-sub="' + i + '" ' + ED() + '>' + renderInlineText(x.title, true) + '</div>' + markBadges(x.id) + entityBtn('sub', x.id) +
      '<span class="acts-edit">' +
      '<button class="iact tiny" data-act="move-sub" data-id="' + esc(s.id) + '" data-sub="' + i + '" data-dir="-1" title="بالا">' + I('up') + '</button>' +
      '<button class="iact tiny" data-act="move-sub" data-id="' + esc(s.id) + '" data-sub="' + i + '" data-dir="1" title="پایین">' + I('down') + '</button>' +
      '<button class="iact tiny d" data-act="del-sub" data-id="' + esc(s.id) + '" data-sub="' + i + '" title="حذف زیرمرحله">' + I('x') + '</button>' +
      '</span>' +
      '</div>' +
      noteUi +
      '</li>';
  }

  function stepHTML(ph, s, si, deferSubs) {
    const done = stepDone(s), part = stepPartial(s);
    const nk = 'n:' + s.id, nv = state.notes[nk] || '';
    const subStatus = s.subs.length
      ? '<span class="tag" data-subcount="' + esc(s.id) + '">' + fa(s.subs.filter(x => state.checks[x.id]).length) + ' از ' + fa(s.subs.length) + ' زیرمرحله</span>'
      : '';
    const partTag = '<span class="tag" data-partial="' + esc(s.id) + '" style="color:#ffe6b0;border-color:rgba(245,158,11,.35);display:' + (part ? '' : 'none') + '">نیمه کاره</span>';
    return '<article class="step ' + (done ? 'done' : '') + (isArchived(s.id) ? ' is-archived' : '') + (needsReview(s.id) ? ' needs-review' : '') + '" id="' + esc(s.id) + '">' +
      '<div class="st-head">' +
      '<label class="ck" title="تکمیل شد"><input type="checkbox" data-ck="' + esc(s.id) + '" ' + (done ? 'checked' : '') + '><span class="box"></span></label>' +
      '<span class="st-num" title="شماره خودکار مرحله">' + stepNumLabel(ph, si) + '</span>' +
      '<div class="st-main">' +
      '<div class="st-title" data-field="title" data-id="' + esc(s.id) + '" ' + ED() + '>' + renderInlineText(stripStepPrefix(s.title)) + '</div>' +
      '<div class="st-meta">' + metaTags(s.meta) +
      (s.stack ? '<button class="tag stk' + (state.ui.stack && norm(state.ui.stack) === norm(s.stack) ? ' hl-tag' : '') + '" data-act="stack-filter" data-id="' + esc(s.stack) + '" title="فیلتر بر اساس این استک">' + hiStack(s.stack) + '</button>' : '') + subStatus + partTag +
      (state.ui.editing ? '<input class="tag" data-meta="' + esc(s.id) + '" value="' + esc(s.meta) + '" placeholder="≈ زمان · مسئول" style="min-width:230px;background:rgba(7,11,20,.6);color:var(--tx);padding:3px 10px;font-family:inherit;font-size:calc(11px * var(--font-scale,1));text-align:center">' : '') +
      markBadges(s.id) +
      (nv ? '<span class="tag" style="color:#c8fff4;border-color:rgba(45,212,191,.35)">' + I('note') + ' یادداشت دارد</span>' : '') +
      '</div></div>' +
      '<div class="acts-edit">' +
      '<button class="iact" data-act="move-step" data-id="' + esc(s.id) + '" data-dir="-1" title="جابه جایی مرحله">' + I('up') + '</button>' +
      '<button class="iact" data-act="move-step" data-id="' + esc(s.id) + '" data-dir="1" title="جابه جایی مرحله">' + I('down') + '</button>' +
      '<button class="iact d" data-act="del-step" data-id="' + esc(s.id) + '" title="حذف مرحله">' + I('x') + ' حذف</button>' +
      '</div>' + entityBtn('step', s.id) +
      '</div>' +
      (s.tip ? '<div class="tip"><span class="ti">' + I('bulb') + '</span><div class="tip-content md" data-field="tip" data-id="' + esc(s.id) + '" ' + ED() + '>' + renderBlockText(s.tip) + '</div></div>' : (state.ui.editing ? '<div class="tip"><span class="ti">' + I('bulb') + '</span><div class="tip-content md" data-field="tip" data-id="' + esc(s.id) + '" ' + ED() + '>نکته تجربی این مرحله را اینجا بنویس…</div></div>' : '')) +
      '<ul class="subs">' + (deferSubs ? '' : s.subs.map((x, i) => subShown(ph, s, x) ? subHTML(ph, s, x, i, si) : '').join('')) + '</ul>' +
      '<div class="acts">' +
      '<button class="iact ' + (nv ? 'note-on' : '') + '" data-act="note-toggle" data-key="' + esc(nk) + '">' + I('note') + ' یادداشت مرحله</button>' +
      '<span class="acts-edit">' +
      '<span class="insert-action-group">' + insertPositionControl('sub', s.subs.length + 1) + '<button class="iact" data-act="add-sub" data-id="' + esc(s.id) + '" data-after="-1">' + I('plus') + ' زیرمرحله</button></span>' +
      '<button class="iact" data-act="add-tip" data-id="' + esc(s.id) + '">' + I('bulb') + ' نکته</button>' +
      '</span>' +
      '</div>' +
      notePanel(s.id, nv, ph, false) +
      '</article>';
  }

  function phaseHTML(ph, pi, prefilteredSteps, deferSteps) {
    const c = counts(ph), done = phaseDone(ph, c);
    const partial = phasePartial(ph, c);
    const noteKey='n:'+ph.id,noteValue=state.notes[noteKey]||'';
    const color = COLORS[pi % COLORS.length];
    const isOpen = !!state.open[ph.id] || isFiltering();
    const lazy = !isOpen && !state.ui.editing;
    const steps = lazy ? [] : (prefilteredSteps || ph.steps.filter(s => matchesAll(ph, s) || state.ui.editing));
    const visibleCount = steps.length;
    return '<section class="phase ' + (isOpen ? 'open' : '') + ' ' + (done ? 'done' : '') + (isArchived(ph.id) ? ' is-archived' : '') + (needsReview(ph.id) ? ' needs-review' : '') + '" id="' + esc(ph.id) + '" data-phase="' + esc(ph.id) + '" style="--c:' + color + '">' +
      '<div class="ph-head" data-act="toggle-phase" data-id="' + esc(ph.id) + '">' +
      '<label class="ck ph-ck" title="تکمیل همه مرحله ها و زیرمرحله های این فاز" aria-label="تکمیل فاز ' + esc(phaseNumLabel(ph)) + '"><input type="checkbox" data-ck="' + esc(ph.id) + '" ' + (done ? 'checked' : '') + (partial ? ' data-partial-check="1"' : '') + '><span class="box"></span></label>' +
      '<div class="ph-ico" data-field="icon" data-id="' + esc(ph.id) + '" title="نام آیکون (مثلاً: cart, flask, rocket)" ' + ED() + '>' + iconOf(ph.icon) + '</div>' +
      '<div class="ph-main">' +
      '<h2 class="ph-title"><span class="ph-num" title="شماره خودکار فاز">' + phaseNumLabel(ph) + '</span><span data-field="ptitle" data-id="' + esc(ph.id) + '" dir="' + markdownLineDirection(stripPhasePrefix(ph.title)) + '" ' + ED() + '>' + esc(stripPhasePrefix(ph.title)) + '</span>' +
      '<span class="ph-badge ' + (done ? 'ok' : '') + '" data-phbadge="' + esc(ph.id) + '">' + (done ? 'کامل شد ✓' : fa(c.d) + '/' + fa(c.t)) + '</span>' + markBadges(ph.id) +
      '</h2>' +
      '<div class="ph-goal md" data-field="goal" data-id="' + esc(ph.id) + '" ' + ED() + '>' + renderBlockText(ph.goal) + '</div>' +
      '</div>' +
      '<div class="ph-side">' +
      '<div class="ph-pct" data-ppct="' + esc(ph.id) + '">' + fa(c.p) + '٪ <small>پیشرفت</small></div>' +
      '<div style="width:126px" class="pbar"><i style="width:' + c.p + '%" data-pbar="' + esc(ph.id) + '"></i></div>' +
      '<button type="button" class="iact tiny phase-note-toggle ' + (noteValue?'note-on':'') + '" data-act="note-toggle" data-key="' + esc(noteKey) + '" title="یادداشت فاز" aria-label="باز کردن یادداشت فاز ' + esc(phaseNumLabel(ph)) + '">' + I('note') + '<span>یادداشت</span></button>' +
      entityBtn('phase', ph.id) +
      '<span class="ph-caret">' + I('chev', 'caret') + '</span>' +
      '</div></div>' +
      '<div class="ph-body"' + (lazy ? ' data-lazy="1"' : '') + '>' + (lazy ? '' :
      (ph.dod ? '<div class="dod"><div class="dod-head"><b>' + I('target') + ' شرط اتمام فاز:</b></div><div class="dod-body md" data-field="dod" data-id="' + esc(ph.id) + '" ' + ED() + '>' + renderBlockText(ph.dod) + '</div></div>' : '') +
      (ph.steps.length === 0 ? '<div class="empty">این فاز هنوز مرحله ای ندارد — با دکمه «افزودن مرحله به این فاز» شروع کن.</div>'
        : (!visibleCount && !state.ui.editing ? '<div class="empty">با فیلتر/جست وجوی فعلی، مرحله ای در این فاز دیده نمی شود.</div>' : '')) +
      '<div class="editbar"><b>حالت ویرایش:</b> روی متن ها کلیک کن و مستقیم تایپ کن؛ Enter = تأیید.' +
      '<span class="phase-add-actions">' +
      '<span class="insert-action-group">' + insertPositionControl('step', ph.steps.length + 1) + '<button class="iact phase-add-btn" data-act="add-step" data-id="' + esc(ph.id) + '" aria-label="افزودن مرحله به این فاز" title="افزودن مرحله به این فاز">' + I('plus') + ' افزودن مرحله</button></span>' +
      '<span class="insert-action-group">' + insertPositionControl('phase', state.plan.length + 1) + '<button class="iact phase-add-btn" data-act="add-phase" data-id="' + esc(ph.id) + '" aria-label="افزودن فاز جدید" title="افزودن فاز جدید">' + I('plus') + ' افزودن فاز</button></span>' +
      '</span>' +
      '<button class="iact" data-act="move-phase" data-id="' + esc(ph.id) + '" data-dir="-1">' + I('up') + ' فاز</button>' +
      '<button class="iact" data-act="move-phase" data-id="' + esc(ph.id) + '" data-dir="1">' + I('down') + ' فاز</button>' +
      '<button class="iact d" data-act="del-phase" data-id="' + esc(ph.id) + '">' + I('trash') + ' حذف این فاز</button>' +
      '</div>' +
      '<div class="steps">' + (deferSteps ? '' : steps.map((s, i) => stepHTML(ph, s, ph.steps.indexOf(s))).join('')) + '</div>' +
      notePanel(ph.id, noteValue, ph, false, 'phase')) +
      '</div></section>';
  }

  function renderTop() {
    const g = counts();
    const C = 150.8;
    const off = (C * (1 - g.p / 100)).toFixed(1);
    const marks = ['all', 'todo', 'done', 'notes'];
    const labels = { all: 'همه', todo: 'باقی مانده', done: 'انجام شده', notes: 'یادداشت دار' };
    const filterButtons = marks.map(m => '<button class="chip ' + (state.ui.filter === m ? 'on' : '') + '" data-act="filter" data-id="' + m + '" title="' + labels[m] + '" aria-label="فیلتر ' + labels[m] + '">' + labels[m] + '</button>').join('');
    const stickyFilterLabels = { all:'همه', todo:'باقی', done:'انجام', notes:'یادداشت' };
    const stickyFilterButtons = marks.map(m => '<button class="chip ' + (state.ui.filter === m ? 'on' : '') + '" data-act="filter" data-id="' + m + '" title="' + labels[m] + '" aria-label="فیلتر ' + labels[m] + '">' + stickyFilterLabels[m] + '</button>').join('');
    const markButtons = '<button class="chip mk ' + (archivedFilterOn() ? 'on' : '') + '" data-act="mark-filter" data-id="archived" title="فقط آرشیو شده ها را نشان بده" aria-label="فیلتر آرشیو">' + I('archive') + ' آرشیو <b data-mkcount="archived">' + fa(markCount('archived')) + '</b></button>' +
      '<button class="chip mk ' + ((state.ui.markFilters || []).indexOf('review') !== -1 ? 'on' : '') + '" data-act="mark-filter" data-id="review" title="فقط نیازمند بررسی ها را نشان بده" aria-label="فیلتر نیازمند بررسی">' + I('flag') + ' نیازمند بررسی <b data-mkcount="review">' + fa(markCount('review')) + '</b></button>';
    const stickyMarkButtons = '<button class="chip mk ' + (archivedFilterOn() ? 'on' : '') + '" data-act="mark-filter" data-id="archived" title="فقط آرشیو شده ها را نشان بده" aria-label="فیلتر آرشیو">' + I('archive') + ' آرشیو</button>' +
      '<button class="chip mk ' + ((state.ui.markFilters || []).indexOf('review') !== -1 ? 'on' : '') + '" data-act="mark-filter" data-id="review" title="فقط نیازمند بررسی ها را نشان بده" aria-label="فیلتر نیازمند بررسی">' + I('flag') + ' بررسی</button>';
    const reportMenu = (extraClass, includeAnswers) => '<span class="menu-wrap ' + extraClass + '">' +
      '<button type="button" class="btn ' + (extraClass === 'header-report-menu' ? 'header-secondary' : 'sticky-action') + '" data-act="report-menu" title="گزارش MD — انتخاب وضعیت" aria-label="گزارش MD، انتخاب وضعیت">' + I('report') + '<span class="control-label">گزارش MD</span><i class="caret">▾</i></button>' +
      '<div class="menu-pop">' +
        '<button type="button" data-act="report" data-id="done">✅ فقط انجام شده ها <b data-mcount="done">' + fa(g.d) + '</b></button>' +
        '<button type="button" data-act="report" data-id="todo">⏳ فقط باقی مانده ها <b data-mcount="todo">' + fa(g.t - g.d) + '</b></button>' +
        '<button type="button" data-act="report" data-id="full">📄 گزارش کامل <b data-mcount="full">' + fa(g.t) + '</b></button>' +
        (includeAnswers ? '<div class="menu-sep"></div><button type="button" data-act="export-answers">💾 فقط فایل پاسخ ها (JSON)</button>' : '') +
      '</div></span>';
    const editButton = (extraClass, compact) => '<button type="button" class="btn edit-mode-btn ' + extraClass + (state.ui.editing ? ' on' : '') + '" data-act="edit-mode" title="روشن یا خاموش کردن حالت ویرایش" aria-label="حالت ویرایش" aria-pressed="' + (state.ui.editing ? 'true' : 'false') + '">' + I('edit') + (compact ? '' : '<span class="control-label">' + (state.ui.editing ? 'پایان ویرایش' : 'حالت ویرایش') + '</span>') + '</button>';
    const resetButton = extraClass => '<button type="button" class="btn sidebar-size-reset ' + extraClass + '" data-act="sidebar-size-reset" title="ریست سایز سایدبار" aria-label="ریست سایز سایدبار">' + I('reset') + '<span class="control-label">ریست سایز سایدبار</span></button>';
    const expandButton = extraClass => '<button type="button" class="btn header-secondary ' + extraClass + '" data-act="expand-all" title="باز کردن همه فازها" aria-label="باز کردن همه">' + I('expand') + '<span class="control-label">باز کردن همه</span></button>';
    const collapseButton = extraClass => '<button type="button" class="btn header-secondary ' + extraClass + '" data-act="collapse-all" title="بستن همه فازها" aria-label="بستن همه">' + I('collapse') + '<span class="control-label">بستن همه</span></button>';
    const jsonExportButton = (extraClass, compact) => '<button type="button" class="btn ' + (compact ? 'sticky-action ' : 'header-secondary ') + extraClass + '" data-act="export" title="خروجی JSON" aria-label="خروجی JSON">' + I('export') + (compact ? '' : '<span class="control-label">خروجی JSON</span>') + '</button>';
    const jsonImportButton = (extraClass, compact) => '<button type="button" class="btn ' + (compact ? 'sticky-action ' : 'header-secondary ') + extraClass + '" data-act="import" title="ورودی JSON" aria-label="ورودی JSON">' + I('import') + (compact ? '' : '<span class="control-label">ورودی JSON</span>') + '</button>';
    const cleanButton = (extraClass, compact) => '<button type="button" class="btn danger ' + (compact ? 'sticky-action ' : 'header-secondary ') + extraClass + '" data-act="clean-all" title="پاکسازی پاسخ ها" aria-label="پاکسازی">' + I('trash') + (compact ? '' : '<span class="control-label">پاکسازی</span>') + '</button>';
    const printButton = (extraClass, compact) => '<button type="button" class="btn ' + (compact ? 'sticky-action ' : 'header-secondary ') + extraClass + '" data-act="print" title="چاپ یا PDF" aria-label="چاپ یا PDF">' + I('print') + (compact ? '' : '<span class="control-label">چاپ/PDF</span>') + '</button>';
    return '<div class="topbar">' +
      '<div class="brand">' +
      '<div class="ring"><svg width="56" height="56" viewBox="0 0 56 56">' +
      '<defs><linearGradient id="rg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2dd4bf"/><stop offset="1" stop-color="#6366f1"/></linearGradient></defs>' +
      '<circle class="bgc" cx="28" cy="28" r="24" stroke-width="5"/>' +
      '<circle class="fgc" cx="28" cy="28" r="24" stroke-width="5" stroke-dasharray="' + C + '" stroke-dashoffset="' + off + '" data-ring="1"/>' +
      '</svg><b data-stat="ringpct">' + fa(g.p) + '٪</b></div>' +
      '<div style="min-width:0"><h1 data-field="mtitle" ' + ED() + '><span>' + esc(state.meta.title) + '</span></h1>' +
      '<p data-field="msub" ' + ED() + '>' + esc(state.meta.sub) + '</p></div>' +
      '<span class="brand-pill">' + esc(BRAND) + '</span>' +
      '</div>' +
      '<div class="tools header-actions header-actions-left"><span class="sidebar-layout-slot">' + sidebarLayoutButton('header') + resetButton('sidebar-reset-btn') + '</span>' + fontScaleControls('ui','header') + '</div>' +
      '<div class="search"><span class="ico">' + I('search') + '</span><input id="q" type="search" placeholder="جست وجو در مراحل، پلاگین ها، توضیحات…  ( / )" value="' + esc(state.ui.q) + '"></div>' +
      '<div class="chips filters-main" aria-label="فیلتر وضعیت ها">' + filterButtons + '</div>' +
      '<div class="chips mark-chips filters-marks" aria-label="فیلتر نشان ها">' + markButtons + (markFiltersOn() ? '<button class="chip mk clear" data-act="mark-clear" title="پاک کردن فیلتر نشان ها" aria-label="پاک کردن فیلتر نشان ها">پاک کردن نشان ها</button>' : '') + '</div>' +
      '<div class="tools header-actions header-actions-right">' +
        editButton('', false) +
        expandButton('') + collapseButton('') +
        (state.ui.stack ? '<button type="button" class="btn pri header-secondary stack-clear-btn" data-act="stack-clear" title="پاک کردن فیلتر استک" aria-label="پاک کردن فیلتر استک"><span class="stack-clear-mark">✕</span><span class="control-label">پاک کردن فیلتر استک: ' + esc(state.ui.stack) + '</span></button>' : '') +
        reportMenu('header-report-menu', true) +
        '<button type="button" class="btn notebook-btn ' + (state.ui.nbOpen ? 'on' : '') + '" data-act="notebook" title="باز کردن دفترچه یادداشت" aria-label="دفترچه">' + I('note') + '<span class="control-label">دفترچه</span></button>' +
        cleanButton('', false) + jsonExportButton('', false) + jsonImportButton('', false) + printButton('', false) +
      '</div>' +
      '<div class="sticky-actions-left" role="group" aria-label="فیلترها و تنظیمات سربرگ فشرده">' +
        '<div class="sticky-side-tools"><span class="sticky-layout-slot">' + sidebarLayoutButton('sticky') + resetButton('sticky-action sidebar-reset-btn') + '</span>' + fontScaleControls('ui','sticky') + '</div>' +
        '<div class="sticky-filters">' +
          '<div class="chips sticky-filters-main filters-main" aria-label="فیلتر وضعیت ها">' + stickyFilterButtons + '</div>' +
          '<div class="chips sticky-filters-marks filters-marks" aria-label="فیلتر نشان ها">' + stickyMarkButtons + '</div>' +
        '</div>' +
      '</div>' +
      '<div class="sticky-actions-right" role="group" aria-label="اقدام های سربرگ فشرده">' +
        editButton('sticky-action sticky-edit', true) +
        jsonExportButton('sticky-json-export', true) + jsonImportButton('sticky-json-import', true) +
        reportMenu('sticky-report-menu', false) +
        expandButton('sticky-action sticky-expand') + collapseButton('sticky-action sticky-collapse') +
        printButton('sticky-action sticky-print', true) + cleanButton('sticky-action sticky-clean', true) +
      '</div>' +
    '</div>';
  }

  /* کارت تاشوی سایدبار: همه کارت ها (نه فقط راهنمای توسعه دهنده) باز/بسته می شوند
   * و وضعیت شان در state.ui.sideClosed ذخیره می ماند. */
  function sideCard(key, icon, title, small, bodyHTML, extraClass) {
    const closed = !!(state.ui.sideClosed && state.ui.sideClosed[key]);
    return '<div class="card side-card side-card-' + esc(key) + ' ' + (extraClass || '') + (closed ? ' closed' : '') + '">' +
      '<button type="button" class="card-h side-h" data-act="side-toggle" data-id="' + key + '" aria-expanded="' + (closed ? 'false' : 'true') + '" title="باز/بسته کردن این بخش">' +
        '<span class="side-h-t">' + I(icon) + ' ' + title + '</span>' +
        '<span class="side-h-r"><small>' + small + '</small><span class="side-chev">' + I('chev') + '</span></span>' +
      '</button>' +
      (closed ? '' : bodyHTML) +
      '</div>';
  }
  function sideCardBody(inner, style) {
    return '<div class="card-b"' + (style ? ' style="' + style + '"' : '') + '>' + inner + '</div>';
  }

  function sidebarResetButton(extraClass) {
    return '<button type="button" class="btn sidebar-size-reset ' + (extraClass || '') + '" data-act="sidebar-size-reset" title="ریست سایز سایدبار" aria-label="ریست سایز سایدبار">' + I('reset') + '<span class="control-label">ریست سایز سایدبار</span></button>';
  }
  function sidebarLayoutButton(place) {
    const mode = validSidebarLayout(state.ui.sidebarLayout);
    const i = SIDEBAR_LAYOUTS.indexOf(mode);
    const meta = {
      'dual-right': { icon:'layout-right', label:'دو سایدبار', detail:'فهرست فازها راست، ابزارها چپ' },
      'single-right': { icon:'layout-single', label:'یک سایدبار', detail:'همه بخش ها در سمت راست' },
      'dual-left': { icon:'layout-left', label:'دو سایدبار برعکس', detail:'فهرست فازها چپ، ابزارها راست' }
    }[mode];
    const next = SIDEBAR_LAYOUTS[(i + 1) % SIDEBAR_LAYOUTS.length];
    return '<button type="button" class="btn sidebar-layout-btn ' + esc(place || '') + '" data-act="sidebar-layout-cycle" data-mode="' + mode + '" ' +
      'aria-label="چیدمان فعلی: ' + esc(meta.detail) + '. برای تغییر کلیک کن" title="چیدمان فعلی: ' + esc(meta.detail) + ' · کلیک برای رفتن به ' + esc(next === 'single-right' ? 'یک سایدبار' : (next === 'dual-left' ? 'دو سایدبار برعکس' : 'دو سایدبار')) + '">' +
      I(meta.icon) + '<span class="control-label">' + meta.label + '</span><b class="layout-step">' + fa(i + 1) + '/۳</b></button>';
  }
  function fontScaleControls(scope, place) {
    const isNb = scope === 'nb';
    const v = isNb ? state.nbFontScale : state.ui.fontScale;
    const pctValue = Math.round(clampScale(v, 1) * 100);
    const targetAttr = isNb ? 'data-nb="font-scale"' : 'data-act="font-scale"';
    return '<div class="font-controls ' + (place || '') + '" role="group" aria-label="تنظیم اندازه فونت ' + (isNb ? 'دفترچه' : 'رابط کاربری') + '" data-font-group="' + (isNb ? 'nb' : 'ui') + '">' +
      '<button type="button" class="font-step" ' + targetAttr + ' data-scope="' + (isNb ? 'nb' : 'ui') + '" data-dir="-1" title="کوچک تر کردن فونت ' + (isNb ? 'دفترچه' : 'رابط کاربری') + '" aria-label="کاهش اندازه فونت">A−</button>' +
      '<output class="font-scale-value" data-font-scale="' + (isNb ? 'nb' : 'ui') + '">' + fa(pctValue) + '٪</output>' +
      '<button type="button" class="font-step" ' + targetAttr + ' data-scope="' + (isNb ? 'nb' : 'ui') + '" data-dir="1" title="بزرگ تر کردن فونت ' + (isNb ? 'دفترچه' : 'رابط کاربری') + '" aria-label="افزایش اندازه فونت">A+</button>' +
      '<button type="button" class="font-reset" ' + targetAttr + ' data-scope="' + (isNb ? 'nb' : 'ui') + '" data-dir="0" title="بازنشانی اندازه فونت به ۱۰۰٪" aria-label="بازنشانی اندازه فونت">↺</button>' +
      '</div>';
  }
  function refreshFontScales() {
    document.documentElement.style.setProperty('--app-font-scale', String(clampScale(state.ui.fontScale, 1)));
    document.documentElement.style.setProperty('--nb-font-scale', String(clampScale(state.nbFontScale, 1)));
    $$('[data-font-scale="ui"]').forEach(e => e.textContent = fa(Math.round(clampScale(state.ui.fontScale, 1) * 100)) + '٪');
    $$('[data-font-scale="nb"]').forEach(e => e.textContent = fa(Math.round(clampScale(state.nbFontScale, 1) * 100)) + '٪');
  }
  function adjustFontScale(scope, dir) {
    const isNb = scope === 'nb';
    const key = isNb ? 'nbFontScale' : null;
    const current = isNb ? state.nbFontScale : state.ui.fontScale;
    const next = Number(dir) === 0 ? 1 : clampScale(current + (Number(dir) < 0 ? -.05 : .05), 1);
    if (isNb) state[key] = next; else state.ui.fontScale = next;
    refreshFontScales(); saveNow();
  }
  function renderPhaseTree(navId, query) {
    const q = norm(query || '');
    const trees = state.plan.map(ph => {
      const phaseCounts=counts(ph);
      const pText = norm([phaseNumLabel(ph), ph.title, ph.goal, ph.dod].join(' '));
      const pHit = !q || pText.indexOf(q) !== -1;
      const stepMatches = ph.steps.map((s, si) => {
        const text = norm([stepNumLabel(ph, si), s.title, s.meta, s.tip, s.stack].join(' '));
        const matchingSubs = s.subs.map((x, xi) => ({ x, xi })).filter(o => norm([subNumLabel(ph, si, o.xi), o.x.title].join(' ')).indexOf(q) !== -1);
        return { s, si, hit: !q || pHit || text.indexOf(q) !== -1 || matchingSubs.length > 0, textHit: !q || pHit || text.indexOf(q) !== -1, matchingSubs };
      }).filter(o => o.hit);
      if (q && !pHit && !stepMatches.length) return '';
      const openPh = !!(state.ui.sideOpen && state.ui.sideOpen[ph.id]);
      const stepsHTML = openPh ? '<div class="tree-steps">' + stepMatches.map(o => {
        const s = o.s, si = o.si, dn = stepDone(s);
        const subOpen = !!(state.ui.sideStepOpen && state.ui.sideStepOpen[s.id]);
        const subItems = s.subs.map((x, xi) => ({ x, xi })).filter(z => !q || pHit || o.textHit || o.matchingSubs.some(m => m.xi === z.xi));
        const subsHTML = subOpen ? '<div class="tree-subs">' + subItems.map(z =>
          '<div class="navsub' + (state.checks[z.x.id] ? ' done' : '') + (isArchived(z.x.id) ? ' is-archived' : '') + (needsReview(z.x.id) ? ' needs-review' : '') + '" data-act="goto-sub" data-id="' + esc(z.x.id) + '" data-ph="' + esc(ph.id) + '" data-nav-role="sub" title="' + esc(z.x.title) + '">' +
            '<span class="nsub-num">' + subNumLabel(ph, si, z.xi) + '</span><span class="nsub-tt">' + hiStack(z.x.title) + '</span>' +
            (needsReview(z.x.id) ? '<span class="mini-flag">' + I('flag') + '</span>' : '') + (isArchived(z.x.id) ? '<span class="mini-arch">' + I('archive') + '</span>' : '') +
          '</div>'
        ).join('') + (s.subs.length && !subItems.length ? '<div class="ns-empty">با این جستجو زیرمرحله ای پیدا نشد</div>' : (s.subs.length ? '' : '<div class="ns-empty">زیرمرحله ای ندارد</div>')) + '</div>' : '';
        return '<div class="tree-step-wrap"><div class="navstep' + (dn ? ' done' : '') + (isArchived(s.id) ? ' is-archived' : '') + (needsReview(s.id) ? ' needs-review' : '') + '" data-act="goto-step" data-id="' + esc(s.id) + '" data-ph="' + esc(ph.id) + '" data-nav-role="step" title="' + esc(stripStepPrefix(s.title)) + '">' +
          '<button type="button" class="tree-step-toggle' + (subOpen ? ' open' : '') + '" data-act="side-step-toggle" data-id="' + esc(s.id) + '" title="' + (subOpen ? 'بستن زیرمرحله ها' : 'نمایش زیرمرحله ها') + '" aria-expanded="' + (subOpen ? 'true' : 'false') + '">' + I('chev') + '</button>' +
          '<span class="ns-num">' + stepNumLabel(ph, si) + '</span>' +
          '<span class="ns-tt">' + hiStack(stripStepPrefix(s.title)) + '</span>' +
          (dn ? '<span class="ns-ok">✓</span>' : '') + '</div>' + subsHTML + '</div>';
      }).join('') + (ph.steps.length && !stepMatches.length ? '<div class="ns-empty">با این جستجو مرحله ای پیدا نشد</div>' : (ph.steps.length ? '' : '<div class="ns-empty">هنوز مرحله ای ندارد</div>')) + '</div>' : '';
      return '<div class="tree-ph" data-phase-nav="' + esc(ph.id) + '">' +
        '<div class="navitem' + (phaseDone(ph,phaseCounts)?' done':'') + '" data-act="goto" data-id="' + esc(ph.id) + '" data-nav-role="phase">' +
          '<button type="button" class="tree-toggle' + (openPh ? ' open' : '') + '" data-act="side-phase-toggle" data-id="' + esc(ph.id) + '" title="' + (openPh ? 'بستن مرحله های این فاز' : 'نمایش مرحله های این فاز') + '" aria-expanded="' + (openPh ? 'true' : 'false') + '">' + I('chev') + '</button>' +
          '<span class="ic">' + iconOf(ph.icon) + '</span>' +
          '<span class="tt"><b class="nav-num">' + phaseNumLabel(ph) + '</b> ' + esc(stripPhasePrefix(ph.title)) + '</span>' +
          (needsReview(ph.id) ? '<span class="mini-flag" title="نیازمند بررسی">' + I('flag') + '</span>' : '') + (isArchived(ph.id) ? '<span class="mini-arch" title="آرشیو شده">' + I('archive') + '</span>' : '') +
          '<span class="ct" data-nav="' + esc(ph.id) + '">' + fa(counts(ph).d) + '/' + fa(counts(ph).t) + '</span></div>' + stepsHTML + '</div>';
    }).join('');
    return trees || '<div class="nav-search-empty">موردی با این عبارت پیدا نشد.</div>';
  }
  function renderPhaseDrawer() {
    const open = !!state.ui.phaseDrawerOpen;
    return '<div class="phase-drawer-scrim ' + (open ? 'show' : '') + '" id="phaseDrawerScrim" data-act="phase-drawer-close" aria-hidden="' + (!open) + '"></div>' +
      '<aside class="phase-drawer ' + (open ? 'open' : '') + '" id="phaseNavDrawer" role="dialog" aria-modal="true" aria-label="فهرست فازها" aria-hidden="' + (!open) + '">' +
        '<header class="phase-drawer-head"><div><b>' + I('phases') + ' فهرست فازها</b><small>ناوبری کامل فاز، مرحله و زیرمرحله</small></div>' +
          '<button type="button" class="iact" data-act="phase-drawer-close" title="بستن فهرست فازها (Esc)" aria-label="بستن">' + I('x') + '</button></header>' +
        (state.ui.editing ? '<div class="phase-edit-warning">✎ حالت ویرایش فعال است؛ تغییر ساختار از دکمه های منوی هر مورد انجام می شود.</div>' : '') +
        '<div class="phase-drawer-tools">' + sidebarLayoutButton('drawer') + sidebarResetButton('sidebar-reset-btn') + fontScaleControls('ui','drawer') + '</div>' +
        '<label class="phase-drawer-search"><span>' + I('search') + '</span><input id="phaseDrawerSearch" type="search" value="' + esc(state.ui.phaseDrawerQuery || '') + '" placeholder="جستجوی فاز، مرحله یا زیرمرحله…" aria-label="جستجو در فهرست فازها"></label>' +
        '<div class="phase-drawer-list"><div class="navlist" id="phaseDrawerNavList" tabindex="0">' + (open ? renderPhaseTree('phaseDrawerNavList', state.ui.phaseDrawerQuery) : '') + '</div></div>' +
      '</aside>';
  }
  function expandDrawerSearch(q) {
    const query = norm(q);
    if (!query) return;
    state.plan.forEach(ph => {
      const pHit = norm([phaseNumLabel(ph), ph.title, ph.goal, ph.dod].join(' ')).includes(query);
      const matching = [];
      ph.steps.forEach((s, si) => {
        const sHit = norm([stepNumLabel(ph, si), s.title, s.meta, s.tip, s.stack].join(' ')).includes(query);
        const subHits = s.subs.some((x, xi) => norm([subNumLabel(ph, si, xi), x.title].join(' ')).includes(query));
        if (sHit || subHits) matching.push({s,subHits});
      });
      if (pHit || matching.length) state.ui.sideOpen[ph.id] = true;
      matching.forEach(o => { if (o.subHits) state.ui.sideStepOpen[o.s.id] = true; });
    });
  }

  function sidebarLayoutStyle() {
    const ratio=clampSidebarPairRatio(state.ui.sidebarPairRatio,.5);
    return '--sidebar-left-width:'+clampSidebarWidth(state.ui.sidebarLeftWidth,300)+'px;'+
      '--sidebar-right-width:'+clampSidebarWidth(state.ui.sidebarRightWidth,300)+'px;'+
      '--sidebar-pair-left:'+ratio+'fr;--sidebar-pair-right:'+(1-ratio)+'fr;';
  }
  function sidebarResizeHandle(kind, extraClass, label, value, min, max) {
    return '<div class="sidebar-resizer '+extraClass+'" data-sidebar-resize="'+kind+'" role="separator" aria-orientation="vertical" aria-label="'+label+'" title="'+label+'" aria-valuemin="'+min+'" aria-valuemax="'+max+'" aria-valuenow="'+value+'" tabindex="0"></div>';
  }
  function renderSidebarResizeHandles(mode) {
    if(mode==='single-right')return sidebarResizeHandle('right','sidebar-resizer-single','تغییر عرض سایدبار سمت راست',state.ui.sidebarRightWidth,SIDEBAR_MIN_WIDTH,SIDEBAR_MAX_WIDTH);
    return sidebarResizeHandle('left','sidebar-resizer-left','تغییر عرض سایدبار سمت چپ',state.ui.sidebarLeftWidth,SIDEBAR_MIN_WIDTH,SIDEBAR_MAX_WIDTH)+
      sidebarResizeHandle('right','sidebar-resizer-right','تغییر عرض سایدبار سمت راست',state.ui.sidebarRightWidth,SIDEBAR_MIN_WIDTH,SIDEBAR_MAX_WIDTH)+
      sidebarResizeHandle('pair','sidebar-resizer-pair','تغییر نسبت عرض دو سایدبار',Math.round(clampSidebarPairRatio(state.ui.sidebarPairRatio,.5)*100),38,62);
  }
  function sideCards(includePhaseCard) {
    const g = counts();
    const total = state.plan.reduce((a, ph) => a + ph.steps.length, 0);
    const nbCount = (state.nbNotes || []).filter(n => String(n.body || '').trim() || String(n.title || '').trim()).length;

    const overviewBody = sideCardBody(
      '<div class="meta-row"><span>' + fa(g.d) + ' مورد از ' + fa(g.t) + ' انجام شده</span><span>' + fa(g.t - g.d) + ' باقی مانده</span></div>' +
      '<div class="pbar"><i style="width:' + g.p + '%" data-pbar="global"></i></div>' +
      '<div class="stats" style="margin-top:13px">' +
      '<div class="stat ok"><b data-stat="done">' + fa(g.d) + '</b><span>انجام شده</span></div>' +
      '<div class="stat warn"><b data-stat="todo">' + fa(g.t - g.d) + '</b><span>باقی مانده</span></div>' +
      '<div class="stat"><b data-stat="phases">' + fa(state.plan.length) + '</b><span>فاز</span></div>' +
      '<div class="stat"><b data-stat="notes">' + fa(g.notes) + '</b><span>یادداشت</span></div>' +
      '</div>' +
      '<div class="hint" style="margin-top:10px">مجموع مراحل: <b>' + fa(total) + '</b> · زیرمرحله ها: <b>' + fa(g.t - total) + '</b><br>نسخه نهایی برنامه: <b>V' + APP_VERSION + '</b></div>');

    const phasesBody = sideCardBody(
      '<div class="side-phase-tools">' + sidebarLayoutButton('sidebar') + sidebarResetButton('sidebar-reset-btn') + fontScaleControls('ui','sidebar') + '</div>' +
      (state.ui.editing ? '<div class="phase-edit-warning">✎ حالت ویرایش فعال است؛ برای درج مرحله یا فاز، محل درج را کنار دکمه وارد کن.</div>' : '') +
      '<div class="navlist" id="sideNavList" tabindex="0">' + renderPhaseTree('sideNavList','') + '</div>', 'padding:8px');

    const marksBody = sideCardBody(
      '<div class="stack-chips" aria-label="فیلتر نشان ها در سایدبار">' +
        '<button class="schip mk ' + (archivedFilterOn() ? 'on' : '') + '" data-act="mark-filter" data-id="archived">' + I('archive') + ' آرشیو شده ها <b data-mkcount="archived">' + fa(markCount('archived')) + '</b></button>' +
        '<button class="schip mk ' + ((state.ui.markFilters || []).indexOf('review') !== -1 ? 'on' : '') + '" data-act="mark-filter" data-id="review">' + I('flag') + ' نیازمند بررسی <b data-mkcount="review">' + fa(markCount('review')) + '</b></button>' +
        (markFiltersOn() ? '<button class="schip mk" data-act="mark-clear">پاک کردن فیلتر</button>' : '') +
      '</div>' +
      '<div class="hint" style="margin-top:9px">چند انتخاب ممکن است: هر دو نشان را با هم فعال کن تا هر دو نوع با هم دیده شوند. آرشیو شده ها بدون این فیلتر در صفحه اصلی دیده نمی شوند.</div>');

    const stackBody = sideCardBody(
      '<div class="stack-chips" aria-label="فیلتر استک ها">' +
      '<button class="schip ' + (!state.ui.stack ? 'on' : '') + '" data-act="stack-filter" data-id="">همه مراحل</button>' +
      STACK.map(st => {
        const n = stackCount(st);
        if (!n) return '';
        return '<button class="schip ' + (state.ui.stack === st ? 'on' : '') + '" data-act="stack-filter" data-id="' + esc(st) + '" title="' + fa(n) + ' مرحله مرتبط">' + esc(st) + ' <b>' + fa(n) + '</b></button>';
      }).join('') +
      '</div>' +
      (state.ui.stack ? '<div class="stack-active-note">استک فیلترشده: <mark class="hl-stack">' + esc(state.ui.stack) + '</mark> — همین کلمه در عنوان، نکته و زیرمرحله های نمایش داده شده هم هایلایت شده است.</div>' : '') +
      '<div class="hint" style="margin-top:9px">با کلیک روی هر ابزار، مراحل مرتبط با آن فیلتر و کلمه استک در متن ها برجسته می شود (مثلاً فقط مراحل Dokan Pro).</div>',
      'padding:10px 12px 12px');

    const dataBody = sideCardBody(
      '<div class="toolbtns">' +
      '<button class="btn" data-act="export">' + I('export') + ' خروجی JSON کامل</button>' +
      '<button class="btn" data-act="export-answers">💾 فقط فایل پاسخ ها</button>' +
      '<button class="btn" data-act="import">' + I('import') + ' ورودی JSON</button>' +
      '<button class="btn" data-act="copy-json">' + I('copy') + ' کپی JSON</button>' +
      '</div>' +
      '<div class="toolbtns" style="margin-top:8px">' +
      '<button class="btn danger" data-act="clean-all">' + I('trash') + ' پاکسازی همه پاسخ ها</button>' +
      '<button class="btn danger" data-act="reset-content">' + I('reset') + ' بازنشانی محتوای پیش فرض</button>' +
      '</div>' +
      '<div class="hint" style="margin-top:9px">«پاکسازی» تیک ها، یادداشت ها و دفترچه را خالی می کند (و فایل کناری را هم خالی می کند).</div>');

    const storeBody = sideCardBody(
      '<div class="store-row">' +
        '<span class="dot ' + (fileStore.connected ? 'ok' : (fileStore.status === 'error' ? 'err' : 'off')) + '"></span>' +
        '<span data-store-label>' +
          (fileStore.connected
            ? 'فایل کناری متصل است: <b>' + esc(SIDECAR) + '</b>'
            : (fileStore.status === 'need-permission' ? 'فایل قبلی پیدا شد؛ برای فعال سازی دسترسی دکمه را بزن.' : 'ذخیره سازی فعلی: ' + (store.available ? 'حافظه مرورگر (localStorage)' : 'حافظه موقت'))) +
        '</span>' +
      '</div>' +
      '<div class="store-state" data-store-state>' + (fileStore.connected ? ('ذخیره شد · ' + esc(fileStore.lastSaved || '-')) : 'آماده') + '</div>' +
      '<div class="toolbtns" style="margin-top:8px">' +
      (fileStore.status === 'need-permission'
        ? '<button class="btn pri" data-act="file-regrant">🔓 فعال سازی دسترسی فایل</button>'
        : '<button class="btn" data-act="file-connect">🔗 اتصال فایل پاسخ ها</button>') +
      (fileStore.connected ? '<button class="btn" data-act="file-write">💾 ذخیره فوری در فایل</button><button class="btn" data-act="file-disconnect">✂ قطع اتصال</button>' : '') +
      '</div>' +
      '<div class="hint" style="margin-top:9px">' +
      (store.available ? I('check') + ' پیشرفت در همین مرورگر ذخیره می شود.' : I('warn') + ' در این نمایش (iframe سندباکس) ذخیره سازی مرورگر غیرفعال است؛ فایل را دانلود و باز کن.') +
      '<br>اتصال فایل: یک بار <code>' + esc(SIDECAR) + '</code> را کنار همین HTML بساز و انتخاب کن؛ از آن پس همه پاسخ ها خودکار در همان فایل ذخیره می شود.' +
      '</div>');

    const notebookBody = sideCardBody(
      '<div class="hint" style="margin:0 0 9px">دفترچه چندیادداشتی مستقل (مثل Obsidian): ' + fa(nbCount) + ' یادداشت ذخیره شده است. آخرین یادداشت بازشده حفظ می شود.</div>' +
      '<div class="toolbtns">' +
      '<button class="btn pri" data-act="notebook">' + I('note') + ' باز کردن دفترچه</button>' +
      '<button class="btn" data-act="notebook-copy">' + I('copy') + ' کپی</button>' +
      '<button class="btn" data-act="notebook-share">🔗 اشتراک گذاری</button>' +
      '</div>');

    const quickBody = sideCardBody(
      '<div class="hint">' +
      '<kbd>/</kbd> جست وجو · <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>.</kbd> خروجی JSON · <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>;</kbd> یادداشت جدید<br>' +
      'هر مرحله را کلیک/تیک بزن؛ روی «یادداشت» بزن تا یادداشت بنویسی.<br>' +
      'در حالت ویرایش، متن ها را کلیک کن و مستقیم تغییر بده؛ برای درج در شماره دلخواه، فیلد «محل درج» کنار دکمه افزودن را پر کن.' +
      '</div>');

    const devBody = sideCardBody(
      '<div class="hint">' +
      'کل محتوای مراحل در بلوک <code>PLAN_PARTS</code> همین فایل است. هر فایل <code>PLAN_*.js</code> یک یا چند فاز را اضافه می کند.' +
      '<br>ساختار یک مرحله: <code>{ id, title, meta, tip, stack, subs: [ … ] }</code>' +
      '<br><code>meta</code>: «≈ زمان · مسئول» — <code>tip</code>: نکته تجربی — <code>stack</code>: نام ابزار برای فیلتر (مثلاً Dokan Pro)' +
      '<br>هویت برند و فهرست استک در بلوک <code>PLAN_META</code> تعریف شده است.' +
      '<br>آیکون فاز: یکی از نام ها → <code>compass, server, cart, palette, building, package, flask, zap, megaphone, rocket, paperclip</code>' +
      '<br>شماره فاز/مرحله/زیرمرحله محاسباتی است و با افزودن/حذف/جابه جایی خودکار اصلاح می شود؛ برای درج، فیلد «محل درج» را پر کن و برای افزودن عادی خالی بگذار.' +
      '<br>خروجی JSON معادل فایل ذخیره شده است؛ با «ورودی JSON» می توانی همان نقشه راه را روی نسخه دیگر بازیابی کنی.' +
      '</div>');

    const overviewCard = sideCard('overview', 'chart', 'نمای کلی پروژه', fa(g.p) + '٪', overviewBody);
    const phaseCard = sideCard('phases', 'phases', 'فهرست فازها', 'اسکرول مستقل', phasesBody, 'phases-card');
    const otherCards =
      sideCard('marks', 'flag', 'آرشیو و نیازمند بررسی', fa(markCount('archived') + markCount('review')) + ' نشان', marksBody) +
      sideCard('stack', 'tools', 'فیلتر استک پروژه', fa(STACK.length) + ' ابزار', stackBody) +
      sideCard('data', 'tools', 'داده و ابزار', '', dataBody) +
      sideCard('store', 'export', 'محل ذخیره پاسخ ها', esc(SIDECAR), storeBody) +
      sideCard('notebook', 'note', 'دفترچه یادداشت', 'مستقل از مراحل', notebookBody) +
      sideCard('quick', 'keyboard', 'راهنمای سریع', '', quickBody) +
      sideCard('dev', 'tools', 'راهنمای توسعه دهنده', 'برای ویرایش فایل', devBody);
    const mode = validSidebarLayout(state.ui.sidebarLayout);
    if (!includePhaseCard) return overviewCard + otherCards;
    if (mode === 'single-right') {
      return '<aside class="side side-right side-single" aria-label="سایدبار سمت راست">' + overviewCard + phaseCard + otherCards + '</aside>';
    }
    if (mode === 'dual-left') {
      return '<aside class="side side-left side-phases" aria-label="فهرست فازها">' + phaseCard + '</aside>' +
        '<aside class="side side-right side-tools" aria-label="ابزارها و وضعیت پروژه">' + overviewCard + otherCards + '</aside>';
    }
    return '<aside class="side side-left side-tools" aria-label="ابزارها و وضعیت پروژه">' + overviewCard + otherCards + '</aside>' +
      '<aside class="side side-right side-phases" aria-label="فهرست فازها">' + phaseCard + '</aside>';
  }
  function renderSide() { return sideCards(true); }

  function phaseRenderData(ph,i,deferSteps) {
    if(!state.ui.editing&&isArchived(ph.id)&&!archivedFilterOn())return null;
    if(!state.ui.editing&&markFiltersOn()&&ph.steps.length===0&&!entityHasFilterMark(ph,null,null))return null;
    const filtered=state.ui.editing?ph.steps:ph.steps.filter(s=>matchesAll(ph,s));
    if(!filtered.length&&ph.steps.length&&!state.ui.editing)return null;
    return {html:phaseHTML(ph,i,filtered,!!deferSteps),steps:filtered};
  }
  function phaseMarkup(ph,i) { const data=phaseRenderData(ph,i,false);return data?data.html:''; }
  function renderPhases() {
    const list=state.plan.map(phaseMarkup).join('');
    return '<main class="phases" id="phases">'+(list||'<div class="card"><div class="empty">موردی با این فیلتر/جست وجو پیدا نشد.</div></div>')+'</main>';
  }

  function renderBanner() {
    return '<div class="banner ' + (state.ui.stale ? 'show' : '') + '" id="banner">' +
      '<span>' + I('info') + ' محتوای پیش فرض این فایل به روزرسانی شده است. می توانی محتوای جدید را بارگذاری کنی (تیک ها و یادداشت ها حفظ می شوند).</span>' +
      '<button class="btn pri" data-act="apply-stale">بارگذاری محتوای جدید</button>' +
      '<button class="btn" data-act="dismiss-stale">بعداً</button></div>';
  }

  let phaseDrawerScrollY = 0;
  let menuDrawerScrollY = 0;
  function renderMenuDrawer() {
    const open = !!state.ui.menuDrawerOpen;
    return '<div class="menu-drawer-scrim ' + (open ? 'show' : '') + '" id="menuDrawerScrim" data-act="menu-drawer-close" aria-hidden="' + (!open) + '"></div>' +
      '<aside class="menu-drawer ' + (open ? 'open' : '') + '" id="menuNavDrawer" role="dialog" aria-modal="true" aria-label="منوی ابزارها" aria-hidden="' + (!open) + '">' +
      '<header class="menu-drawer-head"><div><b>' + I('more') + ' منو</b><small>نمای کلی، فیلترها، ابزارها و دفترچه</small></div>' +
      '<button type="button" class="iact" data-act="menu-drawer-close" title="بستن منو (Esc)" aria-label="بستن منو">' + I('x') + '</button></header>' +
      '<div class="menu-drawer-list">' + (open ? sideCards(false) : '') + '</div>' +
      '</aside>';
  }
  function refreshMenuDrawer() {
    const scrim = $('#menuDrawerScrim'), oldDrawer = $('#menuNavDrawer');
    if (!scrim || !oldDrawer) { render(); return; }
    const template = document.createElement('template');
    template.innerHTML = renderMenuDrawer();
    scrim.replaceWith(template.content.firstElementChild);
    oldDrawer.replaceWith(template.content.lastElementChild);
    updateHeaderCompact();
  }
  function toggleMenuDrawer(force) {
    const wasOpen = !!state.ui.menuDrawerOpen;
    const open = typeof force === 'boolean' ? force : !wasOpen;
    if (open && !wasOpen) {
      if (state.ui.phaseDrawerOpen) togglePhaseDrawer(false);
      menuDrawerScrollY = window.scrollY;
    }
    const restoreY = open ? menuDrawerScrollY : (wasOpen ? menuDrawerScrollY : window.scrollY);
    state.ui.menuDrawerOpen = open;
    document.body.classList.toggle('menu-nav-open', open);
    save(); refreshMenuDrawer();
    if (document.scrollingElement) document.scrollingElement.scrollTop = restoreY;
    updateHeaderCompact();
  }
  function togglePhaseDrawer(force) {
    const wasOpen = !!state.ui.phaseDrawerOpen;
    const open = typeof force === 'boolean' ? force : !wasOpen;
    if (open && !wasOpen) {
      if (state.ui.menuDrawerOpen) toggleMenuDrawer(false);
      phaseDrawerScrollY = window.scrollY;
    }
    const restoreY = open ? phaseDrawerScrollY : (wasOpen ? phaseDrawerScrollY : window.scrollY);
    state.ui.phaseDrawerOpen = open;
    document.body.classList.toggle('phase-nav-open', open);
    save(); refreshPhaseDrawer();
    // Locking body scroll for the scrim can alter the browser's stored scroll position; restore it exactly.
    if (document.scrollingElement) document.scrollingElement.scrollTop = restoreY;
    updateHeaderCompact();
    const phaseFab=$('#phaseFab'); if(phaseFab)phaseFab.setAttribute('aria-expanded',open?'true':'false');
    if (open) requestAnimationFrame(() => { const q = $('#phaseDrawerSearch'); if (q) { try { q.focus({ preventScroll:true }); } catch (_) { q.focus(); } } });
    else if(phaseFab)requestAnimationFrame(()=>{try{phaseFab.focus({preventScroll:true});}catch(_){phaseFab.focus();}});
  }
  function updateHeaderCompact() {
    const compact = window.scrollY > 48;
    const header = $('.topbar');
    if (header) header.classList.toggle('compact', compact);
    document.body.classList.toggle('header-compact', compact);
  }
  function editModeHasScrollableAncestor(target, deltaY) {
    let node=target&&target.nodeType===1?target:(target&&target.parentElement);
    while(node&&node!==document.body&&node!==document.documentElement){
      const style=getComputedStyle(node),overflow=style.overflowY,max=node.scrollHeight-node.clientHeight;
      if((overflow==='auto'||overflow==='scroll')&&max>1){
        if(deltaY<0&&node.scrollTop>1||deltaY>0&&node.scrollTop<max-1)return true;
      }
      node=node.parentElement;
    }
    return false;
  }
  function routeEditModeWheel(e) {
    if(!state.ui.editing||e.defaultPrevented||e.ctrlKey||!e.deltaY)return;
    const body=document.body;
    if(body.classList.contains('nb-open')||body.classList.contains('phase-nav-open')||body.classList.contains('modal-open'))return;
    const target=e.target&&e.target.nodeType===1?e.target:(e.target&&e.target.parentElement);
    if(target&&target.closest&&target.closest('.nb,.modal,.phase-drawer,.phase-drawer-scrim'))return;
    // Only route wheel events originating on editable surfaces; ordinary page scrolling stays native/passive.
    if(!target||!target.closest||!target.closest('[contenteditable="true"],textarea[data-note]'))return;
    const lineHeight=target?parseFloat(getComputedStyle(target).lineHeight)||24:24;
    const delta=e.deltaMode===1?e.deltaY*lineHeight:(e.deltaMode===2?e.deltaY*innerHeight:e.deltaY);
    if(editModeHasScrollableAncestor(target,delta))return;
    e.preventDefault();
    const root=document.documentElement,scroller=document.scrollingElement||root,oldBehavior=root.style.scrollBehavior;
    root.style.scrollBehavior='auto';
    const max=Math.max(0,scroller.scrollHeight-scroller.clientHeight);
    scroller.scrollTop=Math.max(0,Math.min(max,scroller.scrollTop+delta));
    root.style.scrollBehavior=oldBehavior;
  }
  document.addEventListener('wheel',routeEditModeWheel,{capture:true,passive:false});
  function refreshPhaseTrees() {
    const main=$('#sideNavList');
    if(main){const y=main.scrollTop;main.innerHTML=renderPhaseTree('sideNavList','');main.scrollTop=y;}
    const drawer=$('#phaseDrawerNavList');
    if(drawer&&state.ui.phaseDrawerOpen){const y=drawer.scrollTop;drawer.innerHTML=renderPhaseTree('phaseDrawerNavList',state.ui.phaseDrawerQuery);drawer.scrollTop=y;}
  }
  function renderSidebarLayoutOnly() {
    const old=$('.layout'), phases=$('#phases');
    if(!old||!phases){render();return;}
    const sidePos={};$$('.side').forEach(el=>{const k=el.classList.contains('side-phases')?'phases':(el.classList.contains('side-tools')?'tools':'single');sidePos[k]=el.scrollTop;});
    const nav=$('#sideNavList'),navY=nav?nav.scrollTop:0;
    const mode=validSidebarLayout(state.ui.sidebarLayout);
    const fresh=document.createElement('div');fresh.className='layout';fresh.dataset.sidebarLayout=mode;fresh.setAttribute('style',sidebarLayoutStyle());fresh.innerHTML=renderSide()+renderSidebarResizeHandles(mode);
    phases.remove();old.replaceWith(fresh);fresh.appendChild(phases);
    $$('.side').forEach(el=>{const k=el.classList.contains('side-phases')?'phases':(el.classList.contains('side-tools')?'tools':'single');if(sidePos[k]!=null)el.scrollTop=sidePos[k];});
    const newNav=$('#sideNavList');if(newNav)newNav.scrollTop=navY;
    $$('.sidebar-layout-btn').forEach(btn=>{
      if(btn.closest('.layout'))return;
      const place=btn.classList.contains('header')?'header':(btn.classList.contains('header-mobile')?'header-mobile':(btn.classList.contains('drawer')?'drawer':'sidebar'));
      const hadFocus=document.activeElement===btn,template=document.createElement('template');template.innerHTML=sidebarLayoutButton(place);const replacement=template.content.firstElementChild;
      btn.replaceWith(replacement);if(hadFocus)try{replacement.focus({preventScroll:true});}catch(_){replacement.focus();}
    });
    refreshFontScales();updateHeaderCompact();syncSidebarResizeA11y(fresh);if (state.ui.menuDrawerOpen) refreshMenuDrawer();
  }
  function renderTopOnly() {
    const top=$('.topbar');if(!top){render();return;}
    const active=document.activeElement,inside=top.contains(active),focusId=inside?active.id:'',act=inside&&active.dataset?active.dataset.act:'',id=inside&&active.dataset?active.dataset.id:'',scope=inside&&active.dataset?active.dataset.scope:'',dir=inside&&active.dataset?active.dataset.dir:'';
    top.outerHTML=renderTop();
    let next=focusId?document.getElementById(focusId):null;
    if(!next&&act)next=$$('.topbar [data-act]').find(e=>e.dataset.act===act&&(e.dataset.id||'')===(id||'')&&(e.dataset.scope||'')===(scope||'')&&(e.dataset.dir||'')===(dir||''));
    if(inside&&next)try{next.focus({preventScroll:true});}catch(_){next.focus();}
    updateHeaderCompact();
  }
  let searchRenderGeneration=0;
  function renderSearchResults() {
    const main=$('#phases'); if(!main){render();return;}
    const y=window.scrollY,query=String(state.ui.q||'').trim();
    const token=++searchRenderGeneration;
    main.dataset.searchRendering='true';
    if(spyObs)spyObs.disconnect();
    main.replaceChildren();
    let i=0,visible=0;const pending=[],pendingSubs=[];
    const finish=()=>{
      if(!visible)main.innerHTML='<div class="card"><div class="empty">موردی با این فیلتر/جست وجو پیدا نشد.</div></div>';
      if(document.scrollingElement)document.scrollingElement.scrollTop=y;
      spy();updateHeaderCompact();
      attachmentStore.resolve(main);
      main.dataset.searchRendering='false';
    };
    const batch=()=>{
      if(token!==searchRenderGeneration||!main.isConnected)return;
      const start=performance.now(),frag=document.createDocumentFragment(),containers=[];let count=0;
      while(i<state.plan.length&&(count===0||performance.now()-start<6)){
        const ph=state.plan[i],data=phaseRenderData(ph,i,true);i++;count++;
        if(data){const t=document.createElement('template');t.innerHTML=data.html;const section=t.content.firstElementChild,container=section&&section.querySelector('.steps');frag.appendChild(t.content);visible++;if(container&&data.steps.length)containers.push({ph,steps:data.steps,container,index:0});}
      }
      if(frag.childNodes.length)main.appendChild(frag);
      pending.push(...containers);
      const stepStart=performance.now();let stepWork=0;
      while(pending.length&&(stepWork===0||performance.now()-stepStart<4)){
        const item=pending[0];
        if(item.index>=item.steps.length){pending.shift();continue;}
        const step=item.steps[item.index++],ix=item.ph.steps.indexOf(step),t=document.createElement('template');
        t.innerHTML=stepHTML(item.ph,step,ix,true);const article=t.content.firstElementChild,subList=article&&article.querySelector('.subs');
        const subSlot=subList?document.createComment('deferred-substeps'):null;if(subList)subList.replaceWith(subSlot);
        item.container.appendChild(t.content);stepWork++;
        if(subList){const subs=[];step.subs.forEach((x,index)=>{if(subShown(item.ph,step,x))subs.push({x,index});});if(subs.length)pendingSubs.push({ph:item.ph,step,si:ix,list:subList,slot:subSlot,subs,index:0});else subSlot.replaceWith(subList);}
        if(item.index>=item.steps.length)pending.shift();
      }
      const subStart=performance.now();let subWork=0;
      while(pendingSubs.length&&(subWork===0||performance.now()-subStart<4)){
        const item=pendingSubs[0];
        if(item.index>=item.subs.length){item.slot.replaceWith(item.list);pendingSubs.shift();continue;}
        const sub=item.subs[item.index++],t=document.createElement('template');
        t.innerHTML=subHTML(item.ph,item.step,sub.x,sub.index,item.si);item.list.appendChild(t.content);subWork++;
        if(item.index>=item.subs.length){item.slot.replaceWith(item.list);pendingSubs.shift();}
      }
      if(i<state.plan.length||pending.length||pendingSubs.length)requestAnimationFrame(batch);
      else finish();
    };
    requestAnimationFrame(batch);
  }
  function refreshPhaseDrawer() {
    const scrim=$('#phaseDrawerScrim'),oldDrawer=$('#phaseNavDrawer'); if(!scrim||!oldDrawer){render();return;}
    const oldList=$('#phaseDrawerNavList'),oldScroll=oldList?oldList.scrollTop:0;
    const template=document.createElement('template');template.innerHTML=renderPhaseDrawer();
    const newScrim=template.content.firstElementChild,newDrawer=template.content.lastElementChild;
    scrim.replaceWith(newScrim);oldDrawer.replaceWith(newDrawer);
    const list=$('#phaseDrawerNavList');if(list)list.scrollTop=oldScroll;
    const q=$('#phaseDrawerSearch');if(q){const caret=q.value.length;try{q.focus({preventScroll:true});}catch(_){q.focus();}try{q.setSelectionRange(caret,caret);}catch(_){}}
    updateHeaderCompact();
  }
  function render() {
    searchRenderGeneration++;
    const y = window.scrollY;
    const sideScroll = {};
    $$('.side').forEach(el => {
      const k = el.classList.contains('side-phases') ? 'phases' : (el.classList.contains('side-tools') ? 'tools' : 'single');
      sideScroll[k] = el.scrollTop;
    });
    const navScroll = {};
    $$('.navlist').forEach(el => { navScroll[el.id || ('nav-' + Object.keys(navScroll).length)] = el.scrollTop; });
    const mode = validSidebarLayout(state.ui.sidebarLayout);
    const phaseContent = state.ui.editing ? '<main class="phases" id="phases" aria-label="مراحل نقشه راه"></main>' : renderPhases();
    $('#app').innerHTML = '<div class="wrap">' + renderBanner() + renderTop() +
      '<div class="layout" data-sidebar-layout="' + mode + '" style="' + sidebarLayoutStyle() + '">' + renderSide() + renderSidebarResizeHandles(mode) + phaseContent + '</div>' +
      '<div class="foot">' +
      '<div class="legend">' +
      '<span><i style="background:#34d399"></i> انجام شده</span>' +
      '<span><i style="background:#2dd4bf"></i> پیشرفت</span>' +
      '<span><i style="background:#f59e0b"></i> نکته تجربی</span>' +
      '<span><i style="background:#6366f1"></i> B2B</span>' +
      '</div>' +
      'نسخه نهایی برنامه: V' + APP_VERSION + ' · ' +
      'این فایل یک چک لیست اجرایی زنده است: تیک بزن، یادداشت بنویس، ساختار را ویرایش کن و خروجی JSON بگیر. ' +
      'همه داده ها فقط در مرورگر خودت ذخیره می شود (بدون سرور، بدون وابستگی).' +
      '</div></div>' + renderPhaseDrawer() + renderMenuDrawer();
    document.body.classList.toggle('editing', !!state.ui.editing);
    document.body.classList.toggle('phase-nav-open', !!state.ui.phaseDrawerOpen);
    $$('.phase').forEach(sect => {
      const ph = findPhase(sect.dataset.phase), box = sect.querySelector('.ph-ck input[data-ck]');
      if (!ph || !box) return;
      const c = counts(ph);
      box.checked = phaseDone(ph, c);
      box.indeterminate = phasePartial(ph, c);
    });
    $$('.side').forEach(el => {
      const k = el.classList.contains('side-phases') ? 'phases' : (el.classList.contains('side-tools') ? 'tools' : 'single');
      if (sideScroll[k] != null) el.scrollTop = sideScroll[k];
    });
    $$('.navlist').forEach(el => { if (navScroll[el.id] != null) el.scrollTop = navScroll[el.id]; });
    // Preserve the exact page position without triggering a smooth-scroll animation.
    document.scrollingElement.scrollTop = y;
    refreshFontScales();
    attachmentStore.resolve($('#app'));
    attachmentStore.updateGuidance(document);
    syncSidebarResizeA11y($('.layout'));
    updateHeaderCompact();
    const phaseFab = $('#phaseFab');
    if (phaseFab) phaseFab.setAttribute('aria-expanded', state.ui.phaseDrawerOpen ? 'true' : 'false');
    if (state.ui.editing) renderSearchResults(); else spy();
  }

  function updateStats() {
    let g = { d:0, t:0, notes:0, p:0 };
    const phaseStats = [], navDone = Object.create(null);
    state.plan.forEach(ph => {
      const c = counts(ph); phaseStats.push([ph,c]);
      g.d += c.d; g.t += c.t; g.notes += c.notes;
      navDone[ph.id] = phaseDone(ph, c);
      ph.steps.forEach(s => {
        navDone[s.id] = stepDone(s);
        s.subs.forEach(x => { navDone[x.id] = !!state.checks[x.id]; });
      });
    });
    g.p = pct(g.d,g.t);
    const C = 150.8, ring = $('[data-ring]');
    if (ring) ring.setAttribute('stroke-dashoffset', (C * (1 - g.p / 100)).toFixed(1));
    $$('[data-stat="ringpct"]').forEach(e => e.textContent = fa(g.p) + '٪');
    $$('[data-stat="pctside"]').forEach(e => e.textContent = fa(g.p) + '٪');
    $$('[data-stat="done"]').forEach(e => e.textContent = fa(g.d));
    $$('[data-stat="todo"]').forEach(e => e.textContent = fa(g.t - g.d));
    $$('[data-stat="notes"]').forEach(e => e.textContent = fa(g.notes));
    $$('[data-stat="phases"]').forEach(e => e.textContent = fa(state.plan.length));
    $$('[data-pbar="global"]').forEach(e => e.style.width = g.p + '%');
    phaseStats.forEach(([ph,c]) => {
      $$('[data-pbar="' + ph.id + '"]').forEach(e => e.style.width = c.p + '%');
      $$('[data-ppct="' + ph.id + '"]').forEach(e => e.innerHTML = fa(c.p) + '٪ <small>پیشرفت</small>');
      $$('[data-nav="' + ph.id + '"]').forEach(e => e.textContent = fa(c.d) + '/' + fa(c.t));
    });
    // رنگ کامل شدن در درخت سایدبار/Drawer بدون رندر مجدد، همان لحظه تغییر می کند.
    $$('[data-nav-role]').forEach(el => el.classList.toggle('done', !!navDone[el.dataset.id]));
    const m = $('.meta-row');
    if (m) m.innerHTML = '<span>' + fa(g.d) + ' مورد از ' + fa(g.t) + ' انجام شده</span><span>' + fa(g.t - g.d) + ' باقی مانده</span>';
    $$('[data-mkcount]').forEach(e => { e.textContent = fa(markCount(e.dataset.mkcount)); });
    $$('[data-mcount]').forEach(e => {
      const k = e.dataset.mcount;
      e.textContent = fa(k === 'done' ? g.d : (k === 'todo' ? (g.t - g.d) : g.t));
    });
  }

  /* ---------- عملیات ساختاری ------------------------------------------- */
  function findPhase(id) { return state.plan.filter(p => p.id === id)[0]; }
  function findStepOfSub(subId) {
    for (const ph of state.plan) for (const s of ph.steps) if (s.subs.some(x => x.id === subId)) return { ph, s };
    return null;
  }
  function findStep(id) {
    for (const ph of state.plan) { const s = ph.steps.filter(x => x.id === id)[0]; if (s) return { ph, s }; }
    return null;
  }
  function touch() { state.ui.stale = false; save(); }

  /* درج در جایگاه دلخواه؛ مقدار خالی رفتار پیش فرض را حفظ می کند. */
  function parseInsertPosition(raw, label, count) {
    if (raw == null || !String(raw).trim()) return { ok:true, index:null };
    const m = norm(raw).match(/^([0-9]+)$/);
    if (!m) { toast('در «محل درج ' + label + '» فقط عدد وارد کن.'); return {ok:false,index:null}; }
    const n = Number(m[1]);
    if (!Number.isInteger(n) || n < 1 || n > count + 1) {
      toast('محل درج ' + label + ' باید بین ۱ تا ' + fa(count + 1) + ' باشد.');
      return {ok:false,index:null};
    }
    return {ok:true,index:n - 1};
  }
  function addStep(phId, afterStepId, position) {
    const ph = findPhase(phId); if (!ph) return;
    const pos = parseInsertPosition(position, 'مرحله', ph.steps.length);
    if (!pos.ok) return;
    const s = { id: uid('st'), title: 'مرحله جدید — عنوان را در حالت ویرایش تغییر بده', meta: '≈ ؟ · مسئول', tip: '', subs: [] };
    delete state.checks[ph.id];
    if (pos.index != null) ph.steps.splice(pos.index, 0, s);
    else if (afterStepId && typeof afterStepId === 'string') {
      const i = ph.steps.map(x => x.id).indexOf(afterStepId);
      ph.steps.splice(i + 1, 0, s);
    } else ph.steps.push(s);
    state.open[phId] = true; touch(); render();
    flash(s.id);
    toast('مرحله جدید در جایگاه ' + fa(ph.steps.indexOf(s) + 1) + ' درج شد؛ شماره بقیه مراحل خودکار به روز شد.');
  }
  function addSub(stepId, after, position) {
    const f = findStep(stepId); if (!f) return;
    const list = f.s.subs;
    const pos = parseInsertPosition(position, 'زیرمرحله', list.length);
    if (!pos.ok) return;
    const item = { id: uid('sb'), title: 'زیرمرحله جدید — متن را ویرایش کن' };
    if (pos.index != null) list.splice(pos.index, 0, item);
    else {
      const i = Number(after);
      if (i >= 0 && i < list.length) list.splice(i + 1, 0, item); else list.push(item);
    }
    touch(); render(); flash(item.id);
    toast('زیرمرحله جدید در جایگاه ' + fa(list.indexOf(item) + 1) + ' درج شد؛ شماره بقیه خودکار به روز شد.');
  }
  function addPhase(afterId, position) {
    const pos = parseInsertPosition(position, 'فاز', state.plan.length);
    if (!pos.ok) return;
    const ph = { id: uid('ph'), icon: '🧩', title: 'فاز جدید — عنوان را ویرایش کن', goal: 'هدف این فاز را بنویس.', dod: 'شرط اتمام این فاز را بنویس.', steps: [] };
    if (pos.index != null) state.plan.splice(pos.index, 0, ph);
    else {
      const i = state.plan.map(p => p.id).indexOf(afterId);
      state.plan.splice(i >= 0 ? i + 1 : state.plan.length, 0, ph);
    }
    touch(); render(); flash(ph.id);
    toast('فاز جدید در جایگاه ' + fa(state.plan.indexOf(ph) + 1) + ' درج شد؛ شماره همه فازها خودکار به روز شد.');
  }
  async function delPhase(id) {
    const ph = findPhase(id); if (!ph) return;
    if (!await showInlineConfirm('فاز «' + ph.title + '» با همه مراحلش حذف شود؟','حذف فاز')) return;
    state.plan = state.plan.filter(p => p.id !== id); touch(); render(); toast('فاز حذف شد');
  }
  async function delStep(id) {
    const f = findStep(id); if (!f) return;
    if (!await showInlineConfirm('این مرحله حذف شود؟','حذف مرحله')) return;
    f.ph.steps = f.ph.steps.filter(s => s.id !== id); touch(); render(); toast('مرحله حذف شد');
  }
  function delSub(stepId, i) {
    const f = findStep(stepId); if (!f) return;
    f.s.subs.splice(Number(i), 1); touch(); render(); toast('زیرمرحله حذف شد');
  }
  function moveStep(id, dir) {
    const f = findStep(id); if (!f) return;
    const arr = f.ph.steps, i = arr.map(s => s.id).indexOf(id), j = i + Number(dir);
    if (j < 0 || j >= arr.length) return;
    arr.splice(j, 0, arr.splice(i, 1)[0]); touch(); render(); flash(id);
  }
  function moveSub(stepId, i, dir) {
    const f = findStep(stepId); if (!f) return;
    const arr = f.s.subs, a = Number(i), b = a + Number(dir);
    if (b < 0 || b >= arr.length) return;
    arr.splice(b, 0, arr.splice(a, 1)[0]); touch(); render(); flash(arr[b].id);
  }
  function movePhaseTo(id, dir) {
    const i = state.plan.map(p => p.id).indexOf(id), j = i + Number(dir);
    if (j < 0 || j >= state.plan.length) return;
    state.plan.splice(j, 0, state.plan.splice(i, 1)[0]); touch(); render(); flash(id);
  }
  function flash(id) {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.add('hit');
    if (el.scrollIntoView) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
    setTimeout(() => el.classList.remove('hit'), 1500);
  }

  async function resetPlanContent() {
    if(!await showInlineConfirm('ساختار مراحل به حالت پیش فرض این فایل بازگردد؟ (تیک ها حفظ می شوند)','بازنشانی ساختار'))return;
    state.plan=clone(DEFAULT_PLAN);state.customized=false;state.ui.stale=false;
    saveNow();render();toast('محتوای پیش فرض بازنشانی شد');
  }
  /* ---------- پاکسازی همه پاسخ ها --------------------------------------- */
  async function cleanAll() {
    const g = counts();
    const nbLen = nbAllText().length;
    const msg = 'همه پاسخ های فعلی پاک شوند؟\n\n' +
      '• ' + fa(g.d) + ' تیک ثبت شده\n' +
      '• ' + fa(g.notes) + ' یادداشت مرحله/زیرمرحله\n' +
      '• دفترچه یادداشت (' + fa((state.nbNotes || []).length) + ' یادداشت، ' + fa(nbLen) + ' کاراکتر)\n' +
      (fileStore.connected ? '• محتوای فایل ' + SIDECAR + ' هم خالی می شود\n' : '') +
      '\nساختار و متن مراحل دست نخورده می ماند. این کار قابل بازگشت نیست.';
    if (!await showInlineConfirm(msg,'پاکسازی همه پاسخ ها')) return;
    state.checks = {};
    state.notes = {};
    state.marks = { archived: {}, review: {} };
    state.ui.markFilters = [];
    state.openNotes = {};state.noteModes={};state.noteDirections={};
    state.notebook = '';
    state.nbNotes = [];state.nbFolders=[];state.nbTags=[];state.nbCategories=[];state.nbBrowseMode='all';state.nbBrowseValue='';state.nbSort='updated';state.nbCardEditorId='';state.nbCardEditorType='';
    state.nbActiveId = '';
    state.nbSecondaryId = '';
    state.nbSplit = false;
    state.nbMode = 'edit';
    state.nbSecondaryMode = 'edit';
    state.nbView = 'list';
    saveNow();
    const done = () => { render(); nbRender(); if (fileStore.connected) fileStore.write(); toast('همه پاسخ ها پاک شد' + (fileStore.connected ? ' و فایل ' + SIDECAR + ' خالی شد.' : '.')); };
    setTimeout(done, 30);
  }

  function closeMenus() {
    $$('.menu-wrap.open').forEach(w => w.classList.remove('open'));
  }

  /* ---------- خروجی ها -------------------------------------------------- */
  const BOM = '\uFEFF';   // برای نمایش درست فارسی در Notepad ویندوز
  function downloadBlob(name, blob) {
    try {
      if (!(blob instanceof Blob)) throw new Error('download expects a Blob');
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = name; a.rel = 'noopener';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 8000);
      toast('دانلود شروع شد: ' + name);
      return true;
    } catch (e) {
      toast('مرورگر اجازه دانلود نداد؛ متن در بخش خروجی همین صفحه آماده است.');
      return false;
    }
  }
  function download(name, text, type) {
    try {
      const isText = /json|markdown|text/i.test(type || 'application/json');
      const body = (isText && /markdown|text\/plain/i.test(type || '')) ? (BOM + text) : text;
      const b = new Blob([body], { type: (type || 'application/json') + ';charset=utf-8' });
      return downloadBlob(name, b);
    } catch (e) {
      toast('مرورگر اجازه دانلود نداد — متن در بخش خروجی همین صفحه آماده است.');
      return false;
    }
  }

  const ZIP_CRC_TABLE = (() => {
    const table = new Uint32Array(256);
    for (let n=0;n<256;n++) { let c=n; for(let k=0;k<8;k++) c=(c&1)?(0xedb88320^(c>>>1)):(c>>>1); table[n]=c>>>0; }
    return table;
  })();
  const ZIP_ENCODER = typeof TextEncoder === 'function' ? new TextEncoder() : null;
  function zipU16(view, offset, value) { view.setUint16(offset, value & 0xffff, true); }
  function zipU32(view, offset, value) { view.setUint32(offset, value >>> 0, true); }
  function zipDosDateTime(date) {
    const year=Math.max(1980,date.getFullYear()),time=(date.getHours()<<11)|(date.getMinutes()<<5)|(Math.floor(date.getSeconds()/2));
    const day=((year-1980)<<9)|((date.getMonth()+1)<<5)|date.getDate();
    return {time,date:day};
  }
  async function zipCrc32(blob) {
    let crc=0xffffffff;
    const consume=chunk=>{for(let i=0;i<chunk.length;i++)crc=ZIP_CRC_TABLE[(crc^chunk[i])&0xff]^(crc>>>8);};
    if (blob && typeof blob.stream === 'function') {
      const reader=blob.stream().getReader();let processed=0;
      try {
        while(true){const part=await reader.read();if(part.done)break;consume(part.value);processed+=part.value.length;if(processed>=4194304){processed=0;await new Promise(resolve=>setTimeout(resolve,0));}}
      } finally { try { reader.releaseLock(); } catch (_) { } }
    } else consume(new Uint8Array(await blob.arrayBuffer()));
    return (crc^0xffffffff)>>>0;
  }
  async function createStoredZip(entries) {
    if (!ZIP_ENCODER) throw new Error('UTF-8 encoder is unavailable');
    if (!Array.isArray(entries) || entries.length>0xffff) throw new Error('Too many ZIP entries');
    const localParts=[],centralParts=[],now=zipDosDateTime(new Date());let localOffset=0,centralSize=0;
    for (const entry of entries) {
      const name=String(entry.name||'').replace(/^\/+/,'');
      const nameBytes=ZIP_ENCODER.encode(name),blob=entry.blob instanceof Blob?entry.blob:new Blob([entry.blob]);
      if(!name||nameBytes.length>0xffff||blob.size>0xffffffff||localOffset>0xffffffff)throw new Error('Attachment is too large for a standard ZIP archive');
      const crc=await zipCrc32(blob),size=blob.size,flag=0x0800;
      const local=new Uint8Array(30);const lv=new DataView(local.buffer);
      zipU32(lv,0,0x04034b50);zipU16(lv,4,20);zipU16(lv,6,flag);zipU16(lv,8,0);zipU16(lv,10,now.time);zipU16(lv,12,now.date);zipU32(lv,14,crc);zipU32(lv,18,size);zipU32(lv,22,size);zipU16(lv,26,nameBytes.length);zipU16(lv,28,0);
      localParts.push(local,nameBytes,blob);localOffset+=local.length+nameBytes.length+size;
      const central=new Uint8Array(46);const cv=new DataView(central.buffer);
      zipU32(cv,0,0x02014b50);zipU16(cv,4,0x0314);zipU16(cv,6,20);zipU16(cv,8,flag);zipU16(cv,10,0);zipU16(cv,12,now.time);zipU16(cv,14,now.date);zipU32(cv,16,crc);zipU32(cv,20,size);zipU32(cv,24,size);zipU16(cv,28,nameBytes.length);zipU16(cv,30,0);zipU16(cv,32,0);zipU16(cv,34,0);zipU16(cv,36,0);zipU32(cv,38,0);zipU32(cv,42,localOffset-(local.length+nameBytes.length+size));
      centralParts.push(central,nameBytes);centralSize+=central.length+nameBytes.length;
    }
    if(localOffset+centralSize>0xffffffff)throw new Error('ZIP archive exceeds 4 GiB');
    const end=new Uint8Array(22),ev=new DataView(end.buffer);
    zipU32(ev,0,0x06054b50);zipU16(ev,4,0);zipU16(ev,6,0);zipU16(ev,8,entries.length);zipU16(ev,10,entries.length);zipU32(ev,12,centralSize);zipU32(ev,16,localOffset);zipU16(ev,20,0);
    return new Blob([...localParts,...centralParts,end],{type:'application/zip'});
  }
  function noteAttachmentPaths(markdown) {
    let source=String(markdown||'').replace(/^ {0,3}(`{3,}|~{3,})[^\n]*\n[\s\S]*?^ {0,3}\1[ \t]*$/gm,'');
    source=source.replace(/(`+)([^`\n]*?)\1(?!`)/g,'');
    const paths=new Set(),add=value=>{const path=mdAttachmentPath(value);if(path)paths.add(path);};
    let match;
    const wiki=/!?\[\[(attachments\/[A-Za-z0-9][A-Za-z0-9._-]{0,150})\]\]/gi;
    while((match=wiki.exec(source)))add(match[1]);
    const inline=/!?\[[^\]]*\]\(\s*<?(attachments\/[A-Za-z0-9][A-Za-z0-9._-]{0,150})(?:[?#][^\s)>]*)?>?(?:\s+["'][^"']*["'])?\s*\)/gi;
    while((match=inline.exec(source)))add(match[1]);
    const reference=/^\s*\[[^\]]+\]:\s*<?(attachments\/[A-Za-z0-9][A-Za-z0-9._-]{0,150})/gmi;
    while((match=reference.exec(source)))add(match[1]);
    return Array.from(paths);
  }
  /* ---------- نمایش درون صفحه ای متن خروجی؛ بدون پنجره شناور یا تب تازه ---------- */
  function closeModal() {
    const m=$('#textModal');if(m)m.remove();
    document.body.classList.remove('modal-open');
  }
  function showTextModal(opts) {
    let m=$('#textModal');
    if(!m){
      m=document.createElement('section');m.id='textModal';m.className='text-panel show';m.setAttribute('aria-label','متن خروجی');
      const top=$('.topbar'),host=top&&top.parentElement?top.parentElement:$('#app');
      if(top&&top.parentElement)top.insertAdjacentElement('afterend',m);else if(host)host.prepend(m);else document.body.appendChild(m);
      m.addEventListener('click',e=>{
        if(e.target.closest('[data-modal="close"]'))closeModal();
        else{
          const b=e.target.closest('[data-modal]');if(!b)return;
          const text=m._text||'',fname=m._name||'report.md';
          if(b.dataset.modal==='copy')fallbackCopy(text,()=>toast('متن کپی شد ✅'));
          else if(b.dataset.modal==='redownload'){if(typeof m._redownload==='function')m._redownload();else download(fname,text,'text/markdown');}
        }
      });
    }
    m._text=opts.text;m._name=opts.filename||'report.md';m._redownload=typeof opts.redownload==='function'?opts.redownload:null;
    m.innerHTML='<div class="text-panel-inner">'+

      '<div class="modal-head"><b>'+esc(opts.title||'متن خروجی')+'</b><span class="modal-hint">'+(opts.mode==='notebook'?'دفترچه یادداشت':'گزارش')+' · '+esc(opts.filename||'')+'</span><button class="iact" data-modal="close" title="بستن">'+I('x')+'</button></div>'+
      '<textarea class="modal-text" readonly spellcheck="false">'+esc(opts.text||'')+'</textarea>'+
      '<div class="modal-foot"><button class="btn" data-modal="copy">'+I('copy')+' کپی متن</button><button class="btn pri" data-modal="redownload">'+I('export')+' دانلود مجدد</button><button class="btn" data-modal="close">بستن بخش</button><span class="modal-note">متن خروجی در همین صفحه نمایش داده می شود.</span></div></div>';
    m.classList.add('show');
    requestAnimationFrame(()=>{if(!m.isConnected)return;const r=m.getBoundingClientRect();if(r.top<0||r.bottom>innerHeight)m.scrollIntoView({block:'start',behavior:'smooth'});});
  }
  function stamp() {
    const d = new Date();
    const p = (n) => (n < 10 ? '0' + n : '' + n);
    return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '-' + p(d.getHours()) + p(d.getMinutes());
  }
  function exportJSON() {
    saveNow();
    const out = {
      app: APP_ID, kind: 'full-state', version: 2, appVersion: APP_VERSION,
      exportedAt: new Date().toISOString(),
      state: state
    };
    download('answers-roadmap-export-' + stamp() + '.json', JSON.stringify(out, null, 2), 'application/json');
  }
  /* فقط پاسخ ها (همان فرمت فایل کناری) — برای فایل سبک و قابل ویرایش دستی */
  function exportAnswers() {
    saveNow();
    const out = fileStore.answerPayload();
    download('answers-roadmap-' + stamp() + '.json', JSON.stringify(out, null, 2), 'application/json');
  }
  function writeSidecarNow() {
    if (!fileStore.connected) { toast('فایلی متصل نیست — اول «اتصال فایل پاسخ ها» را بزن.'); return; }
    fileStore.write().then(ok => { if (ok) toast('پاسخ ها در ' + SIDECAR + ' ذخیره شد ✅'); });
  }
  /* ---------- گزارش MD سه حالته: انجام شده / باقی مانده / کامل ---------- */
  const REPORT_MODES = {
    done: { label: 'فقط کارهای انجام شده', short: 'انجام شده' },
    todo: { label: 'فقط کارهای باقی مانده', short: 'باقی مانده' },
    full: { label: 'گزارش کامل (همه موارد)', short: 'کامل' }
  };
  function buildReport(mode) {
    mode = REPORT_MODES[mode] ? mode : 'full';
    const g = counts();
    const faDate = new Date().toLocaleString('fa-IR');
    let md = '# ' + state.meta.title + '\n\n';
    md += '- نوع گزارش: **' + REPORT_MODES[mode].label + '**\n';
    md += '- تاریخ گزارش: ' + faDate + '\n';
    md += '- پیشرفت کل: **' + fa(g.p) + '٪** (' + fa(g.d) + ' از ' + fa(g.t) + ' مورد)\n';
    md += '- باکس یادداشت ها: ' + fa(g.notes) + ' مورد\n';
    if (fileStore.connected) md += '- منبع ذخیره: ' + SIDECAR + '\n';
    md += '\n---\n';
    let any = false;
    state.plan.forEach(ph => {
      const c = counts(ph);
      const buf = [];
      ph.steps.forEach(s => {
        const isDone = stepDone(s);
        const doneSubs = s.subs.filter(x => !!state.checks[x.id]);
        const todoSubs = s.subs.filter(x => !state.checks[x.id]);
        let subsToShow = [], stepTag = '';
        if (mode === 'done') {
          if (!isDone && !doneSubs.length) return;
          subsToShow = doneSubs;
          stepTag = isDone ? '[x]' : '[~]';
        } else if (mode === 'todo') {
          if (isDone) return;
          subsToShow = todoSubs;
          stepTag = '[ ]';
        } else {
          subsToShow = s.subs;
          stepTag = isDone ? '[x]' : (doneSubs.length ? '[~]' : '[ ]');
        }
        buf.push('\n### ' + stepTag + ' ' + s.title + (s.meta ? '  (' + s.meta + ')' : '') + (s.stack ? '  \u00ab' + s.stack + '\u00bb' : ''));
        subsToShow.forEach(x => {
          const mark = state.checks[x.id] ? '[x]' : '[ ]';
          buf.push('- ' + mark + ' ' + x.title);
          const sn = state.notes['n:' + x.id];
          if (sn && mode !== 'todo') buf.push('    - 🗒 یادداشت: ' + String(sn).replace(/\n/g, ' '));
        });
        const stn = state.notes['n:' + s.id];
        if (stn) buf.push('\n> 📝 **یادداشت مرحله:** ' + String(stn).replace(/\n/g, '\n> '));
      });
      if (buf.length) {
        any = true;
        md += '\n## ' + phaseNumLabel(ph) + ' — ' + stripPhasePrefix(ph.title) + '  —  ' + fa(c.p) + '٪' + '\n';
        if (mode === 'full' && ph.goal) md += '> ' + ph.goal + '\n';
        if (mode === 'full' && ph.dod) md += '\n**شرط اتمام فاز:** ' + ph.dod + '\n';
        md += buf.join('\n') + '\n';
      }
    });
    if (!any) md += '\n_(موردی برای این حالت گزارش وجود ندارد.)_\n';
    const nbList = nbSorted((state.nbNotes || []).filter(n => String(n.body || '').trim() || String(n.title || '').trim()));
    if (nbList.length) {
      md += '\n---\n\n## 📝 دفترچه یادداشت (مستقل) — ' + fa(nbList.length) + ' یادداشت\n';
      nbList.forEach((n, i) => {
        md += '\n### ' + fa(i + 1) + '. ' + (String(n.title || '').trim() || nbTitleFromBody(n.body)) + '\n\n' + String(n.body || '').trim() + '\n';
      });
    } else if ((state.notebook || '').trim()) {
      md += '\n---\n\n## 📝 دفترچه یادداشت (مستقل)\n\n' + state.notebook.trim() + '\n';
    }
    md += '\n---\n\n_ساخته شده با نقشه راه ' + BRAND + ' — ' + faDate + '_\n';
    return md;
  }
  function reportModeCounts() {
    const g = counts();
    return { done: g.d, todo: g.t - g.d, full: g.t };
  }
  function reportMD(mode) {
    mode = REPORT_MODES[mode] ? mode : (state.ui.reportMode || 'full');
    state.ui.reportMode = mode; save();
    const md = buildReport(mode);
    const fname = 'packpolymer-report-' + mode + '-' + stamp() + '.md';
    download(fname, md, 'text/markdown');
    showTextModal({ title: 'گزارش ' + REPORT_MODES[mode].short, text: md, filename: fname, mode: 'report' });
    closeMenus();
  }
  function copyJSON() {
    saveNow();
    const t = JSON.stringify(fileStore.answerPayload(), null, 2);
    const done = () => toast('JSON در کلیپ بورد کپی شد');
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(t).then(done, () => fallbackCopy(t, done));
    } else fallbackCopy(t, done);
  }
  function fallbackCopy(t, cb) {
    const ta = document.createElement('textarea');
    ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); cb(); } catch (e) { toast('کپی نشد؛ از «خروجی JSON» استفاده کن.'); }
    ta.remove();
  }
  function importJSON() {
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = '.json,application/json';
    inp.onchange = () => {
      const f = inp.files && inp.files[0]; if (!f) return;
      const r = new FileReader();
      r.onload = async () => {
        try {
          const raw = String(r.result).replace(/^\uFEFF/, '');
          const d = JSON.parse(raw);
          const st = (d && d.state) ? d.state : d;
          if (!st || typeof st !== 'object') throw new Error('ساختار نامعتبر');
          const isFull = Array.isArray(st.plan) && st.plan.length > 0;
          const msg = isFull
            ? 'وضعیت کامل (ساختار مراحل + پاسخ ها) با فایل ورودی جایگزین شود؟'
            : 'پاسخ های فایل ورودی (تیک ها، یادداشت ها، دفترچه) روی نقشه راه فعلی اعمال شود؟';
          if (!await showInlineConfirm(msg,'اعمال فایل')) return;
          if (isFull) {
            state.plan = st.plan.map(normalizePhase);
            state.open = st.open || {}; state.meta = Object.assign(state.meta, st.meta || {});
            state.ui.stale = false;
          }
          state.checks = st.checks || {};
          state.notes = st.notes || {};
          state.noteDirections=st.noteDirections&&typeof st.noteDirections==='object'?Object.fromEntries(Object.entries(st.noteDirections).map(([key,value])=>[key,normalizeTextDirection(value)])):{};
          state.ui.sidebarLayout = validSidebarLayout(st.sidebarLayout || (st.ui && st.ui.sidebarLayout));
          state.ui.fontScale = clampScale(st.uiFontScale || (st.ui && st.ui.fontScale), state.ui.fontScale);
          state.nbFontScale = clampScale(st.nbFontScale, state.nbFontScale);
          state.nbWidthPct = clampNbWidth(Number(st.nbWidthPct)===78?75:st.nbWidthPct,state.nbWidthPct); state.nbSplitRatio = clampNbSplit(st.nbSplitRatio,state.nbSplitRatio);
          state.nbBodyRatio = clampNbBodyRatio(st.nbBodyRatio,state.nbBodyRatio); state.nbBodyRatioSecondary = clampNbBodyRatio(st.nbBodyRatioSecondary,state.nbBodyRatioSecondary);
          if (st.marks) state.marks = { archived: st.marks.archived || {}, review: st.marks.review || {} };
          if (Array.isArray(st.nbFolders)) state.nbFolders=nbNormalizeFolders(st.nbFolders);
          if (Array.isArray(st.nbTags)) state.nbTags=nbNormalizeValues(st.nbTags);
          if (Array.isArray(st.nbCategories)) state.nbCategories=nbNormalizeValues(st.nbCategories);
          if (Array.isArray(st.nbNotes)) {
            state.nbNotes = st.nbNotes.map(nbNormalizeNote).filter(Boolean);
            state.nbActiveId = st.nbActiveId || '';
            state.nbSecondaryId = st.nbSecondaryId || '';
            state.nbSplit = !!st.nbSplit;
            state.nbMode = ['edit','read','both'].includes(st.nbMode) ? st.nbMode : 'edit';
            state.nbSecondaryMode = ['edit','read','both'].includes(st.nbSecondaryMode) ? st.nbSecondaryMode : 'edit';
            state.nbView = state.nbNotes.length?(st.nbView||'list'):'list';
            if(!state.nbNotes.length){state.nbActiveId='';state.nbSecondaryId='';state.nbSplit=false;}
          } else if (typeof st.notebook === 'string') { state.notebook = st.notebook; state.nbNotes = []; }
          nbMigrate();
          state.customized = !!st.customized;
          state.ui.editing = false;
          saveNow(); render(); nbRender();
          if (fileStore.connected) fileStore.write();
          toast('فایل با موفقیت بارگذاری شد ✅');
        } catch (e) { toast('خطا در خواندن فایل JSON'); }
      };
      r.readAsText(f);
    };
    inp.click();
  }


  /* =====================================================================
   *  دفترچه یادداشت مستقل (Notebook) — با پشتیبانی Markdown
   *  مستقل از فاز/مرحله/زیرمرحله؛ در همه جا با دکمه شناور و دکمه هدر
   *  در دسترس است. متن در state.notebook ذخیره و در فایل کناری هم نوشته می شود.
   * ===================================================================== */
  /* --- رندر مینیمال Markdown (بدون وابستگی خارجی) --- */
  function highlightStackEscaped(text) {
    const term = String(state.ui.stack || '').trim();
    if (!term) return text;
    const needle = esc(term).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    if (!needle) return text;
    try { return text.replace(new RegExp(needle, 'gi'), m => '<mark class="hl-stack">' + m + '</mark>'); }
    catch (e) { return text; }
  }
  function mdInlineFormat(escapedText) {
    let x = highlightStackEscaped(String(escapedText || ''));
    x = x.replace(/==([^=\n]+?)==/g, '<mark>$1</mark>');
    x = x.replace(/\*\*\*([^\n]+?)\*\*\*/g, '<strong><em>$1</em></strong>');
    x = x.replace(/___([^\n]+?)___/g, '<strong><em>$1</em></strong>');
    x = x.replace(/~~([^~\n]+?)~~/g, '<del>$1</del>');
    x = x.replace(/\*\*([^*\n]+?)\*\*/g, '<strong>$1</strong>');
    x = x.replace(/__([^_\n]+?)__/g, '<strong>$1</strong>');
    x = x.replace(/(^|[^*])\*([^*\n]+?)\*(?!\*)/g, '$1<em>$2</em>');
    x = x.replace(/(^|[^A-Za-z0-9_])_([^_\n]+?)_(?![A-Za-z0-9_])/g, '$1<em>$2</em>');
    return x;
  }
  function mdTrimUrlTail(value) {
    let url = String(value || ''), tail = '';
    const trailing = /[.,!?;:،؛؟۔…*]+$/u;
    while (url && trailing.test(url) && !/&amp;$/.test(url)) {
      const ch = url.slice(-1); url = url.slice(0, -1); tail = ch + tail;
    }
    const pairs = [[')', '('], [']', '['], ['}', '{']];
    pairs.forEach(([close, open]) => {
      while (url.endsWith(close) && (url.split(close).length - 1) > (url.split(open).length - 1)) {
        url = url.slice(0, -1); tail = close + tail;
      }
    });
    return { url, tail };
  }
  const ATTACHMENT_MIME_BY_EXT = Object.freeze({
    png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',gif:'image/gif',webp:'image/webp',avif:'image/avif',bmp:'image/bmp',svg:'image/svg+xml',heic:'image/heic',
    mp4:'video/mp4',m4v:'video/x-m4v',mov:'video/quicktime',webm:'video/webm',ogv:'video/ogg','3gp':'video/3gpp',mkv:'video/x-matroska',
    mp3:'audio/mpeg',m4a:'audio/mp4',aac:'audio/aac',wav:'audio/wav',ogg:'audio/ogg',oga:'audio/ogg',opus:'audio/opus',flac:'audio/flac',aiff:'audio/aiff',aif:'audio/aiff',
    pdf:'application/pdf',txt:'text/plain',md:'text/markdown',csv:'text/csv',json:'application/json',zip:'application/zip',doc:'application/msword',docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    xls:'application/vnd.ms-excel',xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',ppt:'application/vnd.ms-powerpoint',pptx:'application/vnd.openxmlformats-officedocument.presentationml.presentation'
  });
  function mdAttachmentPath(value) {
    const match=String(value||'').trim().match(/^attachments\/([A-Za-z0-9][A-Za-z0-9._-]{0,150})$/i);
    return match?'attachments/'+match[1]:'';
  }
  function mdAttachmentMime(href) {
    const path=String(href||'').split(/[?#]/,1)[0],match=path.match(/\.([a-z0-9]{1,12})$/i);
    return match?(ATTACHMENT_MIME_BY_EXT[match[1].toLowerCase()]||''):'';
  }
  function mdSafeUrl(value, image) {
    const href=String(value||'').trim().replace(/^&lt;/i,'').replace(/&gt;$/i,'');
    if(!href||/[\u0000-\u001f\u007f]/.test(href)||href.startsWith('//'))return '';
    if(/^(?:https?:\/\/|mailto:)/i.test(href))return href;
    // Keep legacy embedded media readable; newly inserted files use attachments/ paths instead.
    if(image&&/^data:(?:image|video|audio)\/[a-z0-9.+-]+;base64,[a-z0-9+/=]+$/i.test(href))return href;
    if(/^[a-z][a-z0-9+.-]*:/i.test(href))return '';
    return href;
  }
  function mdMediaMarkup(alt, href, titleAttr) {
    const data=String(href||'').match(/^data:(image|video|audio)\/([a-z0-9.+-]+);base64,/i);
    const path=mdAttachmentPath(href),mime=data?(data[1].toLowerCase()+'/'+data[2].toLowerCase()):(path?mdAttachmentMime(path):'');
    const kind=mime.split('/')[0],title=titleAttr||'',pathAttr=path?' data-attachment-path="'+esc(path)+'"':'';
    if((kind==='video'||kind==='audio')&&mime){
      return '<'+kind+' class="md-media md-'+kind+'" controls preload="metadata"'+(kind==='video'?' playsinline':'')+' aria-label="'+alt+'"'+title+pathAttr+'><source src="'+href+'" type="'+mime+'"></'+kind+'>';
    }
    return '<img class="md-image" src="'+href+'" alt="'+alt+'"'+title+pathAttr+' loading="lazy" decoding="async" referrerpolicy="no-referrer">';
  }
  function mdAttachmentMarkup(value, embed) {
    const path=mdAttachmentPath(value);if(!path)return null;
    const name=path.slice('attachments/'.length);
    if(embed)return mdMediaMarkup(esc(name),path,'');
    return '<a class="md-attachment-link" href="'+esc(path)+'" data-attachment-path="'+esc(path)+'" download="'+esc(name)+'" rel="noopener noreferrer"><span aria-hidden="true">📎</span> '+esc(name)+'</a>';
  }
  function mdRefKey(value) { return String(value||'').trim().toLowerCase().replace(/\s+/g,' '); }
  function mdInline(t, refs) {
    const held = [], tokenOpen = String.fromCharCode(0xE000), tokenClose = String.fromCharCode(0xE001);
    const tokenPattern = new RegExp(tokenOpen + '([' + String.fromCharCode(0xE100) + '-' + String.fromCharCode(0xE17F) + '])([' + String.fromCharCode(0xE200) + '-' + String.fromCharCode(0xE2FF) + '])' + tokenClose, 'g');
    const privateUsePattern = new RegExp('[' + String.fromCharCode(0xE000) + '-' + String.fromCharCode(0xF8FF) + ']', 'g');
    const hold = html => { const id = held.push(html) - 1; return tokenOpen + String.fromCharCode(0xE100 + (id >> 8)) + String.fromCharCode(0xE200 + (id & 255)) + tokenClose; };
    const restore = (value, depth) => {
      if (depth > 8) return value;
      return String(value).replace(new RegExp(tokenPattern.source, 'g'), (token, high, low) => {
        const id = (high.charCodeAt(0) - 0xE100) * 256 + (low.charCodeAt(0) - 0xE200);
        const html = held[id]; return html == null ? token : restore(html, depth + 1);
      });
    };
    const rawText = String(t == null ? '' : t).replace(privateUsePattern, '�');
    let x = esc(rawText);
    // Protect variable-length inline code spans, including double-backtick code.
    x = x.replace(/(`+)([\s\S]*?)\1(?!`)/g, (_m, ticks, code) => {
      let content=code;
      if(/^ .+ $/.test(content)&&/\S/.test(content))content=content.slice(1,-1);
      return hold('<code>' + content + '</code>');
    });
    // Markdown backslash escapes remain literal and cannot become formatting delimiters.
    x = x.replace(/\\([\\`*_{}\[\]()#+\-.!|>~=])/g, (_m, ch) => hold(ch));
    const refValue = key => refs && refs.get(mdRefKey(key));
    const refMarkup = (tag, label, ref, image) => {
      const data=refValue(ref||label);if(!data)return null;
      const href=mdSafeUrl(esc(data.url),image);if(!href)return null;
      const title=data.title? ' title="'+esc(data.title)+'"':'';
      if(image)return mdMediaMarkup(label,href,title);
      return '<a href="'+href+'"'+title+' target="_blank" rel="noopener noreferrer">'+mdInlineFormat(label)+'</a>';
    };
    // Wiki-style attachments stay compact in the source; media embeds and other files become readable links.
    x = x.replace(/!\[\[(attachments\/[A-Za-z0-9][A-Za-z0-9._-]{0,150})\]\]/gi, (m,path) => {
      const html=mdAttachmentMarkup(path,true);return html?hold(html):m;
    });
    x = x.replace(/(^|[^!])\[\[(attachments\/[A-Za-z0-9][A-Za-z0-9._-]{0,150})\]\]/gi, (m,prefix,path) => {
      const html=mdAttachmentMarkup(path,false);return prefix+(html?hold(html):m);
    });
    // Image syntax is processed before links so the leading exclamation mark is preserved.
    x = x.replace(/!\[([^\]]*)\]\s*\[([^\]]*)\]/g, (m,alt,ref) => {
      const html=refMarkup('img',alt,ref||alt,true);return html?hold(html):m;
    });
    x = x.replace(/!\[([^\]]*)\]\(\s*(<[^>]+>|&lt;[^&]+&gt;|[^)\s]+)(?:\s+["']([^"']*)["'])?\s*\)/gi, (m,alt,destination,title) => {
      const href=mdSafeUrl(destination,true);if(!href)return m;
      const titleAttr=title?' title="'+title+'"':'';
      return hold(mdMediaMarkup(alt,href,titleAttr));
    });
    x = x.replace(/\[([^\]]+)\]\s*\[([^\]]*)\]/g, (m,label,ref) => {
      const html=refMarkup('a',label,ref||label,false);return html?hold(html):m;
    });
    // Inline links support safe web, email and relative destinations plus optional titles.
    x = x.replace(/\[([^\]]+)\]\(\s*(<[^>]+>|&lt;[^&]+&gt;|[^)\s]+)(?:\s+["']([^"']*)["'])?\s*\)/gi, (m,label,destination,title) => {
      const href=mdSafeUrl(destination,false);if(!href)return m;
      const titleAttr=title?' title="'+title+'"':'';
      return hold('<a href="'+href+'"'+titleAttr+' target="_blank" rel="noopener noreferrer">'+mdInlineFormat(label)+'</a>');
    });
    // Shortcut reference links are resolved only when their label was defined above.
    x = x.replace(/\[([^\]]+)\](?![\[(])/g, (m,label) => {
      const html=refMarkup('a',label,label,false);return html?hold(html):m;
    });
    x = x.replace(/&lt;(https?:\/\/[^\s<>]+|mailto:[^\s<>]+)&gt;/gi, (m,url) => {
      const href=mdSafeUrl(url,false);return href?hold('<a href="'+href+'" target="_blank" rel="noopener noreferrer">'+url+'</a>'):m;
    });
    // Auto-link raw http(s) URLs. Trim sentence punctuation and unmatched closing brackets.
    x = x.replace(/(^|[^A-Za-z0-9_/@])((?:https?:\/\/)[^\s<>]+)/gi, (match, prefix, rawUrl) => {
      const trimmed = mdTrimUrlTail(rawUrl);
      if (!trimmed.url) return match;
      return prefix + hold('<a href="' + trimmed.url + '" target="_blank" rel="noopener noreferrer">' + trimmed.url + '</a>') + trimmed.tail;
    });
    x = x.replace(/(^|[\s(])([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})(?=$|[\s).,!?])/gi, (_m,prefix,email) => prefix+hold('<a href="mailto:'+email+'" target="_blank" rel="noopener noreferrer">'+email+'</a>'));
    return restore(mdInlineFormat(x), 0);
  }
  const CODE_HIGHLIGHT_CACHE = new Map();
  const MD_RENDER_CACHE = new Map();
  const CODE_PROFILE_DATA = {
    plain:{kw:'',types:'',builtins:''},
    javascript:{kw:'async await break case catch class const continue debugger default delete do else export extends finally for from function if import in instanceof let new of return static super switch this throw try typeof var void while with yield null undefined true false as implements interface package private protected public enum',types:'Array BigInt Boolean Date Error Function Map Math Number Object Promise Proxy Reflect RegExp Set String Symbol WeakMap WeakSet JSON',builtins:'console document window navigator fetch localStorage sessionStorage setTimeout setInterval clearTimeout clearInterval parseInt parseFloat isNaN Promise Error URL URLSearchParams JSON Math Object Array String Number Boolean Date Map Set RegExp'},
    typescript:{kw:'abstract any as asserts async await bigint boolean break case catch class const constructor continue debugger declare default delete do else enum export extends finally for from function if implements import in infer instanceof interface is keyof let module namespace never new null number object of package private protected public readonly require return satisfies static string super switch symbol this throw try type typeof undefined unique unknown var void while with yield',types:'Array BigInt Boolean Date Error Function Map Math Number Object Promise Proxy Reflect RegExp Set String Symbol WeakMap WeakSet Record Partial Pick Omit Readonly PromiseLike HTMLElement Event',builtins:'console document window navigator fetch setTimeout clearTimeout Promise Error JSON Math Object Array String Number Boolean Date Map Set RegExp'},
    python:{kw:'and as assert async await break class continue def del elif else except False finally for from global if import in is lambda nonlocal not or pass raise return True try while with yield None match case',types:'int float complex bool str bytes bytearray list tuple dict set frozenset range object type property',builtins:'print len range enumerate zip map filter sum min max abs all any open input sorted reversed isinstance issubclass super self cls'},
    bash:{kw:'if then else elif fi for while until do done case esac select function time coproc in break continue return exit export local declare typeset readonly unset shift source eval exec test true false',types:'',builtins:'echo printf read cd pwd set unset trap alias jobs fg bg wait kill source command builtin getopts readlink grep sed awk cat chmod mkdir rm cp mv find xargs curl wget git npm node python python3 sudo apt systemctl'},
    powershell:{kw:'begin break catch class continue data define do dynamicparam else elseif end enum exit filter finally for foreach from function if in param process return switch throw trap try until using var while workflow class enum hidden static true false null begin',types:'array bool byte char decimal double float guid hashtable int long object scriptblock sbyte short single string uint ulong uri ushort void xml',builtins:'Write-Host Write-Output Write-Error Write-Warning Write-Verbose Write-Debug Get-ChildItem Get-Content Set-Content Get-Item Set-Item Get-Process Get-Service Where-Object ForEach-Object Select-Object Sort-Object Measure-Object Test-Path New-Item Remove-Item Invoke-WebRequest ConvertTo-Json ConvertFrom-Json Import-Module Export-Csv'},
    rust:{kw:'as async await break const continue crate dyn else enum extern false fn for if impl in let loop match mod move mut pub ref return self Self static struct super trait true type unsafe use where while yield i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize f32 f64 bool char str',types:'String Vec Option Result Some None Ok Err Box Rc Arc HashMap HashSet Iterator IntoIterator Future',builtins:'println eprintln format print dbg vec panic assert assert_eq todo unreachable'},
    cpp:{kw:'alignas alignof asm auto bool break case catch char class concept const consteval constexpr constinit const_cast continue co_await co_return co_yield decltype default delete do double dynamic_cast else enum explicit export extern false float for friend goto if inline int long mutable namespace new noexcept nullptr operator private protected public register reinterpret_cast requires return short signed sizeof static static_assert static_cast struct switch template this thread_local throw true try typedef typeid typename union unsigned using virtual void volatile wchar_t while',types:'std string vector map unordered_map set unordered_set array pair tuple optional variant unique_ptr shared_ptr weak_ptr size_t ptrdiff_t',builtins:'std cout cin cerr endl move forward make_unique make_shared printf scanf'},
    c:{kw:'auto break case char const continue default do double else enum extern float for goto if inline int long register restrict return short signed sizeof static static_assert struct switch typedef union unsigned void volatile while _Bool _Complex',types:'size_t bool FILE NULL',builtins:'printf scanf fprintf fopen fclose malloc calloc realloc free memcpy memset strlen strcmp strcpy'},
    java:{kw:'abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for if implements import instanceof int interface long native new package private protected public return short static strictfp super switch synchronized this throw throws transient try void volatile while true false null var record sealed permits',types:'String Object Integer Long Double Float Boolean Character Byte Short List Map Set ArrayList HashMap Optional Stream',builtins:'System out println print Math Objects Arrays Collections StringBuilder'},
    csharp:{kw:'abstract as base bool break byte case catch char checked class const continue decimal default delegate do double else enum event explicit extern false finally fixed float for foreach goto if implicit in int interface internal is lock long namespace new null object operator out override params private protected public readonly ref return sbyte sealed short sizeof stackalloc static string struct switch this throw true try typeof uint ulong unchecked unsafe ushort using var virtual void volatile while async await get set init value yield',types:'String Object Int32 Int64 Boolean Task List Dictionary IEnumerable DateTime Guid',builtins:'Console WriteLine ReadLine LINQ Math Task Exception'},
    go:{kw:'break case chan const continue default defer else fallthrough for func go goto if import interface map package range return select struct switch type var true false nil',types:'bool byte complex64 complex128 error float32 float64 int int8 int16 int32 int64 rune string uint uint8 uint16 uint32 uint64 uintptr any',builtins:'append cap clear close complex copy delete imag len make max min new panic print println real recover'},
    ruby:{kw:'BEGIN END alias and begin break case class defined do else elsif end ensure false for if in module next nil not or redo rescue retry return self super then true undef unless until when while yield def',types:'Array Hash Integer Float String Symbol Object Class Module Range',builtins:'puts print p require attr_reader attr_writer attr_accessor raise'},
    php:{kw:'abstract and array as break callable case catch class clone const continue declare default do else elseif empty enddeclare endfor endforeach endif endswitch endwhile eval exit extends final finally fn for foreach function global goto if implements include include_once instanceof insteadof interface isset list match namespace new or print private protected public readonly require require_once return static switch throw trait try unset use var while xor true false null echo',types:'String Integer Float Boolean Array Object Callable Iterable Self Parent',builtins:'echo print count strlen array_map in_array json_encode json_decode'},
    sql:{kw:'add all alter and any as asc between by case cast check column constraint create cross current_date current_time database default delete desc distinct drop else end except exists false fetch from full group having in index inner insert intersect into is join key left like limit not null offset on or order outer primary procedure references right schema select set table then true truncate union unique update use values view when where with',types:'int integer bigint smallint decimal numeric varchar char text date datetime timestamp boolean'},
    css:{kw:'important inherit initial unset auto none block flex grid inline inline-block inline-flex inline-grid absolute relative fixed sticky static center cover contain repeat no-repeat solid dashed dotted hidden visible scroll uppercase lowercase pointer border-box content-box',types:'',builtins:'var calc min max clamp rgb rgba hsl hsla linear-gradient radial-gradient'},
    html:{kw:'doctype html',types:'',builtins:''},
    json:{kw:'true false null',types:'',builtins:''},
    yaml:{kw:'true false null yes no on off',types:'',builtins:''},
    toml:{kw:'true false',types:'',builtins:''},
    kotlin:{kw:'as break class continue do else false for fun if in interface is null object package return super this throw true try typealias typeof val var when while suspend inline data sealed override open abstract actual expect companion constructor init public private protected internal import by field file finally get set enum annotation operator infix tailrec external const lateinit lazy vararg where out reified',types:'Any Array Boolean Byte Char Double Float Int Long Nothing Number Short String Unit UByte UInt ULong UShort List MutableList Map MutableMap Set MutableSet Sequence Result Pair Triple',builtins:'println print readLine TODO require check assert lazy listOf mutableListOf mapOf setOf arrayOf sequenceOf run let apply also with repeat'},
    swift:{kw:'associatedtype break case class continue default defer do else enum extension fallthrough false for func guard if import in init inout internal let nil operator override private protocol public repeat return self static struct subscript super switch throw throws try true typealias var where async await actor some any open fileprivate weak unowned mutating nonmutating nonisolated',types:'Array Bool Character Dictionary Double Error Float Int Optional Set String UInt Void Result Task',builtins:'print dump fatalError precondition assert min max abs zip stride enumerate map filter reduce sorted compactMap flatMap guard'},
    scala:{kw:'abstract case catch class def do else extends false final finally for forSome if implicit import lazy match new null object override package private protected return sealed super this throw trait true try type val var while with yield given using enum export opaque inline end extension open transparent',types:'Any AnyRef AnyVal Boolean Byte Char Double Float Int Long Nothing Null Option Some None Either Left Right List Vector Map Set Seq String Unit Future Try',builtins:'println print require assert assume locally identity implicitly summon classOf'},
    dart:{kw:'abstract as assert async await break case catch class const continue covariant default deferred do else enum export extends extension external factory false final finally for Function get hide if implements import in interface is late library mixin new null on operator part required rethrow return set show static super switch sync this throw true try typedef var void while with yield',types:'bool int double num String Object dynamic List Map Set Iterable Future Stream Duration DateTime Uri Exception',builtins:'print identical assert RangeError ArgumentError StateError FormatException'},
    lua:{kw:'and break do else elseif end false for function goto if in local nil not or repeat return then true until while',types:'string number boolean table function thread userdata',builtins:'print pairs ipairs next select tonumber tostring type assert error pcall xpcall require module rawget rawset setmetatable getmetatable coroutine math string table io os'},
    r:{kw:'if else repeat while function for in next break true false null na na_integer_ na_real_ na_complex_ inf nan',types:'character complex double integer logical numeric raw list matrix array factor data.frame tibble',builtins:'c list vector matrix data.frame tibble library require mean median sd var sum min max range length nrow ncol dim names class str print paste sprintf read.csv write.csv ggplot'},
    matlab:{kw:'break case catch classdef continue else elseif end for function global if otherwise parfor persistent return spmd switch try while arguments properties methods enumeration events',types:'double single logical char string int8 int16 int32 int64 uint8 uint16 uint32 uint64 cell struct table timetable categorical datetime duration calendarDuration',builtins:'disp fprintf sprintf input zeros ones eye rand randi sum mean median min max size length numel reshape plot figure hold grid legend title xlabel ylabel'},
    perl:{kw:'and cmp continue do else elsif eq for foreach ge given gt if last le local lt my ne no not or our package redo require return sub unless until use when while xor state say undef BEGIN END',types:'ARRAY HASH SCALAR REF IO FileHandle',builtins:'print say map grep sort split join keys values each push pop shift unshift splice chomp chop open close die warn eval bless ref defined exists delete'},
    elixir:{kw:'after alias and case catch cond def defdelegate defexception defguard defimpl defmacro defmodule defoverridable defp defprotocol defstruct do else end false fn for if import in not or quote raise receive require rescue reraise try unless unquote use when with true nil',types:'Atom Binary BitString Boolean Charlist Float Function Integer List Map Module PID Port Reference String Tuple',builtins:'IO Enum Map String List Kernel Agent GenServer Task Supervisor Process send receive spawn apply exit raise throw inspect length hd tl'},
    haskell:{kw:'as case class data default deriving do else foreign if import in infix infixl infixr instance let module newtype of qualified then type where hiding family forall mdo rec stock via',types:'Bool Char Double Float Int Integer IO Maybe Either EitherT Ordering String Word List Monad Functor Foldable Traversable Show Eq Ord Num Integral Fractional Applicative',builtins:'map fmap filter foldr foldl foldMap traverse sequence length head tail null reverse concat take drop zipWith sum product maximum minimum show read print putStrLn return pure id const flip curry uncurry'},
    clojure:{kw:'def defn defmacro defmulti defmethod defprotocol defrecord deftype ns require use import refer alias let letfn loop recur if if-let if-not when when-let when-not cond case do fn quote var set! throw try catch finally new reify proxy deftest testing deftest true false nil',types:'Boolean Byte Character Double Float Integer Long Number Object Short String Symbol Keyword PersistentVector PersistentMap PersistentSet LazySeq Atom Agent Ref',builtins:'map reduce filter remove keep mapcat apply comp partial juxt inc dec count conj assoc dissoc get nth first rest next seq cons vector hash-map hash-set atom swap! reset! println print str format slurp spit'},
    groovy:{kw:'abstract as assert break case catch class const continue def default do else enum extends false finally for if implements import in instanceof interface native new null package private protected public return static strictfp super switch synchronized this throw throws trait transient try true volatile while with yield sealed permits record var',types:'String Object Integer Long Double Float Boolean Character Byte Short List Map Set ArrayList HashMap Optional Closure BigDecimal BigInteger',builtins:'println print printf each collect find findAll inject any every withFile readLine tokenize split plus minus times div'},
    objectivec:{kw:'interface implementation protocol end property synthesize dynamic class selector try catch finally throw autoreleasepool import auto break case char const continue default do double else enum extern float for goto if inline int long register restrict return short signed sizeof static struct switch typedef union unsigned void volatile while BOOL YES NO nil Nil self super id SEL instancetype',types:'NSString NSArray NSDictionary NSMutableArray NSMutableDictionary NSNumber NSObject NSError NSData NSURL',builtins:'NSLog alloc init retain release autorelease copy mutableCopy dispatch_async'},
    solidity:{kw:'abstract after alias apply as assembly assert auto break case catch constant constructor continue contract copyof day define do else emit enum error event external false fallback for from function if implements import indexed in inline let library mapping match memory modifier new of override payable pragma private public pure receive return returns revert selfdestruct storage string struct switch this throw true try type typedef typeof unchecked using view virtual while wei gwei ether',types:'address bool bytes string int uint fixed ufixed mapping payable',builtins:'block msg tx abi now require assert revert keccak256 sha256 ecrecover addmod mulmod selfdestruct'},
    graphql:{kw:'query mutation subscription fragment on type input interface union enum scalar schema directive extend implements repeat true false null',types:'ID String Int Float Boolean',builtins:'skip include deprecated specifiedBy defer stream'},
    dockerfile:{kw:'add arg cmd copy entrypoint env expose from healthcheck label maintainer onbuild run shell stopsignal user volume workdir as',types:'',builtins:'apt-get apk dnf yum npm pip python node'},
    makefile:{kw:'ifeq ifneq ifdef ifndef else endif include -include sinclude define endef export unexport override private vpath',types:'',builtins:'all clean install test build'},
    ini:{kw:'true false yes no on off null',types:'',builtins:''},
    nginx:{kw:'http server location upstream map events stream worker_processes worker_connections listen server_name root index proxy_pass proxy_set_header include return rewrite ssl_certificate ssl_certificate_key try_files client_max_body_size gzip access_log error_log',types:'',builtins:''},
    terraform:{kw:'resource data module provider variable output locals terraform backend required_providers count for_each depends_on lifecycle provisioner connection dynamic content source version type default description sensitive nullable validation true false null',types:'string number bool list map set object tuple any',builtins:'length join split lower upper trim replace lookup merge concat format jsonencode jsondecode file templatefile'},
    protobuf:{kw:'syntax package import public option message enum service rpc returns stream oneof map reserved to extensions extend group required optional repeated singular double float int32 int64 uint32 uint64 sint32 sint64 fixed32 fixed64 sfixed32 sfixed64 bool string bytes true false',types:'',builtins:''},
    diff:{kw:'',types:'',builtins:''},
    markdown:{kw:'',types:'',builtins:''}
  };
  const CODE_PROFILES = Object.fromEntries(Object.entries(CODE_PROFILE_DATA).map(([name, p]) => [name, {
    keywords:new Set(String(p.kw||'').split(/\s+/).filter(Boolean)), types:new Set(String(p.types||'').split(/\s+/).filter(Boolean)), builtins:new Set(String(p.builtins||'').split(/\s+/).filter(Boolean))
  }]));
  function highlightCode(source, language) {
    const src = String(source || ''), original = String(language || '').toLowerCase().trim();
    const aliases = {js:'javascript',jsx:'javascript',mjs:'javascript',cjs:'javascript',ts:'typescript',tsx:'typescript',py:'python',shell:'bash',sh:'bash',zsh:'bash',console:'bash',terminal:'bash',ps:'powershell',ps1:'powershell',pwsh:'powershell',rs:'rust','c++':'cpp',cxx:'cpp',cc:'cpp',h:'c',hpp:'cpp',cs:'csharp','c#':'csharp',yml:'yaml',xml:'html',xhtml:'html',htm:'html',md:'markdown',rb:'ruby',kt:'kotlin',kts:'kotlin',m:'matlab',rscript:'r',pl:'perl',pm:'perl',ex:'elixir',exs:'elixir',hs:'haskell',clj:'clojure',cljs:'clojure',cljc:'clojure',groovy:'groovy',objc:'objectivec',objcpp:'objectivec',mm:'objectivec',sol:'solidity',gql:'graphql',graphqls:'graphql',proto:'protobuf',tf:'terraform',hcl:'terraform',mk:'makefile',mak:'makefile',make:'makefile',cfg:'ini',conf:'ini',patch:'diff',dockerfile:'dockerfile'};
    const lang = aliases[original] || original || 'plain';
    const cacheKey = lang + '\u0000' + src;
    if (src.length <= 40000 && CODE_HIGHLIGHT_CACHE.has(cacheKey)) {
      const cached = CODE_HIGHLIGHT_CACHE.get(cacheKey); CODE_HIGHLIGHT_CACHE.delete(cacheKey); CODE_HIGHLIGHT_CACHE.set(cacheKey, cached); return cached;
    }
    const profile = CODE_PROFILES[lang] || CODE_PROFILES.plain;
    const caseInsensitive = ['powershell','html','sql','yaml','toml','r','ini','dockerfile','makefile','nginx'].includes(lang);
    const lineComments = ['sql','haskell','lua'].includes(lang) ? ['--'] : lang==='matlab' ? ['%'] : lang==='ini' ? [';'] : lang==='clojure' ? [';'] : ['javascript','typescript','java','c','cpp','csharp','go','rust','swift','kotlin','scala','dart','css','php','solidity','graphql','objectivec','groovy','terraform','protobuf'].includes(lang) ? ['//'] : [];
    const hashComments = ['python','bash','powershell','ruby','yaml','toml','php','r','perl','elixir','graphql','dockerfile','makefile','ini','nginx','terraform'].includes(lang);
    const blockComments = ['javascript','typescript','java','c','cpp','csharp','go','rust','swift','kotlin','scala','dart','css','php','sql','objectivec','solidity','graphql','groovy','terraform','protobuf'].includes(lang);
    const lineBreak = (at) => { const e = src.indexOf('\n', at); return e < 0 ? src.length : e; };
    const nextNonSpace = (at) => { while(at<src.length&&/\s/.test(src[at]))at++; return src[at]||''; };
    const span = (cls, raw) => '<span class="hl-' + cls + '">' + esc(raw) + '</span>';
    const starts = (needle) => src.startsWith(needle, i);
    let out = '', i = 0, expectFunction = false, expectType = false, previousSignificant = '';
    const wordRE = /[A-Za-z_][A-Za-z0-9_]*/y;
    const hyphenWordRE = /[A-Za-z_][A-Za-z0-9_-]*/y;
    const numberRE = /(?:0[xX][\da-fA-F]+(?:_[\da-fA-F]+)*|0[bB][01]+(?:_[01]+)*|(?:\d[\d_]*\.?[\d_]*|\.\d[\d_]*)(?:[eE][+-]?[\d_]+)?)(?:n|u|l|f|d)?/y;
    const operatorRE = /(?:===|!==|=>|==|!=|<=|>=|&&|\|\||\?\?|\?\.|\+\+|--|\+=|-=|\*=|\/=|\*\*|->|::|:=|<<=?|>>=?|[=+*/%<>!&|^~?:-])/y;
    const rawRustRE = /(?:br|rb|r)(#{0,16})"/y;
    while (i < src.length) {
      const ch = src[i];
      if (/\s/.test(ch)) { let j = i + 1; while (j < src.length && /\s/.test(src[j])) j++; out += src.slice(i,j); i = j; continue; }
      if (lang === 'html' && ch === '<') {
        const tagRE = /<\/?[A-Za-z][^>\n]*>|<!DOCTYPE[^>]*>/iy; tagRE.lastIndex = i; const m = tagRE.exec(src);
        if (m) { out += span('tag',m[0]); i += m[0].length; previousSignificant='>'; continue; }
      }
      if (lang === 'html' && starts('<!--')) { const e = src.indexOf('-->',i+4), j=e<0?src.length:e+3; out+=span('comment',src.slice(i,j));i=j;previousSignificant='>';continue; }
      if (blockComments && starts('/*')) { const e=src.indexOf('*/',i+2),j=e<0?src.length:e+2;out+=span('comment',src.slice(i,j));i=j;previousSignificant='/';continue; }
      if (lang==='lua' && starts('--[[')) { const e=src.indexOf(']]',i+4),j=e<0?src.length:e+2;out+=span('comment',src.slice(i,j));i=j;previousSignificant=']';continue; }
      if (lang==='diff' && (i===0 || src[i-1]==='\n')) {
        const j=lineBreak(i),row=src.slice(i,j),cls=row.startsWith('@@')?'keyword':row.startsWith('+++')?'type':row.startsWith('---')?'comment':row.startsWith('+')?'string':row.startsWith('-')?'tag':'';
        if(cls){out+=span(cls,row);i=j;previousSignificant=j>0?src[j-1]:previousSignificant;continue;}
      }
      let commentMarker = lineComments.find(x => starts(x));
      if (commentMarker || (hashComments && ch === '#')) { const j=lineBreak(i);out+=span('comment',src.slice(i,j));i=j;previousSignificant=j>0?src[j-1]:previousSignificant;continue; }
      if (lang === 'powershell' && ch === '@' && (starts("@'\n") || starts('@"\n') || starts("@'\r\n") || starts('@"\r\n'))) {
        const quote=src[i+1], startEnd=src.indexOf('\n',i+2)+1, close='\n'+quote+'@', e=src.indexOf(close,startEnd), j=e<0?src.length:e+close.length;out+=span('string',src.slice(i,j));i=j;previousSignificant=j>0?src[j-1]:previousSignificant;continue;
      }
      if (lang === 'rust' && /[rRbB]/.test(ch)) {
        rawRustRE.lastIndex=i; const rm=rawRustRE.exec(src);
        if (rm) { const close='"'+rm[1],e=src.indexOf(close,i+rm[0].length),j=e<0?src.length:e+close.length;out+=span('string',src.slice(i,j));i=j;previousSignificant=j>0?src[j-1]:previousSignificant;continue; }
      }
      if ((ch === '"' || ch === "'" || ch === '`') && !(lang === 'rust' && ch === "'" && !src.slice(i+1,lineBreak(i)).includes("'"))) {
        let delim=ch, triple=false;
        if (lang === 'python' && (src.startsWith(ch.repeat(3),i))) { delim=ch.repeat(3);triple=true; }
        let j=i+delim.length;
        while(j<src.length){
          if(src[j]==='\\'){j+=2;continue;}
          if(src.startsWith(delim,j)){j+=delim.length;break;}
          if(!triple&&src[j]==='\n')break;
          j++;
        }
        if (j>src.length) j=src.length;
        out+=span('string',src.slice(i,j));i=j;previousSignificant=j>0?src[j-1]:previousSignificant;continue;
      }
      if ((lang === 'bash' || lang === 'powershell' || lang === 'php') && ch === '$') {
        const variableRE = lang === 'powershell' ? /\$(?:\{[^}\n]+\}|[A-Za-z_][\w:?-]*)/y : /\$(?:\{[^}\n]+\}|[A-Za-z_][\w]*)/y;
        variableRE.lastIndex=i;const vm=variableRE.exec(src);if(vm){out+=span('property',vm[0]);i+=vm[0].length;previousSignificant=vm[0][vm[0].length-1];continue;}
      }
      numberRE.lastIndex=i;const nm=numberRE.exec(src);
      if(nm && (i===0 || !/[A-Za-z_$]/.test(src[i-1]))){out+=span('number',nm[0]);i+=nm[0].length;previousSignificant=nm[0][nm[0].length-1];continue;}
      const wordRx=lang==='powershell'?hyphenWordRE:wordRE;wordRx.lastIndex=i;const wm=wordRx.exec(src);
      if(wm){
        const token=wm[0],cmp=caseInsensitive?token.toLowerCase():token,lower=token.toLowerCase();
        const following=nextNonSpace(i+token.length),previous=previousSignificant;let cls='';
        const declFn=['def','function','fn','func','proc','procedure'].includes(lower);
        const declType=['class','struct','enum','interface','trait','type'].includes(lower);
        if(expectFunction){cls='function';expectFunction=false;expectType=false;}
        else if(expectType){cls='type';expectType=false;expectFunction=false;}
        else if(profile.keywords.has(cmp))cls='keyword';
        else if(profile.types.has(token)||profile.types.has(cmp))cls='type';
        else if(profile.builtins.has(token)||profile.builtins.has(cmp)||profile.builtins.has(lower))cls='function';
        else if(lang==='json'&&following===':')cls='property';
        else if((['css','yaml','toml'].includes(lang)&&following===':')||(lang==='ini'&&[':', '='].includes(following)))cls='property';
        else if(previous==='.')cls='property';
        else if(following==='('||following==='!')cls='function';
        else if(lang==='powershell'&&/^[A-Z][a-z]+-[A-Z][A-Za-z]+$/.test(token))cls='function';
        else if(['javascript','typescript','java','cpp','c','csharp','rust','go'].includes(lang)&&/^[A-Z]/.test(token))cls='type';
        out+=cls?span(cls,token):esc(token);i+=token.length;
        expectFunction=declFn;expectType=declType;previousSignificant=token[token.length-1];continue;
      }
      operatorRE.lastIndex=i;const op=operatorRE.exec(src);
      if(op){out+=span('operator',op[0]);i+=op[0].length;previousSignificant=op[0][op[0].length-1];continue;}
      out+=esc(ch);i++;previousSignificant=ch;if(!/[\s([{]/.test(ch)){expectFunction=false;expectType=false;}
    }
    if (src.length <= 40000) { CODE_HIGHLIGHT_CACHE.set(cacheKey,out); if(CODE_HIGHLIGHT_CACHE.size>64) CODE_HIGHLIGHT_CACHE.delete(CODE_HIGHLIGHT_CACHE.keys().next().value); }
    return out;
  }
  function mdCodeLinesHtml(highlighted) {
    const tokens=String(highlighted||'').match(/<span\b[^>]*>|<\/span>|\n|[^<\n]+|</g)||[];
    const stack=[],lines=[];let line='';
    const reopen=()=>stack.join(''),close=()=>stack.slice().reverse().map(()=>'</span>').join('');
    line=reopen();
    tokens.forEach(token=>{
      if(token==='\n'){lines.push(line+close());line=reopen();return;}
      if(/^<span\b/.test(token)){line+=token;stack.push(token);return;}
      if(token==='</span>'){line+=token;if(stack.length)stack.pop();return;}
      line+=token;
    });
    lines.push(line+close());
    return lines.map((content,i)=>'<span class="md-code-line"><span class="md-code-ln" aria-hidden="true">'+(i+1)+'</span><span class="md-code-content">'+(content||' ')+'</span></span>').join('');
  }
  function markdownLineDirection(text, forceLtr, mode) {
    if (forceLtr) return 'ltr';
    mode = normalizeTextDirection(mode);
    if (mode === 'rtl') return 'rtl';
    if (mode === 'ltr') return 'ltr';
    const probe = String(text == null ? '' : text)
      .replace(/^\s*(?:(?:#{1,6}|>)\s*|[-*+]\s+|\d+[.)]\s+|[-*+]\s+\[[ xX]\]\s*)+/, '')
      .replace(/^[`*_~=\[({]+/, '')
      .trimStart();
    for (const ch of Array.from(probe)) {
      if (/[\u0590-\u08ff\ufb1d-\ufdff\ufe70-\ufeff]/u.test(ch)) return 'rtl';
      if (/[A-Za-z\u00c0-\u024f]/u.test(ch)) return 'ltr';
    }
    return 'rtl';
  }
  function mdLineHtml(text, mode) {
    const dir = markdownLineDirection(text, false, mode);
    return '<span class="md-line" dir="' + dir + '">' + mdInline(text) + '</span>';
  }
  function mdToHtml(src, directionMode) {
    directionMode = normalizeTextDirection(directionMode);
    const source = String(src || '').replace(/\r\n?/g, '\n');
    const cacheKey = String(state.ui.stack || '') + '\u0000' + directionMode + '\u0000' + source;
    if (source.length <= 30000 && MD_RENDER_CACHE.has(cacheKey)) {
      const cached = MD_RENDER_CACHE.get(cacheKey); MD_RENDER_CACHE.delete(cacheKey); MD_RENDER_CACHE.set(cacheKey, cached); return cached;
    }
    const lines = source.split('\n'), refs = new Map();
    lines.forEach((line,index)=>{
      const def=line.match(/^ {0,3}\[([^\]]+)\]:\s*(?:<([^>]+)>|(\S+))(?:\s+(?:"([^"]*)"|'([^']*)'|\(([^)]*)\)))?\s*$/);
      if(!def)return;
      refs.set(mdRefKey(def[1]),{url:def[2]||def[3]||'',title:def[4]||def[5]||def[6]||''});
      lines[index]='';
    });
    const out = []; let i = 0;
    const cellSplit = r => r.trim().replace(/^\||\|$/g, '').split('|').map(c => c.trim());
    const lineDirection = (line,forceLtr) => markdownLineDirection(line,forceLtr,directionMode);
    const wrapLine = (line,forceLtr) => '<span class="md-line" dir="' + lineDirection(line,forceLtr) + '">' + mdInline(line,refs) + '</span>';
    const fenceClose = (line,marker) => {
      const close=String(line||'').match(/^ {0,3}(`+|~+)[ \t]*$/);
      return !!close&&close[1][0]===marker[0]&&close[1].length>=marker.length;
    };
    const codeBlockHtml = (code,language) => {
      const lang=String(language||'').toLowerCase(),langAttr=lang||'code';
      const codeHtml=mdCodeLinesHtml(highlightCode(code,lang));
      return '<pre class="md-pre" dir="ltr" data-lang="'+esc(langAttr)+'"><button type="button" class="md-code-copy" data-codecopy dir="rtl" title="کپی همین Code Block" aria-label="کپی Code Block">'+I('copy')+'<span>کپی</span></button><code dir="ltr" class="language-'+esc(langAttr)+'">'+codeHtml+'</code></pre>';
    };
    const listInfo = line => {
      const m=String(line||'').match(/^([ \t]*)([-*+]|(\d+)[.)])[ \t]+(.*)$/);
      return m?{indent:m[1].replace(/\t/g,'    ').length,ordered:!!m[3],text:m[4]}:null;
    };
    const readList = (start,indent,ordered) => {
      const items=[];let at=start;
      while(at<lines.length){
        const info=listInfo(lines[at]);
        if(!info||info.indent!==indent||info.ordered!==ordered)break;
        const item={text:info.text,children:[]};at++;
        while(at<lines.length){
          if(/^\s*$/.test(lines[at])){
            const after=listInfo(lines[at+1]);
            if(after&&after.indent>indent){at++;continue;}
            if(after&&after.indent===indent&&after.ordered===ordered){at++;break;}
            break;
          }
          const next=listInfo(lines[at]);
          if(next){
            if(next.indent>indent){const nested=readList(at,next.indent,next.ordered);item.children.push(nested.html);at=nested.index;continue;}
            break;
          }
          if(/^[ \t]+/.test(lines[at])){item.text+='\n'+lines[at].replace(/^[ \t]+/,'');at++;continue;}
          break;
        }
        items.push(item);
      }
      const tag=ordered?'ol':'ul';
      const html='<'+tag+'>'+items.map(item=>{
        const parts=item.text.split('\n'),task=parts[0].match(/^\[( |x|X)\]\s*(.*)$/);
        if(task)parts[0]=task[2];
        const dir=lineDirection(parts[0]||'');
        const content=parts.map(wrapLine).join('<br>'),prefix=task?(task[1].toLowerCase()==='x'?'☑':'☐')+' ':'';
        return '<li'+(task?' class="md-task"':'')+' dir="'+dir+'">'+prefix+content+item.children.join('')+'</li>';
      }).join('')+'</'+tag+'>';
      return {html,index:at};
    };
    const isSetext = index => index+1<lines.length&&/^ {0,3}(=+|-+)[ \t]*$/.test(lines[index+1])&&String(lines[index]||'').trim()&&!/^ {0,3}(?:#{1,6}(?:[ \t]|$)|>|\||[-*+]|\d+[.)]|`{3,}|~{3,})/.test(lines[index]);
    const startsBlock = line => /^\s*$/.test(line)||/^ {0,3}(?:#{1,6}(?:[ \t]|$)|>|`{3,}|~{3,})/.test(line)||/^ {0,3}(-{3,}|\*{3,}|_{3,})[ \t]*$/.test(line)||/^\s*\|.*\|\s*$/.test(line)||!!listInfo(line)||/^(?: {4}|\t)/.test(line);
    while (i < lines.length) {
      const ln = lines[i];
      const fence = ln.match(/^ {0,3}(`{3,}|~{3,})(.*)$/);
      if (fence) {
        const marker=fence[1],info=(fence[2]||'').trim(),language=(info.match(/^[a-z0-9_+#.-]+/i)||[''])[0].toLowerCase();
        i++;const buf=[];
        while(i<lines.length&&!fenceClose(lines[i],marker)){buf.push(lines[i]);i++;}
        if(i<lines.length)i++;
        out.push(codeBlockHtml(buf.join('\n'),language));continue;
      }
      if (/^\s*$/.test(ln)) { i++; continue; }
      if (/^(?: {4}|\t)/.test(ln)) {
        const buf=[];
        while(i<lines.length){
          if(/^(?: {4}|\t)/.test(lines[i])){buf.push(lines[i].replace(/^(?: {4}|\t)/,''));i++;continue;}
          if(/^\s*$/.test(lines[i])&&i+1<lines.length&&/^(?: {4}|\t)/.test(lines[i+1])){buf.push('');i++;continue;}
          break;
        }
        while(buf.length&&buf[buf.length-1]==='')buf.pop();
        out.push(codeBlockHtml(buf.join('\n'),''));continue;
      }
      if (isSetext(i)) {
        const setext=lines[i+1].match(/^ {0,3}(=+|-+)[ \t]*$/),level=setext[1][0]==='='?1:2,text=ln.trim(),dir=lineDirection(text);
        out.push('<h'+level+' dir="'+dir+'">'+wrapLine(text)+'</h'+level+'>');i+=2;continue;
      }
      if (/^ {0,3}(-{3,}|\*{3,}|_{3,})[ \t]*$/.test(ln)) { out.push('<hr>'); i++; continue; }
      let m = ln.match(/^ {0,3}(#{1,6})(?:[ \t]+(.*)|[ \t]*)$/);
      if (m) {
        const level=m[1].length,text=String(m[2]||'').replace(/[ \t]+#+[ \t]*$/,'').trimEnd(),dir=lineDirection(text);
        out.push('<h'+level+' dir="'+dir+'">'+wrapLine(text)+'</h'+level+'>');i++;continue;
      }
      if (/^\s*>/.test(ln)) {
        const buf=[];
        while(i<lines.length&&/^\s*>/.test(lines[i])){buf.push(lines[i].replace(/^\s*>\s?/,''));i++;}
        const callout=buf[0]&&buf[0].match(/^\[!([a-z0-9_-]+)\][+-]?\s*(.*)$/i);
        if(callout){
          const raw=callout[1].toLowerCase(),allowed=['note','abstract','info','todo','tip','success','check','done','warning','caution','attention','failure','fail','missing','danger','error','bug','example','quote','cite'];
          const type=allowed.includes(raw)?raw:'note',names={note:'یادداشت',abstract:'خلاصه',info:'اطلاعات',todo:'کار',tip:'نکته',success:'موفق',check:'انجام شده',done:'انجام شده',warning:'هشدار',caution:'احتیاط',attention:'توجه',failure:'خطا',fail:'خطا',missing:'ناموجود',danger:'خطر',error:'خطا',bug:'اشکال',example:'نمونه',quote:'نقل قول',cite:'منبع'};
          const title=callout[2].trim()||names[type],body=buf.slice(1),dir=directionMode==='rtl'?'ltr':lineDirection(title);
          out.push('<aside class="md-callout md-callout-'+type+'" dir="'+dir+'"><div class="md-callout-title">'+mdInline(title,refs)+'</div>'+(body.length?'<div class="md-callout-body">'+body.map(line=>wrapLine(line,directionMode==='rtl')).join('<br>')+'</div>':'')+'</aside>');
        }else{
          const dir=directionMode==='rtl'?'ltr':lineDirection(buf[0]||'');out.push('<blockquote dir="'+dir+'">'+buf.map(line=>wrapLine(line,directionMode==='rtl')).join('<br>')+'</blockquote>');
        }
        continue;
      }
      if (/^\s*\|.*\|\s*$/.test(ln)&&i+1<lines.length&&/^\s*\|[\s:\-|]+\|\s*$/.test(lines[i+1])) {
        const head=cellSplit(ln),alignments=cellSplit(lines[i+1]).map(cell=>{
          const left=cell.startsWith(':'),right=cell.endsWith(':');return left&&right?'center':left?'left':right?'right':'';
        });
        i+=2;const rows=[];
        while(i<lines.length&&/^\s*\|.*\|\s*$/.test(lines[i])){rows.push(cellSplit(lines[i]));i++;}
        const cell=(value,tag,index)=>'<'+tag+' dir="'+lineDirection(value)+'"'+(alignments[index]?' style="text-align:'+alignments[index]+'"':'')+'>'+mdInline(value,refs)+'</'+tag+'>';
        out.push('<table class="md-table"><thead><tr>'+head.map((h,index)=>cell(h,'th',index)).join('')+'</tr></thead><tbody>'+rows.map(row=>'<tr>'+row.map((v,index)=>cell(v,'td',index)).join('')+'</tr>').join('')+'</tbody></table>');continue;
      }
      const list=listInfo(ln);
      if(list){const result=readList(i,list.indent,list.ordered);out.push(result.html);i=result.index;continue;}
      const buf=[ln];i++;
      while(i<lines.length&&!startsBlock(lines[i])&&!isSetext(i)){buf.push(lines[i]);i++;}
      const dir=lineDirection(buf[0]||'');
      out.push('<p dir="'+dir+'">'+buf.map(wrapLine).join('<br>')+'</p>');
    }
    const emptyDirection=directionMode==='auto'?'rtl':directionMode;
    const html=out.join('\n')||'<p class="md-empty" dir="'+emptyDirection+'">هنوز چیزی نوشته نشده…</p>';
    if(source.length<=30000){MD_RENDER_CACHE.set(cacheKey,html);if(MD_RENDER_CACHE.size>256)MD_RENDER_CACHE.delete(MD_RENDER_CACHE.keys().next().value);}
    return html;
  }
  const EDITOR_HISTORY = new Map();
  const EDITOR_HISTORY_LIMIT = 120;
  function isAppMarkdownEditor(el) {
    return !!(el && el.matches && el.matches('textarea[data-note],textarea[data-nb-edit]'));
  }
  function editorHistoryKey(el) {
    if (el.matches('textarea[data-note]')) return 'note:' + el.dataset.note;
    const side = el.dataset.nbEdit === 'secondary' ? 'secondary' : 'primary';
    const note = nbActive(side);
    return 'notebook:' + (note ? note.id : side);
  }
  function editorSnapshot(el) {
    const value = String(el && el.value != null ? el.value : '');
    const length = value.length;
    const start = Number.isFinite(el.selectionStart) ? Math.max(0, Math.min(length, el.selectionStart)) : length;
    const end = Number.isFinite(el.selectionEnd) ? Math.max(start, Math.min(length, el.selectionEnd)) : start;
    return { value, start, end, direction: el.selectionDirection || 'none' };
  }
  function editorNewHistory(snapshot) {
    return { undo: [], redo: [], current: snapshot, pendingBefore: null, pendingInputType: '', lastInputType: '', lastInputAt: 0, applying: false };
  }
  function editorHistoryFor(el, resetOnValueMismatch) {
    if (!isAppMarkdownEditor(el)) return null;
    const key = editorHistoryKey(el), snapshot = editorSnapshot(el);
    let history = EDITOR_HISTORY.get(key);
    if (!history || (resetOnValueMismatch && history.current.value !== snapshot.value)) {
      history = editorNewHistory(snapshot);
      EDITOR_HISTORY.set(key, history);
      if (EDITOR_HISTORY.size > 400) EDITOR_HISTORY.delete(EDITOR_HISTORY.keys().next().value);
    }
    return history;
  }
  function editorHistoryPush(stack, snapshot) {
    stack.push({ value: snapshot.value, start: snapshot.start, end: snapshot.end, direction: snapshot.direction });
    if (stack.length > EDITOR_HISTORY_LIMIT) stack.splice(0, stack.length - EDITOR_HISTORY_LIMIT);
  }
  function editorHistoryFocus(e) {
    const el = isAppMarkdownEditor(e.target) ? e.target : null;
    if (el) editorHistoryFor(el, true);
  }
  function editorHistoryBeforeInput(e) {
    const el = isAppMarkdownEditor(e.target) ? e.target : null;
    if (!el || e.isComposing) return;
    const history = editorHistoryFor(el, true);
    if (history) { history.pendingBefore = editorSnapshot(el); history.pendingInputType = e.inputType || ''; }
  }
  function editorHistoryInput(e) {
    const el = isAppMarkdownEditor(e.target) ? e.target : null;
    if (!el) return;
    const key = editorHistoryKey(el), after = editorSnapshot(el);
    let history = EDITOR_HISTORY.get(key);
    if (!history) { EDITOR_HISTORY.set(key, editorNewHistory(after)); return; }
    if (history.applying) { history.current = after; history.pendingBefore = null; history.pendingInputType = ''; return; }
    const previous = history.current;
    const before = history.pendingBefore || history.current;
    const inputType = e.inputType || history.pendingInputType || 'unknown';
    history.pendingBefore = null; history.pendingInputType = '';
    if (after.value === before.value) { history.current = after; return; }
    if (before.value !== history.current.value) {
      history.undo.length = 0; history.redo.length = 0; history.current = before; history.lastInputType = '';
    } else history.current = before;
    const groupable = inputType === 'insertText' || inputType === 'deleteContentBackward' || inputType === 'deleteContentForward';
    const contiguous = groupable && inputType === history.lastInputType && Date.now() - history.lastInputAt < 900 && before.start === previous.start && before.end === previous.end && before.start === before.end;
    if (!contiguous) editorHistoryPush(history.undo, before);
    history.redo.length = 0;
    history.current = after;
    history.lastInputType = groupable ? inputType : '';
    history.lastInputAt = Date.now();
  }
  function editorSetSelection(el, snapshot) {
    try { el.setSelectionRange(snapshot.start, snapshot.end, snapshot.direction); }
    catch (_) { try { el.setSelectionRange(snapshot.start, snapshot.end); } catch (__) { } }
  }
  function editorHistoryReplace(el, nextValue, start, end) {
    if (!isAppMarkdownEditor(el)) return false;
    const before = editorSnapshot(el), history = editorHistoryFor(el, true);
    const value = String(nextValue == null ? '' : nextValue);
    const selectionStart = Math.max(0, Math.min(value.length, Number.isFinite(start) ? start : before.start));
    const selectionEnd = Math.max(selectionStart, Math.min(value.length, Number.isFinite(end) ? end : selectionStart));
    if (before.value !== value) {
      editorHistoryPush(history.undo, before);
      history.redo.length = 0; history.lastInputType = ''; history.pendingBefore = null; history.pendingInputType = '';
      el.value = value;
    }
    editorSetSelection(el, { start: selectionStart, end: selectionEnd, direction: 'none' });
    history.current = editorSnapshot(el);
    return before.value !== value;
  }
  function editorHistoryStep(el, redo) {
    if (!isAppMarkdownEditor(el)) return false;
    const history = editorHistoryFor(el, true), source = redo ? history.redo : history.undo, destination = redo ? history.undo : history.redo;
    if (!source.length) return false;
    const current = editorSnapshot(el), target = source.pop();
    editorHistoryPush(destination, current);
    history.applying = true;
    el.value = target.value;
    editorSetSelection(el, target);
    history.current = editorSnapshot(el); history.pendingBefore = null; history.pendingInputType = ''; history.lastInputType = '';
    try { el.dispatchEvent(new Event('input', { bubbles: true })); }
    finally { history.applying = false; history.current = editorSnapshot(el); }
    return true;
  }
  function editorContinueList(el) {
    if (el.selectionStart !== el.selectionEnd) return false;
    const value = el.value, caret = el.selectionStart;
    const lineStart = value.lastIndexOf('\n', caret - 1) + 1;
    const foundEnd = value.indexOf('\n', caret), lineEnd = foundEnd < 0 ? value.length : foundEnd;
    const line = value.slice(lineStart, lineEnd);
    let indent = '', marker = '', spaces = '', rest = '', ordered = null;
    let match = line.match(/^([ \t]*)([-+*])(?:([ \t]+)(.*)|$)/);
    if (match) { indent = match[1]; marker = match[2]; spaces = match[3] || ' '; rest = match[4] || ''; }
    else {
      match = line.match(/^([ \t]*)(\d+)([.)])(?:([ \t]+)(.*)|$)/);
      if (!match) return false;
      indent = match[1]; marker = match[3]; spaces = match[4] || ' '; rest = match[5] || '';
      ordered = Number(match[2]);
    }
    const task = rest.match(/^\[(?: |x|X)\](?:[ \t]+|$)(.*)$/);
    const itemText = task ? task[1] : rest;
    if (!itemText.trim()) {
      const next = value.slice(0, lineStart) + value.slice(lineEnd);
      const point = Math.min(lineStart, next.length);
      editorHistoryReplace(el, next, point, point);
      el.dispatchEvent(new Event('input', { bubbles: true }));
      return true;
    }
    let nextMarker;
    if (ordered !== null) {
      const nextNumber = Number.isSafeInteger(ordered) ? ordered + 1 : ordered;
      nextMarker = indent + String(nextNumber) + marker + spaces;
    } else nextMarker = indent + marker + spaces;
    if (task) nextMarker += '[ ] ';
    const insertion = '\n' + nextMarker;
    const next = value.slice(0, caret) + insertion + value.slice(caret);
    const point = caret + insertion.length;
    editorHistoryReplace(el, next, point, point);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    return true;
  }
  function editorOnKeydown(e) {
    const el = isAppMarkdownEditor(e.target) ? e.target : null;
    if (!el) return;
    const mod = e.ctrlKey || e.metaKey;
    if (mod && !e.altKey && (e.key.toLowerCase() === 'z' || e.code === 'KeyZ')) {
      const redo = !!e.shiftKey;
      if (editorHistoryStep(el, redo)) { e.preventDefault(); e.stopPropagation(); return; }
    } else if (mod && !e.altKey && !e.shiftKey && (e.key.toLowerCase() === 'y' || e.code === 'KeyY')) {
      if (editorHistoryStep(el, true)) { e.preventDefault(); e.stopPropagation(); return; }
    }
    if (e.key === 'Enter' && !e.shiftKey && !e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && e.keyCode !== 229) {
      if (editorContinueList(el)) { e.preventDefault(); e.stopPropagation(); return; }
    }
    if (e.key.length !== 1 || mod || e.altKey) {
      const history = EDITOR_HISTORY.get(editorHistoryKey(el));
      if (history && e.key !== 'Shift' && e.key !== 'Control' && e.key !== 'Meta' && e.key !== 'Alt') history.lastInputType = '';
    }
  }
  function editorFileMime(file, fallbackType) {
    const name = String(file && file.name || '').toLowerCase().replace(/\\/g, '/').split('/').pop() || '';
    const ext = (name.match(/\.([a-z0-9]{1,12})$/i) || [,''])[1].toLowerCase();
    const raw = String(file && file.type || fallbackType || '').toLowerCase().split(';')[0].trim();
    if (/^[a-z0-9.+-]+\/[a-z0-9.+-]+$/.test(raw)) return raw;
    return ATTACHMENT_MIME_BY_EXT[ext] || 'application/octet-stream';
  }
  function isEditorMediaMime(mime) { return /^(?:image|video|audio)\//i.test(String(mime||'')); }
  function editorClipboardMedia(e) {
    const el = isAppMarkdownEditor(e.target) ? e.target : null, data = e.clipboardData;
    if (!el || !data) return;
    const files = [], seen = new Set();
    const add = file => {
      if (!file || typeof file.size !== 'number') return;
      const mime = editorFileMime(file, file.type);
      const key = [file.name || '', file.size || 0, mime, file.lastModified || 0].join('|');
      if (seen.has(key)) return; seen.add(key); files.push(file);
    };
    try { Array.from(data.items || []).forEach(item => { if (item.kind === 'file') add(item.getAsFile()); }); } catch (_) { }
    try { Array.from(data.files || []).forEach(add); } catch (_) { }
    if (!files.length) return;
    e.preventDefault();
    const text = (() => { try { return data.getData('text/plain') || ''; } catch (_) { return ''; } })();
    insertEditorMedia(el, files, editorSnapshot(el), text);
  }
  async function insertEditorMedia(el, files, initial, clipboardText) {
    const media = Array.from(files || []).map(file => ({ file, mime: editorFileMime(file, file && file.type) })).filter(item => item.file);
    if (!media.length) { toast('فایلی برای پیوست پیدا نشد.'); return; }
    if (!el || !el.isConnected) { toast('ویرایشگر بسته شد؛ پیوست درج نشد.'); return; }
    if (!await attachmentStore.ensureForPaste()) return;
    const saved = []; let failures = 0;
    // Save sequentially as raw File/Blob objects: never base64-encode large attachments or run parallel conversions.
    for (const item of media) {
      try {
        const path = await attachmentStore.save(item.file, item.mime);
        saved.push({ path, mime: item.mime, embed: isEditorMediaMime(item.mime) });
      } catch (_) { failures++; }
    }
    if (!saved.length) { toast(attachmentStore.mode === 'permission' ? 'ذخیره پیوست ناموفق بود؛ دسترسی پوشه attachments را دوباره وصل کن. هیچ ارجاع ناقصی درج نشد.' : attachmentStore.mode === 'indexeddb' ? 'ذخیره در IndexedDB ناموفق بود؛ فایلی به متن اضافه نشد.' : 'ذخیره پیوست ناموفق بود؛ فایلی به متن اضافه نشد.'); return; }
    if (!el || !el.isConnected) { toast('ویرایشگر بسته شد؛ پیوست ذخیره شد اما ارجاع درج نشد.'); return; }
    let value = el.value, start = initial && Number.isFinite(initial.start) ? initial.start : el.selectionStart, end = initial && Number.isFinite(initial.end) ? initial.end : el.selectionEnd;
    if (initial && value !== initial.value && document.activeElement === el) { start = el.selectionStart; end = el.selectionEnd; }
    start = Math.max(0, Math.min(value.length, Number.isFinite(start) ? start : value.length));
    end = Math.max(start, Math.min(value.length, Number.isFinite(end) ? end : start));
    const prefix = clipboardText ? String(clipboardText) + '\n' : '';
    const snippets = saved.map(item => item.embed ? '![[attachments/' + item.path.slice('attachments/'.length) + ']]' : '[[' + item.path + ']]');
    const insertion = prefix + snippets.join('\n');
    const next = value.slice(0, start) + insertion + value.slice(end), point = start + insertion.length;
    editorHistoryReplace(el, next, point, point);
    try { el.focus({ preventScroll: true }); } catch (_) { el.focus(); }
    el.dispatchEvent(new Event('input', { bubbles: true }));
    const destination = attachmentStore.mode === 'filesystem' ? 'پوشهٔ attachments' : 'IndexedDB همین مرورگر';
    if (failures) toast(saved.length+' پیوست در '+destination+' ذخیره شد؛ '+failures+' فایل ذخیره نشد.');
    else toast(saved.length === 1 ? 'پیوست در '+destination+' ذخیره و به نوشته اضافه شد ✅' : 'پیوست‌ها در '+destination+' ذخیره و به نوشته اضافه شدند ✅');
  }
  async function openEditorMediaPicker(el) {
    if (!isAppMarkdownEditor(el)) return;
    const storage = await attachmentStore.ensureForToolbar();
    if (storage !== 'ready') return;
    const input = document.createElement('input');
    input.type = 'file'; input.multiple = true;
    input.setAttribute('aria-label', 'انتخاب فایل برای پیوست');
    input.style.cssText = 'position:fixed;left:-10000px;top:0;width:1px;height:1px;opacity:0;';
    const initial = editorSnapshot(el);
    input.addEventListener('change', () => {
      const files = Array.from(input.files || []); input.remove();
      if (files.length) insertEditorMedia(el, files, initial, '');
    }, { once: true });
    input.addEventListener('cancel', () => input.remove(), { once: true });
    document.body.appendChild(input);
    input.click();
  }
  let nbEls = null;
  let nbSearchTimer = null, nbListRenderGeneration = 0;
  let nbManagerEdit = null, nbManagerDelete = null;
  const nbScrollSyncEnabled = { primary: false, secondary: false };
  const nbScrollSyncGuard = { primary: false, secondary: false };
  const nbPaneNoteIds = { primary: '', secondary: '' };
  const nbTypewriterEnabled = { primary: false, secondary: false };
  const nbTypewriterFrames = { primary: null, secondary: null };
  const nbTypewriterMirrors = { primary: null, secondary: null };
  function nbUpdateTypewriterButton(side) {
    side = side === 'secondary' ? 'secondary' : 'primary';
    const button = nbEls && nbEls.panel.querySelector('[data-nb="typewriter"][data-side="' + side + '"]');
    if (!button) return;
    const on = !!nbTypewriterEnabled[side];
    button.setAttribute('aria-pressed', on ? 'true' : 'false');
    button.classList.toggle('on', on);
    button.title = on ? 'Auto Scroll by follow Text — روشن (برای خاموش کردن کلیک کن)' : 'Auto Scroll by follow Text — خاموش (برای روشن کردن کلیک کن)';
    button.setAttribute('aria-label', button.title);
  }
  function nbRunTypewriterScroll(ta, side) {
    if (!ta || !ta.isConnected || ta.hidden || !nbTypewriterEnabled[side] || nbMode(side) === 'read' || !ta.clientHeight) return;
    const style = getComputedStyle(ta), mirror = nbTypewriterMirrors[side] || document.createElement('div');
    nbTypewriterMirrors[side] = mirror;
    Object.assign(mirror.style, {
      position:'fixed', left:'-100000px', top:'0', visibility:'hidden', pointerEvents:'none', zIndex:'-1',
      boxSizing:'border-box', width:Math.max(1,ta.clientWidth)+'px', height:'auto', minHeight:'0', maxHeight:'none',
      margin:'0', border:'0', padding:style.padding, whiteSpace:'pre-wrap', overflowWrap:'break-word', wordBreak:'break-word',
      fontFamily:style.fontFamily, fontSize:style.fontSize, fontWeight:style.fontWeight, fontStyle:style.fontStyle,
      lineHeight:style.lineHeight, letterSpacing:style.letterSpacing, wordSpacing:style.wordSpacing, textIndent:style.textIndent,
      textTransform:style.textTransform, textAlign:style.textAlign, tabSize:style.tabSize, direction:style.direction, unicodeBidi:style.unicodeBidi,
      overflow:'hidden'
    });
    mirror.dir = style.direction || ta.dir || 'auto';
    if (!mirror.isConnected) document.body.appendChild(mirror);
    const caret = ta.selectionDirection === 'backward' ? ta.selectionStart : ta.selectionEnd;
    mirror.textContent = String(ta.value || '').slice(0, Math.max(0,caret));
    const marker = document.createElement('span'); marker.textContent = '\u200b';
    marker.style.cssText = 'display:inline-block;width:1px;height:1px;padding:0;margin:0;vertical-align:baseline;';
    mirror.appendChild(marker);
    const lineHeight = parseFloat(style.lineHeight) || (parseFloat(style.fontSize) || 14) * 1.8;
    const max = Math.max(0, ta.scrollHeight - ta.clientHeight);
    const target = Math.max(0, Math.min(max, marker.offsetTop - ta.clientHeight / 2 + lineHeight / 2));
    if (Math.abs(ta.scrollTop - target) > 1) ta.scrollTop = target;
  }
  function nbScheduleTypewriterScroll(ta) {
    if (!ta || !ta.matches || !ta.matches('textarea[data-nb-edit]')) return;
    const side = ta.dataset.nbEdit === 'secondary' ? 'secondary' : 'primary';
    if (!nbTypewriterEnabled[side] || nbMode(side) === 'read') return;
    if (nbTypewriterFrames[side] != null) cancelAnimationFrame(nbTypewriterFrames[side]);
    nbTypewriterFrames[side] = requestAnimationFrame(() => {
      nbTypewriterFrames[side] = null;
      nbRunTypewriterScroll(ta, side);
    });
  }
  function nbTypewriterEvent(e) {
    const ta = e.target && e.target.closest ? e.target.closest('textarea[data-nb-edit]') : null;
    if (ta) nbScheduleTypewriterScroll(ta);
  }
  function nbToggleTypewriter(side) {
    side = side === 'secondary' ? 'secondary' : 'primary';
    if (nbMode(side) === 'read') return;
    nbTypewriterEnabled[side] = !nbTypewriterEnabled[side];
    nbUpdateTypewriterButton(side);
    if (nbTypewriterEnabled[side]) {
      const ta = side === 'secondary' ? nbEls.editSecondary : nbEls.edit;
      if (ta) { try { ta.focus({ preventScroll:true }); } catch (_) { ta.focus(); } nbScheduleTypewriterScroll(ta); }
    }
  }
  function nbMount() {
    if (nbEls) return;
    const makeToolbar = (side) => {
      const fmt = (v, icon, label) => '<button type="button" class="iact nb-icon-button nb-format-button" data-nb="fmt" data-v="' + v + '" data-side="' + side + '" title="' + label + '" aria-label="' + label + '">' + icon + '</button>';
      const act = (name, icon, label, cls) => '<button type="button" class="iact nb-icon-button nb-action-button ' + (cls || '') + '" data-nb="' + name + '" data-side="' + side + '" title="' + label + '" aria-label="' + label + '"' + (name === 'typewriter' ? ' aria-pressed="false"' : '') + '>' + icon + '</button>';
      return '<div class="nb-tools" data-nb-tools="' + side + '">' +
        '<div class="nb-format" data-nb-formatbar="' + side + '" aria-label="ابزارهای Markdown">' +
          fmt('h1',I('h1'),'عنوان ۱ (Heading 1)') + fmt('h2',I('h2'),'عنوان ۲ (Heading 2)') + fmt('h3',I('h3'),'عنوان ۳ (Heading 3)') + fmt('h4',I('h4'),'عنوان ۴ (Heading 4)') + fmt('h5',I('h5'),'عنوان ۵ (Heading 5)') + fmt('h6',I('h6'),'عنوان ۶ (Heading 6)') + '<span class="nb-sep" aria-hidden="true"></span>' +
          fmt('b',I('bold'),'ضخیم (Bold)') + fmt('i',I('italic'),'کج (Italic)') + fmt('bolditalic',I('bolditalic'),'ضخیم و کج (Bold Italic)') + fmt('strike',I('strike'),'خط خورده (Strikethrough)') + fmt('highlight',I('highlight'),'برجسته (Highlight)') + fmt('code',I('code'),'کد درون خطی (Inline code)') + fmt('codeblock',I('codeblock'),'بلوک کد (Code Block)') + '<span class="nb-sep" aria-hidden="true"></span>' +
          fmt('ul',I('list'),'فهرست نقطه ای (Bullet list)') + fmt('ol',I('list-ordered'),'فهرست شماره دار (Ordered list)') + fmt('cb',I('checklist'),'چک باکس (Task list)') + fmt('quote',I('quote'),'نقل قول (Quote)') + fmt('callout',I('callout'),'کال اوت (Callout)') +
          fmt('link',I('link'),'لینک (Link)') + fmt('table',I('table'),'جدول (Table)') + fmt('hr',I('hr'),'خط جداکننده (Horizontal rule)') + fmt('media',I('paperclip'),'افزودن تصویر، ویدئو، صدا یا فایل پیوست') +
        '</div>' +
        '<span class="nb-toolbar-split" aria-hidden="true"></span>' +
        '<div class="nb-actions" aria-label="اقدام های یادداشت">' +
          act('copy',I('copy'),'کپی متن خواندنی این پنل') +
          act('share',I('share'),'اشتراک گذاری این یادداشت') +
          act('download',I('export'),'دانلود Markdown این یادداشت') +
          act('duplicate',I('copy'),'تکثیر یادداشت این پنل') +
          act('new2',I('plus'),'ساخت یادداشت جدید در این پنل') +
          act('delete',I('trash'),'حذف یادداشت این پنل','d') +
          act('typewriter',I('target'),'Auto Scroll by follow Text — اسکرول دنبال کننده متن') +
        '</div>' +
      '</div>';
    };
    const wrap = document.createElement('div');
    wrap.innerHTML =
      '<div class="nb-overlay" id="nbOverlay"></div>' +
      '<aside class="nb" id="nbPanel" role="dialog" aria-modal="false" aria-label="دفترچه یادداشت" aria-hidden="true">' +
        '<div class="nb-resize-handle" data-nb-resize="width" role="separator" aria-orientation="vertical" aria-label="تغییر عرض دفترچه" aria-valuemin="50" aria-valuemax="100" tabindex="0"></div>' +
        '<div class="nb-head">' +
          '<span class="nb-title">' + I('note') + ' دفترچه یادداشت <small>Notebook</small><b class="nb-total" data-nb-total>۰</b></span>' +
          fontScaleControls('nb','notebook') +
          '<span class="nb-state" data-nb-state>—</span>' +
          '<button class="iact" data-nb="close" title="بستن (Esc)">' + I('x') + '</button>' +
        '</div>' +
        '<div class="nb-listview" data-nb-listview>' +
          '<div class="attachment-guidance" data-attachment-guidance data-guidance-scope="notebook" role="status" aria-live="polite" hidden></div>' +
          '<div class="nb-listtools">' +
            '<div class="nb-listtools-main"><div class="nb-search"><span class="ico">' + I('search') + '</span><input id="nbSearch" type="search" placeholder="جست وجو در عنوان، متن، تگ، فولدر و دسته بندی…" aria-label="جست وجو در همه بخش های یادداشت"></div>' +
            '<button class="btn pri" data-nb="new">' + I('plus') + ' یادداشت جدید</button></div>' +
            '<div class="nb-browse-modes" data-nb-browse-modes role="tablist" aria-label="نمای فهرست یادداشت ها"></div>' +
          '</div>' +
          '<div class="nb-explorer" data-nb-explorer>' +
            '<aside class="nb-explorer-side" aria-label="فهرست ویژگی ها">' +
              '<div class="nb-explorer-side-head"><b data-nb-facet-heading>فهرست نوشته ها</b><span data-nb-breadcrumb></span></div>' +
              '<div class="nb-browse-items" data-nb-browse-items></div>' +
            '</aside>' +
            '<section class="nb-explorer-main" aria-label="نوشته های انتخاب شده">' +
              '<div class="nb-list-controls"><span data-nb-path>همه نوشته ها</span><label class="nb-sort-control"><span>مرتب سازی</span><select data-nb-sort aria-label="مرتب سازی نوشته ها"><option value="updated">آخرین ویرایش</option><option value="created">تاریخ ساخت</option><option value="title">عنوان (A-Z)</option></select></label></div>' +
              '<div class="nb-list" id="nbList" role="list"></div>' +
              '<div class="nb-explorer-count"><span data-nb-listcount>۰ نوشته</span><span class="nb-save">ذخیره خودکار · آخرین نوشته بازشده حفظ می شود</span></div>' +
            '</section>' +
          '</div>' +
        '</div>' +
        '<div class="nb-noteview" data-nb-noteview hidden>' +
          '<div class="nb-note-top">' +
            '<button class="iact nb-back" data-nb="back-list" title="بازگشت به لیست نوشته ها">‹ بازگشت به لیست نوشته ها</button>' +
            '<span class="nb-top-title">یادداشت آخر · Split View برای مقایسه اختیاری</span>' +
            '<div class="nb-top-actions">' +
              '<button class="iact nb-split-toggle" data-nb="split-toggle" aria-pressed="false" title="نمایش دو یادداشت کنار هم">▥ Split View | مقایسه</button>' +
              '<button class="iact" data-nb="new" title="یادداشت جدید">' + I('plus') + ' یادداشت جدید</button>' +
            '</div>' +
          '</div>' +
          '<div class="nb-workspace" data-nb-workspace>' +
            '<section class="nb-pane nb-pane-primary" data-nb-pane="primary" aria-label="یادداشت اصلی">' +
              '<div class="nb-pane-head">' +
                '<input class="nb-title-input" id="nbTitle" type="text" dir="auto" data-nb-title="primary" placeholder="عنوان یادداشت…" aria-label="عنوان یادداشت اصلی">' +
                '<div class="nb-pane-head-actions">' +
                  '<button type="button" class="iact nb-properties-toggle" data-nb="properties-toggle" data-side="primary" aria-expanded="false" title="باز کردن ویژگی های فولدر، تگ و دسته بندی">◈ ویژگی ها</button>' +
                  '<button type="button" class="iact nb-direction-toggle" data-nb="direction" data-side="primary" data-direction-mode="auto" aria-pressed="false" title="' + esc(textDirectionTitle('auto')) + '" aria-label="' + esc(textDirectionTitle('auto')) + '">' + I('direction') + '<span data-direction-label>AUTO</span></button>' +
                  '<button type="button" class="iact nb-scroll-sync" data-nb="scroll-sync" data-side="primary" aria-pressed="false" hidden title="هماهنگ سازی اسکرول ویرایشگر و پیش نمایش" aria-label="هماهنگ سازی اسکرول این پنل">' + I('sync') + '</button>' +
                  '<button type="button" class="iact nb-mode-toggle nb-pane-mode" data-nb="toggle-mode" data-side="primary" title="چرخه حالت Edit، Read و خواندن و ویرایش" aria-label="تغییر حالت یادداشت"></button>' +
                '</div>' +
              '</div>' +
              '<div class="nb-properties-slot" data-nb-properties="primary" data-open="false" hidden></div>' +
              makeToolbar('primary') +
              '<div class="attachment-guidance" data-attachment-guidance data-guidance-scope="notebook" role="status" aria-live="polite" hidden></div>' +
              '<div class="nb-body">' +
                '<textarea class="nb-edit" id="nbEdit" data-nb-edit="primary" dir="auto" spellcheck="false" placeholder="یادداشتت را با Markdown بنویس…&#10;&#10;# عنوان، **ضخیم**، - لیست، - [ ] کار، | جدول | و `کد` پشتیبانی می شود."></textarea>' +
                '<div class="nb-body-divider" data-nb-resize="body-primary" role="separator" aria-orientation="vertical" aria-label="تغییر اندازه ویرایشگر و پیش نمایش" aria-valuemin="20" aria-valuemax="80" aria-valuenow="50" tabindex="0" hidden></div>' +
                '<div class="nb-preview md things-markdown" id="nbPreview" data-nb-preview="primary" hidden></div>' +
              '</div>' +
              '<div class="nb-foot"><span data-nb-count="primary">۰ کاراکتر</span><span data-nb-updated="primary"></span><span class="nb-save">ذخیره خودکار ✓</span></div>' +
            '</section>' +
            '<div class="nb-split-divider" data-nb-resize="split" role="separator" aria-label="تغییر اندازه دو یادداشت" aria-valuemin="20" aria-valuemax="80" tabindex="0" hidden></div>' +
            '<section class="nb-pane nb-pane-secondary" data-nb-pane="secondary" aria-label="یادداشت دوم" hidden>' +
              '<div class="nb-pane-head nb-pane-head-secondary">' +
                '<div class="nb-pane-select"><select data-nb-secondary-select aria-label="انتخاب یادداشت دوم"></select></div>' +
                '<div class="nb-pane-head-actions">' +
                  '<button type="button" class="iact nb-properties-toggle" data-nb="properties-toggle" data-side="secondary" aria-expanded="false" title="باز کردن ویژگی های فولدر، تگ و دسته بندی">◈ ویژگی ها</button>' +
                  '<button type="button" class="iact nb-direction-toggle" data-nb="direction" data-side="secondary" data-direction-mode="auto" aria-pressed="false" title="' + esc(textDirectionTitle('auto')) + '" aria-label="' + esc(textDirectionTitle('auto')) + '">' + I('direction') + '<span data-direction-label>AUTO</span></button>' +
                  '<button type="button" class="iact nb-scroll-sync" data-nb="scroll-sync" data-side="secondary" aria-pressed="false" hidden title="هماهنگ سازی اسکرول ویرایشگر و پیش نمایش" aria-label="هماهنگ سازی اسکرول این پنل">' + I('sync') + '</button>' +
                  '<button type="button" class="iact nb-mode-toggle nb-pane-mode" data-nb="toggle-mode" data-side="secondary" title="چرخه حالت Edit، Read و خواندن و ویرایش" aria-label="تغییر حالت یادداشت"></button>' +
                '</div>' +
                '<button class="iact nb-pane-close" data-nb="close-split" title="بستن پنل دوم">' + I('x') + '</button>' +
              '</div>' +
              '<div class="nb-title-row nb-secondary-title-row"><input class="nb-title-input" id="nbTitleSecondary" type="text" dir="auto" data-nb-title="secondary" placeholder="عنوان یادداشت دوم…" aria-label="عنوان یادداشت دوم"></div>' +
              '<div class="nb-properties-slot" data-nb-properties="secondary" data-open="false" hidden></div>' +
              makeToolbar('secondary') +
              '<div class="nb-body">' +
                '<textarea class="nb-edit" id="nbEditSecondary" data-nb-edit="secondary" dir="auto" spellcheck="false" placeholder="یادداشت دوم را اینجا ویرایش کن…"></textarea>' +
                '<div class="nb-body-divider" data-nb-resize="body-secondary" role="separator" aria-orientation="vertical" aria-label="تغییر اندازه ویرایشگر و پیش نمایش" aria-valuemin="20" aria-valuemax="80" aria-valuenow="50" tabindex="0" hidden></div>' +
                '<div class="nb-preview md things-markdown" id="nbPreviewSecondary" data-nb-preview="secondary" hidden></div>' +
              '</div>' +
              '<div class="nb-foot"><span data-nb-count="secondary">۰ کاراکتر</span><span data-nb-updated="secondary"></span><span class="nb-save">ذخیره خودکار ✓</span></div>' +
            '</section>' +
          '</div>' +
        '</div>' +
      '</aside>' +
      '<button class="fab" id="fabNote" type="button" title="باز/بسته کردن دفترچه یادداشت">' +
        I('note', 'big') + '<span>دفترچه</span><b class="fab-dot" data-nb-dot hidden></b>' +
      '</button>';
    while (wrap.firstChild) document.body.appendChild(wrap.firstChild);
    nbEls = {
      panel: $('#nbPanel'), overlay: $('#nbOverlay'), fab: $('#fabNote'),
      edit: $('#nbEdit'), editSecondary: $('#nbEditSecondary'), preview: $('#nbPreview'), previewSecondary: $('#nbPreviewSecondary'),
      title: $('#nbTitle'), titleSecondary: $('#nbTitleSecondary'), search: $('#nbSearch'), secondarySelect: $('[data-nb-secondary-select]'),
      list: $('#nbList'), listView: $('[data-nb-listview]'), noteView: $('[data-nb-noteview]'), workspace: $('[data-nb-workspace]'),
      browseModes: $('[data-nb-browse-modes]'), browseItems: $('[data-nb-browse-items]'), sort: $('[data-nb-sort]'), facetHeading: $('[data-nb-facet-heading]'), breadcrumb: $('[data-nb-breadcrumb]'), path: $('[data-nb-path]'),
      propertiesPrimary: $('[data-nb-properties="primary"]'), propertiesSecondary: $('[data-nb-properties="secondary"]'),
      primaryPane: $('[data-nb-pane="primary"]'), secondaryPane: $('[data-nb-pane="secondary"]'),
      widthHandle: $('[data-nb-resize="width"]'), splitHandle: $('[data-nb-resize="split"]'),
      bodyDivider: $('[data-nb-resize="body-primary"]'), bodyDividerSecondary: $('[data-nb-resize="body-secondary"]'),
      state: $('[data-nb-state]'), dot: $('[data-nb-dot]'), total: $('[data-nb-total]'), listCount: $('[data-nb-listcount]'),
      modeBtn: $('[data-nb="toggle-mode"][data-side="primary"]'), splitBtn: $('[data-nb="split-toggle"]')
    };
    nbEls.fab.addEventListener('click', () => nbToggle());
    nbEls.overlay.addEventListener('click', () => nbToggle(false));
    nbEls.panel.addEventListener('scroll', nbHandleScrollSync, true);
    [nbEls.widthHandle,nbEls.splitHandle,nbEls.bodyDivider,nbEls.bodyDividerSecondary].filter(Boolean).forEach(handle=>handle.addEventListener('pointerdown',nbResizeStart));
    [nbEls.widthHandle,nbEls.splitHandle,nbEls.bodyDivider,nbEls.bodyDividerSecondary].filter(Boolean).forEach(handle=>handle.addEventListener('keydown',nbResizeKey));
    window.addEventListener('resize',()=>{nbApplyResizeLayout();updateHeaderCompact();if(nbTypewriterEnabled.primary)nbScheduleTypewriterScroll(nbEls&&nbEls.edit);if(nbTypewriterEnabled.secondary)nbScheduleTypewriterScroll(nbEls&&nbEls.editSecondary);},{passive:true});
    nbApplyResizeLayout();
    nbEls.panel.addEventListener('click', (e) => {
      const b = e.target.closest('[data-nb]'); if (!b) return;
      if (e.target.closest('.nb-card-editor') && !e.target.closest('.nb-card-editor [data-nb]')) return;
      const a = b.dataset.nb, side = b.dataset.side || 'primary';
      if (a === 'attachment-connect') attachmentStore.connectFromUser();
      else if (a === 'close') nbToggle(false);
      else if (a === 'new' || a === 'new2') nbCreate(side);
      else if (a === 'back-list') nbBackToList();
      else if (a === 'open') nbOpenNote(b.dataset.id);
      else if (a === 'browse-mode') { state.nbBrowseMode=b.dataset.mode||'all';state.nbBrowseValue='';state.nbCardEditorId='';nbManagerEdit=null;nbManagerDelete=null;save();nbRenderList(); }
      else if (a === 'browse-value') { state.nbBrowseMode=b.dataset.mode||state.nbBrowseMode;state.nbBrowseValue=b.dataset.value||'';state.nbCardEditorId='';nbManagerEdit=null;nbManagerDelete=null;save();nbRenderList(); }
      else if (a === 'facet-create-submit') nbCreateFacet(b.dataset.mode);
      else if (a === 'facet-edit') { e.stopPropagation();nbStartFacetEdit(b.dataset.mode,b.dataset.value); }
      else if (a === 'facet-edit-save') { e.stopPropagation();nbSaveFacetEdit(b.dataset.mode,b.dataset.value); }
      else if (a === 'facet-edit-cancel') { e.stopPropagation();nbManagerEdit=null;nbRenderList(); }
      else if (a === 'facet-delete') { e.stopPropagation();nbManagerDelete={mode:b.dataset.mode,key:b.dataset.value};nbManagerEdit=null;nbRenderBrowse(); }
      else if (a === 'facet-confirm-delete') { e.stopPropagation();nbDeleteFacet(b.dataset.mode,b.dataset.value); }
      else if (a === 'facet-cancel-delete') { e.stopPropagation();nbManagerDelete=null;nbRenderBrowse(); }
      else if (a === 'property-tag-toggle') { e.stopPropagation();nbToggleNoteTag(side,b.dataset.value); }
      else if (a === 'property-create') { e.stopPropagation();nbCreatePropertyForNote(side,b.dataset.kind); }
      else if (a === 'metadata-edit') { e.stopPropagation();state.nbCardEditorId=state.nbCardEditorId===b.dataset.id?'':b.dataset.id;nbRenderList(); }
      else if (a === 'metadata-create-property') { e.stopPropagation();nbCreateCardProperty(b.dataset.id,b.dataset.kind); }
      else if (a === 'metadata-save') { e.stopPropagation();nbSaveCardMetadata(b.dataset.id); }
      else if (a === 'metadata-cancel') { e.stopPropagation();state.nbCardEditorId='';nbRenderList(); }
      else if (a === 'split-toggle') nbToggleSplit();
      else if (a === 'close-split') nbToggleSplit(false);
      else if (a === 'properties-toggle') nbToggleProperties(side);
      else if (a === 'properties-close') nbToggleProperties(side, false);
      else if (a === 'font-scale') adjustFontScale('nb', b.dataset.dir);
      else if (a === 'toggle-mode') nbToggleMode(null, side);
      else if (a === 'direction') nbCycleDirection(side);
      else if (a === 'scroll-sync') nbToggleScrollSync(side);
      else if (a === 'typewriter') nbToggleTypewriter(side);
      else if (a === 'fmt') { if(b.dataset.v==='media')openEditorMediaPicker(side==='secondary'?nbEls.editSecondary:nbEls.edit);else nbFormat(b.dataset.v, side); }
      else if (a === 'copy') nbCopy(side);
      else if (a === 'share') nbShare(side);
      else if (a === 'download') nbDownload(side);
      else if (a === 'duplicate') nbDuplicate(null, side);
      else if (a === 'delete') nbDeleteNote(nbNoteId(side), true, side);
      else if (a === 'delete-card') { e.stopPropagation(); nbDeleteNote(b.dataset.id, false, 'list'); }
      else if (a === 'duplicate-card') { e.stopPropagation(); nbDuplicate(b.dataset.id, 'primary'); }
    });
    nbEls.panel.addEventListener('keydown', e => {
      if (e.key !== 'Enter' || e.shiftKey || e.ctrlKey || e.metaKey || e.altKey || e.isComposing || e.keyCode === 229) return;
      const input = e.target;
      if (!input || !input.matches || !input.matches('input')) return;
      let button = null;
      const facet = input.dataset.nbFacetInput;
      if (facet && nbEls.browseItems) button = nbEls.browseItems.querySelector('[data-nb="facet-create-submit"][data-mode="' + facet + '"]');
      const property = input.dataset.nbPropertyNew;
      if (property) button = nbEls.panel.querySelector('[data-nb="property-create"][data-kind="' + property + '"][data-side="' + (input.dataset.side || 'primary') + '"]');
      const card = input.closest('.nb-card-editor');
      const cardKind = input.dataset.nbCardNew;
      if (card && cardKind) button = card.querySelector('[data-nb="metadata-create-property"][data-kind="' + cardKind + '"]');
      if (card && input.matches('[data-nb-card-field="category"]')) button = card.querySelector('[data-nb="metadata-create-property"][data-kind="category"]');
      if (button) { e.preventDefault(); e.stopPropagation(); button.click(); }
    });
    document.addEventListener('input', nbTypewriterEvent, true);
    document.addEventListener('keyup', nbTypewriterEvent, true);
    document.addEventListener('mouseup', nbTypewriterEvent, true);
    document.addEventListener('focusin', nbTypewriterEvent, true);
    [nbEls.edit, nbEls.editSecondary].forEach(ta => ta.addEventListener('input', () => {
      const side = ta.dataset.nbEdit, n = nbActive(side); if (!n) return;
      n.body = ta.value; n.updatedAt = new Date().toISOString(); nbLegacyDirty = true;
      if (nbMode(side) === 'both') {
        clearTimeout(ta._previewTimer);
        if (ta.value.length <= 4000) nbRenderPreview(side);
        else ta._previewTimer = setTimeout(() => { if (ta.isConnected && nbMode(side) === 'both') nbRenderPreview(side); }, 180);
      }
      clearTimeout(ta._saveTimer); ta._saveTimer = setTimeout(() => { save(650); nbRenderCounts(side); }, 220);
    }));
    [nbEls.title, nbEls.titleSecondary].filter(Boolean).forEach(inp => inp.addEventListener('input', () => {
      const side = inp.dataset.nbTitle, n = nbActive(side); if (!n) return;
      n.title = inp.value; n.updatedAt = new Date().toISOString(); nbLegacyDirty = true;
      clearTimeout(inp._saveTimer); inp._saveTimer = setTimeout(() => { save(500); nbRenderCounts(side); }, 220);
    }));
    nbEls.secondarySelect.addEventListener('change', () => {
      const id = nbEls.secondarySelect.value;
      if (!id || id === state.nbActiveId) return;
      nbSetPropertiesOpen('secondary', false);
      state.nbSecondaryId = id; state.nbSecondaryMode = 'edit'; nbScrollSyncEnabled.secondary = false; save(); nbRender();
    });
    nbEls.search.addEventListener('input', () => {
      state.nbQuery = nbEls.search.value;
      clearTimeout(nbSearchTimer);
      const query=state.nbQuery;
      nbSearchTimer=setTimeout(()=>{if(state.nbQuery===query)nbRenderList(true);},120);
    });
    if (nbEls.sort) nbEls.sort.addEventListener('change', () => { state.nbSort = nbEls.sort.value; save(); nbRenderList(); });
    nbEls.panel.addEventListener('change',e=>{
      const field=e.target.closest('[data-nb-property]');if(!field)return;
      const side=field.dataset.side==='secondary'?'secondary':'primary',note=nbActive(side);if(!note)return;
      if(field.dataset.nbProperty==='folder')note.folderId=field.value||'';
      else if(field.dataset.nbProperty==='category')note.category=field.value?nbEnsureFacet('categories',field.value):'';
      note.updatedAt=new Date().toISOString();nbSyncLegacy();saveNow();nbRenderList();nbRenderCounts(side);
    });
    nbEls.panel.addEventListener('input',e=>{
      const filter=e.target.closest('[data-nb-tag-filter]');if(!filter)return;
      const q=norm(filter.value);const slot=filter.closest('.nb-property-tags');
      if(slot)slot.querySelectorAll('.nb-tag-option').forEach(btn=>{btn.hidden=!!q&&norm(btn.dataset.value).indexOf(q)<0;});
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') { if(activeInlineConfirm){activeInlineConfirm(false);return;} if (state.ui.phaseDrawerOpen) { togglePhaseDrawer(false); return; } if (state.ui.menuDrawerOpen) { toggleMenuDrawer(false); return; } closeMenus(); nbToggle(false, true); closeModal(); }
    });
    document.addEventListener('click', (e) => { if (!e.target.closest('.menu-wrap')) closeMenus(); });
  }
  function nbApplyBodySplitLayout(side) {
    if(!nbEls)return;
    side=side==='secondary'?'secondary':'primary';
    const edit=side==='secondary'?nbEls.editSecondary:nbEls.edit;
    const divider=side==='secondary'?nbEls.bodyDividerSecondary:nbEls.bodyDivider;
    const body=edit&&edit.closest('.nb-body');if(!body)return;
    const mode=nbMode(side),active=mode==='both',mobile=window.innerWidth<=720;
    body.dataset.mode=mode;
    if(divider){
      divider.hidden=!active;
      divider.setAttribute('aria-orientation',mobile?'horizontal':'vertical');
      divider.setAttribute('aria-valuenow',String(Math.round(clampNbBodyRatio(side==='secondary'?state.nbBodyRatioSecondary:state.nbBodyRatio,.5)*100)));
    }
    if(!active){body.style.removeProperty('grid-template-columns');body.style.removeProperty('grid-template-rows');body.style.removeProperty('gap');return;}
    const ratio=clampNbBodyRatio(side==='secondary'?state.nbBodyRatioSecondary:state.nbBodyRatio,.5);
    body.style.gridTemplateColumns=mobile?'minmax(0,1fr)':`minmax(0, ${ratio}fr) 12px minmax(0, ${1-ratio}fr)`;
    body.style.gridTemplateRows=mobile?`minmax(0, ${ratio}fr) 12px minmax(0, ${1-ratio}fr)`:'minmax(0,1fr)';
    body.style.gap='0';
  }
  function nbApplyResizeLayout() {
    if(!nbEls)return;
    const desktop=window.innerWidth>=1440, mobile=window.innerWidth<=720;
    const split=state.nbView==='note'&&state.nbSplit&&!!nbActive('secondary'),ratio=clampNbSplit(state.nbSplitRatio,.5);
    nbEls.panel.style.setProperty('width',desktop?clampNbWidth(state.nbWidthPct,75)+'vw':'100vw','important');
    if(nbEls.widthHandle){nbEls.widthHandle.hidden=!desktop;nbEls.widthHandle.setAttribute('aria-valuenow',String(Math.round(clampNbWidth(state.nbWidthPct,75))));}
    if(nbEls.splitHandle){
      nbEls.splitHandle.hidden=!split;
      nbEls.splitHandle.setAttribute('aria-valuenow',String(Math.round(ratio*100)));
      nbEls.splitHandle.setAttribute('aria-orientation',mobile?'horizontal':'vertical');
    }
    if(nbEls.workspace){
      nbEls.workspace.classList.toggle('split-vertical',split&&mobile);
      nbEls.workspace.style.setProperty('--nb-split-ratio',String(ratio));
      nbEls.workspace.style.gridTemplateColumns=split&&!mobile?`minmax(260px, ${ratio}fr) 14px minmax(260px, ${1-ratio}fr)`:'minmax(0,1fr)';
      nbEls.workspace.style.gridTemplateRows=split&&mobile?`minmax(150px, ${ratio}fr) 14px minmax(150px, ${1-ratio}fr)`:'minmax(0,1fr)';
    }
    nbApplyBodySplitLayout('primary');nbApplyBodySplitLayout('secondary');
  }
  function nbResizeStart(e) {
    if(e.isPrimary===false||(e.pointerType==='mouse'&&e.button!==0))return;
    e.preventDefault();
    const kind=e.currentTarget.dataset.nbResize,handle=e.currentTarget,pointerId=e.pointerId;
    try{if(pointerId!=null&&handle.setPointerCapture)handle.setPointerCapture(pointerId);}catch(_){ }
    const move=ev=>{
      if(pointerId!=null&&ev.pointerId!==pointerId)return;
      ev.preventDefault();
      if(kind==='width'){
        const viewport=Math.max(1,window.innerWidth);
        state.nbWidthPct=clampNbWidth((viewport-ev.clientX)*100/viewport,75);
        nbEls.panel.style.setProperty('width',state.nbWidthPct+'vw','important');
        handle.setAttribute('aria-valuenow',String(Math.round(state.nbWidthPct)));
      }else if(kind==='split'){
        const workspace=nbEls.workspace,r=workspace.getBoundingClientRect(),style=getComputedStyle(workspace),mobile=window.innerWidth<=720;
        const pl=parseFloat(style.paddingLeft)||0,pr=parseFloat(style.paddingRight)||0,pt=parseFloat(style.paddingTop)||0,pb=parseFloat(style.paddingBottom)||0;
        const available=mobile?workspace.clientHeight-pt-pb-14:workspace.clientWidth-pl-pr-14;
        if(available<=0)return;
        const raw=mobile?(ev.clientY-r.top-pt-7)/available:(r.right-pr-ev.clientX-7)/available;
        state.nbSplitRatio=clampNbSplit(raw,.5);nbApplyResizeLayout();
      }else if(kind==='body-primary'||kind==='body-secondary'){
        const side=kind==='body-secondary'?'secondary':'primary',edit=side==='secondary'?nbEls.editSecondary:nbEls.edit;
        const body=edit&&edit.closest('.nb-body');if(!body)return;
        const r=body.getBoundingClientRect(),style=getComputedStyle(body),mobile=window.innerWidth<=720;
        const pl=parseFloat(style.paddingLeft)||0,pr=parseFloat(style.paddingRight)||0,pt=parseFloat(style.paddingTop)||0,pb=parseFloat(style.paddingBottom)||0;
        const available=mobile?body.clientHeight-pt-pb-12:body.clientWidth-pl-pr-12;
        if(available<=0)return;
        const raw=mobile?(ev.clientY-r.top-pt-6)/available:(r.right-pr-ev.clientX-6)/available;
        if(side==='secondary')state.nbBodyRatioSecondary=clampNbBodyRatio(raw,.5);else state.nbBodyRatio=clampNbBodyRatio(raw,.5);
        nbApplyBodySplitLayout(side);
      }
    };
    const orientation=(kind==='split'||kind==='body-primary'||kind==='body-secondary')&&window.innerWidth<=720?'nb-resizing-vertical':'nb-resizing-horizontal';
    const end=()=>{
      window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',end);window.removeEventListener('pointercancel',end);
      document.body.classList.remove('nb-resizing','nb-resizing-horizontal','nb-resizing-vertical');
      try{if(pointerId!=null&&handle.releasePointerCapture&&handle.hasPointerCapture(pointerId))handle.releasePointerCapture(pointerId);}catch(_){ }
      saveNow();
    };
    document.body.classList.add('nb-resizing',orientation);
    window.addEventListener('pointermove',move,{passive:false});window.addEventListener('pointerup',end,{once:true});window.addEventListener('pointercancel',end,{once:true});
  }
  function nbResizeKey(e) {
    const kind=e.currentTarget.dataset.nbResize;
    if(kind==='width'&&(e.key==='ArrowLeft'||e.key==='ArrowRight')){
      e.preventDefault();state.nbWidthPct=clampNbWidth(state.nbWidthPct+(e.key==='ArrowLeft'?2:-2),75);nbApplyResizeLayout();saveNow();
    }else if(kind==='split'){
      const mobile=window.innerWidth<=720,keys=mobile?['ArrowUp','ArrowDown']:['ArrowLeft','ArrowRight'];
      if(!keys.includes(e.key))return;
      e.preventDefault();const grow=mobile?e.key==='ArrowDown':e.key==='ArrowLeft';
      state.nbSplitRatio=clampNbSplit(state.nbSplitRatio+(grow?0.05:-0.05),.5);nbApplyResizeLayout();saveNow();
    }else if(kind==='body-primary'||kind==='body-secondary'){
      const side=kind==='body-secondary'?'secondary':'primary',mobile=window.innerWidth<=720,keys=mobile?['ArrowUp','ArrowDown']:['ArrowLeft','ArrowRight'];
      if(!keys.includes(e.key))return;
      e.preventDefault();const grow=mobile?e.key==='ArrowDown':e.key==='ArrowLeft',key=side==='secondary'?'nbBodyRatioSecondary':'nbBodyRatio';
      state[key]=clampNbBodyRatio(state[key]+(grow?0.05:-0.05),.5);nbApplyBodySplitLayout(side);saveNow();
    }
  }
  function nbNoteId(side) { return side === 'secondary' ? state.nbSecondaryId : state.nbActiveId; }
  function nbMode(side) { return side === 'secondary' ? state.nbSecondaryMode : state.nbMode; }
  function nbToggle(force, silent) {
    if (!nbEls) return;
    const open = (typeof force === 'boolean') ? force : !state.ui.nbOpen;
    state.ui.nbOpen = open;
    nbEls.panel.classList.toggle('open', open);
    nbEls.panel.setAttribute('aria-hidden', open ? 'false' : 'true');
    nbEls.overlay.classList.toggle('show', open);
    document.body.classList.toggle('nb-open', open);
    if (open) {
      nbMigrate();
      if (nbActive()) state.nbMode = 'edit';
      if (state.nbSplit && nbActive('secondary')) state.nbSecondaryMode = 'edit';
      nbScrollSyncEnabled.primary = false; nbScrollSyncEnabled.secondary = false;
      nbSetPropertiesOpen('primary', false); nbSetPropertiesOpen('secondary', false);
      state.nbView = nbActive() ? 'note' : 'list';
      nbRender(); save();
      setTimeout(() => {
        if (state.nbView === 'note') { if (nbMode('primary') === 'read') nbEls.modeBtn.focus(); else nbEls.edit.focus(); }
        else if (nbEls.search) nbEls.search.focus();
      }, 140);
    } else if (!silent) save();
    const hb = $('[data-act="notebook"]'); if (hb) hb.classList.toggle('on', open);
  }
  function nbBackToList() {
    nbSetPropertiesOpen('primary', false); nbSetPropertiesOpen('secondary', false);
    state.nbView = 'list'; save(); nbRender();
    if (nbEls.search) setTimeout(() => nbEls.search.focus(), 60);
  }
  function nbOpenNote(id) {
    const n = (state.nbNotes || []).filter(x => x.id === id)[0]; if (!n) return;
    nbSetPropertiesOpen('primary', false); nbSetPropertiesOpen('secondary', false);
    state.nbActiveId = id; state.nbMode = 'edit'; nbScrollSyncEnabled.primary = false; state.nbView = 'note'; nbMigrate(); save(); nbRender();
    setTimeout(() => { if (nbMode('primary') !== 'read') nbEls.edit.focus(); }, 80);
  }
  function nbToggleSplit(force) {
    const want = typeof force === 'boolean' ? force : !state.nbSplit;
    if (!want) { nbSetPropertiesOpen('secondary', false); state.nbSplit = false; save(); nbRender(); return; }
    nbMigrate();
    if (!state.nbActiveId) { toast('ابتدا یک یادداشت را باز کن.'); return; }
    let other = (state.nbNotes || []).find(n => n.id === state.nbSecondaryId && n.id !== state.nbActiveId);
    if (!other) other = (state.nbNotes || []).find(n => n.id !== state.nbActiveId);
    if (!other) { toast('برای Split View دست کم دو یادداشت لازم است. یک یادداشت دیگر بساز.'); return; }
    nbSetPropertiesOpen('secondary', false);
    state.nbSecondaryId = other.id; state.nbSecondaryMode = 'edit'; nbScrollSyncEnabled.secondary = false; state.nbSplit = true; save(); nbRender();
  }
  function nbCreate(side, metadata) {
    side = side === 'secondary' ? 'secondary' : 'primary';
    nbSetPropertiesOpen(side, false);
    nbMigrate();
    const seed=Object.assign({},metadata||{});
    if (!metadata && state.nbView === 'list' && state.nbBrowseValue) {
      if (state.nbBrowseMode === 'folders' && state.nbBrowseValue !== '__none__') seed.folderId=state.nbBrowseValue;
      else if (state.nbBrowseMode === 'tags') seed.tags=[state.nbBrowseValue];
      else if (state.nbBrowseMode === 'categories') seed.category=state.nbBrowseValue;
    }
    const now = new Date().toISOString();
    const n = { id: uid('nb'), title: '', body: '', folderId:String(seed.folderId||''),category:String(seed.category||''),tags:nbParseTags(seed.tags),direction:'auto',createdAt: now, updatedAt: now };
    state.nbNotes.push(n);
    if (side === 'secondary') { state.nbSecondaryId = n.id; state.nbSecondaryMode = 'edit'; state.nbSplit = true; }
    else { state.nbActiveId = n.id; state.nbMode = 'edit'; }
    state.nbView = 'note'; nbSyncLegacy(); saveNow(); nbRender();
    setTimeout(() => { const input = side === 'secondary' ? $('[data-nb-title="secondary"]') : nbEls.title; if (input) input.focus(); }, 80);
    toast('یادداشت جدید ساخته شد؛ عنوان و متن را بنویس (ذخیره خودکار است).');
  }
  async function nbDeleteNote(id, goList, side) {
    const n = (state.nbNotes || []).find(x => x.id === id); if (!n) { toast('یادداشتی انتخاب نشده است.'); return; }
    const label = String(n.title || '').trim() || nbTitleFromBody(n.body);
    if (!await showInlineConfirm('نوشته «' + label + '» حذف شود؟ این کار قابل بازگشت نیست.','حذف نوشته',nbEls&&nbEls.panel)) return;
    if (state.nbActiveId === id) nbSetPropertiesOpen('primary', false);
    if (state.nbSecondaryId === id) nbSetPropertiesOpen('secondary', false);
    state.nbNotes = state.nbNotes.filter(x => x.id !== id);
    if (state.nbActiveId === id) {
      const rest = nbSorted(state.nbNotes); state.nbActiveId = rest.length ? rest[0].id : '';
    }
    if (state.nbSecondaryId === id) {
      const other = state.nbNotes.find(x => x.id !== state.nbActiveId);
      state.nbSecondaryId = other ? other.id : '';
      if (!other) state.nbSplit = false;
    }
    if (state.nbSecondaryId === state.nbActiveId) {
      const other = state.nbNotes.find(x => x.id !== state.nbActiveId);
      state.nbSecondaryId = other ? other.id : ''; if (!other) state.nbSplit = false;
    }
    if (!state.nbActiveId || (goList && side !== 'secondary')) state.nbView = 'list';
    nbSyncLegacy(); saveNow(); nbRender(); toast('یادداشت حذف شد.');
  }
  function nbDuplicate(id, side) {
    side = side === 'secondary' ? 'secondary' : 'primary';
    nbSetPropertiesOpen(side, false);
    const src = (state.nbNotes || []).find(x => x.id === (id || nbNoteId(side)));
    if (!src) { toast('یادداشتی برای تکثیر نیست.'); return; }
    const now = new Date().toISOString();
    const n = { id: uid('nb'), title: (String(src.title || '').trim() || nbTitleFromBody(src.body)) + ' (کپی)', body: src.body || '', folderId:src.folderId||'',category:src.category||'',tags:nbParseTags(src.tags),direction:normalizeTextDirection(src.direction),createdAt: now, updatedAt: now };
    state.nbNotes.push(n);
    if (side === 'secondary') { state.nbSecondaryId = n.id; state.nbSecondaryMode = 'edit'; state.nbSplit = true; }
    else { state.nbActiveId = n.id; state.nbMode = 'edit'; }
    state.nbView = 'note'; nbSyncLegacy(); saveNow(); nbRender(); toast('یادداشت تکثیر شد.');
  }
  function nbToggleMode(force, side) {
    side = side === 'secondary' ? 'secondary' : 'primary';
    const key = side === 'secondary' ? 'nbSecondaryMode' : 'nbMode';
    const nextMode = { edit: 'read', read: 'both', both: 'edit' };
    state[key] = ['edit','read','both'].includes(force) ? force : (nextMode[state[key]] || 'read');
    if (state[key] !== 'both') nbScrollSyncEnabled[side] = false;
    save(); nbRenderPane(side);
  }
  function nbSyncScrollPosition(side, source) {
    side=side==='secondary'?'secondary':'primary';
    if(!nbEls||!nbScrollSyncEnabled[side]||nbScrollSyncGuard[side]||nbMode(side)!=='both')return;
    const edit=side==='secondary'?nbEls.editSecondary:nbEls.edit,preview=side==='secondary'?nbEls.previewSecondary:nbEls.preview;
    const from=source===preview?preview:edit,to=from===edit?preview:edit;
    if(!from||!to)return;
    const maxFrom=Math.max(0,from.scrollHeight-from.clientHeight),maxTo=Math.max(0,to.scrollHeight-to.clientHeight);
    const ratio=maxFrom?Math.max(0,Math.min(1,from.scrollTop/maxFrom)):0,targetTop=ratio*maxTo;
    if(Math.abs(to.scrollTop-targetTop)<1)return;
    nbScrollSyncGuard[side]=true;to.scrollTop=targetTop;
    requestAnimationFrame(()=>requestAnimationFrame(()=>{nbScrollSyncGuard[side]=false;}));
  }
  function nbToggleScrollSync(side) {
    side = side === 'secondary' ? 'secondary' : 'primary';
    if (nbMode(side) !== 'both') return;
    nbScrollSyncEnabled[side] = !nbScrollSyncEnabled[side];
    const button = nbEls && nbEls.panel.querySelector('[data-nb="scroll-sync"][data-side="' + side + '"]');
    if (button) {
      button.setAttribute('aria-pressed', nbScrollSyncEnabled[side] ? 'true' : 'false');
      button.classList.toggle('on', nbScrollSyncEnabled[side]);
      button.title = nbScrollSyncEnabled[side] ? 'خاموش کردن هماهنگ سازی اسکرول' : 'هماهنگ سازی اسکرول ویرایشگر و پیش نمایش';
    }
    if(nbScrollSyncEnabled[side])nbSyncScrollPosition(side,side==='secondary'?nbEls.editSecondary:nbEls.edit);
    save();
  }
  function nbHandleScrollSync(e) {
    const source=e.target;if(!source||!source.matches||!source.matches('[data-nb-edit],[data-nb-preview]'))return;
    const side=source.dataset.nbEdit||source.dataset.nbPreview;
    if((side!=='primary'&&side!=='secondary')||!nbScrollSyncEnabled[side]||nbScrollSyncGuard[side]||nbMode(side)!=='both')return;
    nbSyncScrollPosition(side,source);
  }
  function nbSnippet(body) {
    return String(body || '').replace(/```[\s\S]*?```/g, ' ').replace(/[#>*`~=\-|[\]()]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 140);
  }
  function nbDateLabel(iso) {
    if (!iso) return '';
    try { return new Date(iso).toLocaleString('fa-IR', { dateStyle: 'medium', timeStyle: 'short' }); } catch (e) { return ''; }
  }
  function nbFacetCounts(type) {
    const isCategory=type==='categories', source=isCategory?(state.nbCategories||[]):(state.nbTags||[]), map=new Map();
    source.forEach(value=>{const key=norm(value);if(key&&!map.has(key))map.set(key,{value:String(value),count:0});});
    (state.nbNotes||[]).forEach(n=>{
      const vals=isCategory?(n.category?[n.category]:[]):(n.tags||[]);
      vals.forEach(value=>{const key=norm(value);if(!key)return;const item=map.get(key)||{value:String(value),count:0};item.count++;map.set(key,item);});
    });
    return [...map.values()].sort((a,b)=>a.value.localeCompare(b.value));
  }
  function nbFacetLabel(type) { return type==='folders'?'فولدر':(type==='tags'?'تگ':(type==='categories'?'دسته بندی':'همه نوشته ها')); }
  function nbFacetManagerRow(mode,item) {
    const key=mode==='folders'?String(item.id):String(item.key!==undefined?item.key:item.value),value=String(item.value||item.name||''),isSpecial=!!item.special||(mode==='folders'&&(!key||key==='__none__'));
    const same=(x)=>x&&x.mode===mode&&norm(x.key)===norm(key);
    if(same(nbManagerDelete))return '<div class="nb-facet-confirm"><span>«'+esc(value)+'» حذف شود؟</span><button type="button" class="iact tiny d" data-nb="facet-confirm-delete" data-mode="'+mode+'" data-value="'+esc(key)+'">حذف</button><button type="button" class="iact tiny" data-nb="facet-cancel-delete">لغو</button></div>';
    if(same(nbManagerEdit))return '<div class="nb-facet-edit"><input type="text" maxlength="60" data-nb-manager-edit value="'+esc(nbManagerEdit.name||value)+'" aria-label="نام جدید '+nbFacetLabel(mode)+'"><button type="button" class="iact tiny" data-nb="facet-edit-save" data-mode="'+mode+'" data-value="'+esc(key)+'">ذخیره</button><button type="button" class="iact tiny" data-nb="facet-edit-cancel">لغو</button></div>';
    const icon=mode==='folders'?(key==='__none__'?'◌':'▰'):(mode==='tags'?'#':'◈');
    return '<div class="nb-facet-row"><button type="button" class="nb-facet '+((mode==='folders'?key===String(state.nbBrowseValue||''):norm(key)===norm(state.nbBrowseValue||''))?'on':'')+'" data-nb="browse-value" data-mode="'+mode+'" data-value="'+esc(key)+'"><span class="nb-facet-icon">'+icon+'</span><span>'+esc(value)+'</span><b>'+fa(item.count||0)+'</b></button>'+(!isSpecial?'<span class="nb-facet-actions"><button type="button" class="iact tiny" data-nb="facet-edit" data-mode="'+mode+'" data-value="'+esc(key)+'" title="ویرایش '+nbFacetLabel(mode)+'" aria-label="ویرایش '+esc(value)+'">'+I('edit')+'</button><button type="button" class="iact tiny d" data-nb="facet-delete" data-mode="'+mode+'" data-value="'+esc(key)+'" title="حذف '+nbFacetLabel(mode)+'" aria-label="حذف '+esc(value)+'">'+I('trash')+'</button></span>':'')+'</div>';
  }
  function nbRenderBrowse() {
    if(!nbEls)return;
    const browseScrollTop=nbEls.browseItems?nbEls.browseItems.scrollTop:0;
    const mode=state.nbBrowseMode||'all',value=state.nbBrowseValue||'',notes=state.nbNotes||[];
    const modes=[['all','همه نوشته ها',notes.length],['folders','فولدر',(state.nbFolders||[]).length],['tags','تگ',nbFacetCounts('tags').length],['categories','دسته بندی',nbFacetCounts('categories').length]];
    if(nbEls.browseModes)nbEls.browseModes.innerHTML=modes.map(([id,label,count])=>'<button type="button" class="nb-browse-mode '+(mode===id?'on':'')+'" role="tab" aria-selected="'+(mode===id?'true':'false')+'" data-nb="browse-mode" data-mode="'+id+'">'+label+' <b>'+fa(count)+'</b></button>').join('');
    const countByFolder=id=>notes.filter(n=>id==='__none__'?!n.folderId:n.folderId===id).length;
    let rows=[],html='';
    if(mode==='folders'){
      rows=[{id:'',value:'همه فولدرها',count:notes.length},...(state.nbFolders||[]).map(f=>({id:f.id,value:f.name,count:countByFolder(f.id)})),{id:'__none__',value:'بدون فولدر',count:countByFolder('__none__')}];
      html='<div class="nb-facet-create-inline"><input type="text" maxlength="60" data-nb-facet-input="folders" placeholder="نام فولدر جدید" aria-label="نام فولدر جدید"><button type="button" class="btn pri" data-nb="facet-create-submit" data-mode="folders">'+I('plus')+' ساخت فولدر</button></div>'+rows.map(item=>nbFacetManagerRow('folders',item)).join('');
    }else if(mode==='tags'||mode==='categories'){
      const items=nbFacetCounts(mode),isTag=mode==='tags';
      rows=[{key:'',value:isTag?'همه تگ ها':'همه دسته بندی ها',count:notes.length,special:true},...items];
      html='<div class="nb-facet-create-inline"><input type="text" maxlength="60" data-nb-facet-input="'+mode+'" placeholder="نام '+nbFacetLabel(mode)+' جدید" aria-label="نام '+nbFacetLabel(mode)+' جدید"><button type="button" class="btn pri" data-nb="facet-create-submit" data-mode="'+mode+'">'+I('plus')+' افزودن</button></div>'+rows.map(item=>nbFacetManagerRow(mode,item)).join('');
      if(!items.length)html+='<div class="nb-facet-empty">هنوز '+nbFacetLabel(mode)+'ی ساخته نشده است.</div>';
    }else html='<div class="nb-browse-hint">برای دیدن نوشته های مرتبط، یکی از تب های فولدر، تگ یا دسته بندی را انتخاب کن.</div>';
    if(nbEls.browseItems){nbEls.browseItems.innerHTML=html;nbEls.browseItems.scrollTop=browseScrollTop;}
    if(nbEls.facetHeading)nbEls.facetHeading.textContent=mode==='folders'?'فهرست فولدرها':(mode==='tags'?'فهرست تگ ها':(mode==='categories'?'فهرست دسته بندی ها':'فهرست نوشته ها'));
    if(nbEls.breadcrumb){
      let selected='همه نوشته ها';
      if(mode==='folders'&&value){const f=value==='__none__'?null:nbFolder(value);selected=f?f.name:'بدون فولدر';}
      else if((mode==='tags'||mode==='categories')&&value)selected=value;
      nbEls.breadcrumb.textContent=nbFacetLabel(mode)+'  /  '+selected;
    }
    if(nbEls.sort&&nbEls.sort.value!==state.nbSort)nbEls.sort.value=state.nbSort||'updated';
  }
  function nbNoteMetaHTML(note) {
    const folder=nbFolderName(note),parts=[];
    if(folder)parts.push('<span class="nb-meta-pill nb-meta-folder">▰ فولدر · '+esc(folder)+'</span>');
    if(note.category)parts.push('<span class="nb-meta-pill nb-meta-category">◈ دسته بندی · '+esc(note.category)+'</span>');
    (note.tags||[]).forEach(tag=>parts.push('<span class="nb-meta-pill nb-meta-tag">تگ · # '+esc(tag)+'</span>'));
    return '<div class="nb-card-tags">'+(parts.join('')||'<span class="nb-meta-empty">بدون فولدر، دسته بندی یا تگ</span>')+'</div>';
  }
  function nbCardMetadataEditor(note) {
    const id=esc(note.id),options='<option value="">بدون فولدر</option>'+(state.nbFolders||[]).map(f=>'<option value="'+esc(f.id)+'" '+(note.folderId===f.id?'selected':'')+'>'+esc(f.name)+'</option>').join('');
    return '<div class="nb-card-editor" data-note-id="'+id+'">'+
      '<div class="nb-card-field"><label><span>فولدر</span><select data-nb-card-field="folder">'+options+'</select></label><div class="nb-card-inline-add"><input type="text" maxlength="60" data-nb-card-new="folder" placeholder="نام فولدر جدید"><button type="button" class="iact tiny" data-nb="metadata-create-property" data-id="'+id+'" data-kind="folder">ساخت و انتخاب</button></div></div>'+
      '<div class="nb-card-field"><label><span>دسته بندی</span><input type="text" maxlength="60" data-nb-card-field="category" value="'+esc(note.category||'')+'" placeholder="مثلا: ایده، پروژه، مرجع"></label><button type="button" class="iact tiny" data-nb="metadata-create-property" data-id="'+id+'" data-kind="category">ثبت دسته بندی</button></div>'+
      '<div class="nb-card-field"><label><span>تگ ها</span><input type="text" maxlength="500" data-nb-card-field="tags" value="'+esc((note.tags||[]).join(', '))+'" placeholder="تگ ها را با ویرگول جدا کن"></label><div class="nb-card-inline-add"><input type="text" maxlength="60" data-nb-card-new="tag" placeholder="تگ جدید"><button type="button" class="iact tiny" data-nb="metadata-create-property" data-id="'+id+'" data-kind="tag">افزودن تگ</button></div></div>'+
      '<div class="nb-card-editor-actions"><button type="button" class="iact tiny" data-nb="metadata-save" data-id="'+id+'">'+I('check')+' ذخیره</button><button type="button" class="iact tiny" data-nb="metadata-cancel">لغو</button></div></div>';
  }
  function nbCleanValue(raw,kind) {
    let value=String(raw==null?'':raw).trim();
    if(kind==='tags')value=value.replace(/^#+/,'').trim();
    return value.slice(0,60);
  }
  function nbEnsureFolder(raw) {
    const name=nbCleanValue(raw,'folders');if(!name)return null;
    let folder=(state.nbFolders||[]).find(f=>norm(f.name)===norm(name));
    if(!folder){folder={id:uid('folder'),name,createdAt:new Date().toISOString()};state.nbFolders.push(folder);}
    return folder;
  }
  function nbEnsureFacet(type,raw) {
    const value=nbCleanValue(raw,type);if(!value)return '';
    const key=type==='tags'?'nbTags':'nbCategories',list=state[key]||(state[key]=[]);
    const existing=list.find(x=>norm(x)===norm(value));
    if(existing)return existing;
    list.push(value);return value;
  }
  function nbCreateFacet(type) {
    const input=nbEls&&nbEls.browseItems&&nbEls.browseItems.querySelector('[data-nb-facet-input="'+type+'"]');
    const raw=input?input.value:'';
    if(type==='folders'){
      const name=nbCleanValue(raw,type);if(!name){toast('نام فولدر را در فیلد وارد کن.');if(input)input.focus();return;}
      if((state.nbFolders||[]).some(f=>norm(f.name)===norm(name))){toast('فولدری با این نام از قبل وجود دارد.');if(input)input.select();return;}
      const folder=nbEnsureFolder(name);state.nbBrowseMode='folders';state.nbBrowseValue=folder.id;
    }else{
      const value=nbCleanValue(raw,type);if(!value){toast('نام '+nbFacetLabel(type)+' را در فیلد وارد کن.');if(input)input.focus();return;}
      const list=type==='tags'?state.nbTags:state.nbCategories;
      if((list||[]).some(x=>norm(x)===norm(value))){toast(nbFacetLabel(type)+' با این نام از قبل وجود دارد.');if(input)input.select();return;}
      state.nbBrowseMode=type;state.nbBrowseValue=nbEnsureFacet(type,value);
    }
    nbManagerEdit=null;nbManagerDelete=null;state.nbCardEditorId='';saveNow();nbRenderList();toast(nbFacetLabel(type)+' ساخته شد.');
  }
  function nbStartFacetEdit(mode,key) {
    let name='';
    if(mode==='folders'){const f=nbFolder(key);if(!f)return;name=f.name;}
    else {const item=nbFacetCounts(mode).find(x=>norm(x.value)===norm(key));if(!item)return;name=item.value;}
    nbManagerEdit={mode,key,name};nbManagerDelete=null;nbRenderBrowse();
    const input=nbEls.browseItems&&nbEls.browseItems.querySelector('[data-nb-manager-edit]');if(input){input.focus();input.select();}
  }
  function nbSaveFacetEdit(mode,key) {
    const input=nbEls&&nbEls.browseItems&&nbEls.browseItems.querySelector('[data-nb-manager-edit]');
    const value=nbCleanValue(input?input.value:'',mode);if(!value){toast('نام جدید را در فیلد وارد کن.');if(input)input.focus();return;}
    if(mode==='folders'){
      const folder=nbFolder(key);if(!folder)return;
      if(state.nbFolders.some(f=>f.id!==key&&norm(f.name)===norm(value))){toast('فولدری با این نام از قبل وجود دارد.');return;}
      folder.name=value;
    }else{
      const keyName=mode==='tags'?'nbTags':'nbCategories',list=state[keyName]||[];
      if(list.some(x=>norm(x)!==norm(key)&&norm(x)===norm(value))){toast(nbFacetLabel(mode)+'ی با این نام از قبل وجود دارد.');return;}
      state[keyName]=nbNormalizeValues(list.map(x=>norm(x)===norm(key)?value:x));
      (state.nbNotes||[]).forEach(n=>{
        if(mode==='tags'){n.tags=nbParseTags((n.tags||[]).map(x=>norm(x)===norm(key)?value:x));}
        else if(norm(n.category)===norm(key))n.category=value;
      });
      if(norm(state.nbBrowseValue)===norm(key))state.nbBrowseValue=value;
    }
    nbManagerEdit=null;saveNow();nbRenderList();toast(nbFacetLabel(mode)+' به روز شد.');
  }
  function nbDeleteFacet(mode,key) {
    if(mode==='folders'){
      const folder=nbFolder(key);if(!folder)return;
      state.nbFolders=state.nbFolders.filter(f=>f.id!==key);state.nbNotes.forEach(n=>{if(n.folderId===key)n.folderId='';});
    }else{
      const listKey=mode==='tags'?'nbTags':'nbCategories';
      state[listKey]=(state[listKey]||[]).filter(x=>norm(x)!==norm(key));
      (state.nbNotes||[]).forEach(n=>{if(mode==='tags')n.tags=(n.tags||[]).filter(t=>norm(t)!==norm(key));else if(norm(n.category)===norm(key))n.category='';});
    }
    if((mode==='folders'&&state.nbBrowseValue===key)||((mode==='tags'||mode==='categories')&&norm(state.nbBrowseValue)===norm(key)))state.nbBrowseValue='';
    nbManagerDelete=null;nbManagerEdit=null;saveNow();nbRenderList();toast(nbFacetLabel(mode)+' و پیوند آن از نوشته ها حذف شد.');
  }
  function nbToggleNoteTag(side,value) {
    const n=nbActive(side),tag=nbEnsureFacet('tags',value);if(!n||!tag)return;
    const has=(n.tags||[]).some(x=>norm(x)===norm(tag));
    n.tags=has?(n.tags||[]).filter(x=>norm(x)!==norm(tag)):nbParseTags([...(n.tags||[]),tag]);
    n.updatedAt=new Date().toISOString();nbSyncLegacy();saveNow();nbRenderProperties(side);nbRenderList();nbRenderCounts(side);
  }
  function nbCreatePropertyForNote(side,kind) {
    const n=nbActive(side),slot=nbEls.panel.querySelector('[data-nb-properties="'+side+'"]');
    const input=slot&&slot.querySelector('[data-nb-property-new="'+kind+'"]');
    if(!n||!input)return;
    const value=nbCleanValue(input.value,kind);if(!value){toast('نام '+nbFacetLabel(kind==='folder'?'folders':kind==='category'?'categories':'tags')+' را در فیلد وارد کن.');input.focus();return;}
    if(kind==='folder'){const folder=nbEnsureFolder(value);n.folderId=folder.id;state.nbBrowseMode='folders';state.nbBrowseValue=folder.id;}
    else if(kind==='category'){n.category=nbEnsureFacet('categories',value);}
    else {const tag=nbEnsureFacet('tags',value);n.tags=nbParseTags([...(n.tags||[]),tag]);}
    n.updatedAt=new Date().toISOString();input.value='';nbManagerEdit=null;nbSyncLegacy();saveNow();nbRenderProperties(side);nbRenderList();nbRenderCounts(side);toast(nbFacetLabel(kind==='folder'?'folders':kind==='category'?'categories':'tags')+' ساخته و به نوشته اضافه شد.');
  }
  function nbCreateCardProperty(id,kind) {
    const editor=nbEls&&nbEls.list&&nbEls.list.querySelector('.nb-card-editor[data-note-id="'+id+'"]');
    const note=(state.nbNotes||[]).find(n=>n.id===id);if(!editor||!note)return;
    if(kind==='folder'){
      const input=editor.querySelector('[data-nb-card-new="folder"]'),select=editor.querySelector('[data-nb-card-field="folder"]');
      const value=nbCleanValue(input&&input.value,'folders');if(!value){toast('نام فولدر را در فیلد وارد کن.');if(input)input.focus();return;}
      const folder=nbEnsureFolder(value);if(select){let option=Array.from(select.options).find(x=>x.value===folder.id);if(!option){option=document.createElement('option');option.value=folder.id;option.textContent=folder.name;select.appendChild(option);}select.value=folder.id;}if(input)input.value='';
    }else if(kind==='category'){
      const input=editor.querySelector('[data-nb-card-field="category"]');const value=nbCleanValue(input&&input.value,'categories');if(!value){toast('نام دسته بندی را در فیلد وارد کن.');if(input)input.focus();return;}nbEnsureFacet('categories',value);if(input)input.value=value;
    }else{
      const input=editor.querySelector('[data-nb-card-new="tag"]'),tags=editor.querySelector('[data-nb-card-field="tags"]');
      const value=nbCleanValue(input&&input.value,'tags');if(!value){toast('نام تگ را در فیلد وارد کن.');if(input)input.focus();return;}
      const tag=nbEnsureFacet('tags',value);if(tags)tags.value=nbParseTags([...(tags.value||'').split(','),tag]).join(', ');if(input)input.value='';
    }
    saveNow();toast(nbFacetLabel(kind==='folder'?'folders':kind==='category'?'categories':'tags')+' به فهرست ویژگی ها اضافه شد؛ برای ثبت نوشته ذخیره را بزن.');
  }

  function nbSaveCardMetadata(id) {
    const note=(state.nbNotes||[]).find(n=>n.id===id),editor=nbEls&&nbEls.list&&nbEls.list.querySelector('.nb-card-editor[data-note-id="'+id+'"]');if(!note||!editor)return;
    const folder=$('[data-nb-card-field="folder"]',editor),category=$('[data-nb-card-field="category"]',editor),tags=$('[data-nb-card-field="tags"]',editor);
    note.folderId=folder?folder.value:'';note.category=category?nbCleanValue(category.value,'categories'):'';note.tags=nbParseTags(tags?tags.value:'');
    state.nbCategories=nbNormalizeValues([...(state.nbCategories||[]),note.category]);state.nbTags=nbNormalizeValues([...(state.nbTags||[]),...note.tags]);
    note.updatedAt=new Date().toISOString();state.nbCardEditorId='';nbSyncLegacy();saveNow();nbRenderList();nbRenderCounts('primary');toast('ویژگی های نوشته ذخیره شد.');
  }
  function nbRenderList(skipBrowse) {
    if (!nbEls || !nbEls.list) return;
    const listEl=nbEls.list,listScrollTop=listEl.scrollTop,generation=++nbListRenderGeneration;
    if(!skipBrowse)nbRenderBrowse();
    const q=norm(state.nbQuery||''),mode=state.nbBrowseMode||'all',value=state.nbBrowseValue||'';
    let list=nbSorted(state.nbNotes||[]);
    if(mode==='folders'&&value)list=list.filter(n=>value==='__none__'?!n.folderId:n.folderId===value);
    else if(mode==='tags'&&value)list=list.filter(n=>(n.tags||[]).some(t=>norm(t)===norm(value)));
    else if(mode==='categories'&&value)list=list.filter(n=>norm(n.category)===norm(value));
    if(q)list=list.filter(n=>nbSearchNormalized(n).indexOf(q)!==-1);
    if(nbEls.search&&nbEls.search.value!==(state.nbQuery||''))nbEls.search.value=state.nbQuery||'';
    const empty=q?'نوشته ای با این جست وجو پیدا نشد.':value?'نوشته ای در این دسته پیدا نشد.':'هنوز نوشته ای نداری.<br>با «یادداشت جدید» اولین نوشته را بساز.';
    if(nbEls.listCount)nbEls.listCount.textContent=fa(list.length)+' از '+fa((state.nbNotes||[]).length)+' نوشته'+(q?' · نتیجه جست وجو':'');
    const cardHTML=n=>{
      const title=String(n.title||'').trim()||nbTitleFromBody(n.body),snip=nbSnippet(n.body)||'بدون متن…',active=n.id===state.nbActiveId;
      const editing=state.nbCardEditorId===n.id;
      return '<div class="nb-card '+(active?'active ':'')+(editing?'editing-meta':'')+'" role="listitem" data-nb="open" data-id="'+esc(n.id)+'" tabindex="0" title="باز کردن یادداشت">'+
        '<div class="nb-card-main"><div class="nb-card-heading"><b>'+esc(title)+'</b><button type="button" class="iact tiny nb-meta-edit" data-nb="metadata-edit" data-id="'+esc(n.id)+'" title="ویرایش فولدر، دسته بندی و تگ ها" aria-label="ویرایش ویژگی های '+esc(title)+'">'+I('edit')+'<span>دسته بندی</span></button></div><p>'+esc(snip)+'</p>'+nbNoteMetaHTML(n)+'<span class="nb-card-meta">'+esc(nbDateLabel(n.updatedAt))+' · '+fa(String(n.body||'').length)+' کاراکتر'+(active?' · آخرین یادداشت بازشده':'')+'</span></div>'+
        '<span class="nb-card-acts"><button type="button" class="iact tiny" data-nb="duplicate-card" data-id="'+esc(n.id)+'" title="تکثیر" aria-label="تکثیر یادداشت">'+I('copy')+'</button><button type="button" class="iact tiny d" data-nb="delete-card" data-id="'+esc(n.id)+'" title="حذف" aria-label="حذف یادداشت">'+I('trash')+'</button></span>'+(editing?nbCardMetadataEditor(n):'')+'</div>';
    };
    if(!list.length){listEl.innerHTML='<div class="nb-empty">'+empty+'</div>';listEl.scrollTop=listScrollTop;return;}
    if(list.length<=60){listEl.innerHTML=list.map(cardHTML).join('');listEl.scrollTop=listScrollTop;return;}
    listEl.innerHTML='<div class="nb-empty nb-list-progress" role="status">در حال نمایش '+fa(list.length)+' نوشته…</div>';
    let cursor=0;const chunkSize=24;
    const appendBatch=()=>{
      if(generation!==nbListRenderGeneration||!listEl.isConnected)return;
      const end=Math.min(cursor+chunkSize,list.length),html=[];
      while(cursor<end)html.push(cardHTML(list[cursor++]));
      const template=document.createElement('template');template.innerHTML=html.join('');
      if(listEl.querySelector('.nb-list-progress'))listEl.replaceChildren();
      listEl.appendChild(template.content);
      if(cursor<list.length)requestAnimationFrame(appendBatch);
      else listEl.scrollTop=listScrollTop;
    };
    requestAnimationFrame(appendBatch);
  }
  function nbRenderPreview(side) {
    if (!nbEls) return;
    side = side === 'secondary' ? 'secondary' : 'primary';
    const n=nbActive(side),preview=side==='secondary'?nbEls.previewSecondary:nbEls.preview;
    if(!preview)return;
    const direction=normalizeTextDirection(n&&n.direction),oldMax=Math.max(0,preview.scrollHeight-preview.clientHeight),oldRatio=oldMax?preview.scrollTop/oldMax:0;
    preview.dir=direction==='auto'?'auto':direction;preview.dataset.textDirection=direction;
    preview.innerHTML=mdToHtml(n?(n.body||''):'',direction);
    attachmentStore.resolve(preview);
    if(nbMode(side)==='both'&&nbScrollSyncEnabled[side])nbSyncScrollPosition(side,side==='secondary'?nbEls.editSecondary:nbEls.edit);
    else {
      const nextMax=Math.max(0,preview.scrollHeight-preview.clientHeight);
      if(nextMax)preview.scrollTop=Math.max(0,Math.min(1,oldRatio))*nextMax;
    }
  }
  function nbCycleDirection(side) {
    side=side==='secondary'?'secondary':'primary';
    const note=nbActive(side);if(!note)return;
    note.direction=nextTextDirection(note.direction);note.updatedAt=new Date().toISOString();nbSyncLegacy();save();
    nbRenderPane(side);
  }
  function nbSetPropertiesOpen(side, open) {
    side = side === 'secondary' ? 'secondary' : 'primary';
    const slot = side === 'secondary' ? nbEls && nbEls.propertiesSecondary : nbEls && nbEls.propertiesPrimary;
    const pane = side === 'secondary' ? nbEls && nbEls.secondaryPane : nbEls && nbEls.primaryPane;
    const button = nbEls && nbEls.panel.querySelector('[data-nb="properties-toggle"][data-side="' + side + '"]');
    if (!slot) return;
    open = !!open;
    if (open && !nbActive(side)) { toast('ابتدا یک نوشته را باز کن.'); return; }
    slot.dataset.open = open ? 'true' : 'false'; slot.hidden = !open;
    slot.setAttribute('aria-hidden', open ? 'false' : 'true');
    if (pane) pane.classList.toggle('properties-open', open);
    if (button) { button.setAttribute('aria-expanded', open ? 'true' : 'false'); button.classList.toggle('on', open); }
    if (open) nbRenderProperties(side); else slot.innerHTML = '';
  }
  function nbToggleProperties(side, force) {
    side = side === 'secondary' ? 'secondary' : 'primary';
    const slot = side === 'secondary' ? nbEls && nbEls.propertiesSecondary : nbEls && nbEls.propertiesPrimary;
    if (!slot) return;
    const open = typeof force === 'boolean' ? force : slot.hidden;
    nbSetPropertiesOpen(side, open);
  }
  function nbRenderProperties(side) {
    if(!nbEls)return;
    side=side==='secondary'?'secondary':'primary';
    const n=nbActive(side),slot=side==='secondary'?nbEls.propertiesSecondary:nbEls.propertiesPrimary;
    if(!n||!slot)return;
    const open=slot.dataset.open==='true',pane=side==='secondary'?nbEls.secondaryPane:nbEls.primaryPane;
    const button=nbEls.panel.querySelector('[data-nb="properties-toggle"][data-side="'+side+'"]');
    slot.className='nb-properties-slot';slot.hidden=!open;slot.setAttribute('aria-hidden',open?'false':'true');
    if(pane)pane.classList.toggle('properties-open',open);
    if(button){button.setAttribute('aria-expanded',open?'true':'false');button.classList.toggle('on',open);}
    if(!open){slot.innerHTML='';return;}
    const previousScroll=slot.querySelector('.nb-properties-scroll')?.scrollTop||0;
    const previousTagScrollLeft=slot.querySelector('.nb-tag-options')?.scrollLeft||0;
    const pageHead='<section class="nb-properties-page" aria-label="ویژگی های نوشته"><header class="nb-properties-head"><div class="nb-properties-heading"><b>ویژگی های نوشته</b><span>فولدر · تگ · دسته بندی</span></div><button type="button" class="iact nb-properties-close" data-nb="properties-close" data-side="'+side+'" title="بستن صفحه ویژگی ها">'+I('x')+' بستن</button></header><div class="nb-properties-scroll">';
    const folderOptions='<option value="">بدون فولدر</option>'+(state.nbFolders||[]).map(f=>'<option value="'+esc(f.id)+'" '+(n.folderId===f.id?'selected':'')+'>'+esc(f.name)+'</option>').join('');
    const categoryOptions='<option value="">بدون دسته بندی</option>'+(state.nbCategories||[]).map(v=>'<option value="'+esc(v)+'" '+(norm(n.category)===norm(v)?'selected':'')+'>'+esc(v)+'</option>').join('');
    const tags=nbFacetCounts('tags');
    const tagOptions=tags.length?tags.map(t=>'<button type="button" class="nb-tag-option '+((n.tags||[]).some(x=>norm(x)===norm(t.value))?'on':'')+'" data-nb="property-tag-toggle" data-side="'+side+'" data-value="'+esc(t.value)+'" aria-pressed="'+((n.tags||[]).some(x=>norm(x)===norm(t.value))?'true':'false')+'"># '+esc(t.value)+' <small>'+fa(t.count)+'</small></button>').join(''):'<span class="nb-property-empty">هنوز تگی ساخته نشده است.</span>';
    slot.innerHTML=pageHead+'<div class="nb-properties-grid">'+
      '<label class="nb-property-field"><span>فولدر</span><select data-nb-property="folder" data-side="'+side+'">'+folderOptions+'</select><span class="nb-property-add"><input type="text" maxlength="60" data-nb-property-new="folder" data-side="'+side+'" placeholder="نام فولدر جدید"><button type="button" class="iact tiny" data-nb="property-create" data-kind="folder" data-side="'+side+'">ساخت و انتخاب</button></span></label>'+
      '<label class="nb-property-field"><span>دسته بندی</span><select data-nb-property="category" data-side="'+side+'">'+categoryOptions+'</select><span class="nb-property-add"><input type="text" maxlength="60" data-nb-property-new="category" data-side="'+side+'" placeholder="نام دسته بندی جدید"><button type="button" class="iact tiny" data-nb="property-create" data-kind="category" data-side="'+side+'">ساخت و انتخاب</button></span></label>'+
      '<div class="nb-property-field nb-property-tags"><span>تگ ها</span><div class="nb-tag-manager-row" role="group" aria-label="جستجو، انتخاب یا ساخت تگ">'+
        '<input class="nb-tag-filter" type="search" data-nb-tag-filter="'+side+'" placeholder="جستجو در تگ ها" aria-label="جستجو در تگ های موجود">'+
        '<div class="nb-tag-options" aria-label="تگ های موجود">'+tagOptions+'</div>'+
        '<input class="nb-tag-new" type="text" maxlength="60" data-nb-property-new="tag" data-side="'+side+'" placeholder="نام تگ جدید" aria-label="نام تگ جدید">'+
        '<button type="button" class="iact tiny nb-tag-add" data-nb="property-create" data-kind="tag" data-side="'+side+'" title="ساخت و افزودن تگ" aria-label="ساخت و افزودن تگ">'+I('plus')+'</button>'+
      '</div></div>'+
      '</div></div></section>';
    const scroll=slot.querySelector('.nb-properties-scroll');if(scroll)scroll.scrollTop=previousScroll;
    const tagList=slot.querySelector('.nb-tag-options');if(tagList)tagList.scrollLeft=previousTagScrollLeft;
  }
  function nbRenderCounts(side) {
    if (!nbEls) return;
    side = side === 'secondary' ? 'secondary' : 'primary';
    const n = nbActive(side), txt = n ? String(n.body || '') : '';
    let words=0,inWord=false;
    for(let i=0;i<txt.length;i++){
      const c=txt.charCodeAt(i),space=c<=32||c===160||c===0x1680||(c>=0x2000&&c<=0x200a)||c===0x2028||c===0x2029||c===0x202f||c===0x205f||c===0x3000||c===0xfeff;
      if(space)inWord=false;else if(!inWord){words++;inWord=true;}
    }
    const count = $('[data-nb-count="' + side + '"]'), updated = $('[data-nb-updated="' + side + '"]');
    if (count) count.textContent = fa(txt.length) + ' کاراکتر · ' + fa(words) + ' کلمه';
    if (updated) updated.textContent = n ? 'آخرین ویرایش: ' + nbDateLabel(n.updatedAt) : '';
    if (nbEls.total) nbEls.total.textContent = fa((state.nbNotes || []).length);
    if (nbEls.dot) nbEls.dot.hidden = !((state.nbNotes || []).some(x => String(x.body || '').trim()));
    const st = fileStore.connected ? ('ذخیره در فایل ' + SIDECAR + ' (' + (fileStore.lastSaved || '…') + ')') :
      (store.available ? 'ذخیره در مرورگر' : 'ذخیره موقت (پیش نمایش)');
    if (nbEls.state) nbEls.state.textContent = st;
    const copyLabel = $('[data-nb-copylabel="' + side + '"]');
    if (copyLabel) copyLabel.textContent = 'کپی متن خواندنی';
  }
  function nbRenderPane(side) {
    if (!nbEls) return;
    side = side === 'secondary' ? 'secondary' : 'primary';
    const n = nbActive(side);
    const title = side === 'secondary' ? $('[data-nb-title="secondary"]') : nbEls.title;
    const edit = side === 'secondary' ? nbEls.editSecondary : nbEls.edit;
    const preview = side === 'secondary' ? nbEls.previewSecondary : nbEls.preview;
    const body = (side === 'secondary' ? nbEls.secondaryPane : nbEls.primaryPane).querySelector('.nb-body');
    const modeBtn = $('[data-nb="toggle-mode"][data-side="' + side + '"]');
    const syncBtn = $('[data-nb="scroll-sync"][data-side="' + side + '"]');
    const typewriterBtn = $('[data-nb="typewriter"][data-side="' + side + '"]');
    const directionBtn = $('[data-nb="direction"][data-side="' + side + '"]');
    const formatBar = $('[data-nb-formatbar="' + side + '"]');
    if (!n || !title || !edit || !preview) return;
    if (nbPaneNoteIds[side] !== n.id) {
      nbPaneNoteIds[side] = n.id;
      const modeKey = side === 'secondary' ? 'nbSecondaryMode' : 'nbMode';
      state[modeKey] = 'edit';
      nbScrollSyncEnabled[side] = false;
      nbScrollSyncGuard[side] = false;
      nbTypewriterEnabled[side] = false;
    }
    const mode = nbMode(side),direction=normalizeTextDirection(n.direction),dirValue=direction==='auto'?'auto':direction;
    if (mode !== 'both') { nbScrollSyncEnabled[side] = false; nbScrollSyncGuard[side] = false; }
    title.dir=dirValue;title.dataset.textDirection=direction;
    edit.dir=dirValue;edit.dataset.textDirection=direction;
    preview.dir=dirValue;preview.dataset.textDirection=direction;
    updateDirectionButton(directionBtn,direction);
    if (document.activeElement !== title && title.value !== (n.title || '')) title.value = n.title || '';
    if (document.activeElement !== edit && edit.value !== (n.body || '')) edit.value = n.body || '';
    title.disabled = mode === 'read';
    edit.hidden = mode === 'read'; preview.hidden = mode === 'edit';
    if (body) body.dataset.mode = mode;
    if (formatBar) formatBar.hidden = mode === 'read';
    if (typewriterBtn) {
      if (mode === 'read') nbTypewriterEnabled[side] = false;
      typewriterBtn.hidden = mode === 'read';
      nbUpdateTypewriterButton(side);
    }
    if (syncBtn) {
      syncBtn.hidden = mode !== 'both';
      syncBtn.setAttribute('aria-pressed', nbScrollSyncEnabled[side] ? 'true' : 'false');
      syncBtn.classList.toggle('on', nbScrollSyncEnabled[side]);
      syncBtn.title = nbScrollSyncEnabled[side] ? 'خاموش کردن هماهنگ سازی اسکرول' : 'هماهنگ سازی اسکرول ویرایشگر و پیش نمایش';
    }
    if (modeBtn) {
      const next = mode === 'edit' ? 'Read' : (mode === 'read' ? 'خواندن و ویرایش' : 'Edit');
      const icon = mode === 'edit' ? 'eye' : (mode === 'read' ? 'layout-left' : 'edit');
      const current = mode === 'edit' ? 'Edit' : (mode === 'read' ? 'Read' : 'خواندن و ویرایش');
      modeBtn.innerHTML = I(icon);
      modeBtn.title = 'حالت فعلی: ' + current + '؛ رفتن به ' + next;
      modeBtn.setAttribute('aria-label', modeBtn.title);
      modeBtn.classList.toggle('on', mode !== 'edit');
      modeBtn.setAttribute('aria-pressed', mode === 'edit' ? 'false' : 'true');
    }
    nbApplyBodySplitLayout(side);nbRenderPreview(side); nbRenderProperties(side); nbRenderCounts(side);
  }
  function nbRender() {
    if (!nbEls) return;
    attachmentStore.updateGuidance(document);
    nbMigrate();
    const inNote = state.nbView === 'note' && !!nbActive();
    const split = inNote && state.nbSplit && !!nbActive('secondary');
    nbEls.panel.classList.toggle('mode-read', nbMode('primary') === 'read');
    nbEls.panel.classList.toggle('mode-edit', nbMode('primary') === 'edit');
    nbEls.panel.classList.toggle('mode-both', nbMode('primary') === 'both');
    nbEls.panel.classList.toggle('split-open', split);
    nbEls.listView.hidden = inNote; nbEls.noteView.hidden = !inNote;
    nbEls.workspace.classList.toggle('split-open', split);
    nbEls.secondaryPane.hidden = !split;
    nbApplyResizeLayout();
    if (nbEls.splitBtn) {
      nbEls.splitBtn.setAttribute('aria-pressed', split ? 'true' : 'false');
      nbEls.splitBtn.classList.toggle('on', split);
      nbEls.splitBtn.title = split ? 'بستن Split View' : 'نمایش دو یادداشت کنار هم';
    }
    if (!inNote) { nbRenderList(); nbRenderCounts('primary'); return; }
    if (split && nbEls.secondarySelect) {
      const others = (state.nbNotes || []).filter(n => n.id !== state.nbActiveId);
      nbEls.secondarySelect.innerHTML = others.map(n => '<option value="' + esc(n.id) + '">' + esc(String(n.title || '').trim() || nbTitleFromBody(n.body)) + '</option>').join('');
      nbEls.secondarySelect.value = state.nbSecondaryId;
    }
    nbRenderPane('primary');
    if (split) nbRenderPane('secondary');
  }
  function nbFormat(kind, side) {
    side = side === 'secondary' ? 'secondary' : 'primary';
    if (nbMode(side) === 'read') nbToggleMode('edit', side);
    const ta = side === 'secondary' ? nbEls.editSecondary : nbEls.edit; if (!ta) return;
    const s0 = ta.selectionStart, s1 = ta.selectionEnd, val = ta.value, sel = val.slice(s0, s1);
    const setText = (text,start,end) => { editorHistoryReplace(ta,text,start,end); };
    const wrapIn = (pre, post, ph) => { const txt = sel || ph; setText(val.slice(0,s0)+pre+txt+post+val.slice(s1),s0+pre.length,s0+pre.length+txt.length); };
    const linePrefix = pfx => { const ls=val.lastIndexOf('\n',s0-1)+1;setText(val.slice(0,ls)+pfx+val.slice(ls),s0+pfx.length,s0+pfx.length); };
    const heading = level => {
      const ls=val.lastIndexOf('\n',s0-1)+1,le=val.indexOf('\n',s0),end=le<0?val.length:le,line=val.slice(ls,end);
      const clean=line.replace(/^ {0,3}#{1,6}[ \t]*/,''),pfx='#'.repeat(level)+' ',removed=line.length-clean.length;
      const next=val.slice(0,ls)+pfx+clean+val.slice(end),start=ls+pfx.length+Math.max(0,s0-ls-removed),finish=Math.max(start,Math.min(next.length,start+sel.length));
      setText(next,start,finish);
    };
    const insertBlock = (block,bodyOffset,bodyLength,selectBody) => {
      const left=val.slice(0,s0),right=val.slice(s1);
      const beforeGap=left.length?(left.endsWith('\n\n')?'':(left.endsWith('\n')?'\n':'\n\n')):'';
      const afterGap=right.length?(right.startsWith('\n\n')?'\n\n':(right.startsWith('\n')?'\n':'\n\n')):'';
      const insertion=beforeGap+block+afterGap,next=left+insertion+right,start=left.length+beforeGap.length+bodyOffset;
      setText(next,start,selectBody?start+bodyLength:start);
    };
    if (kind === 'b') wrapIn('**', '**', 'متن ضخیم');
    else if (kind === 'i') wrapIn('*', '*', 'متن کج');
    else if (kind === 'bolditalic') wrapIn('***', '***', 'متن ضخیم و کج');
    else if (kind === 'highlight') wrapIn('==', '==', 'متن برجسته');
    else if (kind === 'strike') wrapIn('~~', '~~', 'متن خط خورده');
    else if (kind === 'h1') heading(1); else if (kind === 'h2' || kind === 'h') heading(2); else if (kind === 'h3') heading(3); else if (kind === 'h4') heading(4); else if (kind === 'h5') heading(5); else if (kind === 'h6') heading(6);
    else if (kind === 'ul') linePrefix('- '); else if (kind === 'ol') linePrefix('1. '); else if (kind === 'cb') linePrefix('- [ ] ');
    else if (kind === 'quote') linePrefix('> ');
    else if (kind === 'code') wrapIn('`', '`', 'کد');
    else if (kind === 'codeblock') {
      const content=sel||'کد را اینجا بنویس';let fence='```';
      while(content.includes(fence))fence+='`';
      const block=fence+'\n'+content+'\n'+fence;
      insertBlock(block,fence.length+1,content.length,true);
    }
    else if (kind === 'callout') {
      const content=sel||'Contents',lines=content.split('\n').map(line=>'> '+line).join('\n');
      const header='> [!NOTE] Title\n',block=header+lines;
      insertBlock(block,header.length+2,content.split('\n')[0].length,!sel||!content.includes('\n'));
    }
    else if (kind === 'link') wrapIn('[', '](https://)', 'متن لینک');
    else if (kind === 'hr') setText(val.slice(0,s0)+'\n\n---\n\n'+val.slice(s1),s0+3,s0+3);
    else if (kind === 'table') setText(val.slice(0,s0)+'\n| ستون ۱ | ستون ۲ |\n|---|---|\n| مقدار | مقدار |\n'+val.slice(s1),s0+1,s0+1);
    const n = nbActive(side); if (n) { n.body = ta.value; n.updatedAt = new Date().toISOString(); }
    nbSyncLegacy(); ta.focus(); save(); nbRenderPane(side);
  }
  function nbReadableText(side) {
    const n=nbActive(side==='secondary'?'secondary':'primary');if(!n)return '';
    const root=document.createElement('div');root.innerHTML=mdToHtml(String(n.body||''));
    const blocks=new Set(['P','H1','H2','H3','H4','H5','H6','UL','OL','BLOCKQUOTE','ASIDE','PRE','TABLE','TR']);
    const read=node=>{
      if(node.nodeType===3)return node.nodeValue||'';
      if(node.nodeType!==1)return '';
      if(node.matches('[data-codecopy],[aria-hidden="true"],.md-code-ln'))return '';
      const tag=node.tagName;
      if(tag==='BR')return '\n';
      if(tag==='HR')return '\n---\n';
      const content=Array.from(node.childNodes).map(read).join('');
      if(tag==='LI')return '\n• '+content.trim();
      if(tag==='TD'||tag==='TH')return content+' | ';
      return blocks.has(tag)?'\n'+content+'\n':content;
    };
    return read(root).replace(/\u00a0/g,' ').replace(/[ \t]+\n/g,'\n').replace(/\n{3,}/g,'\n\n').trim();
  }
  function nbCurrentText(rendered, side) {
    side = side === 'secondary' ? 'secondary' : 'primary';
    const n = nbActive(side); if (!n) return '';
    const edit = side === 'secondary' ? nbEls.editSecondary : nbEls.edit;
    if (rendered) return nbReadableText(side);
    return document.activeElement === edit ? edit.value : (n.body || '');
  }
  function nbCopy(side) {
    side = side === 'secondary' ? 'secondary' : 'primary';
    const t=nbReadableText(side);
    if (!t.trim()) { toast('این یادداشت خالی است.'); return; }
    const done = () => toast('متن خواندنی این پنل کپی شد ✅');
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(done, () => fallbackCopy(t, done));
    else fallbackCopy(t, done);
  }
  async function nbShare(side) {
    side = side === 'secondary' ? 'secondary' : 'primary';
    const rendered = state.nbView === 'note' && nbMode(side) === 'read', t = nbCurrentText(rendered, side), n = nbActive(side);
    if (!t.trim()) { toast('این یادداشت خالی است.'); return; }
    const title = (n && String(n.title || '').trim()) || nbTitleFromBody(n ? n.body : '') || ('دفترچه یادداشت ' + BRAND);
    try {
      if (!rendered && navigator.canShare && window.File) {
        const file = new File([t], 'packpolymer-note.md', { type: 'text/markdown' });
        if (navigator.canShare({ files: [file] })) { await navigator.share({ title, files: [file] }); toast('اشتراک گذاری انجام شد ✅'); return; }
      }
      if (navigator.share) { await navigator.share({ title, text: t }); toast('اشتراک گذاری انجام شد ✅'); return; }
    } catch (e) { if (e && e.name === 'AbortError') return; }
    nbCopy(side); toast('مرورگر اشتراک گذاری مستقیم ندارد — متن کپی شد؛ هر جا می خواهی بچسبان.');
  }
  async function nbDownload(side) {
    side = side === 'secondary' ? 'secondary' : 'primary';
    const n = nbActive(side), t = n ? String(n.body || '') : '';
    if (!t.trim()) { toast('این یادداشت خالی است.'); return; }
    const safe = (String(n.title || '').trim() || nbTitleFromBody(n.body) || 'note').replace(/[\\/:*?"<>|]+/g, '-').slice(0, 50);
    const stem = 'packpolymer-note-' + stamp(), markdownName = stem + '.md';
    const text = '# ' + (String(n.title || '').trim() || nbTitleFromBody(n.body)) + '\n\n' + t;
    const paths = noteAttachmentPaths(text);
    if (!paths.length) {
      download(markdownName, text, 'text/markdown');
      showTextModal({ title: 'یادداشت: ' + safe, text, filename: markdownName, mode: 'notebook' });
      return;
    }
    let blobs = await Promise.all(paths.map(path => attachmentStore.blobFor(path)));
    if (blobs.some(blob => !(blob instanceof Blob)) && attachmentStore.supported() && attachmentStore.mode !== 'indexeddb') {
      const ready = await attachmentStore.ensureForToolbar();
      if (ready !== 'ready') return;
      blobs = await Promise.all(paths.map(path => attachmentStore.blobFor(path)));
    }
    const missing = paths.filter((_, index) => !(blobs[index] instanceof Blob));
    if (missing.length) {
      const sample = missing.slice(0,2).map(path => path.slice('attachments/'.length)).join('، ');
      toast('خروجی ساخته نشد؛ فایل پیوست پیدا نشد: ' + sample + (missing.length>2?' و '+(missing.length-2)+' فایل دیگر':'')+'. پوشهٔ attachments یا دسترسی مرورگر را بررسی کن.');
      return;
    }
    let zipText = text;
    paths.forEach(path => {
      const escaped = path.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      zipText = zipText.replace(new RegExp(escaped, 'g'), 'attachment/' + path.slice('attachments/'.length));
    });
    const entries = [
      { name:markdownName, blob:new Blob([BOM + zipText],{type:'text/markdown;charset=utf-8'}) },
      { name:'attachment/', blob:new Blob([]) }
    ];
    paths.forEach((path,index)=>entries.push({name:'attachment/'+path.slice('attachments/'.length),blob:blobs[index]}));
    const zipName = stem + '.zip';
    try {
      const archive = await createStoredZip(entries);
      if (downloadBlob(zipName, archive)) {
        showTextModal({ title:'یادداشت و پیوست‌ها: '+safe, text:zipText, filename:zipName, mode:'notebook', redownload:()=>downloadBlob(zipName,archive) });
        toast('فایل ZIP آماده شد؛ Markdown و '+paths.length+' پیوست در پوشهٔ attachment قرار دارند.');
      }
    } catch (error) {
      toast('ساخت ZIP ناموفق بود؛ هیچ فایل ناقصی دانلود نشد. '+(error&&error.message?error.message:''));
    }
  }
  function nbClear() { nbDeleteNote(state.nbActiveId, true, 'primary'); }


  /* ---------- commit متن های ویرایش شده --------------------------------- */
  function editableTextValue(el) {
    let value=String(el.innerText||'');
    if(!value.trim()&&el.textContent&&el.textContent.trim()){
      const clone=el.cloneNode(true);clone.querySelectorAll('br').forEach(br=>br.replaceWith(document.createTextNode('\n')));value=clone.textContent||'';
    }
    return value.replace(/\u00a0/g,' ').replace(/\r\n?/g,'\n').trim();
  }
  function commitField(el) {
    const f = el.dataset.field, id = el.dataset.id;
    const val = editableTextValue(el);
    if (!f || !id) return;
    if (f === 'mtitle') { state.meta.title = val || DEF_TITLE; }
    else if (f === 'msub') { state.meta.sub = val || DEF_SUB; }
    else if (f === 'sub') {
      const fs = findStep(id); if (!fs) return;
      const x = fs.s.subs[Number(el.dataset.sub)]; if (!x) return;
      x.title = val;
    } else {
      const ph = findPhase(id);
      if (ph) {
        if (f === 'icon') ph.icon = val || ph.icon;
        else if (f === 'ptitle') ph.title = val || ph.title;
        else if (f === 'goal') ph.goal = val;
        else if (f === 'dod') ph.dod = val;
        state.plan.forEach(x => x.steps.forEach(st2 => invalidateHay(st2)));
      } else {
        const fs = findStep(id);
        if (!fs) return;
        if (f === 'title') fs.s.title = val || fs.s.title;
        else if (f === 'tip') fs.s.tip = val;
        else if (f === 'meta') fs.s.meta = val;
        invalidateHay(fs.s);
      }
    }
    markCustomized(); save();
  }
  function markCustomized() { try { state.customized = true; } catch (e) { } }

  function sidebarResizeMax(layout, side) {
    const width=layout?layout.clientWidth:0,mode=validSidebarLayout(layout&&layout.dataset.sidebarLayout);
    if(window.innerWidth<1181)return SIDEBAR_MAX_WIDTH;
    const otherKey=side==='left'?'sidebarRightWidth':'sidebarLeftWidth';
    const reserve=mode==='single-right'?374:(388+clampSidebarWidth(state.ui[otherKey],300));
    return Math.max(SIDEBAR_MIN_WIDTH,Math.min(SIDEBAR_MAX_WIDTH,Math.floor(width-reserve)));
  }
  function setSidebarResizeWidth(layout, side, value) {
    const key=side==='left'?'sidebarLeftWidth':'sidebarRightWidth';
    const max=sidebarResizeMax(layout,side),next=Math.max(SIDEBAR_MIN_WIDTH,Math.min(max,Math.round(Number(value)||SIDEBAR_MIN_WIDTH)));
    state.ui[key]=next;
    layout.style.setProperty('--sidebar-'+side+'-width',next+'px');
    return next;
  }
  function setSidebarPairRatio(layout, value) {
    const next=clampSidebarPairRatio(value,.5);
    state.ui.sidebarPairRatio=next;
    layout.style.setProperty('--sidebar-pair-left',next+'fr');
    layout.style.setProperty('--sidebar-pair-right',(1-next)+'fr');
    return next;
  }
  function syncSidebarResizeA11y(layout) {
    layout=layout||$('.layout');if(!layout)return;
    layout.querySelectorAll('[data-sidebar-resize]').forEach(handle=>{
      const kind=handle.dataset.sidebarResize;
      if(kind==='pair'){
        const value=Math.round(clampSidebarPairRatio(state.ui.sidebarPairRatio,.5)*100);
        handle.setAttribute('aria-valuenow',String(value));handle.setAttribute('aria-valuetext',fa(value)+'٪ نسبت ستون ها');
        return;
      }
      const side=layout.querySelector(kind==='left'?'.side-left':'.side-right');
      const value=side?Math.round(side.getBoundingClientRect().width):clampSidebarWidth(kind==='left'?state.ui.sidebarLeftWidth:state.ui.sidebarRightWidth,300);
      handle.setAttribute('aria-valuenow',String(value));handle.setAttribute('aria-valuetext','حدود '+fa(value)+' پیکسل');
    });
  }
  function sidebarResizeStart(e, handle) {
    if(e.isPrimary===false||(e.pointerType==='mouse'&&e.button!==0))return;
    const layout=handle.closest('.layout'),kind=handle.dataset.sidebarResize;
    if(!layout)return;
    e.preventDefault();
    const pointerId=e.pointerId;
    try{if(pointerId!=null&&handle.setPointerCapture)handle.setPointerCapture(pointerId);}catch(_){ }
    const move=ev=>{
      if(pointerId!=null&&ev.pointerId!==pointerId)return;
      ev.preventDefault();
      const rect=layout.getBoundingClientRect();
      if(kind==='pair'){
        const available=layout.clientWidth-14;if(available<=0)return;
        setSidebarPairRatio(layout,(ev.clientX-rect.left-7)/available);
      }else{
        const side=kind==='left'?'left':'right';
        const raw=side==='left'?ev.clientX-rect.left-7:rect.right-ev.clientX-7;
        setSidebarResizeWidth(layout,side,raw);
      }
      syncSidebarResizeA11y(layout);
    };
    const end=()=>{
      window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',end);window.removeEventListener('pointercancel',end);
      document.body.classList.remove('sidebar-resizing');
      try{if(pointerId!=null&&handle.releasePointerCapture&&handle.hasPointerCapture(pointerId))handle.releasePointerCapture(pointerId);}catch(_){ }
      syncSidebarResizeA11y(layout);saveNow();
    };
    document.body.classList.add('sidebar-resizing');
    window.addEventListener('pointermove',move,{passive:false});window.addEventListener('pointerup',end,{once:true});window.addEventListener('pointercancel',end,{once:true});
  }
  function sidebarResizeKey(e, handle) {
    const layout=handle.closest('.layout'),kind=handle.dataset.sidebarResize;
    if(!layout)return;
    if(kind==='pair'){
      if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;
      e.preventDefault();
      const current=clampSidebarPairRatio(state.ui.sidebarPairRatio,.5);
      const next=e.key==='Home' ? .38 : (e.key==='End' ? .62 : current+(e.key==='ArrowRight' ? .02 : -.02));
      setSidebarPairRatio(layout,next);
    }else{
      if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;
      e.preventDefault();
      const side=kind==='left'?'left':'right',key=side==='left'?'sidebarLeftWidth':'sidebarRightWidth';
      const current=clampSidebarWidth(state.ui[key],300),grows=side==='left'?e.key==='ArrowRight':e.key==='ArrowLeft';
      const next=e.key==='Home'?SIDEBAR_MIN_WIDTH:(e.key==='End'?sidebarResizeMax(layout,side):current+(grows?16:-16));
      setSidebarResizeWidth(layout,side,next);
    }
    syncSidebarResizeA11y(layout);saveNow();
  }
  let sidebarA11yFrame=0;
  window.addEventListener('resize',()=>{
    if(sidebarA11yFrame)return;
    sidebarA11yFrame=requestAnimationFrame(()=>{sidebarA11yFrame=0;syncSidebarResizeA11y();});
  },{passive:true});

  /* ---------- رویدادها -------------------------------------------------- */
  function bind() {
    const app = $('#app');
    document.addEventListener('focusin', editorHistoryFocus, true);
    document.addEventListener('beforeinput', editorHistoryBeforeInput, true);
    document.addEventListener('input', editorHistoryInput, true);
    document.addEventListener('keydown', editorOnKeydown, true);
    document.addEventListener('paste', editorClipboardMedia, true);
    document.addEventListener('click',(e)=>{
      const b=e.target.closest('[data-codecopy]');if(!b)return;
      e.preventDefault();e.stopPropagation();
      const code=b.closest('pre')?.querySelector('code');
      const text=code?[...code.querySelectorAll('.md-code-line')].map(line=>line.querySelector('.md-code-content')?.textContent||'').join('\n'):'';
      if(!text.trim()){toast('این Code Block خالی است.');return;}
      const done=()=>toast('Code Block کپی شد ✅');
      if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(text).then(done,()=>fallbackCopy(text,done));else fallbackCopy(text,done);
    });

    app.addEventListener('pointerdown', e => {
      const handle=e.target.closest('[data-sidebar-resize]');if(handle)sidebarResizeStart(e,handle);
    });
    app.addEventListener('keydown', e => {
      const handle=e.target.closest('[data-sidebar-resize]');if(handle)sidebarResizeKey(e,handle);
    });
    app.addEventListener('change', (e) => {
      const ck = e.target.closest('input[data-ck]');
      if (!ck) return;
      const k = ck.dataset.ck;
      const phase = findPhase(k);
      if (phase) {
        if (!phase.steps.length) {
          if (ck.checked) state.checks[phase.id] = true; else delete state.checks[phase.id];
        } else {
          delete state.checks[phase.id];
          phase.steps.forEach(s => {
            if (ck.checked) state.checks[s.id] = true; else delete state.checks[s.id];
            s.subs.forEach(x => { if (ck.checked) state.checks[x.id] = true; else delete state.checks[x.id]; });
          });
        }
        phase.steps.forEach(s => refreshStep(s.id, { skipPhaseStats:true }));
        refreshPhase(phase.id);
        const phaseBox = document.querySelector('.phase[data-phase="' + k + '"] .ph-ck input[data-ck]');
        if (phaseBox) { phaseBox.checked = phaseDone(phase); phaseBox.indeterminate = phasePartial(phase); }
        save();
        return;
      }
      if (ck.checked) state.checks[k] = true; else delete state.checks[k];

      // منطق والد/فرزند: تیک مرحله → همه زیرمرحله ها | تیک همه زیرمرحله ها → تیک مرحله
      const fs = findStep(k);
      if (fs) {
        fs.s.subs.forEach(x => { if (ck.checked) state.checks[x.id] = true; else delete state.checks[x.id]; });
        refreshStep(k);
      } else {
        const owner = findStepOfSub(k);
        if (owner) {
          const allDone = owner.s.subs.every(x => !!state.checks[x.id]);
          if (allDone) state.checks[owner.s.id] = true; else delete state.checks[owner.s.id];
          const li = document.getElementById(k);
          if (li) { li.classList.toggle('done', !!state.checks[k]); }
          refreshStep(owner.s.id, { subs: false });
        } else {
          const subEl = document.getElementById(k);
          if (subEl) subEl.classList.toggle('done', !!state.checks[k]);
          updateStats();
        }
      }
      save();
    });

    app.addEventListener('input', (e) => {
      const n = e.target.closest('textarea[data-note]');
      if (n) {
        const k = n.dataset.note, wasPresent = !!String(state.notes[k] || '').trim(), hasValue = !!n.value.trim();
        if (hasValue) state.notes[k] = n.value; else delete state.notes[k];
        n.classList.toggle('has', hasValue);
        const cnt = n.parentElement.querySelector('.cnt');
        if (cnt) cnt.textContent = hasValue ? 'ذخیره شد ✍️' : 'خالی';
        const copy=n.closest('.note-wrap')?.querySelector('.note-copy-btn');if(copy)copy.disabled=!hasValue;
        const entity=n.closest('.sub,.step,.phase');
        if(entity){const toggle=Array.from(entity.querySelectorAll('[data-act="note-toggle"]')).find(btn=>btn.dataset.key===k);if(toggle)toggle.classList.toggle('note-on',hasValue);}
        save(400);
        if (wasPresent !== hasValue) updateStats();
        return;
      }
      if (e.target.dataset && e.target.dataset.meta) {
        const f = findStep(e.target.dataset.meta);
        if (f) { f.s.meta = e.target.value; markCustomized(); save(); }
        return;
      }
      if (e.target.id === 'phaseDrawerSearch') {
        state.ui.phaseDrawerQuery = e.target.value; state.ui.phaseDrawerOpen = true; save();
        clearTimeout(window.__drawerQueryT);
        window.__drawerQueryT = setTimeout(() => { expandDrawerSearch(state.ui.phaseDrawerQuery); refreshPhaseDrawer(); }, 130);
        return;
      }
      if (e.target.id === 'q') {
        state.ui.q = e.target.value; save();
        const searchMain=$('#phases'); if(searchMain)searchMain.dataset.searchRendering='queued';
        clearTimeout(window.__qT);
        window.__qT = setTimeout(renderSearchResults, 130);
      }
    });

    app.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-act]');
      if (!btn) return;
      const act = btn.dataset.act, id = btn.dataset.id;
      // کلیک روی checkbox فاز فقط وضعیت را تغییر می دهد، نه باز/بسته بودن آن را.
      if (act === 'toggle-phase' && (e.target.closest('[data-field]') || e.target.closest('.ph-ck'))) return;
      if (state.ui.editing && e.target.closest('[contenteditable="true"]') && act !== 'toggle-phase') return;

      switch (act) {
        case 'toggle-phase': {
          const ph = findPhase(id); if (!ph) return;
          state.open[id] = !state.open[id];
          save();
          const el = document.getElementById(id);
          if (el && state.open[id] && el.querySelector('.ph-body[data-lazy="1"]')) {
            el.outerHTML = phaseHTML(ph,state.plan.indexOf(ph)); spy();
          } else if (el) el.classList.toggle('open', !!state.open[id]);
          break;
        }
        case 'side-toggle': {
          if (!state.ui.sideClosed) state.ui.sideClosed = { dev: true };
          state.ui.sideClosed[id] = !state.ui.sideClosed[id];
          save(); renderSidebarLayoutOnly();
          const next=$$('.side-card [data-act="side-toggle"]').find(x=>x.dataset.id===id);
          if(next)try{next.focus({preventScroll:true});}catch(_){next.focus();}
          break;
        }
        case 'sidebar-layout-cycle': {
          const idx = SIDEBAR_LAYOUTS.indexOf(validSidebarLayout(state.ui.sidebarLayout));
          state.ui.sidebarLayout = SIDEBAR_LAYOUTS[(idx + 1) % SIDEBAR_LAYOUTS.length];
          saveNow(); renderSidebarLayoutOnly();
          toast('چیدمان سایدبار: ' + (state.ui.sidebarLayout === 'dual-right' ? 'دو سایدبار، فهرست فازها راست' : state.ui.sidebarLayout === 'single-right' ? 'یک سایدبار در سمت راست' : 'دو سایدبار، فهرست فازها چپ'));
          break;
        }
        case 'sidebar-size-reset': {
          state.ui.sidebarLeftWidth = 300;
          state.ui.sidebarRightWidth = 300;
          state.ui.sidebarPairRatio = .5;
          saveNow();
          renderSidebarLayoutOnly();
          toast('اندازه سایدبارها به حالت پیش فرض بازنشانی شد.');
          break;
        }
        case 'font-scale': adjustFontScale(btn.dataset.scope || 'ui', btn.dataset.dir); break;
        case 'phase-drawer-close': togglePhaseDrawer(false); break;
          case 'menu-drawer-close': toggleMenuDrawer(false); break;
        case 'side-phase-toggle': {
          e.stopPropagation();
          if (!state.ui.sideOpen) state.ui.sideOpen = {};
          state.ui.sideOpen[id] = !state.ui.sideOpen[id];
          save(); refreshPhaseTrees();
          break;
        }
        case 'side-step-toggle': {
          e.stopPropagation();
          if (!state.ui.sideStepOpen) state.ui.sideStepOpen = {};
          state.ui.sideStepOpen[id] = !state.ui.sideStepOpen[id];
          save(); refreshPhaseTrees();
          break;
        }
        case 'goto-step': if (btn.closest('#phaseNavDrawer')) state.ui.phaseDrawerOpen = false; navigateToEntity('step', id); break;
        case 'goto-sub': if (btn.closest('#phaseNavDrawer')) state.ui.phaseDrawerOpen = false; navigateToEntity('sub', id); break;
        case 'goto': if (btn.closest('#phaseNavDrawer')) state.ui.phaseDrawerOpen = false; navigateToEntity('phase', id); break;
        case 'entity-menu': {
          e.stopPropagation();
          openEntityMenu(btn, btn.dataset.etype, btn.dataset.eid);
          break;
        }
        case 'mark-filter': {
          const v = btn.dataset.id;
          if (!Array.isArray(state.ui.markFilters)) state.ui.markFilters = [];
          const i = state.ui.markFilters.indexOf(v);
          if (i === -1) state.ui.markFilters.push(v); else state.ui.markFilters.splice(i, 1);
          save(); renderTopOnly(); renderSidebarLayoutOnly(); renderSearchResults();
          toast(state.ui.markFilters.length ? 'فیلتر نشان فعال شد: ' + state.ui.markFilters.join(' + ') : 'فیلتر نشان پاک شد.');
          break;
        }
        case 'mark-clear': state.ui.markFilters = []; save(); renderTopOnly(); renderSidebarLayoutOnly(); renderSearchResults(); break;
        case 'note-toggle': {
          const key=btn.dataset.key;state.openNotes[key]=!state.openNotes[key];save();
          let wrap=document.querySelector('[data-note-wrap="'+key+'"]');
          if(wrap&&wrap.dataset.noteLazy==='true'){
            const template=document.createElement('template'),small=wrap.classList.contains('subnote'),entityKind=wrap.classList.contains('phase-note')?'phase':'';
            template.innerHTML=notePanel(String(key||'').slice(2),state.notes[key]||'',null,small,entityKind);
            const fresh=template.content.firstElementChild;if(fresh){wrap.replaceWith(fresh);wrap=fresh;attachmentStore.updateGuidance(wrap);}
          }
          if(wrap){
            wrap.classList.toggle('show',!!state.openNotes[key]);
            if(state.openNotes[key]){
              const editor=wrap.querySelector('[data-note="'+key+'"]'),preview=wrap.querySelector('[data-note-preview="'+key+'"]'),mode=state.noteModes[key]==='read'?'read':'edit';
              if(mode==='read'&&preview){const direction=normalizeTextDirection(state.noteDirections[key]);preview.innerHTML=mdToHtml(state.notes[key]||'',direction);preview.dir=direction==='auto'?'auto':direction;preview.dataset.textDirection=direction;attachmentStore.resolve(preview);preview.hidden=false;if(editor)editor.hidden=true;try{preview.focus({preventScroll:true});}catch(_){}}
              else if(editor){editor.hidden=false;editor.focus();}
            }
          }
          break;
        }
        case 'note-direction': {
          const key=btn.dataset.key,wrap=btn.closest('.note-wrap');if(!key||!wrap)break;
          const direction=nextTextDirection(state.noteDirections[key]);state.noteDirections[key]=direction;save();
          const editor=wrap.querySelector('[data-note="'+key+'"]'),preview=wrap.querySelector('[data-note-preview="'+key+'"]');
          if(editor){editor.dir=direction==='auto'?'auto':direction;editor.dataset.textDirection=direction;}
          if(preview){preview.dir=direction==='auto'?'auto':direction;preview.dataset.textDirection=direction;preview.innerHTML=mdToHtml(state.notes[key]||'',direction);attachmentStore.resolve(preview);}
          updateDirectionButton(btn,direction);
          break;
        }
        case 'note-mode': {
          const key=btn.dataset.key,wrap=btn.closest('.note-wrap');if(!key||!wrap)break;
          const mode=state.noteModes[key]==='read'?'edit':'read';state.noteModes[key]=mode;save();
          const editor=wrap.querySelector('[data-note="'+key+'"]'),preview=wrap.querySelector('[data-note-preview="'+key+'"]'),media=wrap.querySelector('.note-media-btn');
          if(media)media.hidden=mode==='read';
          if(mode==='read'){
            if(preview){const direction=normalizeTextDirection(state.noteDirections[key]);preview.dir=direction==='auto'?'auto':direction;preview.dataset.textDirection=direction;preview.innerHTML=mdToHtml(state.notes[key]||'',direction);attachmentStore.resolve(preview);preview.hidden=false;}
            if(editor)editor.hidden=true;
            btn.innerHTML='✎ ویرایش';btn.setAttribute('aria-pressed','true');if(preview)try{preview.focus({preventScroll:true});}catch(_){}
          }else{
            if(preview)preview.hidden=true;if(editor){editor.hidden=false;editor.focus();}
            btn.innerHTML='◉ خواندن';btn.setAttribute('aria-pressed','false');
          }
          break;
        }
        case 'note-media': {
          const wrap=btn.closest('.note-wrap'),editor=wrap&&wrap.querySelector('textarea[data-note]');
          if(editor)openEditorMediaPicker(editor);
          break;
        }
        case 'attachment-connect': attachmentStore.connectFromUser(); break;
        case 'note-copy': {
          const key=btn.dataset.key,wrap=btn.closest('.note-wrap');if(!key)break;
          const text=state.noteModes[key]==='read'?(wrap?.querySelector('[data-note-preview="'+key+'"]')?.innerText||''):(state.notes[key]||'');
          if(!text.trim()){toast('این یادداشت خالی است.');break;}
          const done=()=>toast('یادداشت کپی شد ✅');
          if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(text).then(done,()=>fallbackCopy(text,done));else fallbackCopy(text,done);
          break;
        }
        case 'filter': state.ui.filter = id; save(); renderTopOnly(); renderSearchResults(); break;
        case 'stack-filter': {
          const v = btn.dataset.id || '';
          state.ui.stack = (state.ui.stack === v) ? '' : v;
          save(); renderTopOnly(); renderSidebarLayoutOnly(); renderSearchResults();
          window.scrollTo(0, 0);
          if (state.ui.stack) toast('فیلتر استک: ' + state.ui.stack);
          break;
        }
        case 'stack-clear': state.ui.stack = ''; save(); renderTopOnly(); renderSidebarLayoutOnly(); renderSearchResults(); break;
        case 'expand-all': state.plan.forEach(p => state.open[p.id] = true); save(); renderSearchResults(); break;
        case 'collapse-all': state.open = {}; save(); renderSearchResults(); break;
        case 'edit-mode':
          state.ui.editing = !state.ui.editing;
          save(); render();
          toast(state.ui.editing
            ? 'حالت ویرایش روشن شد — روی هر متن کلیک کن، یا با «باز کردن همه» دکمه های افزودن/جابه جایی را ببین.'
            : 'حالت ویرایش خاموش شد — تغییرات ذخیره شد ✍️');
          break;
        case 'export': exportJSON(); break;
        case 'export-answers': exportAnswers(); break;
        case 'import': importJSON(); break;
        case 'report': reportMD(btn.dataset.id); break;
        case 'report-menu': {
          const w = btn.closest('.menu-wrap');
          const openNow = w.classList.contains('open');
          closeMenus();
          if (!openNow) { updateStats(); w.classList.add('open'); }
          break;
        }
        case 'notebook': nbToggle(); break;
        case 'notebook-copy': nbCopy(); break;
        case 'notebook-share': nbShare(); break;
        case 'clean-all': cleanAll(); break;
        case 'file-connect': fileStore.connect(); break;
        case 'file-regrant': fileStore.regrant(); break;
        case 'file-write': writeSidecarNow(); break;
        case 'file-disconnect': fileStore.disconnect(); break;
        case 'copy-json': copyJSON(); break;
        case 'print': window.print(); break;
        case 'move-phase': movePhaseTo(id, btn.dataset.dir); break;
        case 'add-step': addStep(id, null, btn.closest('.insert-action-group')?.querySelector('[data-insert-position]')?.value); break;
        case 'add-phase': addPhase(id, btn.closest('.insert-action-group')?.querySelector('[data-insert-position]')?.value); break;
        case 'del-phase': delPhase(id); break;
        case 'del-step': delStep(id); break;
        case 'add-sub': addSub(id, btn.dataset.after, btn.closest('.insert-action-group')?.querySelector('[data-insert-position]')?.value); break;
        case 'del-sub': delSub(id, btn.dataset.sub); break;
        case 'move-step': moveStep(id, btn.dataset.dir); break;
        case 'move-sub': moveSub(id, btn.dataset.sub, btn.dataset.dir); break;
        case 'add-tip': {
          const f = findStep(id); if (!f) return;
          f.s.tip = f.s.tip || 'نکته تجربی: …'; touch(); render();
          const el = document.getElementById(id);
          if (el) { const t = el.querySelector('.tip [data-field="tip"]'); if (t) t.focus(); }
          break;
        }

        case 'reset-content': resetPlanContent(); break;
        case 'apply-stale':
          state.plan = clone(DEFAULT_PLAN); state.customized = false; state.ui.stale = false;
          saveNow(); render(); toast('محتوای جدید بارگذاری شد');
          break;
        case 'dismiss-stale': state.ui.stale = false; saveNow(); $('#banner').classList.remove('show'); break;
      }
    });

    // بعد از پایان یادداشت: به روزرسانی نشانگرهای همان مرحله
    app.addEventListener('focusout', (e) => {
      const n = e.target.closest('textarea[data-note]');
      if (n) {
        const wrap=n.closest('.note-wrap'),next=e.relatedTarget;
        if(wrap&&next&&wrap.contains(next)&&next.closest('.note-media-btn'))return;
        const id = n.dataset.note.replace(/^n:/, '');
        let fs = findStep(id), ph = null, st = null;
        if (fs) { ph = fs.ph; st = fs.s; }
        else { const o = findStepOfSub(id); if (o) { ph = o.ph; st = o.s; } }
        if (st) {
          const el = document.getElementById(st.id);
          if (el) el.outerHTML = stepHTML(ph, st, ph.steps.indexOf(st));
          updateStats(); save();
        }
        return;
      }
      const el2 = e.target.closest('[data-field]');
      if (el2 && state.ui.editing) commitField(el2);
    });

    app.addEventListener('keydown', (e) => {
      const el = e.target.closest('[contenteditable="true"]');
      if (el && e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); el.blur(); }
    });

    // دکمه شناور، Drawer فهرست فازها را از سمت چپ باز و بسته می کند.
    const phaseFab = document.getElementById('phaseFab');
    if (phaseFab) phaseFab.addEventListener('click', () => togglePhaseDrawer());

    // نوار پایینی چسبان (فقط موبایل/تبلت)
    const tabbar = document.getElementById('mobileTabbar');
    if (tabbar) tabbar.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-tab]');
      if (!btn) return;
      const act = btn.dataset.tab;
      if (act === 'home') {
        if (state.ui.nbOpen) nbToggle(false);
        if (state.ui.phaseDrawerOpen) togglePhaseDrawer(false);
        if (state.ui.menuDrawerOpen) toggleMenuDrawer(false);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else if (act === 'phases') togglePhaseDrawer();
      else if (act === 'menu') toggleMenuDrawer();
      else if (act === 'notebook') nbToggle();
      else if (act === 'top') window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    // بستن پیام راهنمای پیوست (دفترچه و یادداشت ها)
    document.addEventListener('click', (e) => {
      const b = e.target.closest('[data-act="attachment-notice-close"]');
      if (!b) return;
      e.preventDefault();
      state.ui.attachmentNoticeDismissed = true;
      save();
      attachmentStore.updateGuidance(document);
      try { nbApplyResizeLayout(); } catch (_) { }
      toast('پیام راهنمای پیوست بسته شد.');
    });

    // دکمه بازگشت به بالا (بیرون از #app است)
    const toTop = document.getElementById('totop');
    if (toTop) {
      toTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
      let ticking = false;
      window.addEventListener('scroll', () => {
        if (ticking) return; ticking = true;
        requestAnimationFrame(() => {
          toTop.classList.toggle('show', window.scrollY > 700);
          updateHeaderCompact();
          ticking = false;
        });
      }, { passive: true });
    }

    // میان برهای اختصاصی بدون Alt و دور از میان برهای رایج مرورگر.
    // Ctrl+Shift+. = خروجی JSON | Ctrl+Shift+; = ساخت یادداشت جدید
    document.addEventListener('keydown', (e) => {
      const tag = (e.target.tagName || '').toLowerCase();
      const typing = tag === 'input' || tag === 'textarea' || e.target.isContentEditable;
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.shiftKey && !e.altKey && !typing && e.code === 'Period') { e.preventDefault(); exportJSON(); return; }
      if (mod && e.shiftKey && !e.altKey && !typing && e.code === 'Semicolon') {
        e.preventDefault();
        if (!state.ui.nbOpen) nbToggle(true);
        setTimeout(() => nbCreate('primary'), state.ui.nbOpen ? 0 : 120);
        return;
      }
      if (e.key === '/' && !typing) { e.preventDefault(); const q = $('#q'); if (q) q.focus(); }
    });
  }

  /* ---------- اسکرول اسپای + اسکرول مستقل لیست فازها -------------------
   * دو مکانیزم اسکرول:
   *  ۱) مکانیزم اصلی: اسکرول خود صفحه برای Phases / Steps / Sub-steps
   *  ۲) مکانیزم سایدبار: aside.side دارای overflow مستقل است و لیست فازها
   *     (.navlist) هم اسکرول داخلی خودش را دارد؛ با اسکرول صفحه، آیتم فعال
   *     خودکار داخل لیست دیده می شود.
   * ------------------------------------------------------------------- */
  let spyObs = null;
  function scrollNavTo(id) {
    const list = $('.navlist'); if (!list) return;
    const item = list.querySelector('[data-act="goto"][data-id="' + id + '"]'); if (!item) return;
    const top = item.offsetTop, h = item.offsetHeight;
    if (top < list.scrollTop + 6) list.scrollTop = Math.max(0, top - 10);
    else if (top + h > list.scrollTop + list.clientHeight - 6) list.scrollTop = top + h - list.clientHeight + 10;
  }
  function spy() {
    if (spyObs) spyObs.disconnect();
    if (!('IntersectionObserver' in window)) return;
    spyObs = new IntersectionObserver((ents) => {
      ents.forEach(en => {
        if (en.isIntersecting) {
          $$('.navitem').forEach(n => n.classList.toggle('on', n.dataset.id === en.target.id));
          scrollNavTo(en.target.id);
        }
      });
    }, { rootMargin: '-90px 0px -70% 0px', threshold: 0 });
    $$('.phase').forEach(p => spyObs.observe(p));
  }

  /* ---------- شروع ------------------------------------------------------ */
  load();
  // پیش فرض: دو فاز اول باز (سایر فازها با کلیک/جست وجو باز می شوند تا صفحه سبک بماند)
  if (!Object.keys(state.open).length) state.plan.slice(0, 2).forEach(p => { state.open[p.id] = true; });
  let booted = false;
  function boot() {
    if (booted) return; booted = true;
    document.body.classList.add('theme-dark');
    attachmentStore.init().then(() => { attachmentStore.resolve(document.body); attachmentStore.updateGuidance(document); }).catch(() => { attachmentStore.updateGuidance(document); });
    nbMount();
    entMenuMount();
    bind();
    render();
    nbRender();
    // Run immediately for deep links, then re-run only if sidecar/handle loading replaced state.
    handleDeepLink();
    bootStores().then(() => { handleDeepLink(); });
    window.addEventListener('hashchange', handleDeepLink);
  }
  async function bootStores() {
    let used = false;
    try { used = await fileStore.restoreFromIdb(); } catch (e) { }
    if (!used && !fileStore.connected) {
      const side = await fileStore.fetchSidecar();
      if (side && !answersEmpty(side)) {
        const localEmpty = answersEmpty(state);
        const newer = side.savedAt && state.savedAt ? (Date.parse(side.savedAt) > Date.parse(state.savedAt)) : false;
        if (localEmpty || newer) { applyAnswers(side, true); used = true; }
      }
    }
    if (used) {
      saveNow(); render(); nbRender();
      toast('پاسخ ها از ' + SIDECAR + ' بارگذاری شد ✅');
    } else if (fileStore.status !== 'connected') {
      renderSidebarLayoutOnly(); nbRender();
    }
    return used;
  }
  document.addEventListener('DOMContentLoaded', boot);
  if (document.readyState !== 'loading') boot();
})();

