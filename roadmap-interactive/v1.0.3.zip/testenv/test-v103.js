const { chromium } = require('playwright');

const URL = 'file:///home/user/uploads/packpolymer-marketplace-roadmap-v1.0.3.html';
let pass = 0, fail = 0;
const failures = [];

function check(name, ok, detail) {
  if (ok) { pass++; console.log('  ✅ ' + name + (detail ? ' — ' + detail : '')); }
  else { fail++; failures.push(name + (detail ? ' — ' + detail : '')); console.log('  ❌ ' + name + (detail ? ' — ' + detail : '')); }
}

async function newPage(browser, w, h) {
  const context = await browser.newContext({ viewport: { width: w, height: h } });
  await context.addInitScript(() => { if (!sessionStorage.getItem('t-cleared')) { try { localStorage.clear(); } catch (e) {} sessionStorage.setItem('t-cleared', '1'); } });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { const tx = m.text(); if (m.type() === 'error' && !/Failed to load resource/.test(tx)) errors.push(tx); });
  await page.goto(URL);
  await page.waitForTimeout(700);
  return { context, page, errors };
}

async function clickTree(page, kind, id, scope) {
  const sel = (scope || '') + (kind === 'sub' ? '.navsub' : (kind === 'step' ? '.navstep' : '.navitem[data-nav-role="phase"]')) + '[data-id="' + id + '"]';
  await page.evaluate((s) => { const el = document.querySelector(s); if (el) el.click(); }, sel);
  await page.waitForTimeout(850);
  return page.evaluate((id) => {
    const el = document.getElementById(id);
    if (!el) return { exists: false };
    const r = el.getBoundingClientRect();
    return { exists: true, top: Math.round(r.top), inView: r.top >= -20 && r.top < innerHeight, y: window.scrollY };
  }, id);
}

(async () => {
  const browser = await chromium.launch();

  // ═══════════ A. TASK 2 — Navigation (desktop) ═══════════
  console.log('\n══ A. TASK 2: Navigation (desktop 1440×900) ══');
  {
    const { context, page, errors } = await newPage(browser, 1440, 900);

    await page.click('.tree-ph[data-phase-nav="f0"] [data-act="side-phase-toggle"]');
    await page.waitForTimeout(120);
    await page.click('.tree-ph[data-phase-nav="f4"] [data-act="side-phase-toggle"]');
    await page.waitForTimeout(120);
    // expand ALL steps inside f0 so its subs are clickable in the tree
    const nF0 = await page.$$eval('.tree-ph[data-phase-nav="f0"] [data-act="side-step-toggle"]', els => els.length);
    for (let i = 0; i < nF0; i++) {
      await page.evaluate((i) => { const b = document.querySelectorAll('.tree-ph[data-phase-nav="f0"] [data-act="side-step-toggle"]')[i]; if (b) b.click(); }, i);
      await page.waitForTimeout(30);
    }
    // expand first step of f4
    await page.evaluate(() => {
      const t = document.querySelector('.tree-ph[data-phase-nav="f4"] [data-act="side-step-toggle"]');
      if (t) t.click();
    });
    await page.waitForTimeout(150);

    let r = await clickTree(page, 'sub', 'f0-s6-1');
    check('sidebar: deep sub f0-s6-1 navigates precisely', r.exists && r.inView && Math.abs(r.top - 150) <= 45, JSON.stringify(r));

    r = await clickTree(page, 'step', 'f4-s1');
    check('sidebar: deep step f4-s1 navigates precisely', r.exists && r.inView && Math.abs(r.top - 128) <= 45, JSON.stringify(r));

    r = await clickTree(page, 'sub', 'f4-s1-7');
    check('sidebar: deep sub f4-s1-7 navigates precisely', r.exists && r.inView && Math.abs(r.top - 150) <= 45, JSON.stringify(r));

    r = await clickTree(page, 'phase', 'f11');
    check('sidebar: phase f11 navigates precisely', r.exists && r.inView && Math.abs(r.top - 106) <= 45, JSON.stringify(r));

    // drawer sub nav (ensure f4 open + its s1 subs visible first; toggle flips so only click when closed)
    await page.click('#phaseFab');
    await page.waitForTimeout(350);
    await page.evaluate(() => {
      const ph = document.querySelector('#phaseNavDrawer .tree-ph[data-phase-nav="f4"]');
      if (!ph) return;
      const hasSteps = !!ph.querySelector('[data-act="side-step-toggle"]');
      const t = ph.querySelector('[data-act="side-phase-toggle"]');
      if (t && !hasSteps) t.click();
    });
    await page.waitForTimeout(200);
    await page.evaluate(() => {
      const ph = document.querySelector('#phaseNavDrawer .tree-ph[data-phase-nav="f4"]');
      if (!ph) return;
      const hasSubs = !!ph.querySelector('.navsub[data-id="f4-s1-7"]');
      const st = ph.querySelector('[data-act="side-step-toggle"]');
      if (st && !hasSubs) st.click();
    });
    await page.waitForTimeout(200);
    r = await clickTree(page, 'sub', 'f4-s1-7', '#phaseNavDrawer ');
    check('drawer: sub f4-s1-7 navigates precisely', r.exists && r.inView && Math.abs(r.top - 150) <= 45, JSON.stringify(r));

    check('desktop nav: no page errors', errors.length === 0, errors.slice(0, 2).join(' | '));
    await context.close();
  }

  // old repro in a FRESH context: heavy tree use (every toggle once) + deep scroll + FIRST click = sub
  {
    const { context, page } = await newPage(browser, 1440, 900);
    for (let i = 0; i < 13; i++) {
      await page.evaluate((i) => { const b = document.querySelectorAll('[data-act="side-phase-toggle"]')[i]; if (b) b.click(); }, i);
      await page.waitForTimeout(35);
    }
    const n = await page.$$eval('[data-act="side-step-toggle"]', els => els.length);
    for (let i = 0; i < n; i++) {
      await page.evaluate((i) => { const b = document.querySelectorAll('[data-act="side-step-toggle"]')[i]; if (b) b.click(); }, i);
      await page.waitForTimeout(15);
    }
    await page.waitForTimeout(300);
    await page.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight));
    await page.waitForTimeout(350);
    const yBefore = await page.evaluate(() => window.scrollY);
    const clicked = await page.evaluate(() => {
      const el = document.querySelector('.navsub[data-id="f0-s6-1"]');
      if (!el) return false;
      el.click();
      return true;
    });
    await page.waitForTimeout(950);
    const r = await page.evaluate((id) => {
      const el = document.getElementById(id);
      const rect = el.getBoundingClientRect();
      return { top: Math.round(rect.top), inView: rect.top >= -20 && rect.top < innerHeight, y: window.scrollY };
    }, 'f0-s6-1');
    check('polluted+deep-scroll: first click on sub lands (old repro)', clicked && r.inView && Math.abs(r.top - 150) <= 45, 'yBefore=' + yBefore + ' ' + JSON.stringify(r));
    await context.close();
  }

  // mobile: drawer navigation for subs
  {
    const { context, page } = await newPage(browser, 390, 844);
    await page.click('#mobileTabbar [data-tab="phases"]');
    await page.waitForTimeout(400);
    await page.evaluate(() => {
      const t = document.querySelector('#phaseNavDrawer .tree-ph[data-phase-nav="f4"] [data-act="side-phase-toggle"]');
      if (t) t.click();
    });
    await page.waitForTimeout(150);
    await page.evaluate(() => {
      const t = document.querySelector('#phaseNavDrawer .tree-ph[data-phase-nav="f4"] [data-act="side-step-toggle"]');
      if (t) t.click();
    });
    await page.waitForTimeout(150);
    const r = await clickTree(page, 'sub', 'f4-s1-7', '#phaseNavDrawer ');
    check('mobile drawer: sub f4-s1-7 navigates precisely', r.exists && r.inView && Math.abs(r.top - 150) <= 45, JSON.stringify(r));
    await context.close();
  }

  // ═══════════ B. TASKS 1&3 — sidebar buttons ═══════════
  console.log('\n══ B. TASKS 1+3: sidebar layout/reset buttons ══');
  {
    const { context, page } = await newPage(browser, 1440, 900);
    const vis = await page.evaluate(() => {
      const v = el => { if (!el) return false; const cs = getComputedStyle(el); return cs.display !== 'none' && cs.visibility !== 'hidden' && el.getClientRects().length > 0; };
      const layoutBtns = Array.from(document.querySelectorAll('.sidebar-layout-btn'));
      const resetBtns = Array.from(document.querySelectorAll('.sidebar-size-reset'));
      const slotPair = document.querySelector('.sidebar-layout-slot');
      return {
        layoutVisible: layoutBtns.filter(v).length,
        resetVisible: resetBtns.filter(v).length,
        resetNextToLayout: !!slotPair && !!slotPair.querySelector('.sidebar-layout-btn') && !!slotPair.querySelector('.sidebar-size-reset'),
        oldStickyReset: !!document.querySelector('.sticky-reset'),
        oldMainReset: !!document.querySelector('.main-sidebar-reset'),
        sideCardPair: (() => { const t = document.querySelector('.side-phase-tools'); return !!t && !!t.querySelector('.sidebar-layout-btn') && !!t.querySelector('.sidebar-size-reset'); })(),
        drawerPair: (() => { const t = document.querySelector('.phase-drawer-tools'); return !!t && !!t.querySelector('.sidebar-layout-btn') && !!t.querySelector('.sidebar-size-reset'); })()
      };
    });
    check('desktop: layout-cycle button visible', vis.layoutVisible >= 2, JSON.stringify(vis));
    check('desktop: sidebar reset visible next to layout button', vis.resetVisible >= 2 && vis.resetNextToLayout, 'resetVisible=' + vis.resetVisible + ' next=' + vis.resetNextToLayout);
    check('desktop: reset also beside layout in sidebar card + drawer', vis.sideCardPair && vis.drawerPair, 'card=' + vis.sideCardPair + ' drawer=' + vis.drawerPair);
    check('desktop: old reset placements removed', !vis.oldStickyReset && !vis.oldMainReset, JSON.stringify({ s: vis.oldStickyReset, m: vis.oldMainReset }));

    // reset actually works (DOM/observable: layout style vars return to defaults)
    await page.evaluate(() => {
      const b = document.querySelector('.sidebar-size-reset');
      if (b) b.click();
    });
    await page.waitForTimeout(350);
    const after = await page.evaluate(() => {
      const lay = document.querySelector('.layout');
      return { style: lay ? lay.getAttribute('style') : '' };
    });
    check('reset button restores sidebar sizes to defaults', /--sidebar-left-width:300px/.test(after.style) && /--sidebar-right-width:300px/.test(after.style) && /--sidebar-pair-left:0?\.5/.test(after.style), after.style.slice(0, 120));
    await context.close();
  }
  for (const [w, h, label] of [[820, 1180, 'tablet'], [390, 844, 'mobile']]) {
    const { context, page } = await newPage(browser, w, h);
    const vis = await page.evaluate(() => {
      const v = el => { if (!el) return false; const cs = getComputedStyle(el); return cs.display !== 'none' && cs.visibility !== 'hidden' && el.getClientRects().length > 0; };
      return {
        layoutVisible: Array.from(document.querySelectorAll('.sidebar-layout-btn')).filter(v).length,
        resetVisible: Array.from(document.querySelectorAll('.sidebar-size-reset')).filter(v).length,
        resizerVisible: Array.from(document.querySelectorAll('.sidebar-resizer')).filter(v).length,
        tabbar: v(document.getElementById('mobileTabbar')),
        phaseFab: v(document.getElementById('phaseFab')),
        totop: v(document.getElementById('totop'))
      };
    });
    check(label + ': layout-cycle buttons hidden', vis.layoutVisible === 0, JSON.stringify(vis));
    check(label + ': sidebar reset buttons hidden', vis.resetVisible === 0);
    check(label + ': sidebar resizers hidden', vis.resizerVisible === 0);
    check(label + ': tabbar visible, floating FABs hidden', vis.tabbar && !vis.phaseFab && !vis.totop, JSON.stringify(vis));
    await context.close();
  }

  // ═══════════ C. FEATURE 1 — menu drawer ═══════════
  console.log('\n══ C. FEATURE 1: menu drawer (mobile 390×844) ══');
  {
    const { context, page, errors } = await newPage(browser, 390, 844);
    await page.click('#mobileTabbar [data-tab="menu"]');
    await page.waitForTimeout(400);
    let m = await page.evaluate(() => {
      const d = document.getElementById('menuNavDrawer');
      return {
        open: !!d && d.classList.contains('open'),
        bodyCls: document.body.className,
        cards: Array.from(d.querySelectorAll('.side-card')).map(c => (c.className.match(/side-card-([a-z]+)/) || [])[1]),
        hasPhasesCard: !!d.querySelector('.phases-card')
      };
    });
    const expected = ['overview', 'marks', 'stack', 'data', 'store', 'notebook', 'quick', 'dev'];
    check('menu drawer opens via منو button', m.open, 'cards=' + m.cards.join(','));
    check('menu drawer has ALL sidebar cards (except phases list)', expected.every(k => m.cards.includes(k)) && !m.hasPhasesCard, JSON.stringify(m.cards));

    // stack filter chip (a real stack, not "all") works inside drawer and drawer stays open
    const chipWorks = await page.evaluate(() => {
      const chips = Array.from(document.querySelectorAll('#menuNavDrawer [data-act="stack-filter"]'));
      const chip = chips.find(c => (c.dataset.id || '') !== '');
      if (!chip) return { clicked: false };
      chip.click();
      return { clicked: true, on: chip.classList.contains('on') };
    });
    await page.waitForTimeout(350);
    const drawerStill = await page.evaluate(() => document.getElementById('menuNavDrawer').classList.contains('open'));
    check('drawer cards interactive (stack filter) and drawer stays open', chipWorks.clicked && drawerStill, JSON.stringify(chipWorks));

    // close via X
    await page.click('#menuNavDrawer [data-act="menu-drawer-close"]');
    await page.waitForTimeout(350);
    m = await page.evaluate(() => ({ open: document.getElementById('menuNavDrawer').classList.contains('open'), bodyCls: document.body.className }));
    check('menu drawer closes via X', !m.open && !/menu-nav-open/.test(m.bodyCls), JSON.stringify(m));

    // reopen then Esc
    await page.click('#mobileTabbar [data-tab="menu"]');
    await page.waitForTimeout(350);
    await page.keyboard.press('Escape');
    await page.waitForTimeout(350);
    m = await page.evaluate(() => document.getElementById('menuNavDrawer').classList.contains('open'));
    check('menu drawer closes via Esc', !m);

    // scrim close
    await page.click('#mobileTabbar [data-tab="menu"]');
    await page.waitForTimeout(350);
    await page.click('#menuDrawerScrim', { position: { x: 8, y: 400 } });
    await page.waitForTimeout(350);
    m = await page.evaluate(() => document.getElementById('menuNavDrawer').classList.contains('open'));
    check('menu drawer closes via scrim', !m);
    check('menu drawer flow: no page errors', errors.length === 0, errors.slice(0, 2).join(' | '));
    await context.close();
  }

  // ═══════════ D. FEATURE 2 — bottom tabbar ═══════════
  console.log('\n══ D. FEATURE 2: bottom tabbar (mobile) ══');
  {
    const { context, page } = await newPage(browser, 390, 844);
    const t = await page.evaluate(() => {
      const bar = document.getElementById('mobileTabbar');
      const items = Array.from(bar.querySelectorAll('[data-tab]')).map(b => b.dataset.tab);
      const cs = getComputedStyle(bar);
      return { items, display: cs.display, fixed: cs.position, bottom: cs.bottom, zIndex: cs.zIndex };
    });
    check('tabbar: 5 buttons (خانه، فهرست فازها، منو، دفترچه، بازگشت به بالا)',
      JSON.stringify(t.items) === JSON.stringify(['home', 'phases', 'menu', 'notebook', 'top']), JSON.stringify(t.items));
    check('tabbar: fixed at bottom with high z-index', t.display === 'flex' && t.fixed === 'fixed' && t.bottom === '0px' && Number(t.zIndex) >= 80, JSON.stringify(t));

    await page.click('#mobileTabbar [data-tab="phases"]');
    await page.waitForTimeout(400);
    let s = await page.evaluate(() => ({
      phases: document.getElementById('phaseNavDrawer').classList.contains('open'),
      menu: document.getElementById('menuNavDrawer').classList.contains('open')
    }));
    check('فهرست فازها opens phase drawer', s.phases && !s.menu, JSON.stringify(s));

    await page.click('#mobileTabbar [data-tab="menu"]');
    await page.waitForTimeout(400);
    s = await page.evaluate(() => ({
      phases: document.getElementById('phaseNavDrawer').classList.contains('open'),
      menu: document.getElementById('menuNavDrawer').classList.contains('open')
    }));
    check('منو closes phase drawer and opens menu (mutual exclusion)', s.menu && !s.phases, JSON.stringify(s));

    await page.click('#mobileTabbar [data-tab="notebook"]');
    await page.waitForTimeout(500);
    s = await page.evaluate(() => ({ nb: document.getElementById('nbPanel').classList.contains('open'), body: document.body.classList.contains('nb-open') }));
    check('دفترچه opens notebook', s.nb && s.body, JSON.stringify(s));

    const nbPos = await page.evaluate(() => {
      const nb = document.getElementById('nbPanel').getBoundingClientRect();
      const bar = document.getElementById('mobileTabbar').getBoundingClientRect();
      return { nbBottom: Math.round(innerHeight - nb.bottom), barH: Math.round(bar.height), nbBehindBar: nb.bottom > bar.top + 1, nbTop: Math.round(nb.top) };
    });
    check('notebook panel sits above the tabbar (main area above the bar)', !nbPos.nbBehindBar && nbPos.nbBottom >= 50, JSON.stringify(nbPos));

    await page.evaluate(() => window.scrollTo(0, 3000));
    await page.waitForTimeout(200);
    await page.click('#mobileTabbar [data-tab="home"]');
    await page.waitForFunction(() => window.scrollY < 50, { timeout: 3000 }).catch(() => {});
    await page.waitForTimeout(150);
    s = await page.evaluate(() => ({
      y: window.scrollY,
      nb: document.getElementById('nbPanel').classList.contains('open'),
      menu: document.getElementById('menuNavDrawer').classList.contains('open'),
      phases: document.getElementById('phaseNavDrawer').classList.contains('open')
    }));
    check('خانه closes notebook+drawers and returns to top of main page', s.y < 50 && !s.nb && !s.menu && !s.phases, JSON.stringify(s));

    await page.evaluate(() => window.scrollTo(0, 4000));
    await page.waitForTimeout(200);
    await page.click('#mobileTabbar [data-tab="top"]');
    await page.waitForFunction(() => window.scrollY < 50, { timeout: 3000 }).catch(() => {});
    s = await page.evaluate(() => window.scrollY);
    check('بازگشت به بالای صفحه scrolls to top', s < 50, 'y=' + s);

    const pad = await page.evaluate(() => {
      const bodyPad = parseFloat(getComputedStyle(document.body).paddingBottom) || 0;
      const barH = document.getElementById('mobileTabbar').getBoundingClientRect().height;
      return { bodyPad, barH };
    });
    check('content has bottom padding above the bar', pad.bodyPad >= pad.barH - 4, JSON.stringify(pad));

    const homeOn = await page.evaluate(() => {
      const el = document.querySelector('#mobileTabbar [data-tab="home"]');
      const bg = getComputedStyle(el).backgroundColor;
      return bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent';
    });
    check('home tab shows active state on main page', homeOn);
    await context.close();
  }

  {
    const { context, page } = await newPage(browser, 820, 1180);
    await page.click('#mobileTabbar [data-tab="menu"]');
    await page.waitForTimeout(400);
    const s = await page.evaluate(() => ({
      menu: document.getElementById('menuNavDrawer').classList.contains('open'),
      fabHidden: getComputedStyle(document.getElementById('phaseFab')).display === 'none'
    }));
    check('tablet: منو works and floating FABs hidden', s.menu && s.fabHidden, JSON.stringify(s));
    await context.close();
  }
  {
    const { context, page } = await newPage(browser, 1440, 900);
    const s = await page.evaluate(() => {
      const bar = document.getElementById('mobileTabbar');
      return {
        tabbarHidden: getComputedStyle(bar).display === 'none',
        fabVisible: getComputedStyle(document.getElementById('phaseFab')).display !== 'none',
        menuClosed: !document.getElementById('menuNavDrawer').classList.contains('open')
      };
    });
    check('desktop: tabbar hidden, phase FAB still available', s.tabbarHidden && s.fabVisible && s.menuClosed, JSON.stringify(s));
    await context.close();
  }

  // ═══════════ E. FIX 4 — attachment guidance close ═══════════
  console.log('\n══ E. FIX 4: attachment guidance close (notebook) ══');
  {
    const { context, page, errors } = await newPage(browser, 1440, 900);
    await page.click('.notebook-btn');
    await page.waitForTimeout(500);
    let g = await page.evaluate(() => {
      const nodes = Array.from(document.querySelectorAll('[data-attachment-guidance]'));
      return {
        count: nodes.length,
        visible: nodes.filter(n => !n.hidden).length,
        closeBtns: document.querySelectorAll('.attachment-guidance-close').length,
        mode: nodes[0] ? nodes[0].dataset.guidanceMode : null
      };
    });
    check('notebook: guidance notice visible with close button', g.visible >= 1 && g.closeBtns >= 1, JSON.stringify(g));

    await page.click('#nbPanel .attachment-guidance-close');
    await page.waitForTimeout(400);
    g = await page.evaluate(() => {
      const nodes = Array.from(document.querySelectorAll('[data-attachment-guidance]'));
      const nb = document.getElementById('nbPanel');
      const list = nb.querySelector('.nb-listview');
      const saved = JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2') || '{}');
      return {
        allHidden: nodes.every(n => n.hidden),
        dismissed: !!(saved.ui && saved.ui.attachmentNoticeDismissed),
        nbOpen: nb.classList.contains('open'),
        listH: list ? Math.round(list.getBoundingClientRect().height) : 0
      };
    });
    check('close hides ALL guidance boxes, layout stays healthy, state saved', g.allHidden && g.dismissed && g.nbOpen && g.listH > 100, JSON.stringify(g));

    await page.waitForTimeout(300);
    await page.reload();
    await page.waitForTimeout(700);
    await page.click('.notebook-btn');
    await page.waitForTimeout(400);
    g = await page.evaluate(() => {
      const nodes = Array.from(document.querySelectorAll('[data-attachment-guidance]'));
      return { visible: nodes.filter(n => !n.hidden).length };
    });
    check('dismissal persists after reload', g.visible === 0, JSON.stringify(g));
    await context.close();
  }
  {
    const { context: c2, page: p2 } = await newPage(browser, 390, 844);
    await p2.click('#mobileTabbar [data-tab="notebook"]');
    await p2.waitForTimeout(500);
    const g2 = await p2.evaluate(() => {
      const n = document.querySelector('#nbPanel [data-attachment-guidance]');
      const c = document.querySelector('#nbPanel .attachment-guidance-close');
      if (!n || !c) return { ok: false };
      const r = c.getBoundingClientRect();
      return { ok: !n.hidden && r.width > 10 && r.width < 60, w: Math.round(r.width) };
    });
    check('mobile: guidance close button visible & responsive', g2.ok, JSON.stringify(g2));
    await p2.click('#nbPanel .attachment-guidance-close');
    await p2.waitForTimeout(300);
    const g3 = await p2.evaluate(() => Array.from(document.querySelectorAll('[data-attachment-guidance]')).every(n => n.hidden));
    check('mobile: close works', g3);
    await c2.close();
  }

  // ═══════════ F. Regressions ═══════════
  console.log('\n══ F. Regressions ══');
  {
    const { context, page, errors } = await newPage(browser, 1440, 900);
    const boot = await page.evaluate(() => ({
      phases: document.querySelectorAll('.phase').length,
      ver: (document.body.innerText.match(/نسخه نهایی برنامه:\s*V([\d.]+)/) || [])[1],
      meta: document.querySelector('meta[name="version"]').content,
      cv: getComputedStyle(document.querySelector('.phase')).contentVisibility
    }));
    check('boot: 13 phases render', boot.phases === 13, 'phases=' + boot.phases);
    check('version: meta & footer show 1.0.3', boot.ver === '1.0.3' && boot.meta === '1.0.3', JSON.stringify(boot));
    check('content-visibility neutralized on phases (nav root cause)', boot.cv === 'visible', boot.cv);

    await page.fill('#q', 'qqqq-not-a-real-term');
    await page.waitForTimeout(900);
    const searchEmpty = await page.evaluate(() => document.querySelectorAll('.phase').length);
    await page.fill('#q', '');
    await page.waitForTimeout(900);
    const searchBack = await page.evaluate(() => document.querySelectorAll('.phase').length);
    check('search still filters phases', searchEmpty < 13 && searchBack === 13, 'empty=' + searchEmpty + ' back=' + searchBack);

    await page.evaluate(() => { const cb = document.querySelector('.ck input'); if (cb) cb.click(); });
    await page.waitForTimeout(300);
    const checked = await page.evaluate(() => !!document.querySelector('.ck input:checked'));
    check('checkbox toggle works', checked);

    await page.evaluate(() => { const b = document.querySelector('.sidebar-layout-btn'); if (b) b.click(); });
    await page.waitForTimeout(400);
    const layout = await page.evaluate(() => document.querySelector('.layout').dataset.sidebarLayout);
    check('layout-cycle button still works on desktop', layout && layout !== 'dual-right', 'layout=' + layout);

    const cssOk = await page.evaluate(() => {
      let found = false;
      for (const sheet of document.styleSheets) {
        try {
          for (const rule of sheet.cssRules) {
            if (rule.cssText && rule.cssText.includes('mobile-tabbar') && /display:\s*none/.test(rule.cssText)) found = true;
          }
        } catch (e) { }
      }
      return found;
    });
    check('print/hidden CSS rules present for tabbar', cssOk);

    check('regression suite: no page errors', errors.length === 0, errors.slice(0, 3).join(' | '));
    await context.close();
  }

  await browser.close();
  console.log('\n══════════════════════════════════');
  console.log(`TOTAL: ${pass + fail} — PASS: ${pass} — FAIL: ${fail}`);
  if (failures.length) { console.log('FAILURES:'); failures.forEach(f => console.log('  ✗ ' + f)); process.exit(1); }
  console.log('🎉 ALL TESTS PASSED');
})().catch(e => { console.error('FATAL', e); process.exit(1); });
