#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
patch2.py — fix round on packpolymer-marketplace-roadmap-v1.0.3.html (in place, no version bump).
Scope (strict — ONLY the user's tasks):
  1.1  performance: lazy note panels (step/phase), edit-chrome only when editing,
       content-visibility:auto + per-phase contain-intrinsic-size + nav-stable in scrollToId,
       solid mobile tabbar (no backdrop blur)
  1.2  mobile/tablet menu drawer redesign (no clipping, readable, proper tap targets)
  2.1  desktop compact header: sidebar-size-reset = icon square like layout button
  2.2  desktop normal header: 3-row layout — layout+reset buttons to END of Row 3
  3.1  mobile/tablet notebook redesign (Obsidian-like): compact new-note, facets drawer,
       single-column list, one-row note toolbar, hide Split on small screens
  3.2  mobile/tablet entity-note placeholder hidden (the broken half "M")
  3.3  mobile/tablet bottom tab bar slightly shorter (64 -> 54)
"""
import shutil, sys

PATH = 'uploads/packpolymer-marketplace-roadmap-v1.0.3.html'

src = open(PATH, encoding='utf-8').read()
orig_len = len(src)
OPS = []

def replace_once(old, new, tag):
    n = src.count(old) if False else None  # placeholder
    OPS.append((old, new, tag))

# ---------------------------------------------------------------- PERF 1.1
# lazy note panel in phaseHTML
replace_once(
    "notePanel(ph.id, noteValue, ph, false, 'phase')) +",
    "(state.openNotes[noteKey] ? notePanel(ph.id, noteValue, ph, false, 'phase') : '<div class=\"note-wrap things-note phase-note\" data-note-wrap=\"' + esc(noteKey) + '\" data-note-lazy=\"true\"></div>')) +",
    "perf-phase-note-lazy")

# edit chrome: stepHTML head (move/del) only while editing
replace_once(
    "'<div class=\"acts-edit\">' +\n      '<button class=\"iact\" data-act=\"move-step\"",
    "(state.ui.editing ? '<div class=\"acts-edit\">' +\n      '<button class=\"iact\" data-act=\"move-step\"",
    "perf-step-edit-open1")
replace_once(
    "'</div>' + entityBtn('step', s.id) +",
    "'</div>' : '') + entityBtn('step', s.id) +",
    "perf-step-edit-close1")

# edit chrome: stepHTML acts (insert/add-sub/add-tip) only while editing
replace_once(
    "'<span class=\"acts-edit\">' +\n      '<span class=\"insert-action-group\">' + insertPositionControl('sub'",
    "(state.ui.editing ? '<span class=\"acts-edit\">' +\n      '<span class=\"insert-action-group\">' + insertPositionControl('sub'",
    "perf-step-edit-open2")
replace_once(
    "'</span>' +\n      '</div>' +\n      notePanel(s.id, nv, ph, false) +",
    "'</span>' : '') +\n      '</div>' +\n      (state.openNotes[nk] ? notePanel(s.id, nv, ph, false) : '<div class=\"note-wrap things-note\" data-note-wrap=\"' + esc(nk) + '\" data-note-lazy=\"true\"></div>') +",
    "perf-step-edit-close2+note-lazy")

# edit chrome: subHTML (move/del) only while editing
replace_once(
    "'<span class=\"acts-edit\">' +\n      '<button class=\"iact tiny\" data-act=\"move-sub\"",
    "(state.ui.editing ? '<span class=\"acts-edit\">' +\n      '<button class=\"iact tiny\" data-act=\"move-sub\"",
    "perf-sub-edit-open")
replace_once(
    "'</span>' +\n      '</div>' +\n      noteUi +",
    "'</span>' : '') +\n      '</div>' +\n      noteUi +",
    "perf-sub-edit-close")

# edit chrome: phaseHTML editbar only while editing
replace_once(
    "'<div class=\"editbar\"><b>حالت ویرایش:</b>",
    "(state.ui.editing ? '<div class=\"editbar\"><b>حالت ویرایش:</b>",
    "perf-editbar-open")
replace_once(
    "</button>' +\n      '</div>' +\n      '<div class=\"steps\">'",
    "</button>' +\n      '</div>' : '') +\n      '<div class=\"steps\">'",
    "perf-editbar-close")

# per-phase contain-intrinsic-size (calibrated: 220 + steps*150 + subs*64 ; closed head=175)
replace_once(
    "+ '\" id=\"' + esc(ph.id) + '\" data-phase=\"' + esc(ph.id) + '\" style=\"--c:' + color + '\">' +",
    "+ '\" id=\"' + esc(ph.id) + '\" data-phase=\"' + esc(ph.id) + '\" style=\"--c:' + color + ';contain-intrinsic-size:auto ' + (isOpen ? (220 + ph.steps.length * 150 + ph.steps.reduce(function (nAcc, s0) { return nAcc + s0.subs.length; }, 0) * 64) : 175) + 'px\">' +",
    "perf-phase-intrinsic")

# content-visibility: auto (restore) + nav-stable escape hatch
replace_once(
    ".phase{content-visibility:visible;contain-intrinsic-size:auto 260px}",
    ".phase{content-visibility:auto;contain-intrinsic-size:auto 260px}\nhtml.nav-stable .phase{content-visibility:visible}",
    "perf-content-visibility")

# scrollToId: keep everything measurable during navigation
replace_once(
    "function scrollToId(id, waitForLayout) {",
    "function scrollToId(id, waitForLayout) {\n    try { window.__navStableToken = (window.__navStableToken || 0) + 1; var __navTok = window.__navStableToken; document.documentElement.classList.add('nav-stable'); setTimeout(function () { if (window.__navStableToken === __navTok) document.documentElement.classList.remove('nav-stable'); }, 1500); } catch (e) {}",
    "perf-nav-stable")

# solid tabbar background + slightly shorter bar (3.3) — kill expensive blur on mobile scroll
replace_once(
    "min-height:64px;padding:6px 6px calc(6px + env(safe-area-inset-bottom));background:rgba(10,16,29,.97);border-top:1px solid var(--line-strong);backdrop-filter:blur(14px);",
    "min-height:54px;padding:5px 6px calc(5px + env(safe-area-inset-bottom));background:rgba(10,16,29,.985);border-top:1px solid var(--line-strong);",
    "perf-tabbar-solid+3.3")

# 3.3 tab items slightly shorter (standard)
replace_once(
    ".mobile-tabbar .tab-item{flex:1 1 0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;min-width:0;min-height:48px;",
    ".mobile-tabbar .tab-item{flex:1 1 0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;min-width:0;min-height:42px;",
    "tab3.3-btn-height")

# ---------------------------------------------------------------- HEADER 2.2
# Row breaks + desktop-only re-flow: brand | search | font ; filters ; actions+layout/reset
replace_once(
    "fontScaleControls('ui','header') + '</div>' +\n      '<div class=\"search\">",
    "fontScaleControls('ui','header') + '</div>' +\n      '<i class=\"topbar-break brk-a\" aria-hidden=\"true\"></i>' +\n      '<div class=\"search\">",
    "hdr22-break-a")
replace_once(
    "' : '') + '</div>' +\n      '<div class=\"tools header-actions header-actions-right\">'",
    "' : '') + '</div>' +\n      '<i class=\"topbar-break brk-b\" aria-hidden=\"true\"></i>' +\n      '<div class=\"tools header-actions header-actions-right\">'",
    "hdr22-break-b")

# ---------------------------------------------------------------- NOTEBOOK 3.1
replace_once(
    "'<button class=\"btn pri\" data-nb=\"new\">' + I('plus') + ' یادداشت جدید</button></div>' +",
    "'<button class=\"btn nb-facets-btn\" data-nb=\"facets-toggle\" title=\"فیلتر نوشته ها: فولدر، دسته بندی و تگ\" aria-label=\"فیلترهای نوشته ها\">' + I('checklist') + '<span class=\"control-label\">فیلترها</span></button>' +\n            '<button class=\"btn pri nb-new-note\" data-nb=\"new\">' + I('plus') + '<span class=\"control-label\">یادداشت جدید</span></button></div>' +",
    "nb31-facets-btn")

replace_once(
    "nbEls.panel.addEventListener('click', (e) => {\n      const b = e.target.closest('[data-nb]'); if (!b) return;",
    "nbEls.panel.addEventListener('click', (e) => {\n      try {\n        const exOpen = e.target.closest ? e.target.closest('[data-nb-explorer]') : null;\n        if (exOpen && exOpen.classList.contains('facets-open')) {\n          const inSide = e.target.closest('.nb-explorer-side');\n          const isFacet = e.target.closest('[data-nb=\"browse-value\"]');\n          if (!inSide || isFacet) exOpen.classList.remove('facets-open');\n        }\n      } catch (ex) {}\n      const b = e.target.closest('[data-nb]'); if (!b) return;",
    "nb31-scrim-close")

replace_once(
    "else if (a === 'browse-value') {",
    "else if (a === 'facets-toggle') { const ex = nbEls.panel.querySelector('[data-nb-explorer]'); if (ex) ex.classList.toggle('facets-open'); }\n      else if (a === 'browse-value') {",
    "nb31-facets-case")

# ---------------------------------------------------------------- APPLY
out = src
for old, new, tag in OPS:
    cnt = out.count(old)
    if cnt != 1:
        print(f'FAIL [{tag}]: expected 1 occurrence, found {cnt}')
        print('   anchor:', repr(old[:90]))
        sys.exit(1)
    out = out.replace(old, new, 1)
    print(f'ok [{tag}]')

# ---------------------------------------------------------------- CSS BLOCK
css = r"""
/* ===== User-requested fixes (round 2): scoped by device; desktop content untouched except header tasks 2.1/2.2 ===== */
@media (min-width:1181px){
  /* 2.2 — desktop normal header: Row1 = brand(right)+search(center)+font(next to search);
     Row2 = filters unchanged; Row3 = actions + sidebar layout/reset buttons at the end. */
  .topbar-break{display:block;flex:0 0 100%;width:0;height:0;padding:0;margin:0;border:0;overflow:hidden;visibility:hidden}
  .topbar:not(.compact)>.header-actions-left{display:contents!important}
  .topbar:not(.compact)>.brand{order:1;flex:1 1 280px}
  .topbar:not(.compact)>.search{order:2;flex:1 1 380px;max-width:560px;margin-inline:auto}
  .topbar:not(.compact)>.header-actions-left>.font-controls{order:3;flex:0 0 auto}
  .topbar:not(.compact)>.topbar-break.brk-a{order:4}
  .topbar:not(.compact)>.filters-main{order:5;flex:0 1 auto}
  .topbar:not(.compact)>.filters-marks{order:6;flex:0 1 auto}
  .topbar:not(.compact)>.topbar-break.brk-b{order:7}
  .topbar:not(.compact)>.header-actions-right{order:8;flex:0 1 auto}
  .topbar:not(.compact)>.header-actions-left>.sidebar-layout-slot{order:9;flex:0 0 auto}
  .topbar.compact>.topbar-break{display:none!important}
  /* 2.1 — compact header: reset sidebar size = icon square exactly like the layout-mode button */
  .topbar.compact .sticky-layout-slot>.sidebar-size-reset{
    width:32px;height:32px;min-width:32px;min-height:32px;padding:0;justify-content:center;
    gap:0;font-size:0;flex:0 0 32px;
  }
  .topbar.compact .sticky-layout-slot>.sidebar-size-reset .ic{width:16px;height:16px;flex:0 0 16px}
  .topbar.compact .sticky-layout-slot>.sidebar-size-reset .control-label{display:none!important}
}
@media (max-width:1180px){
  .topbar-break{display:none!important}

  /* 3.3 — standard slightly-shorter bottom bar */
  .mobile-tabbar .tab-item .ic{width:18px;height:18px}

  /* 3.2 — entity note placeholder removed on mobile/tablet (half-letter "M" glitch) */
  .note-editor::placeholder,.note.note-editor::placeholder{color:transparent!important;opacity:0!important}

  /* 1.2 — menu drawer redesign: full readable cards, no clipping, comfortable tap targets */
  .menu-drawer-list{gap:11px;padding:12px 12px 84px}
  .menu-drawer-list>.side-card{flex:0 0 auto;min-height:0;border-radius:15px;overflow:hidden}
  .menu-drawer .card-h{min-height:48px;padding:13px 15px;gap:10px}
  .menu-drawer .side-h-t{font-size:13px;gap:8px}
  .menu-drawer .side-h-t .ic{width:16px;height:16px}
  .menu-drawer .side-h-r small{font-size:11px}
  .menu-drawer .side-chev{width:11px;height:11px;opacity:.85}
  .menu-drawer .card-b{padding:12px 15px 16px;display:flex;flex-direction:column;gap:11px}
  .menu-drawer .meta-row{flex-wrap:wrap;gap:8px 12px;font-size:12px}
  .menu-drawer .hint{white-space:normal;line-height:1.8;font-size:11.5px;opacity:.92}
  .menu-drawer .stats{grid-template-columns:1fr 1fr;gap:8px;margin-top:0!important}
  .menu-drawer .stat{padding:11px 12px;border-radius:12px;font-size:12px;line-height:1.8}
  .menu-drawer .stat b{font-size:17px}
  .menu-drawer .pbar{height:8px;border-radius:6px}
  .menu-drawer .stack-chips{flex-wrap:wrap;gap:7px}
  .menu-drawer .schip{min-height:38px;padding:8px 13px;font-size:12px;border-radius:11px;gap:6px}
  .menu-drawer .schip b{font-size:11px}
  .menu-drawer .btn{min-height:42px;padding:9px 13px;font-size:12.5px;border-radius:11px;gap:7px;justify-content:center}
  .menu-drawer .toolbtns{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin-top:0!important}
  .menu-drawer .store-row{gap:10px;font-size:12px;line-height:1.8}
  .menu-drawer .card-b ol,.menu-drawer .card-b ul{margin:0;padding-inline-start:20px;font-size:12px;line-height:2}

  /* 3.1 — notebook (Obsidian-mobile style): one list column, facets behind a toggle, compact note editor */
  .nb-listtools{gap:7px;padding:9px 10px 7px}
  .nb-listtools-main{gap:6px}
  .nb-listtools-main .nb-search{flex:1 1 auto;min-width:0;flex-basis:auto}
  .nb-listtools-main>.btn{width:auto!important;flex:0 0 auto;min-height:40px;padding:8px 11px;font-size:11.5px}
  .nb-listtools-main>.nb-facets-btn{padding:8px 10px}
  .nb-browse-modes{width:100%;flex-wrap:nowrap;overflow-x:auto;padding:1px 1px 3px;overscroll-behavior-x:contain}
  .nb-browse-mode{min-height:33px;padding:6px 10px;font-size:11px}
  .nb-explorer{grid-template-columns:minmax(0,1fr)!important;grid-template-rows:minmax(0,1fr)!important;position:relative;margin:0 7px 8px}
  .nb-explorer-side{
    position:absolute;top:0;bottom:0;inset-inline-start:0;width:min(310px,84vw);z-index:35;
    transform:translateX(105%);transition:transform .22s ease;border:1px solid rgba(148,175,224,.16);
    border-radius:14px;box-shadow:-14px 0 34px rgba(0,0,0,.42);background:rgba(11,17,29,.99);
  }
  .nb-explorer.facets-open .nb-explorer-side{transform:translateX(0)}
  .nb-explorer.facets-open::after{content:'';position:absolute;inset:0;z-index:34;background:rgba(3,7,17,.55)}
  .nb-explorer-side-head{padding:10px 11px}
  .nb-browse-items{padding:8px;gap:6px}
  .nb-facet{min-height:38px;padding:7px 9px;font-size:11px}
  .nb-list-controls{gap:6px;padding:7px 8px}
  .nb-list{padding:7px;gap:7px}
  .nb-card{padding:10px 11px;gap:6px 8px}
  .nb-card-main b{font-size:12.5px;line-height:1.65}
  .nb-card-main p{margin:2px 0 5px;font-size:11px;line-height:1.75;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
  .nb-explorer-count{padding:6px 9px;font-size:9.5px}
  .nb-note-top{gap:6px;padding:8px 9px}
  .nb-note-top .nb-split-toggle{display:none!important}
  .nb-note-top .nb-top-title{display:none}
  .nb-back{min-height:36px;padding:6px 9px;font-size:11px}
  .nb-note-top .iact{min-height:36px;padding:6px 9px;font-size:11px}
  .nb-pane-head{padding:7px 9px;gap:5px}
  .nb-title-input{min-height:38px;font-size:13.5px;padding:7px 10px}
  .nb-pane-head-actions{gap:4px}
  .nb-pane-head-actions .iact{min-height:34px;padding:5px 8px;font-size:10.5px}
  .nb-tools{flex-direction:row!important;flex-wrap:nowrap!important;align-items:center;gap:4px;padding:6px 8px;overflow-x:auto;overflow-y:hidden;scrollbar-width:none}
  .nb-tools::-webkit-scrollbar{display:none}
  .nb-format,.nb-actions{flex-wrap:nowrap!important;gap:3px;padding-top:0;border-top:0}
  .nb-format .iact,.nb-actions .iact{min-height:32px;padding:4px 8px;font-size:10px;white-space:nowrap}
  .nb-body{padding:8px 9px}
  .nb-foot{padding:6px 9px;gap:8px;font-size:9.5px}
  .nb-properties-panel{margin:6px 8px;padding:9px}
}
</style>"""

if out.count('</style>') != 1:
    print('FAIL: </style> count =', out.count('</style>'))
    sys.exit(1)
out = out.replace('</style>', css, 1)
print('ok [css-block]')

open(PATH, 'w', encoding='utf-8').write(out)
print(f'DONE: {orig_len} -> {len(out)} bytes (+{len(out)-orig_len})')
