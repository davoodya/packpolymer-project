#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build packpolymer-marketplace-roadmap-v1.0.3.html from v1.0.2 with the requested fixes/features."""
import sys

SRC = '/home/user/uploads/packpolymer-marketplace-roadmap-v1.0.2.html'
DST = '/home/user/uploads/packpolymer-marketplace-roadmap-v1.0.3.html'

src = open(SRC, encoding='utf-8').read()
out = src
n_ops = 0

def rep(tag, old, new, count=1):
    global out, n_ops
    c = out.count(old)
    if c != count:
        print(f'FAIL [{tag}]: expected {count} occurrence(s), found {c}')
        print('   fragment:', old[:120].replace('\n', '\\n'))
        sys.exit(1)
    out = out.replace(old, new)
    n_ops += 1
    print(f'OK  [{tag}] x{count}')

# ─────────────────────────────────────────────
# A) Version bump (meta + APP_VERSION)
# ─────────────────────────────────────────────
rep('meta-version', '<meta name="version" content="1.3.0">', '<meta name="version" content="1.0.3">')
rep('app-version', "const APP_VERSION = '1.3.0';", "const APP_VERSION = '1.0.3';")

# ─────────────────────────────────────────────
# B) FIX 2 — sub-step navigation root cause + hardening
# ─────────────────────────────────────────────
rep('css-content-visibility',
    '.phase{content-visibility:auto;contain-intrinsic-size:auto 260px}',
    '.phase{content-visibility:visible;contain-intrinsic-size:auto 260px}')

rep('scrollToId-verify',
    """      if (highlighted !== el) {
        if (highlighted) highlighted.classList.remove('hit');
        highlighted = el; el.classList.add('hit');
        setTimeout(() => { if (highlighted === el) el.classList.remove('hit'); }, 1800);
      }
      return true;
    };
    if (waitForLayout) {
      [0, 90, 260, 620, 1100].forEach(delay => setTimeout(() => requestAnimationFrame(doScroll), delay));
    } else if (!doScroll()) { setTimeout(doScroll, 80); setTimeout(doScroll, 260); }
    else { requestAnimationFrame(() => requestAnimationFrame(doScroll)); }
  }""",
    """      if (highlighted !== el) {
        if (highlighted) highlighted.classList.remove('hit');
        highlighted = el; el.classList.add('hit');
        setTimeout(() => { if (highlighted === el) el.classList.remove('hit'); }, 1800);
      }
      // اگر هنوز هدف دقیقا در جای درست نیست (جابه جایی دیرهنگام لایه اوت)، تلاش مجدد می شود
      const r2 = el.getBoundingClientRect();
      return Math.abs(r2.top - offset) <= 40;
    };
    if (waitForLayout) {
      [0, 90, 260, 620, 1100].forEach(delay => setTimeout(() => requestAnimationFrame(doScroll), delay));
    } else if (!doScroll()) { setTimeout(doScroll, 80); setTimeout(doScroll, 260); setTimeout(doScroll, 620); }
    else { requestAnimationFrame(() => requestAnimationFrame(doScroll)); }
  }""")

# ─────────────────────────────────────────────
# C) FIX 1+3 — layout/reset buttons: desktop only, reset next to layout button
# ─────────────────────────────────────────────
rep('top-header-left',
    """'<div class="tools header-actions header-actions-left"><span class="sidebar-layout-slot">' + sidebarLayoutButton('header') + '</span>' + fontScaleControls('ui','header') + '</div>' +""",
    """'<div class="tools header-actions header-actions-left"><span class="sidebar-layout-slot">' + sidebarLayoutButton('header') + resetButton('sidebar-reset-btn') + '</span>' + fontScaleControls('ui','header') + '</div>' +""")

rep('top-header-right-remove-reset',
    """        resetButton('main-sidebar-reset') + cleanButton('', false) + jsonExportButton('', false) + jsonImportButton('', false) + printButton('', false) +""",
    """        cleanButton('', false) + jsonExportButton('', false) + jsonImportButton('', false) + printButton('', false) +""")

rep('top-sticky-left',
    """'<div class="sticky-side-tools"><span class="sticky-layout-slot">' + sidebarLayoutButton('sticky') + '</span>' + fontScaleControls('ui','sticky') + '</div>' +""",
    """'<div class="sticky-side-tools"><span class="sticky-layout-slot">' + sidebarLayoutButton('sticky') + resetButton('sticky-action sidebar-reset-btn') + '</span>' + fontScaleControls('ui','sticky') + '</div>' +""")

rep('top-sticky-right-remove-reset',
    """reportMenu('sticky-report-menu', false) + resetButton('sticky-action sticky-reset') +""",
    """reportMenu('sticky-report-menu', false) +""")

rep('sidebar-card-tools',
    """'<div class="side-phase-tools">' + sidebarLayoutButton('sidebar') + fontScaleControls('ui','sidebar') + '</div>' +""",
    """'<div class="side-phase-tools">' + sidebarLayoutButton('sidebar') + sidebarResetButton('sidebar-reset-btn') + fontScaleControls('ui','sidebar') + '</div>' +""")

rep('sidebar-reset-helper',
    """  function sidebarLayoutButton(place) {""",
    """  function sidebarResetButton(extraClass) {
    return '<button type="button" class="btn sidebar-size-reset ' + (extraClass || '') + '" data-act="sidebar-size-reset" title="ریست سایز سایدبار" aria-label="ریست سایز سایدبار">' + I('reset') + '<span class="control-label">ریست سایز سایدبار</span></button>';
  }
  function sidebarLayoutButton(place) {""")

rep('drawer-tools',
    """'<div class="phase-drawer-tools">' + sidebarLayoutButton('drawer') + fontScaleControls('ui','drawer') + '</div>' +""",
    """'<div class="phase-drawer-tools">' + sidebarLayoutButton('drawer') + sidebarResetButton('sidebar-reset-btn') + fontScaleControls('ui','drawer') + '</div>' +""")

# ─────────────────────────────────────────────
# D) FIX 4 — close button for attachment guidance
# ─────────────────────────────────────────────
rep('guidance-close-fallback',
    """ZIP دانلود کن.</span></span>';""",
    """ZIP دانلود کن.</span></span><button type="button" class="iact attachment-guidance-close" data-act="attachment-notice-close" title="بستن این پیام" aria-label="بستن پیام راهنمای پیوست">' + I('x') + '</button>';""")

rep('guidance-close-permission',
    """'>انتخاب پوشه attachments</button>';""",
    """'>انتخاب پوشه attachments</button><button type="button" class="iact attachment-guidance-close" data-act="attachment-notice-close" title="بستن این پیام" aria-label="بستن پیام راهنمای پیوست">' + I('x') + '</button>';""")

rep('guidance-hidden-dismissed',
    """        node.hidden = !html;""",
    """        node.hidden = !html || (typeof state !== 'undefined' && state.ui && !!state.ui.attachmentNoticeDismissed);""")

rep('payload-notice',
    """        customized: !!state.customized
      };""",
    """        attachmentNoticeDismissed: !!state.ui.attachmentNoticeDismissed,
        customized: !!state.customized
      };""")

rep('apply-notice',
    """    if (a.uiFontScale != null) state.ui.fontScale = clampScale(a.uiFontScale, state.ui.fontScale);""",
    """    if (a.uiFontScale != null) state.ui.fontScale = clampScale(a.uiFontScale, state.ui.fontScale);
    if (a.attachmentNoticeDismissed != null) state.ui.attachmentNoticeDismissed = !!a.attachmentNoticeDismissed;""")

# ─────────────────────────────────────────────
# E) state.ui fields + load() restores
# ─────────────────────────────────────────────
rep('state-ui-fields',
    """sideClosed: { dev: true }, markFilters: [] }""",
    """sideClosed: { dev: true }, markFilters: [], attachmentNoticeDismissed: false, menuDrawerOpen: false }""")

rep('load-menu-closed',
    """      state.ui.phaseDrawerOpen = false;""",
    """      state.ui.phaseDrawerOpen = false;
      state.ui.menuDrawerOpen = false;""")

rep('load-notice-dismissed',
    """        state.ui.sideClosed = Object.assign({ dev: true }, d.ui.sideClosed || {});""",
    """        state.ui.sideClosed = Object.assign({ dev: true }, d.ui.sideClosed || {});
        state.ui.attachmentNoticeDismissed = !!d.ui.attachmentNoticeDismissed;""")

# ─────────────────────────────────────────────
# F) Feature 1 — menu drawer (side cards) + toggle + refresh
# ─────────────────────────────────────────────
rep('renderSide-refactor-head',
    """  function renderSide() {
    const g = counts();""",
    """  function sideCards(includePhaseCard) {
    const g = counts();""")

rep('renderSide-refactor-branch',
    """    const mode = validSidebarLayout(state.ui.sidebarLayout);
    if (mode === 'single-right') {""",
    """    const mode = validSidebarLayout(state.ui.sidebarLayout);
    if (!includePhaseCard) return overviewCard + otherCards;
    if (mode === 'single-right') {""")

rep('renderSide-refactor-tail',
    """    return '<aside class="side side-left side-tools" aria-label="ابزارها و وضعیت پروژه">' + overviewCard + otherCards + '</aside>' +
      '<aside class="side side-right side-phases" aria-label="فهرست فازها">' + phaseCard + '</aside>';
  }""",
    """    return '<aside class="side side-left side-tools" aria-label="ابزارها و وضعیت پروژه">' + overviewCard + otherCards + '</aside>' +
      '<aside class="side side-right side-phases" aria-label="فهرست فازها">' + phaseCard + '</aside>';
  }
  function renderSide() { return sideCards(true); }""")

rep('menu-drawer-functions',
    """  function togglePhaseDrawer(force) {""",
    """  let menuDrawerScrollY = 0;
  function renderMenuDrawer() {
    const open = !!state.ui.menuDrawerOpen;
    return '<div class="menu-drawer-scrim ' + (open ? 'show' : '') + '" id="menuDrawerScrim" data-act="menu-drawer-close" aria-hidden="' + (!open) + '"></div>' +
      '<aside class="menu-drawer ' + (open ? 'open' : '') + '" id="menuNavDrawer" role="dialog" aria-modal="true" aria-label="منوی ابزارها" aria-hidden="' + (!open) + '">' +
      '<header class="menu-drawer-head"><div><b>' + I('more') + ' منو</b><small>نمای کلی، فیلترها، ابزارها و دفترچه</small></div>' +
      '<button type="button" class="iact" data-act="menu-drawer-close" title="بستن منو (Esc)" aria-label="بستن منو">' + I('x') + '</button></header>' +
      '<div class="menu-drawer-list">' + (open ? sideCards(false) : '') + '</div>' +
      '</aside>';
  }
  function refreshMenuDrawer() {
    const scrim = $('#menuDrawerScrim'), oldDrawer = $('#menuNavDrawer');
    if (!scrim || !oldDrawer) { render(); return; }
    const template = document.createElement('template');
    template.innerHTML = renderMenuDrawer();
    scrim.replaceWith(template.content.firstElementChild);
    oldDrawer.replaceWith(template.content.lastElementChild);
    updateHeaderCompact();
  }
  function toggleMenuDrawer(force) {
    const wasOpen = !!state.ui.menuDrawerOpen;
    const open = typeof force === 'boolean' ? force : !wasOpen;
    if (open && !wasOpen) {
      if (state.ui.phaseDrawerOpen) togglePhaseDrawer(false);
      menuDrawerScrollY = window.scrollY;
    }
    const restoreY = open ? menuDrawerScrollY : (wasOpen ? menuDrawerScrollY : window.scrollY);
    state.ui.menuDrawerOpen = open;
    document.body.classList.toggle('menu-nav-open', open);
    save(); refreshMenuDrawer();
    if (document.scrollingElement) document.scrollingElement.scrollTop = restoreY;
    updateHeaderCompact();
  }
  function togglePhaseDrawer(force) {""")

rep('phase-drawer-cross-close',
    """    if (open && !wasOpen) phaseDrawerScrollY = window.scrollY;""",
    """    if (open && !wasOpen) {
      if (state.ui.menuDrawerOpen) toggleMenuDrawer(false);
      phaseDrawerScrollY = window.scrollY;
    }""")

rep('render-tail-menu',
    """'</div></div>' + renderPhaseDrawer();""",
    """'</div></div>' + renderPhaseDrawer() + renderMenuDrawer();""")

rep('case-menu-drawer-close',
    """case 'phase-drawer-close': togglePhaseDrawer(false); break;""",
    """case 'phase-drawer-close': togglePhaseDrawer(false); break;
          case 'menu-drawer-close': toggleMenuDrawer(false); break;""")

rep('esc-menu-drawer',
    """if (state.ui.phaseDrawerOpen) { togglePhaseDrawer(false); return; }""",
    """if (state.ui.phaseDrawerOpen) { togglePhaseDrawer(false); return; } if (state.ui.menuDrawerOpen) { toggleMenuDrawer(false); return; }""")

rep('sidebar-layout-only-refresh-menu',
    """    refreshFontScales();updateHeaderCompact();syncSidebarResizeA11y(fresh);""",
    """    refreshFontScales();updateHeaderCompact();syncSidebarResizeA11y(fresh);if (state.ui.menuDrawerOpen) refreshMenuDrawer();""")

# ─────────────────────────────────────────────
# G) Feature 2 — bottom tabbar: body HTML + sprite icons + JS bindings
# ─────────────────────────────────────────────
rep('sprite-icons',
    """<symbol id="i-more" viewBox="0 0 24 24"><path d="M5 12h.01M12 12h.01M19 12h.01"/></symbol>""",
    """<symbol id="i-more" viewBox="0 0 24 24"><path d="M5 12h.01M12 12h.01M19 12h.01"/></symbol>
  <symbol id="i-home" viewBox="0 0 24 24"><path d="M3.5 11 12 4l8.5 7"/><path d="M5.5 9.7V20h13V9.7"/><path d="M9.5 20v-6h5v6"/></symbol>
  <symbol id="i-menu" viewBox="0 0 24 24"><path d="M4 7h16"/><path d="M4 12h16"/><path d="M4 17h16"/></symbol>""")

rep('body-tabbar',
    """<button class="phase-fab" id="phaseFab" type="button" title="باز کردن فهرست فازها" aria-label="باز کردن فهرست فازها" aria-controls="phaseNavDrawer" aria-expanded="false"><svg class="ic" aria-hidden="true"><use href="#i-phases"></use></svg><span>فهرست فازها</span></button>""",
    """<button class="phase-fab" id="phaseFab" type="button" title="باز کردن فهرست فازها" aria-label="باز کردن فهرست فازها" aria-controls="phaseNavDrawer" aria-expanded="false"><svg class="ic" aria-hidden="true"><use href="#i-phases"></use></svg><span>فهرست فازها</span></button>
<nav class="mobile-tabbar" id="mobileTabbar" aria-label="ناوبری سریع">
  <button type="button" class="tab-item" data-tab="home" title="بازگشت به صفحه اصلی" aria-label="خانه"><svg class="ic" aria-hidden="true"><use href="#i-home"></use></svg><span>خانه</span></button>
  <button type="button" class="tab-item" data-tab="phases" title="فهرست فازها" aria-label="فهرست فازها"><svg class="ic" aria-hidden="true"><use href="#i-phases"></use></svg><span>فهرست فازها</span></button>
  <button type="button" class="tab-item" data-tab="menu" title="منوی ابزارها و فیلترها" aria-label="منو"><svg class="ic" aria-hidden="true"><use href="#i-menu"></use></svg><span>منو</span></button>
  <button type="button" class="tab-item" data-tab="notebook" title="دفترچه یادداشت" aria-label="دفترچه"><svg class="ic" aria-hidden="true"><use href="#i-note"></use></svg><span>دفترچه</span></button>
  <button type="button" class="tab-item" data-tab="top" title="بازگشت به بالای صفحه" aria-label="بازگشت به بالای صفحه"><svg class="ic" aria-hidden="true"><use href="#i-up"></use></svg><span>بالای صفحه</span></button>
</nav>""")

rep('bind-tabbar-and-notice-close',
    """    if (phaseFab) phaseFab.addEventListener('click', () => togglePhaseDrawer());""",
    """    if (phaseFab) phaseFab.addEventListener('click', () => togglePhaseDrawer());

    // نوار پایینی چسبان (فقط موبایل/تبلت)
    const tabbar = document.getElementById('mobileTabbar');
    if (tabbar) tabbar.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-tab]');
      if (!btn) return;
      const act = btn.dataset.tab;
      if (act === 'home') {
        if (state.ui.nbOpen) nbToggle(false);
        if (state.ui.phaseDrawerOpen) togglePhaseDrawer(false);
        if (state.ui.menuDrawerOpen) toggleMenuDrawer(false);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else if (act === 'phases') togglePhaseDrawer();
      else if (act === 'menu') toggleMenuDrawer();
      else if (act === 'notebook') nbToggle();
      else if (act === 'top') window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    // بستن پیام راهنمای پیوست (دفترچه و یادداشت ها)
    document.addEventListener('click', (e) => {
      const b = e.target.closest('[data-act="attachment-notice-close"]');
      if (!b) return;
      e.preventDefault();
      state.ui.attachmentNoticeDismissed = true;
      save();
      attachmentStore.updateGuidance(document);
      try { nbApplyResizeLayout(); } catch (_) { }
      toast('پیام راهنمای پیوست بسته شد.');
    });""")

# ─────────────────────────────────────────────
# H) CSS additions (before </style>)
# ─────────────────────────────────────────────
NEW_CSS = """
/* ==================== V1.0.3: بستن پیام راهنمای پیوست ==================== */
.attachment-guidance-close{flex:0 0 auto;display:grid;place-items:center;width:27px;height:27px;min-width:27px;padding:0;border:1px solid rgba(245,158,11,.32);border-radius:8px;background:rgba(245,158,11,.12);color:#ffd58a;cursor:pointer;transition:.16s}
.attachment-guidance-close:hover{background:rgba(245,158,11,.3);color:#fff}
.attachment-guidance-close .ic{width:12px;height:12px}

/* ==================== V1.0.3: Drawer منو (فقط موبایل/تبلت) ==================== */
.menu-drawer-scrim{position:fixed;inset:0;z-index:74;background:rgba(3,6,12,.58);backdrop-filter:blur(3px);opacity:0;pointer-events:none;transition:opacity .24s ease}
.menu-drawer-scrim.show{opacity:1;pointer-events:auto}
.menu-drawer{position:fixed;inset:0 0 0 auto;z-index:76;width:min(430px,94vw);height:100svh;display:flex;flex-direction:column;gap:0;background:linear-gradient(180deg,#0d1424 0%,#0a101d 100%);border-left:1px solid var(--line-strong);box-shadow:-24px 0 60px -30px rgba(0,0,0,1);transform:translateX(102%);visibility:hidden;transition:transform .28s cubic-bezier(.4,0,.2,1),visibility .28s;overflow:hidden}
.menu-drawer.open{transform:none;visibility:visible}
.menu-drawer-head{display:flex;align-items:center;justify-content:space-between;gap:10px;flex:0 0 auto;padding:13px 14px;border-bottom:1px solid var(--line)}
.menu-drawer-head>div{min-width:0;display:flex;flex-direction:column}
.menu-drawer-head b{display:flex;align-items:center;gap:7px;font-size:calc(14px * var(--font-scale,1))}
.menu-drawer-head small{color:var(--tx-3);font-size:calc(10px * var(--font-scale,1))}
.menu-drawer-list{flex:1;min-height:0;overflow-y:auto;overflow-x:hidden;display:flex;flex-direction:column;gap:12px;padding:10px 10px 18px;overscroll-behavior:contain}
body.menu-nav-open{overflow:hidden}
@media(max-width:720px){.menu-drawer{width:min(400px,96vw)}.menu-drawer-head{padding:10px}.menu-drawer-list{padding-inline:8px}}

/* ==================== V1.0.3: نوار پایینی چسبان موبایل/تبلت ==================== */
.mobile-tabbar{position:fixed;left:0;right:0;bottom:0;z-index:88;display:none;align-items:stretch;justify-content:space-around;gap:2px;min-height:64px;padding:6px 6px calc(6px + env(safe-area-inset-bottom));background:rgba(10,16,29,.97);border-top:1px solid var(--line-strong);backdrop-filter:blur(14px);box-shadow:0 -12px 30px -18px rgba(0,0,0,.9)}
.mobile-tabbar .tab-item{flex:1 1 0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;min-width:0;min-height:48px;padding:5px 2px;border:1px solid transparent;border-radius:12px;background:transparent;color:var(--tx-3);font-family:inherit;font-size:calc(9.5px * var(--font-scale,1));font-weight:500;line-height:1.5;text-align:center;cursor:pointer;transition:.18s}
.mobile-tabbar .tab-item .ic{width:20px;height:20px}
.mobile-tabbar .tab-item:hover{color:var(--tx)}
.mobile-tabbar .tab-item:active{transform:scale(.96)}
body:not(.nb-open):not(.phase-nav-open):not(.menu-nav-open) .mobile-tabbar .tab-item[data-tab="home"],
body.nb-open .mobile-tabbar .tab-item[data-tab="notebook"],
body.phase-nav-open .mobile-tabbar .tab-item[data-tab="phases"],
body.menu-nav-open .mobile-tabbar .tab-item[data-tab="menu"]{color:#7ff0e2;background:rgba(45,212,191,.12);border-color:rgba(45,212,191,.28)}
@media (max-width:1180px){
  .mobile-tabbar{display:flex}
  .phase-fab,.totop{display:none!important}
  .sidebar-layout-btn.sidebar-layout-btn.sidebar-layout-btn.sidebar-layout-btn,
  .sidebar-size-reset.sidebar-size-reset.sidebar-size-reset.sidebar-size-reset,
  .sidebar-resizer.sidebar-resizer.sidebar-resizer.sidebar-resizer{display:none!important}
  body{padding-bottom:calc(64px + env(safe-area-inset-bottom))}
  .nb{bottom:calc(64px + env(safe-area-inset-bottom));height:calc(100dvh - 64px - env(safe-area-inset-bottom));max-height:calc(100dvh - 64px - env(safe-area-inset-bottom))}
  .menu-drawer-list{padding-bottom:calc(70px + env(safe-area-inset-bottom))}
  .phase-drawer-list .navlist{padding-bottom:calc(68px + env(safe-area-inset-bottom))}
}
@media print{.mobile-tabbar,.menu-drawer,.menu-drawer-scrim{display:none!important}}
"""
rep('css-additions', '\n</style>', NEW_CSS + '\n</style>')

open(DST, 'w', encoding='utf-8').write(out)
print(f'\nDONE: {n_ops} operations applied.')
print(f'{SRC} ({len(src)} bytes) -> {DST} ({len(out)} bytes)')
