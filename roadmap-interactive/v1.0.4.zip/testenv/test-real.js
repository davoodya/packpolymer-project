const { chromium } = require('playwright');
const path = require('path');

(async () => {
  const file = process.argv[2] || '/home/user/uploads/packpolymer-marketplace-roadmap-v1.0.2.html';
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('CONSOLE: ' + m.text()); });

  await page.goto('file://' + file);
  await page.waitForTimeout(800);

  // Expand all phases in the sidebar tree, then expand steps of phase 5 (f4) one by one (re-render invalidates handles)
  const togglePhase = async (i) => {
    const btns = await page.$$('[data-act="side-phase-toggle"]');
    if (btns[i]) { await btns[i].click(); await page.waitForTimeout(60); }
  };
  // open all phases
  for (let i = 0; i < 13; i++) await togglePhase(i);

  // Now open the steps of the phase in the tree — find side-step-toggle buttons that appeared
  const stepToggleCount = await page.$$eval('[data-act="side-step-toggle"]', els => els.length);
  console.log('step toggles available:', stepToggleCount);

  // Open step toggles one at a time (DOM re-renders on each click)
  let opened = 0;
  for (let i = 0; i < stepToggleCount; i++) {
    const btns = await page.$$('[data-act="side-step-toggle"]');
    if (btns[i]) { await btns[i].click(); opened++; await page.waitForTimeout(40); }
  }
  console.log('step toggles clicked:', opened);

  const subs = await page.$$eval('.navsub', els => els.map(e => ({ id: e.dataset.id, ph: e.dataset.ph, title: (e.textContent || '').trim().slice(0, 40) })));
  console.log('navsubs in tree:', subs.length);

  // Pick a sub DEEP in the page: the very last one (like user example 5.3.3)
  const target = subs[Math.min(30, subs.length - 1)];
  console.log('TARGET sub:', JSON.stringify(target));

  const before = await page.evaluate(() => window.scrollY);
  console.log('scrollY before click:', before);

  // Click the navsub
  await page.click(`.navsub[data-id="${target.id}"]`);
  await page.waitForTimeout(600);

  const result = await page.evaluate((sid) => {
    const el = document.getElementById(sid);
    const r = el ? el.getBoundingClientRect() : null;
    return {
      scrollY: window.scrollY,
      exists: !!el,
      top: r ? r.top : null,
      inView: r ? (r.top >= 0 && r.top < window.innerHeight) : false,
      hit: el ? el.classList.contains('hit') : false,
      toast: (document.getElementById('toast') || {}).textContent || ''
    };
  }, target.id);
  console.log('AFTER sub click:', JSON.stringify(result, null, 1));

  // Comparison: click a STEP and a PHASE
  const stepId = await page.$eval('.navstep[data-act="goto-step"]', e => e.dataset.id);
  await page.click(`.navstep[data-id="${stepId}"]`);
  await page.waitForTimeout(500);
  const stepRes = await page.evaluate((sid) => {
    const el = document.getElementById(sid);
    const r = el.getBoundingClientRect();
    return { scrollY: window.scrollY, top: r.top, inView: r.top >= 0 && r.top < window.innerHeight };
  }, stepId);
  console.log('AFTER step click:', JSON.stringify(stepRes));

  const phId = await page.$eval('.navitem[data-act="goto"]', e => e.dataset.id);
  await page.click(`.navitem[data-id="${phId}"]`);
  await page.waitForTimeout(500);
  const phRes = await page.evaluate((pid) => {
    const el = document.getElementById(pid);
    const r = el.getBoundingClientRect();
    return { scrollY: window.scrollY, top: r.top, inView: r.top >= 0 && r.top < window.innerHeight };
  }, phId);
  console.log('AFTER phase click:', JSON.stringify(phRes));

  // Test drawer path too
  await page.click('#phaseFab');
  await page.waitForTimeout(400);
  // expand a step in the drawer and click its sub
  await page.click('#phaseNavDrawer [data-act="side-step-toggle"]');
  await page.waitForTimeout(200);
  const drawerSub = await page.$('#phaseNavDrawer .navsub');
  if (drawerSub) {
    const dsid = await drawerSub.evaluate(e => e.dataset.id);
    await drawerSub.click();
    await page.waitForTimeout(500);
    const dsRes = await page.evaluate((sid) => {
      const el = document.getElementById(sid);
      const r = el ? el.getBoundingClientRect() : null;
      return { scrollY: window.scrollY, top: r ? r.top : null, inView: r ? (r.top >= 0 && r.top < window.innerHeight) : false, drawerOpen: document.body.classList.contains('phase-nav-open') };
    }, dsid);
    console.log('AFTER drawer sub click:', JSON.stringify(dsRes));
  } else {
    console.log('drawer sub not found');
  }

  console.log('ERRORS:', errors.slice(0, 5));
  await browser.close();
})().catch(e => { console.error('FATAL', e); process.exit(1); });
