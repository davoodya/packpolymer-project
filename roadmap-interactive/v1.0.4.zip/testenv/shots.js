const { chromium } = require('playwright');
const URL = 'file:///home/user/uploads/packpolymer-marketplace-roadmap-v1.0.3.html';

(async () => {
  const browser = await chromium.launch();

  // --- mobile shots ---
  {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 } });
    await ctx.addInitScript(() => { try { localStorage.clear(); } catch (e) {} });
    const page = await ctx.newPage();
    await page.goto(URL);
    await page.waitForTimeout(700);

    // menu drawer
    await page.click('#mobileTabbar [data-tab="menu"]');
    await page.waitForTimeout(500);
    await page.screenshot({ path: 'shot-menu-drawer.png' });
    // expand first collapsed card (marks or store)
    await page.evaluate(() => { const b = document.querySelector('#menuNavDrawer [data-act="side-toggle"]'); if (b) b.click(); });
    await page.waitForTimeout(400);
    await page.screenshot({ path: 'shot-menu-drawer-expanded.png' });
    await page.click('#menuNavDrawer [data-act="menu-drawer-close"]');
    await page.waitForTimeout(300);

    // notebook list
    await page.click('#mobileTabbar [data-tab="notebook"]');
    await page.waitForTimeout(500);
    await page.screenshot({ path: 'shot-nb-list.png' });
    // create a note to see note view
    await page.evaluate(() => { const b = document.querySelector('#nbPanel [data-nb="new"]'); if (b) b.click(); });
    await page.waitForTimeout(500);
    await page.screenshot({ path: 'shot-nb-note.png' });

    // note field on a phase/step/sub (the M placeholder issue)
    await page.click('#mobileTabbar [data-tab="home"]');
    await page.waitForTimeout(400);
    await page.evaluate(() => {
      const btn = document.querySelector('#phases .step .acts .iact[data-act="note-toggle"]');
      if (btn) btn.click();
    });
    await page.waitForTimeout(400);
    await page.screenshot({ path: 'shot-note-field.png' });
    const ph = await page.evaluate(() => {
      const ta = document.querySelector('#phases textarea.note');
      if (!ta) return null;
      const r = ta.getBoundingClientRect();
      const cs = getComputedStyle(ta);
      return { placeholder: ta.placeholder, rect: { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) }, pad: cs.padding, indent: cs.textIndent, font: cs.fontSize, taCls: ta.className };
    });
    console.log('note textarea:', JSON.stringify(ph));
    await ctx.close();
  }

  // --- tablet shot of menu drawer ---
  {
    const ctx = await browser.newContext({ viewport: { width: 820, height: 1180 } });
    await ctx.addInitScript(() => { try { localStorage.clear(); } catch (e) {} });
    const page = await ctx.newPage();
    await page.goto(URL);
    await page.waitForTimeout(700);
    await page.click('#mobileTabbar [data-tab="menu"]');
    await page.waitForTimeout(500);
    await page.screenshot({ path: 'shot-menu-tablet.png' });
    await ctx.close();
  }

  // --- desktop: normal header + compact header ---
  {
    const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
    await ctx.addInitScript(() => { try { localStorage.clear(); } catch (e) {} });
    const page = await ctx.newPage();
    await page.goto(URL);
    await page.waitForTimeout(700);
    await page.screenshot({ path: 'shot-desk-header.png', clip: { x: 0, y: 0, width: 1440, height: 320 } });
    await page.evaluate(() => window.scrollTo(0, 800));
    await page.waitForTimeout(500);
    await page.screenshot({ path: 'shot-desk-compact.png', clip: { x: 0, y: 0, width: 1440, height: 120 } });
    const btnInfo = await page.evaluate(() => {
      const g = sel => { const el = document.querySelector(sel); if (!el) return null; const r = el.getBoundingClientRect(); return { w: Math.round(r.width), h: Math.round(r.height), visible: r.width > 0 }; };
      return {
        layoutBtn: g('.topbar.compact .sidebar-layout-btn'),
        resetBtn: g('.topbar.compact .sidebar-size-reset'),
        layoutFull: g('.topbar:not(.compact) .sidebar-layout-btn'),
        resetFull: g('.topbar:not(.compact) .sidebar-size-reset')
      };
    });
    console.log('desktop buttons:', JSON.stringify(btnInfo));
    await ctx.close();
  }

  await browser.close();
  console.log('screenshots done');
})().catch(e => { console.error('FATAL', e); process.exit(1); });
