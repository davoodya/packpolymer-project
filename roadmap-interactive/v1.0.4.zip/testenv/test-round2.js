const { chromium } = require('playwright');
const URL = 'file:///home/user/uploads/packpolymer-marketplace-roadmap-v1.0.3.html';
let pass = 0, fail = 0;
function check(name, ok, info) {
  if (ok) { pass++; console.log('  ✅', name, info ? '— ' + JSON.stringify(info) : ''); }
  else { fail++; console.log('  ❌', name, info ? '— ' + JSON.stringify(info) : ''); }
}
async function newPage(browser, w, h, tag) {
  const context = await browser.newContext({ viewport: { width: w, height: h } });
  await context.addInitScript(() => { try { localStorage.clear(); } catch (e) {} });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto(URL);
  await page.waitForTimeout(800);
  return { context, page, errors };
}

(async () => {
  const browser = await chromium.launch();

  console.log('══ 1.2 menu drawer (mobile) ══');
  {
    const { context, page, errors } = await newPage(browser, 390, 844);
    await page.click('#mobileTabbar [data-tab="menu"]');
    await page.waitForTimeout(500);
    const r = await page.evaluate(() => {
      const cards = Array.from(document.querySelectorAll('#menuNavDrawer .side-card'));
      let clipped = 0, tiny = 0;
      cards.forEach(c => {
        const body = c.querySelector('.card-b');
        if (body && body.getBoundingClientRect().height > c.getBoundingClientRect().height + 2) clipped++;
      });
      const btns = Array.from(document.querySelectorAll('#menuNavDrawer .btn, #menuNavDrawer .schip'));
      btns.forEach(b => { if (b.getBoundingClientRect().height < 34) tiny++; });
      const hint = document.querySelector('#menuNavDrawer .hint');
      return { cards: cards.length, clipped, tiny, hintWrap: hint ? getComputedStyle(hint).whiteSpace : null };
    });
    check('no clipped cards + tap targets ≥34px + hints wrap', r.clipped === 0 && r.tiny === 0 && r.hintWrap === 'normal', r);
    // expand a collapsed card and see inner items selectable
    const inner = await page.evaluate(() => {
      const card = document.querySelector('#menuNavDrawer .side-card-data');
      const head = card.querySelector('.card-h');
      if (card.classList.contains('closed')) head.click();
      return new Promise(res => setTimeout(() => {
        const c2 = document.querySelector('#menuNavDrawer .side-card-data');
        const body = c2.querySelector('.card-b');
        const btn = body ? body.querySelector('.btn') : null;
        const br = btn ? btn.getBoundingClientRect() : null;
        res({ open: !c2.classList.contains('closed'), btnVisible: !!(br && br.height > 20 && br.width > 40) });
      }, 250));
    });
    check('collapsed card expands; inner buttons visible/selectable', inner.open && inner.btnVisible, inner);
    check('menu drawer: no page errors', errors.length === 0, errors.slice(0, 2));
    await context.close();
  }

  console.log('══ 3.1 notebook (mobile) ══');
  {
    const { context, page, errors } = await newPage(browser, 390, 844);
    await page.click('#mobileTabbar [data-tab="notebook"]');
    await page.waitForTimeout(500);
    // create 3 notes (each create jumps into note view — go back to list each time)
    for (let i = 0; i < 3; i++) {
      await page.click('#nbPanel .nb-new-note');
      await page.waitForTimeout(350);
      await page.click('#nbPanel [data-nb="back-list"]');
      await page.waitForTimeout(300);
    }
    const list = await page.evaluate(() => {
      const cards = Array.from(document.querySelectorAll('#nbList .nb-card'));
      const vh = window.innerHeight;
      const visible = cards.filter(c => { const r = c.getBoundingClientRect(); return r.top < vh && r.bottom > 0; }).length;
      const newBtn = document.querySelector('#nbPanel .nb-new-note').getBoundingClientRect();
      return { total: cards.length, visible, newBtnW: Math.round(newBtn.width), newBtnH: Math.round(newBtn.height) };
    });
    check('list shows ≥2 notes in first viewport', list.visible >= 2, list);
    check('new-note button compact (<160px wide)', list.newBtnW < 160, list);
    // facets drawer
    const facets = await page.evaluate(() => {
      const ex = document.querySelector('#nbPanel [data-nb-explorer]');
      const btn = document.querySelector('#nbPanel [data-nb="facets-toggle"]');
      if (!ex || !btn) return { exists: false };
      btn.click();
      return new Promise(res => setTimeout(() => {
        const side = ex.querySelector('.nb-explorer-side');
        const r = side.getBoundingClientRect();
        const open1 = ex.classList.contains('facets-open') && r.x >= -5 && r.width > 200 && r.width < window.innerWidth;
        // close via facet select OR scrim click
        const facet = side.querySelector('[data-nb="browse-value"]');
        const closePath = facet ? 'facet' : 'scrim';
        if (facet) facet.click(); else ex.click();
        setTimeout(() => res({ exists: true, open1, closePath, closedAfter: !ex.classList.contains('facets-open') }), 350);
      }, 350));
    });
    check('facets drawer opens as overlay & closes on select/scrim', facets.exists && facets.open1 && facets.closedAfter, facets);
    // note view: split hidden, tools one row
    await page.evaluate(() => { const c = document.querySelector('#nbList .nb-card[data-nb="open"]'); if (c) c.click(); });
    await page.waitForTimeout(500);
    const note = await page.evaluate(() => {
      const split = document.querySelector('#nbPanel .nb-split-toggle');
      const tools = document.querySelector('#nbPanel .nb-pane-primary .nb-tools');
      const rows = new Set(Array.from(tools.querySelectorAll('.iact')).map(b => Math.round(b.getBoundingClientRect().top / 4)));
      return {
        splitHidden: !split || getComputedStyle(split).display === 'none',
        toolRows: rows.size,
        toolsH: Math.round(tools.getBoundingClientRect().height),
        editorH: Math.round(document.querySelector('#nbPanel #nbEdit').getBoundingClientRect().height)
      };
    });
    check('Split hidden on mobile + tools in ONE scroll row', note.splitHidden && note.toolRows === 1 && note.toolsH < 70, note);
    check('editor gets the space (h>300)', note.editorH > 300, note);
    check('notebook: no page errors', errors.length === 0, errors.slice(0, 2));
    await context.close();
  }

  console.log('══ 3.2 placeholder + 3.3 tabbar (mobile) ══');
  {
    const { context, page } = await newPage(browser, 390, 844);
    const r = await page.evaluate(() => {
      document.querySelector('#phases .phase .phase-note-toggle').click();
      return new Promise(res => setTimeout(() => {
        const ta = document.querySelector('#phases textarea.note');
        const ph = getComputedStyle(ta, '::placeholder');
        const bar = document.querySelector('#mobileTabbar').getBoundingClientRect();
        res({ phColor: ph.color, phOpacity: ph.opacity, barH: Math.round(bar.height) });
      }, 300));
    });
    check('note placeholder visually removed (transparent)', r.phOpacity === '0' || /rgba\(0, 0, 0, 0\)|transparent/.test(r.phColor), r);
    check('tabbar height reduced to standard (≤58px)', r.barH <= 58, r);
    await context.close();
  }

  console.log('══ 1.1 lazy DOM + edit chrome (desktop) ══');
  {
    const { context, page } = await newPage(browser, 1440, 900);
    const boot = await page.evaluate(() => ({
      nodes: document.querySelectorAll('*').length,
      fullNotePanels: Array.from(document.querySelectorAll('#phases .note-wrap')).filter(n => !n.dataset.noteLazy).length,
      lazyStubs: document.querySelectorAll('#phases .note-wrap[data-note-lazy]').length,
      editChrome: document.querySelectorAll('#phases .acts-edit, #phases .editbar').length
    }));
    check('boot: edit chrome not in DOM; notes lazy', boot.editChrome === 0 && boot.fullNotePanels === 0 && boot.lazyStubs > 0, boot);
    // open a note -> hydrates
    const hyd = await page.evaluate(() => {
      document.querySelector('#phases .step .acts .iact[data-act="note-toggle"]').click();
      return new Promise(res => setTimeout(() => {
        const openPanels = Array.from(document.querySelectorAll('#phases .note-wrap')).filter(n => !n.dataset.noteLazy && n.classList.contains('show'));
        res({ hydrated: openPanels.length, hasTextarea: !!document.querySelector('#phases textarea.note') });
      }, 300));
    });
    check('note toggle hydrates panel on demand', hyd.hydrated === 1 && hyd.hasTextarea, hyd);
    // edit mode -> chrome appears
    const edit = await page.evaluate(() => {
      document.querySelector('.header-actions-right [data-act="edit-mode"]').click();
      return new Promise(res => setTimeout(() => {
        res({ chrome: document.querySelectorAll('#phases .acts-edit, #phases .editbar').length });
      }, 400));
    });
    check('edit mode renders full edit chrome', edit.chrome > 20, edit);
    await context.close();
  }

  console.log('══ nav under content-visibility:auto (desktop + polluted) ══');
  {
    const { context, page } = await newPage(browser, 1440, 900);
    await page.evaluate(() => { for (let i = 0; i < 6; i++) { try { document.querySelector('[data-act="expand-all"]').click(); break; } catch (e) {} } });
    await page.waitForTimeout(600);
    await page.evaluate(() => window.scrollTo(0, 2000));
    await page.waitForTimeout(400);
    const r = await page.evaluate(() => {
      return new Promise(res => {
        const btns = document.querySelectorAll('.navitem[data-nav-role="phase"][data-id]');
        const btn = btns[5];
        btn.click();
        setTimeout(() => {
          const id = btn.getAttribute('data-id');
          const el = document.getElementById(id);
          const top = el ? el.getBoundingClientRect().top : -1;
          res({ id, top: Math.round(top), ok: top > 60 && top < 260 });
        }, 1300);
      });
    });
    check('sub nav lands target in view (cv:auto + nav-stable)', r.ok, r);
    const ns = await page.evaluate(() => document.documentElement.classList.contains('nav-stable'));
    check('nav-stable releases after navigation', ns === false, { ns });
    await context.close();
  }

  await browser.close();
  console.log('\n══════════════════════════════════');
  console.log('TOTAL:', pass + fail, '— PASS:', pass, '— FAIL:', fail);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('FATAL', e); process.exit(1); });
