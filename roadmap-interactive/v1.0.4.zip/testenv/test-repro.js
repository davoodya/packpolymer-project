const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  await context.addInitScript(() => { try { localStorage.clear(); } catch (e) {} });
  const page = await context.newPage();
  page.on('console', m => { const t = m.text(); if (t.includes('doScroll') || t.includes('watch')) console.log('LOG:', t); });
  page.on('pageerror', e => console.log('PAGEERROR:', e.message));

  await page.goto('file:///home/user/testenv/instrumented-nocv.html');
  await page.waitForTimeout(1000);

  // Exactly reproduce test-real.js pollution: Playwright clicks (auto-scroll!) on all tree toggles
  for (let i = 0; i < 13; i++) {
    const btns = await page.$$('[data-act="side-phase-toggle"]');
    if (btns[i]) { await btns[i].click(); await page.waitForTimeout(40); }
  }
  const stepToggleCount = await page.$$eval('[data-act="side-step-toggle"]', els => els.length);
  for (let i = 0; i < stepToggleCount; i++) {
    const btns = await page.$$('[data-act="side-step-toggle"]');
    if (btns[i]) { await btns[i].click(); await page.waitForTimeout(25); }
  }

  const subs = await page.$$eval('.navsub', els => els.map(e => e.dataset.id));
  const target = subs[30];
  console.log('>>> CLICKING SUB:', target, '| total tree subs:', subs.length);
  await page.click(`.navsub[data-id="${target}"]`);
  await page.waitForTimeout(800);
  const res = await page.evaluate((sid) => {
    const el = document.getElementById(sid);
    const r = el.getBoundingClientRect();
    return { scrollY: window.scrollY, top: Math.round(r.top), inView: r.top >= -20 && r.top < innerHeight };
  }, target);
  console.log('RESULT:', JSON.stringify(res), res.inView ? 'PASS' : 'FAIL');
  await browser.close();
})().catch(e => { console.error('FATAL', e); process.exit(1); });
