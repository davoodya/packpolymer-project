const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  page.on('console', m => console.log('LOG:', m.text()));
  page.on('pageerror', e => console.log('PAGEERROR:', e.message));

  await page.goto('file:///home/user/testenv/instrumented.html');
  await page.waitForTimeout(800);

  // expand all phases + steps in the tree (same as before)
  for (let i = 0; i < 13; i++) {
    const btns = await page.$$('[data-act="side-phase-toggle"]');
    if (btns[i]) { await btns[i].click(); await page.waitForTimeout(40); }
  }
  const stepToggleCount = await page.$$eval('[data-act="side-step-toggle"]', els => els.length);
  for (let i = 0; i < stepToggleCount; i++) {
    const btns = await page.$$('[data-act="side-step-toggle"]');
    if (btns[i]) { await btns[i].click(); await page.waitForTimeout(25); }
  }

  const subs = await page.$$eval('.navsub', els => els.map(e => e.dataset.id));
  const target = subs[30];
  console.log('>>> CLICKING SUB:', target);
  await page.evaluate(() => window.scrollTo(0, 10000)); // deep scroll like test
  await page.waitForTimeout(300);
  await page.click(`.navsub[data-id="${target}"]`);
  await page.waitForTimeout(800);

  const res = await page.evaluate((sid) => {
    const el = document.getElementById(sid);
    const r = el.getBoundingClientRect();
    return { scrollY: window.scrollY, top: r.top, inView: r.top >= 0 && r.top < innerHeight };
  }, target);
  console.log('RESULT:', JSON.stringify(res));
  await browser.close();
})().catch(e => { console.error('FATAL', e); process.exit(1); });
