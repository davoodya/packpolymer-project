const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  await context.addInitScript(() => { try { localStorage.clear(); } catch (e) {} });
  const page = await context.newPage();
  page.on('pageerror', e => console.log('PAGEERROR:', e.message));
  await page.goto('file:///home/user/testenv/instrumented.html');
  await page.waitForTimeout(1000);

  // Pollute EXACTLY like test-real.js: Playwright clicks (auto-scroll) on ALL tree toggles
  for (let i = 0; i < 13; i++) {
    const btns = await page.$$('[data-act="side-phase-toggle"]');
    if (btns[i]) { await btns[i].click(); await page.waitForTimeout(35); }
  }
  const n = await page.$$eval('[data-act="side-step-toggle"]', els => els.length);
  for (let i = 0; i < n; i++) {
    const btns = await page.$$('[data-act="side-step-toggle"]');
    if (btns[i]) { await btns[i].click(); await page.waitForTimeout(20); }
  }

  const targets = await page.evaluate(() => {
    const steps = Array.from(document.querySelectorAll('.navstep')).map(e => e.dataset.id);
    const subs = Array.from(document.querySelectorAll('.navsub')).map(e => e.dataset.id);
    return { steps, subs, y: window.scrollY };
  });
  // deep step in f4 and a deep sub within the same step
  const deepStep = targets.steps[targets.steps.length - 40];
  const deepSub = targets.subs.filter(id => id.startsWith(deepStep + '-'))[3] || targets.subs[targets.subs.length - 20];
  console.log('scrollY after pollution:', targets.y, '| deepStep:', deepStep, '| deepSub:', deepSub);

  async function testClick(selector, id, label) {
    const before = await page.evaluate(() => ({ y: window.scrollY, docH: document.documentElement.scrollHeight }));
    await page.evaluate((s) => { const el = document.querySelector(s); if (el) el.click(); }, selector);
    await page.waitForTimeout(800);
    const after = await page.evaluate((id) => {
      const el = document.getElementById(id);
      if (!el) return { exists: false };
      const r = el.getBoundingClientRect();
      return { y: window.scrollY, docH: document.documentElement.scrollHeight, top: Math.round(r.top), inView: r.top >= -20 && r.top < innerHeight };
    }, id);
    console.log(`[${label}] before=${JSON.stringify(before)} after=${JSON.stringify(after)} => ${after.inView ? 'PASS' : 'FAIL'}`);
    return after.inView;
  }

  // NOTE: do not reset scroll — user is deep in the page when clicking (the real scenario)
  await testClick(`.navstep[data-id="${deepStep}"]`, deepStep, 'DEEP STEP');
  await testClick(`.navsub[data-id="${deepSub}"]`, deepSub, 'DEEP SUB');
  await testClick(`.navsub[data-id="${targets.subs[30]}"]`, targets.subs[30], 'MID SUB');

  await browser.close();
})().catch(e => { console.error('FATAL', e); process.exit(1); });
