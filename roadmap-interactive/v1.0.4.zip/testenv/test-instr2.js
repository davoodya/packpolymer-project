const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  page.on('console', m => console.log('LOG:', m.text()));
  page.on('pageerror', e => console.log('PAGEERROR:', e.message));

  await page.goto('file:///home/user/testenv/instrumented.html');
  await page.waitForTimeout(1200);

  // expand phases + steps in tree
  for (let i = 0; i < 13; i++) {
    const btns = await page.$$('[data-act="side-phase-toggle"]');
    if (btns[i]) { await btns[i].click(); await page.waitForTimeout(40); }
  }
  const n = await page.$$eval('[data-act="side-step-toggle"]', els => els.length);
  for (let i = 0; i < n; i++) {
    const btns = await page.$$('[data-act="side-step-toggle"]');
    if (btns[i]) { await btns[i].click(); await page.waitForTimeout(25); }
  }

  const subs = await page.$$eval('.navsub', els => els.map(e => e.dataset.id));
  const target = subs[30];
  console.log('>>> CLICKING SUB:', target);

  // watch docH continuously
  await page.evaluate(() => {
    window.__watch = setInterval(() => {
      console.log('[watch] docH=', document.documentElement.scrollHeight, 'scrollY=', window.scrollY);
    }, 100);
  });
  await page.click(`.navsub[data-id="${target}"]`);
  await page.waitForTimeout(700);
  await page.evaluate(() => clearInterval(window.__watch));
  await browser.close();
})().catch(e => { console.error('FATAL', e); process.exit(1); });
