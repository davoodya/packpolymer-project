const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  await context.addInitScript(() => { try { localStorage.clear(); } catch (e) {} });
  const page = await context.newPage();
  page.on('console', m => { const t = m.text(); if (t.includes('doScroll')) console.log('LOG:', t); });
  page.on('pageerror', e => console.log('PAGEERROR:', e.message));
  await page.goto('file:///home/user/testenv/instrumented-nocv.html');
  await page.waitForTimeout(1000);

  // REAL user flow: expand phase f4 in the tree, expand ONE step, click ONE sub. No scrolling games.
  await page.click('.tree-ph[data-phase-nav="f4"] [data-act="side-phase-toggle"]');
  await page.waitForTimeout(150);
  await page.click('.tree-ph[data-phase-nav="f4"] [data-act="side-step-toggle"]'); // first step of f4
  await page.waitForTimeout(150);

  const subId = await page.$eval('.tree-ph[data-phase-nav="f4"] .navsub', e => e.dataset.id);
  console.log('>>> user clicks sub:', subId);

  const before = await page.evaluate(() => ({ y: window.scrollY, docH: document.documentElement.scrollHeight }));
  await page.click(`.tree-ph[data-phase-nav="f4"] .navsub`);
  await page.waitForTimeout(900);
  const after = await page.evaluate((sid) => {
    const el = document.getElementById(sid);
    const r = el.getBoundingClientRect();
    return { y: window.scrollY, docH: document.documentElement.scrollHeight, top: Math.round(r.top), inView: r.top >= -20 && r.top < innerHeight };
  }, subId);
  console.log('before:', JSON.stringify(before), 'after:', JSON.stringify(after), after.inView ? 'PASS' : 'FAIL');

  // also try a mid/late sub of the same step (user example: 5.3.3)
  await page.waitForTimeout(400);
  const sub2 = await page.evaluate(() => {
    const subs = Array.from(document.querySelectorAll('.tree-ph[data-phase-nav="f4"] .navsub'));
    return subs[Math.min(10, subs.length - 1)].dataset.id;
  });
  console.log('>>> user clicks sub:', sub2);
  await page.click(`.navsub[data-id="${sub2}"]`);
  await page.waitForTimeout(900);
  const after2 = await page.evaluate((sid) => {
    const el = document.getElementById(sid);
    const r = el.getBoundingClientRect();
    return { y: window.scrollY, docH: document.documentElement.scrollHeight, top: Math.round(r.top), inView: r.top >= -20 && r.top < innerHeight };
  }, sub2);
  console.log('after2:', JSON.stringify(after2), after2.inView ? 'PASS' : 'FAIL');

  await browser.close();
})().catch(e => { console.error('FATAL', e); process.exit(1); });
