const { chromium } = require('playwright');

const FILE = process.argv[2] || 'file:///home/user/uploads/packpolymer-marketplace-roadmap-v1.0.3.html';

async function metrics(page, cdp) {
  const m = await cdp.send('Performance.getMetrics');
  const g = n => (m.metrics.find(x => x.name === n) || {}).value || 0;
  return {
    script: +g('ScriptDuration').toFixed(3),
    style: +g('RecalcStyleDuration').toFixed(3),
    layout: +g('LayoutDuration').toFixed(3),
    task: +g('TaskDuration').toFixed(3),
    nodes: g('Nodes'),
  };
}

(async () => {
  const browser = await chromium.launch();
  for (const [w, h, label] of [[1440, 900, 'desktop'], [390, 844, 'mobile']]) {
    const context = await browser.newContext({ viewport: { width: w, height: h } });
    await context.addInitScript(() => { try { localStorage.clear(); } catch (e) {} });
    const page = await context.newPage();
    const cdp = await context.newCDPSession(page);
    await cdp.send('Performance.enable');

    const t0 = Date.now();
    await page.goto(FILE);
    await page.waitForTimeout(50);
    // time until app rendered
    await page.waitForFunction(() => document.querySelectorAll('.phase').length > 0, { timeout: 15000 }).catch(() => {});
    const firstRender = Date.now() - t0;
    await page.waitForTimeout(2500);
    const boot = await metrics(page, cdp);

    // long tasks during boot
    const longs = await page.evaluate(() => performance.getEntriesByType('longtask').map(e => Math.round(e.duration)));
    const nav = await page.evaluate(() => {
      const n = performance.getEntriesByType('navigation')[0] || {};
      return { dcl: Math.round(n.domContentLoadedEventEnd || 0), load: Math.round(n.loadEventEnd || 0) };
    });

    // scroll FPS test: rAF frame times while smooth-scrolling down for 2s
    const fps = await page.evaluate(() => new Promise(resolve => {
      const times = [];
      let last = performance.now(), running = true;
      const tick = t => { times.push(t - last); last = t; if (running) requestAnimationFrame(tick); };
      requestAnimationFrame(tick);
      window.scrollTo({ top: 4000, behavior: 'smooth' });
      setTimeout(() => {
        window.scrollTo({ top: document.documentElement.scrollHeight, behavior: 'smooth' });
        setTimeout(() => {
          running = false;
          times.sort((a, b) => a - b);
          const avg = times.reduce((a, b) => a + b, 0) / (times.length || 1);
          resolve({ frames: times.length, avg: +avg.toFixed(1), p95: +times[Math.floor(times.length * 0.95)].toFixed(1), worst: +times[times.length - 1].toFixed(1) });
        }, 1000);
      }, 1000);
    }));

    // interaction latency: 8 checkbox toggles (measure each click handler + paint)
    const clicks = [];
    for (let i = 0; i < 8; i++) {
      const dt = await page.evaluate((i) => new Promise(resolve => {
        const cb = document.querySelectorAll('.ck input')[i];
        if (!cb) return resolve(-1);
        const t = performance.now();
        cb.click();
        requestAnimationFrame(() => requestAnimationFrame(() => resolve(performance.now() - t)));
      }), i);
      clicks.push(+dt.toFixed(1));
    }

    // expand ALL phases + steps then measure style/layout
    await page.evaluate(() => {
      for (let i = 0; i < 13; i++) { const b = document.querySelectorAll('[data-act="side-phase-toggle"]')[i]; if (b) b.click(); }
    });
    await page.waitForTimeout(400);
    await page.evaluate(() => {
      const btns = document.querySelectorAll('[data-act="side-step-toggle"]');
      for (let i = 0; i < btns.length; i++) { const b = document.querySelectorAll('[data-act="side-step-toggle"]')[i]; if (b) b.click(); }
    });
    await page.waitForTimeout(1200);
    const expanded = await metrics(page, cdp);
    const fps2 = await page.evaluate(() => new Promise(resolve => {
      const times = [];
      let last = performance.now(), running = true;
      const tick = t => { times.push(t - last); last = t; if (running) requestAnimationFrame(tick); };
      requestAnimationFrame(tick);
      window.scrollTo({ top: 8000, behavior: 'smooth' });
      setTimeout(() => {
        window.scrollTo({ top: document.documentElement.scrollHeight, behavior: 'smooth' });
        setTimeout(() => {
          running = false;
          times.sort((a, b) => a - b);
          const avg = times.reduce((a, b) => a + b, 0) / (times.length || 1);
          resolve({ frames: times.length, avg: +avg.toFixed(1), p95: +times[Math.floor(times.length * 0.95)].toFixed(1), worst: +times[times.length - 1].toFixed(1) });
        }, 1000);
      }, 1000);
    }));

    console.log(JSON.stringify({ label, file: FILE.split('/').pop(), firstRender, nav, boot, longTasks: longs, scrollFPS: fps, clicks, expanded, scrollFPSexpanded: fps2 }, null, 1));
    await context.close();
  }
  await browser.close();
})().catch(e => { console.error('FATAL', e); process.exit(1); });
