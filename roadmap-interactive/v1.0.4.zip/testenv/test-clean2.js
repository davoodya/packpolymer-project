const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  // clear storage BEFORE any app script runs
  await context.addInitScript(() => {
    try { localStorage.clear(); sessionStorage.clear(); } catch (e) {}
    try { indexedDB.deleteDatabase('packpolymer-roadmap'); } catch (e) {}
  });
  const page = await context.newPage();
  page.on('pageerror', e => console.log('PAGEERROR:', e.message));

  await page.goto('file:///home/user/testenv/instrumented.html');
  await page.waitForTimeout(1200);

  const boot = await page.evaluate(() => ({
    docH: document.documentElement.scrollHeight,
    openPhases: document.querySelectorAll('.phase.open').length,
    totalPhases: document.querySelectorAll('.phase').length
  }));
  console.log('BOOT STATE:', JSON.stringify(boot));

  // Expand ONLY phase f4's subtree in the tree: click its side-phase-toggle
  await page.evaluate(() => {
    document.querySelector('.tree-ph[data-phase-nav="f4"] [data-act="side-phase-toggle"]').click();
  });
  await page.waitForTimeout(120);
  // expand step toggles one by one (each click re-renders the tree)
  for (let i = 0; i < 13; i++) {
    const done = await page.evaluate((i) => {
      const btns = document.querySelectorAll('.tree-ph[data-phase-nav="f4"] [data-act="side-step-toggle"]');
      if (btns[i]) { btns[i].click(); return true; }
      return false;
    }, i);
    await page.waitForTimeout(80);
    if (!done) break;
  }
  const subs = await page.evaluate(() => Array.from(document.querySelectorAll('.tree-ph[data-phase-nav="f4"] .navsub')).map(e => e.dataset.id));
  console.log('f4 tree subs:', subs.length, subs.slice(0, 8));

  const deepSub = subs[6];   // e.g. f4-s2-4 or so
  const deepStep = await page.evaluate((sid) => {
    const sub = document.querySelector(`.navsub[data-id="${sid}"]`);
    return sub ? sid.split('-').slice(0, 2).join('-') : null;
  }, deepSub);
  console.log('targets: step=', deepStep, 'sub=', deepSub);

  async function testClick(selector, id, label) {
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.waitForTimeout(200);
    const before = await page.evaluate(() => ({ y: window.scrollY, docH: document.documentElement.scrollHeight }));
    await page.evaluate((s) => { const el = document.querySelector(s); if (el) el.click(); }, selector);
    await page.waitForTimeout(800);
    const after = await page.evaluate((id) => {
      const el = document.getElementById(id);
      if (!el) return { exists: false };
      const r = el.getBoundingClientRect();
      return { y: window.scrollY, docH: document.documentElement.scrollHeight, top: Math.round(r.top), inView: r.top >= -20 && r.top < innerHeight, exists: true };
    }, id);
    const pass = after.inView ? 'PASS' : 'FAIL';
    console.log(`[${label}] before=${JSON.stringify(before)} after=${JSON.stringify(after)} => ${pass}`);
    return after.inView;
  }

  await testClick(`.navstep[data-id="${deepStep}"]`, deepStep, 'DEEP STEP');
  await testClick(`.navsub[data-id="${deepSub}"]`, deepSub, 'DEEP SUB');
  await testClick(`.tree-ph[data-phase-nav="f11"] .navitem`, 'f11', 'PHASE f11');

  await browser.close();
})().catch(e => { console.error('FATAL', e); process.exit(1); });
