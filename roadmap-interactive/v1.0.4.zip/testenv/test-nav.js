const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const htmlPath = process.argv[2] || '/home/user/uploads/packpolymer-marketplace-roadmap-v1.0.2.html';
const raw = fs.readFileSync(htmlPath, 'utf-8');

// Strip the cloudflare junk script so it doesn't try network
const cleaned = raw.replace(/<script>\(function\(\)\{function c\(\)\{var b=a\.contentDocument[\s\S]*?<\/script>/, '');

const toasts = [];
const scrolls = [];

const dom = new JSDOM(cleaned, {
  runScripts: 'dangerously',
  pretendToBeVisual: true,
  url: 'http://localhost/',
  beforeParse(window) {
    window.scrollTo = (x, y) => { scrolls.push({ x, y }); };
    window.HTMLElement.prototype.scrollIntoView = function () {};
    // capture toast via MutationObserver after DOM ready; simpler: patch later
  }
});

const { window } = dom;
const { document } = window;

window.addEventListener('error', e => console.log('PAGE ERROR:', e.message));

function captureToasts() {
  const t = document.getElementById('toast');
  if (!t) return;
  const obs = new window.MutationObserver(() => {
    if (t.textContent.trim()) toasts.push(t.textContent.trim());
  });
  obs.observe(t, { childList: true, subtree: true, characterData: true });
}

function click(el) {
  el.dispatchEvent(new window.MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
}

setTimeout(() => {
  try {
    captureToasts();
    console.log('=== DOM ready, app children:', document.getElementById('app').children.length);

    // 1) Find a navsub in the sidebar tree; need to open its phase & step first
    const navsubs = document.querySelectorAll('.navsub');
    console.log('navsub count (should be 0 unless steps open):', navsubs.length);

    // open all phases in the tree
    document.querySelectorAll('[data-act="side-phase-toggle"]').forEach(b => click(b));
    document.querySelectorAll('[data-act="side-step-toggle"]').forEach(b => click(b));
    const subs = document.querySelectorAll('.navsub');
    console.log('navsub count after expanding:', subs.length);

    if (!subs.length) { console.log('NO NAVSUBS FOUND'); process.exit(1); }

    // pick the 5th-ish sub (e.g. deep in phase 5)
    const target = subs[Math.min(20, subs.length - 1)];
    const subId = target.dataset.id;
    console.log('clicking navsub id =', subId, '| ph =', target.dataset.ph);

    // check that the sub element exists in main content
    const subEl = document.getElementById(subId);
    console.log('main content <li id=...> exists BEFORE click?', !!subEl, subEl ? subEl.className : '');

    scrolls.length = 0; toasts.length = 0;
    click(target);

    setTimeout(() => {
      console.log('--- after click ---');
      console.log('toasts:', JSON.stringify(toasts));
      console.log('scrollTo calls:', JSON.stringify(scrolls.slice(0, 6)));
      const subEl2 = document.getElementById(subId);
      console.log('sub element exists AFTER click?', !!subEl2);
      if (subEl2) {
        console.log('sub has hit class?', subEl2.className);
        // simulate what the browser would do: verify getElementById path used by scrollToId
      }

      // 2) Also test goto-step and goto for comparison
      const step = document.querySelector('.navstep');
      if (step) {
        scrolls.length = 0; toasts.length = 0;
        click(step);
        console.log('step click -> toasts:', JSON.stringify(toasts), 'scrolls:', scrolls.length);
      }

      console.log('=== TEST DONE ===');
      process.exit(0);
    }, 400);
  } catch (e) {
    console.error('TEST ERROR', e);
    process.exit(1);
  }
}, 500);
