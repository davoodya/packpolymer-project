const fs = require('fs');
const { JSDOM } = require('jsdom');

const htmlPath = process.argv[2] || '/home/user/uploads/packpolymer-marketplace-roadmap-v1.0.2.html';
const raw = fs.readFileSync(htmlPath, 'utf-8');
const cleaned = raw.replace(/<script>\(function\(\)\{function c\(\)\{var b=a\.contentDocument[\s\S]*?<\/script>/, '');

const toasts = [];
const scrolls = [];
const log = [];

const dom = new JSDOM(cleaned, {
  runScripts: 'dangerously',
  pretendToBeVisual: true,
  url: 'http://localhost/',
  beforeParse(window) {
    Object.defineProperty(window.document, 'scrollingElement', {
      get() { return window.document.documentElement; },
      configurable: true
    });
    window.scrollTo = (x, y) => { scrolls.push({ x: typeof x === 'object' ? x.left : x, y: typeof x === 'object' ? x.top : y }); };
    window.HTMLElement.prototype.scrollIntoView = function () {};
  }
});

const { window } = dom;
const { document } = window;
window.addEventListener('error', e => log.push('PAGE ERROR: ' + e.message));

function click(el) {
  el.dispatchEvent(new window.MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
}

setTimeout(() => {
  try {
    const t = document.getElementById('toast');
    const obs = new window.MutationObserver(() => { if (t.textContent.trim()) toasts.push(t.textContent.trim()); });
    obs.observe(t, { childList: true, subtree: true, characterData: true });

    console.log('app children:', document.getElementById('app').children.length);

    // expand ALL phases + steps in the tree
    document.querySelectorAll('[data-act="side-phase-toggle"]').forEach(b => click(b));
    document.querySelectorAll('[data-act="side-step-toggle"]').forEach(b => click(b));

    const subs = Array.from(document.querySelectorAll('.navsub'));
    console.log('navsubs in tree:', subs.length);

    // Test 1: click last navsub (deep sub, like user's 5.3.3 example)
    const target = subs[subs.length - 1];
    const subId = target.dataset.id;
    console.log('\n--- TEST sub click:', subId, 'in ph', target.dataset.ph);

    // Does the main-content element exist BEFORE click?
    console.log('li exists before click:', !!document.getElementById(subId));

    scrolls.length = 0; toasts.length = 0;
    click(target);

    setTimeout(() => {
      console.log('toasts:', JSON.stringify(toasts));
      console.log('scrollTo calls:', JSON.stringify(scrolls));
      const li = document.getElementById(subId);
      console.log('li exists after:', !!li, li && li.className);

      // What does getElementById return? any duplicate ids?
      const all = document.querySelectorAll('[id="' + subId + '"]');
      console.log('elements with this id:', all.length, Array.from(all).map(e => e.tagName + '.' + e.className).join(' | '));

      // Test 2: goto-step for comparison
      const stepBtn = document.querySelector('.navstep');
      scrolls.length = 0; toasts.length = 0;
      click(stepBtn);
      console.log('\n--- TEST step click:', stepBtn.dataset.id, '-> toasts:', JSON.stringify(toasts), 'scrolls:', JSON.stringify(scrolls));

      // Test 3: goto phase
      const phBtn = document.querySelector('.navitem[data-act="goto"]');
      scrolls.length = 0; toasts.length = 0;
      click(phBtn);
      console.log('--- TEST phase click:', phBtn.dataset.id, '-> toasts:', JSON.stringify(toasts), 'scrolls:', JSON.stringify(scrolls));

      console.log('\nPAGE ERRORS:', JSON.stringify(log.slice(0, 5)));
      process.exit(0);
    }, 500);
  } catch (e) {
    console.error('TEST ERROR', e);
    process.exit(1);
  }
}, 600);
