const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  page.on('pageerror', e => console.log('PAGEERROR:', e.message));

  await page.goto('file:///home/user/testenv/instrumented.html');
  await page.waitForTimeout(1000);
  // clean state
  await page.evaluate(() => { try { localStorage.clear(); } catch (e) {} });

  // Expand tree via direct JS clicks (no Playwright auto-scroll, no pollution of state.open)
  await page.evaluate(() => {
    document.querySelectorAll('[data-act="side-phase-toggle"]').forEach(b => b.click());
    document.querySelectorAll('[data-act="side-step-toggle"]').forEach(b => b.click());
    document.querySelectorAll('[data-act="side-step-toggle"]').forEach(b => b.click());
    document.querySelectorAll('[data-act="side-step-toggle"]').forEach(b => b.click());
    document.querySelectorAll('[data-act="side-step-toggle"]').forEach(b => b.click());
    document.querySelectorAll('[data-act="side-step-toggle"]').forEach(b => b.click());
  });
  await page.waitForTimeout(300);

  const info = await page.evaluate(() => ({
    openState: Object.keys(window.__stateDbg ? {} : {}),
    docH: document.documentElement.scrollHeight,
    subs: Array.from(document.querySelectorAll('.navsub')).map(e => e.dataset.id).slice(0, 300)
  }));
  console.log('docH at rest:', info.docH, 'navsubs:', info.subs.length);

  // find a DEEP step and a DEEP sub in the same step (e.g. in f4 / f11)
  const targets = await page.evaluate(() => {
    const steps = Array.from(document.querySelectorAll('.navstep')).map(e => e.dataset.id);
    const subs = Array.from(document.querySelectorAll('.navsub')).map(e => e.dataset.id);
    return { steps, subs };
  });
  const deepStep = targets.steps.filter(id => id.startsWith('f4-') || id.startsWith('f11-'))[5] || targets.steps[targets.steps.length - 5];
  const deepSub = targets.subs.filter(id => id.startsWith(deepStep.split('-').slice(0, 2).join('-')))[2] || targets.subs[targets.subs.length - 3];
  console.log('deepStep target:', deepStep, '| deepSub target:', deepSub);

  async function testClick(sel, label) {
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.waitForTimeout(150);
    const before = await page.evaluate(() => ({ y: window.scrollY, docH: document.documentElement.scrollHeight }));
    await page.evaluate((s) => document.querySelector(s).click(), sel);
    await page.waitForTimeout(700);
    const after = await page.evaluate((id) => {
      const el = document.getElementById(id);
      const r = el.getBoundingClientRect();
      return { y: window.scrollY, docH: document.documentElement.scrollHeight, top: Math.round(r.top), inView: r.top >= -20 && r.top < innerHeight, exists: !!el };
    }, sel.match(/"([^"]+)"/)[1]);
    console.log(`[${label}] before=${JSON.stringify(before)} after=${JSON.stringify(after)} => ${after.inView ? 'PASS' : 'FAIL'}`);
    return after.inView;
  }

  await testClick(`.navstep[data-id="${deepStep}"]`, 'DEEP STEP');
  await testClick(`.navsub[data-id="${deepSub}"]`, 'DEEP SUB');

  // also test a TOP sub and a MID sub
  const midSub = targets.subs[Math.floor(targets.subs.length / 2)];
  await testClick(`.navsub[data-id="${midSub}"]`, 'MID SUB');
  const topSub = targets.subs[3];
  await testClick(`.navsub[data-id="${topSub}"]`, 'TOP SUB');

  await browser.close();
})().catch(e => { console.error('FATAL', e); process.exit(1); });
