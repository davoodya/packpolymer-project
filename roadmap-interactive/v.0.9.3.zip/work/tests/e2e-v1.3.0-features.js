const puppeteer = require('puppeteer');
const chromium = require('@sparticuz/chromium');
const failures = [];
const wait = (ms=150) => new Promise(resolve => setTimeout(resolve, ms));
function check(name, ok, detail) {
  console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}${detail === undefined ? '' : ' | ' + JSON.stringify(detail)}`);
  if (!ok) failures.push(name);
}
async function clickInPage(page, selector) {
  return page.evaluate(sel => {
    const el = document.querySelector(sel);
    if (!el) throw new Error('Missing element for click: ' + sel);
    el.click();
  }, selector);
}
async function setValue(page, selector, value) {
  return page.$eval(selector, (el, v) => {
    el.value = v;
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }, value);
}

(async () => {
  const browser = await puppeteer.launch({
    executablePath: await chromium.executablePath(),
    args: [...chromium.args, '--no-sandbox', '--disable-dev-shm-usage'],
    headless: true
  });
  const page = await browser.newPage();
  const errors = [];
  const prompts = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error' && !/scrollTo|not implemented/i.test(m.text())) errors.push(m.text()); });
  page.on('dialog', async dialog => {
    try {
      if (dialog.type() === 'prompt') await dialog.accept(prompts.shift() || '');
      else await dialog.accept();
    } catch (_) {}
  });
  await page.evaluateOnNewDocument(() => {
    window.__copiedText = '';
    try { Object.defineProperty(navigator, 'clipboard', { configurable:true, value:{ writeText: async text => { window.__copiedText = String(text); } } }); } catch (_) {}
  });
  await page.setViewport({ width: 1440, height: 1000 });
  await page.goto('file:///home/user/packpolymer-marketplace-roadmap.html', { waitUntil:'load', timeout:60000 });
  await wait(550);

  const initial = await page.evaluate(() => ({
    title: document.title,
    version: document.querySelector('.foot')?.textContent.match(/V[0-9.]+/)?.[0] || '',
    phaseCount: document.querySelectorAll('.phase').length,
    externalScripts: [...document.scripts].filter(s => s.src).map(s => s.src),
    vazirEmbedded: [...document.styleSheets].some(s => { try { return [...s.cssRules].some(r => /font-face/i.test(r.cssText) && /data:font\/woff2;base64/.test(r.cssText)); } catch (_) { return false; } })
  }));
  check('V1.3.0 is built as a self-contained offline HTML with embedded Vazir', initial.version === 'V1.3.0' && initial.phaseCount === 13 && initial.externalScripts.length === 0 && initial.vazirEmbedded, initial);

  // The compact sticky search must remain visually centered with controls on both sides.
  await page.evaluate(() => { document.documentElement.style.scrollBehavior='auto'; window.scrollTo(0, 1000); });
  await wait(220);
  const desktopSearch = await page.evaluate(() => {
    const r = s => document.querySelector(s).getBoundingClientRect();
    const left=r('.header-actions-left'), search=r('.topbar .search'), right=r('.header-actions-right');
    return { compact:document.querySelector('.topbar').classList.contains('compact'),
      center:search.left+search.width/2, viewport:innerWidth/2, width:search.width,
      leftGap:search.left-left.right, rightGap:right.left-search.right,
      controlsVisible:getComputedStyle(document.querySelector('.header-actions-left')).display!=='none'&&getComputedStyle(document.querySelector('.header-actions-right')).display!=='none' };
  });
  check('desktop compact sticky Search is wider, centered, and flanked by controls', desktopSearch.compact && Math.abs(desktopSearch.center-desktopSearch.viewport)<2 && desktopSearch.width>=500 && desktopSearch.leftGap>=0 && desktopSearch.rightGap>=0 && desktopSearch.controlsVisible, desktopSearch);

  // Notebook: rich multi-note library, metadata, query, facets, management and sorting.
  await clickInPage(page, '[data-act="notebook"]');
  await wait(650);
  await page.click('[data-nb="new"]');
  await wait(100);
  const richBody = [
    '## Supplier reference',
    '',
    'Unique bodyterm: procurement alpha.',
    '',
    '```javascript',
    'const answer = 42;',
    'console.log(answer);',
    '```',
    '',
    '```kotlin',
    'fun greet(name: String) = "Hello, $name"',
    '```',
    '',
    '```dockerfile',
    'FROM node:20',
    'RUN npm install',
    '```',
    '',
    '```diff',
    '+const added = true;',
    '-const removed = false;',
    '@@ changed block',
    '```',
    '',
    '```python',
    'def greet(name):',
    '    return f"hello {name}"',
    '```'
  ].join('\n');
  await setValue(page, '#nbTitle', 'Vendor Atlas');
  await setValue(page, '#nbEdit', richBody);
  await page.click('[data-nb="back-list"]');
  await wait(200);

  await clickInPage(page, '[data-nb="browse-mode"][data-mode="folders"]');
  prompts.push('Vendor records');
  await page.click('[data-nb="folder-add"]');
  await wait(100);
  const folderId = await page.$eval('.nb-facet[data-nb="browse-value"][data-mode="folders"][data-value]:not([data-value=""]):not([data-value="__none__"])', e => e.dataset.value);
  await clickInPage(page, '.nb-facet[data-nb="browse-value"][data-mode="folders"][data-value=""]');
  await clickInPage(page, '[data-nb="metadata-edit"]');
  await page.waitForSelector('.nb-card-editor');
  await setValue(page, '[data-nb-card-field="category"]', 'Reference');
  await setValue(page, '[data-nb-card-field="tags"]', 'polymer, b2b-procurement');
  await page.select('[data-nb-card-field="folder"]', folderId);
  await clickInPage(page, '[data-nb="metadata-save"]');
  await wait(100);
  const cardMeta = await page.$eval('.nb-card-tags', e => e.innerText);
  check('note cards visibly carry Folder, Category and Tag metadata', cardMeta.includes('Vendor records') && cardMeta.includes('Reference') && cardMeta.includes('polymer') && cardMeta.includes('b2b-procurement'), cardMeta);

  const searchResults = {};
  for (const [label, query] of [['title','atlas'],['body','bodyterm'],['tag','b2b-procurement'],['folder','vendor records'],['category','reference']]) {
    await setValue(page, '#nbSearch', query);
    searchResults[label] = await page.$$eval('.nb-card', cards => cards.length);
  }
  await setValue(page, '#nbSearch', '');
  check('Notebook search covers title, body, Tag, Folder and Category', Object.values(searchResults).every(n => n === 1), searchResults);

  await clickInPage(page, '[data-nb="browse-mode"][data-mode="tags"]');
  const tagValues = await page.$$eval('.nb-facet[data-mode="tags"]', es => es.map(e => e.dataset.value));
  await clickInPage(page, `.nb-facet[data-nb="browse-value"][data-mode="tags"][data-value="b2b-procurement"]`);
  check('Tag facet filters the note list and offers tag management', (await page.$$eval('.nb-card', es => es.length)) === 1 && tagValues.includes('b2b-procurement') && !!(await page.$('[data-nb="rename-facet"][data-value="b2b-procurement"]')));

  prompts.push('supplier-verified');
  await clickInPage(page, '[data-nb="rename-facet"][data-mode="tags"][data-value="b2b-procurement"]');
  await wait(100);
  const renamedTag = await page.$eval('.nb-card-tags', e => e.innerText);
  check('Tag can be renamed across related notes', renamedTag.includes('supplier-verified') && !renamedTag.includes('b2b-procurement'), renamedTag);
  await clickInPage(page, '[data-nb="delete-facet"][data-mode="tags"][data-value="polymer"]');
  await wait(100);
  const deletedTag = await page.$eval('.nb-card-tags', e => e.innerText);
  check('Tag can be removed from all notes without deleting note content', !deletedTag.includes('polymer') && deletedTag.includes('supplier-verified'), deletedTag);

  await clickInPage(page, '[data-nb="browse-mode"][data-mode="categories"]');
  prompts.push('Planning');
  await clickInPage(page, '[data-nb="rename-facet"][data-mode="categories"][data-value="Reference"]');
  await wait(100);
  const renamedCategory = await page.$eval('.nb-card-tags', e => e.innerText);
  check('Category can be renamed across related notes', renamedCategory.includes('Planning') && !renamedCategory.includes('Reference'), renamedCategory);
  await clickInPage(page, '[data-nb="delete-facet"][data-mode="categories"][data-value="Planning"]');
  await wait(100);
  check('Category can be removed while preserving the note', !(await page.$eval('.nb-card-tags', e => e.innerText)).includes('Planning') && (await page.$$eval('.nb-card', es => es.length)) === 1);

  await clickInPage(page, '[data-nb="browse-mode"][data-mode="folders"]');
  prompts.push('Research library');
  await clickInPage(page, `[data-nb="folder-edit"][data-id="${folderId}"]`);
  await wait(100);
  check('Folder can be renamed and its labels update', (await page.$eval('.nb-card-tags', e => e.innerText)).includes('Research library'));
  await clickInPage(page, `[data-nb="folder-delete"][data-id="${folderId}"]`);
  await wait(100);
  const afterFolderDelete = await page.$eval('.nb-card-tags', e => e.innerText);
  check('Folder deletion preserves notes and clears the Folder label', (await page.$$eval('.nb-card', es => es.length)) === 1 && !afterFolderDelete.includes('Research library'));

  await clickInPage(page, '[data-nb="browse-mode"][data-mode="tags"]');
  prompts.push('new-facet-tag');
  await clickInPage(page, '[data-nb="create-facet"][data-mode="tags"]');
  await wait(160);
  const createdFacetNote = await page.evaluate(() => ({ view:document.querySelector('[data-nb-noteview]').hidden, total:document.querySelector('[data-nb-total]').textContent }));
  await page.click('[data-nb="back-list"]');
  await wait(100);
  check('new Tag creation starts a note already assigned to the new Tag', createdFacetNote.view === false && (await page.$eval('.nb-card-tags', e => e.innerText)).includes('new-facet-tag'));

  // Create a second note to exercise the selected sort control.
  await clickInPage(page, '[data-nb="browse-mode"][data-mode="all"]');
  await page.click('[data-nb="new"]');
  await wait(80);
  await setValue(page, '#nbTitle', 'Aardvark Archive');
  await setValue(page, '#nbEdit', 'Short reference note.');
  await page.click('[data-nb="back-list"]');
  await wait(150);
  await page.select('[data-nb-sort]', 'title');
  await wait(80);
  const sortOrder = await page.$$eval('.nb-card-heading>b', es => es.map(e => e.textContent.trim()));
  check('Notebook sort selection updates the visible note order', sortOrder[0] === 'Aardvark Archive' && sortOrder.includes('Vendor Atlas'), sortOrder);

  // Open the Markdown note in Reader Mode; test Things styling, offline tokenization, and independent Copy.
  await clickInPage(page, '.nb-card[data-nb="open"]:has(.nb-card-heading>b)');
  // The previous selector chooses the first note; if it was not the supplier note, choose by title.
  await wait(100);
  const activeTitle = await page.$eval('#nbTitle', e => e.value);
  if (activeTitle !== 'Vendor Atlas') {
    await page.click('[data-nb="back-list"]');
    await wait(80);
    const vendorId = await page.$$eval('.nb-card', es => es.find(card => card.querySelector('.nb-card-heading>b')?.textContent.trim() === 'Vendor Atlas')?.dataset.id || '');
    await clickInPage(page, `.nb-card[data-id="${vendorId}"]`);
    await wait(80);
  }
  await page.click('[data-nb="toggle-mode"][data-side="primary"]');
  await page.waitForSelector('#nbPreview:not([hidden])');
  const preview = await page.evaluate(() => {
    const box=document.querySelector('#nbPreview'), codes=[...box.querySelectorAll('.md-pre')];
    return { theme:box.classList.contains('things-markdown'), background:getComputedStyle(box).backgroundColor,
      blocks:codes.length, copyButtons:box.querySelectorAll('.md-code-copy').length,
      langs:codes.map(x=>x.dataset.lang), jsKeyword:!!box.querySelector('.language-javascript .hl-keyword'),
      kotlinKeyword:!!box.querySelector('.language-kotlin .hl-keyword'), dockerKeyword:!!box.querySelector('.language-dockerfile .hl-keyword'),
      pythonKeyword:!!box.querySelector('.language-python .hl-keyword'), diffAdded:!!box.querySelector('.language-diff .hl-string'),
      h1:getComputedStyle(box.querySelector('h2')).fontSize };
  });
  check('Reader Mode renders Things 3 Obsidian styling and offline highlighting across extended languages', preview.theme && preview.background === 'rgb(26, 26, 26)' && preview.blocks === 5 && preview.copyButtons === 5 && ['javascript','kotlin','dockerfile','diff','python'].every(x => preview.langs.includes(x)) && preview.jsKeyword && preview.kotlinKeyword && preview.dockerKeyword && preview.pythonKeyword && preview.diffAdded, preview);
  await clickInPage(page, '#nbPreview .md-code-copy');
  await wait(80);
  const copied = await page.evaluate(() => window.__copiedText);
  check('each Code Block Copy excludes visual line numbers and copies only its source', copied === 'const answer = 42;\nconsole.log(answer);', copied);
  await page.evaluate(() => document.querySelectorAll('#nbPreview .md-code-copy')[1].click());
  await wait(80);
  const copiedSecond = await page.evaluate(() => window.__copiedText);
  check('Copy buttons operate independently per Code Block', copiedSecond === 'fun greet(name: String) = "Hello, $name"', copiedSecond);
  await page.click('[data-nb="back-list"]');
  await wait(100);

  // Phase/Step/Sub-step creation, completion propagation, overview navigation, and their Markdown readers.
  await clickInPage(page, '[data-nb="close"]');
  await wait(180);
  await page.evaluate(() => { document.documentElement.style.scrollBehavior='auto'; window.scrollTo(0,0); });
  await wait(160);
  await clickInPage(page, '[data-act="edit-mode"]');
  await wait(120);
  await page.evaluate(() => { const ph=document.querySelector('.phase'); if(ph&&!ph.classList.contains('open'))ph.querySelector('.ph-head').click(); });
  await wait(80);
  const oldPhaseIds = await page.$$eval('.phase', es => es.map(x => x.id));
  await clickInPage(page, '.phase.open [data-act="add-phase"]');
  await wait(180);
  const newPhaseId = await page.$$eval('.phase', (es, old) => es.map(x => x.id).find(id => !old.includes(id)), oldPhaseIds);
  await clickInPage(page, `.phase[data-phase="${newPhaseId}"] .ph-ck input`);
  await wait(80);
  const emptyPhaseDone = await page.evaluate(id => ({
    checked:document.querySelector(`.phase[data-phase="${id}"] .ph-ck input`).checked,
    card:document.querySelector(`.phase[data-phase="${id}"]`).classList.contains('done'),
    nav:document.querySelector(`.navitem[data-id="${id}"]`)?.classList.contains('done'),
    pct:document.querySelector(`[data-ppct="${id}"]`)?.textContent.trim()
  }), newPhaseId);
  check('an empty new Phase can be checked and completion propagates to progress and the phase overview', emptyPhaseDone.checked && emptyPhaseDone.card && emptyPhaseDone.nav && emptyPhaseDone.pct.includes('۱۰۰'), emptyPhaseDone);
  await clickInPage(page, `.phase[data-phase="${newPhaseId}"] .ph-head`);
  await wait(80);
  await clickInPage(page, `.phase[data-phase="${newPhaseId}"] [data-act="add-step"]`);
  await wait(180);
  const stepId = await page.$eval(`.phase[data-phase="${newPhaseId}"] .step`, e => e.id);
  await clickInPage(page, `#${stepId} .st-head input[data-ck]`);
  await wait(80);
  const newStepDone = await page.$eval(`#${stepId}`, e => e.classList.contains('done'));
  await clickInPage(page, `[data-act="side-phase-toggle"][data-id="${newPhaseId}"]`);
  await wait(80);
  const navStepExists = await page.evaluate(id => !!document.querySelector(`.navstep[data-id="${id}"]`), stepId);
  await clickInPage(page, `#${stepId} [data-act="add-sub"]`);
  await wait(150);
  const subId = await page.$eval(`#${stepId} .sub`, e => e.id);
  await clickInPage(page, `[data-act="side-step-toggle"][data-id="${stepId}"]`);
  await wait(80);
  const navSubExists = await page.evaluate(id => !!document.querySelector(`.navsub[data-id="${id}"]`), subId);
  await clickInPage(page, `#${stepId} .st-head input[data-ck]`);
  await wait(80);
  const cascade = await page.evaluate(id => ({
    sub:document.getElementById(id).classList.contains('done'),
    step:document.getElementById(id).closest('.step').classList.contains('done'),
    phase:document.getElementById(id).closest('.phase').classList.contains('done'),
    navSub:document.querySelector(`.navsub[data-id="${id}"]`)?.classList.contains('done')
  }), subId);
  check('new Step/Sub-step checkboxes work, cascade to parents, and appear in the expanded overview tree', newStepDone && navStepExists && navSubExists && cascade.sub && cascade.step && cascade.phase && cascade.navSub, {newStepDone,navStepExists,navSubExists,cascade});

  async function addEntityNote(key, text) {
    await clickInPage(page, `[data-act="note-toggle"][data-key="n:${key}"]`);
    await page.waitForSelector(`[data-note="n:${key}"]`);
    await setValue(page, `[data-note="n:${key}"]`, text);
    await clickInPage(page, `[data-act="note-mode"][data-key="n:${key}"]`);
    await wait(70);
    return page.evaluate(k => {
      const wrap=document.querySelector(`[data-note-wrap="n:${k}"]`),preview=wrap?.querySelector('.note-read');
      return {read:!!preview&&!preview.hidden,theme:preview?.classList.contains('things-markdown'),codeCopy:preview?.querySelectorAll('.md-code-copy').length||0,
        background:preview?getComputedStyle(preview).backgroundColor:'',toolbar:!!wrap?.querySelector('.nb-tools')};
    }, key);
  }
  const phaseNote = await addEntityNote(newPhaseId, '# Phase memo\n\n```python\nprint("phase")\n```');
  const stepNote = await addEntityNote(stepId, '## Step memo\n\n**Ready** and `offline`.');
  const subNote = await addEntityNote(subId, '### Sub-step memo\n\n```kotlin\nfun done() = true\n```');
  check('Phase/Step/Sub-step notes share Markdown, Things Reader styling and independent Read/Edit modes (without Notebook toolbar)',
    [phaseNote,stepNote,subNote].every(x=>x.read&&x.theme&&x.background==='rgb(26, 26, 26)'&&!x.toolbar) && phaseNote.codeCopy===1 && subNote.codeCopy===1,
    {phaseNote,stepNote,subNote});

  // Mobile: compact header layout and the notebook library must stay within the viewport.
  await page.setViewport({ width:390, height:844 });
  await page.evaluate(() => { document.documentElement.style.scrollBehavior='auto'; window.scrollTo(0,document.documentElement.scrollHeight); window.dispatchEvent(new Event('scroll')); document.querySelector('.topbar').classList.add('compact'); });
  await wait(260);
  const mobileHeader = await page.evaluate(() => {
    const r=s=>document.querySelector(s).getBoundingClientRect();const l=r('.header-actions-left'),q=r('.topbar .search'),a=r('.header-actions-right');
    return {compact:document.querySelector('.topbar').classList.contains('compact'),scrollY,center:q.left+q.width/2,mid:innerWidth/2,width:q.width,
      leftGap:q.left-l.right,rightGap:a.left-q.right};
  });
  check('mobile compact Search remains centered, usable and separated from controls', mobileHeader.compact && Math.abs(mobileHeader.center-mobileHeader.mid)<2 && mobileHeader.width>=140 && mobileHeader.leftGap>=0 && mobileHeader.rightGap>=0, mobileHeader);
  await clickInPage(page, '#fabNote');
  await wait(220);
  if (!(await page.$eval('[data-nb-noteview]', e => e.hidden))) { await page.click('[data-nb="back-list"]'); await wait(100); }
  const mobileNotebook = await page.evaluate(() => ({width:document.querySelector('#nbPanel').getBoundingClientRect().width,
    viewport:innerWidth,scrollWidth:document.querySelector('#nbPanel').scrollWidth,bodyWidth:document.body.scrollWidth,
    list:!document.querySelector('[data-nb-listview]').hidden}));
  check('mobile Notebook list is responsive without horizontal overflow', mobileNotebook.width <= mobileNotebook.viewport+1 && mobileNotebook.scrollWidth <= mobileNotebook.viewport+2 && mobileNotebook.bodyWidth <= mobileNotebook.viewport+2 && mobileNotebook.list, mobileNotebook);

  check('the feature run finishes without JavaScript or console errors', errors.length===0, errors);
  await browser.close();
  console.log(`SUMMARY | ${failures.length ? 'FAIL' : 'PASS'} | ${failures.length} failure(s) | ${errors.length} runtime error(s)`);
  if (failures.length || errors.length) process.exit(1);
})().catch(error => { console.error(error); process.exit(1); });
