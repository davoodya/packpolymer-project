const puppeteer = require('puppeteer');
const chromium = require('@sparticuz/chromium');
const fs = require('fs');
const path = require('path');
const http = require('http');
const BASE = '/home/user';
const HTML = '/packpolymer-marketplace-roadmap.html';
const SIDECAR = path.join(BASE, 'answers-roadmap.json');
const DOWNLOADS = path.join(BASE, 'work/tests/.tmp-downloads');
let originalSidecar = null;
let server = null;
let browser = null;
const failures = [];
const wait = (ms=200) => new Promise(resolve => setTimeout(resolve, ms));
function check(name, ok, detail) {
  console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}${detail === undefined ? '' : ' | ' + JSON.stringify(detail)}`);
  if (!ok) failures.push(name);
}

(async () => {
  try {
    originalSidecar = fs.readFileSync(SIDECAR, 'utf8');
    const seed = {
      app: 'packpolymer-marketplace-roadmap', kind: 'answers', version: 2,
      appVersion: '1.3.0', savedAt: '2099-01-01T00:00:00.000Z',
      checks: {}, notes: {}, noteDirections: { 'n:f2-s1': 'rtl' },
      marks: { archived: { 'f2-s1-1': true }, review: { 'f2-s1': true } },
      notebook: '',
      nbNotes: [{ id: 'nb-sidecar-v13', title: 'یادداشت از فایل کناری', body: 'محتوای آزمایش sidecar', folderId: 'sidecar-folder', category: 'مهم', tags: ['sidecar-tag'], direction: 'ltr', createdAt: '2099-01-01T00:00:00.000Z', updatedAt: '2099-01-01T00:00:00.000Z' }],
      nbFolders: [{ id: 'sidecar-folder', name: 'فولدر آزمایش', createdAt: '2099-01-01T00:00:00.000Z' }],
      nbTags: ['sidecar-tag'], nbCategories: ['مهم'],
      nbBrowseMode: 'all', nbBrowseValue: '', nbSort: 'updated',
      nbActiveId: 'nb-sidecar-v13', nbSecondaryId: '', nbSplit: false,
      nbMode: 'edit', nbSecondaryMode: 'read', nbView: 'note',
      sidebarLayout: 'dual-right', uiFontScale: 1, nbFontScale: 1, nbWidthPct: 78, nbSplitRatio: 0.5,
      customized: false
    };
    fs.writeFileSync(SIDECAR, JSON.stringify(seed, null, 2));
    fs.mkdirSync(DOWNLOADS, { recursive: true });

    server = http.createServer((req, res) => {
      const pathname = decodeURIComponent((req.url || '/').split('?')[0]);
      const rel = pathname === '/' ? HTML : pathname;
      const full = path.resolve(BASE, '.' + rel);
      if (!full.startsWith(BASE)) { res.writeHead(403); return res.end('forbidden'); }
      fs.readFile(full, (err, data) => {
        if (err) { res.writeHead(404); return res.end('not found'); }
        const type = full.endsWith('.json') ? 'application/json; charset=utf-8' : full.endsWith('.html') ? 'text/html; charset=utf-8' : 'text/plain; charset=utf-8';
        res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-store' });
        res.end(data);
      });
    });
    await new Promise(resolve => server.listen(8899, '127.0.0.1', resolve));

    browser = await puppeteer.launch({
      executablePath: await chromium.executablePath(),
      headless: true,
      args: [...chromium.args, '--no-sandbox', '--disable-dev-shm-usage']
    });
    const page = await browser.newPage();
    const errors = [];
    const dialogs = [];
    page.on('pageerror', e => errors.push(e.message));
    page.on('console', m => { if (m.type() === 'error' && !/scrollTo|not implemented/i.test(m.text())) errors.push(m.text()); });
    page.on('dialog', async d => { dialogs.push(d.type()); try { await d.dismiss(); } catch (_) {} });
    await page.evaluateOnNewDocument(seedText => {
      window.__fakeFileText = seedText;
      window.__fakeWrites = [];
      window.showOpenFilePicker = async () => [{
        name: 'answers-roadmap.json',
        getFile: async () => ({ text: async () => window.__fakeFileText }),
        createWritable: async () => ({
          write: async value => { window.__fakeFileText = String(value); window.__fakeWrites.push(String(value)); },
          close: async () => {}
        }),
        queryPermission: async () => 'granted',
        requestPermission: async () => 'granted'
      }];
    }, JSON.stringify(seed));
    await page.setViewport({ width: 1280, height: 900 });
    await page.goto('http://127.0.0.1:8899' + HTML, { waitUntil: 'load', timeout: 60000 });
    await page.waitForFunction(() => {
      try {
        const s = JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2') || '{}');
        return !!s.marks?.review?.['f2-s1'] && s.nbNotes?.[0]?.id === 'nb-sidecar-v13';
      } catch (_) { return false; }
    }, { timeout: 15000 });
    const loaded = await page.evaluate(() => {
      const s = JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2') || '{}');
      return { review: !!s.marks?.review?.['f2-s1'], archived: !!s.marks?.archived?.['f2-s1-1'], note: s.nbNotes?.[0]?.title, folder: s.nbFolders?.[0]?.name, tag: s.nbTags?.[0], category: s.nbCategories?.[0], noteDirection: s.noteDirections?.['n:f2-s1'], notebookDirection: s.nbNotes?.[0]?.direction };
    });
    check('answers-roadmap.json imports marks, multi-note Notebook properties, and both new direction settings over HTTP', loaded.review && loaded.archived && loaded.note === 'یادداشت از فایل کناری' && loaded.folder === 'فولدر آزمایش' && loaded.tag === 'sidecar-tag' && loaded.category === 'مهم' && loaded.noteDirection === 'rtl' && loaded.notebookDirection === 'ltr', loaded);

    await page.evaluate(() => {
      const phase = document.querySelector('#f2');
      if (phase && (phase.querySelector('.ph-body[data-lazy="1"]') || !phase.classList.contains('open'))) phase.querySelector('.ph-head')?.click();
    });
    await page.waitForSelector('#f2-s1', { timeout: 15000 });
    const reviewVisible = await page.$eval('#f2-s1', e => e.classList.contains('needs-review'));
    const archivedHidden = !(await page.$('#f2-s1-1'));
    await page.evaluate(() => document.querySelector('[data-act="mark-filter"][data-id="archived"]')?.click());
    await page.waitForSelector('#f2-s1-1', { timeout: 15000 });
    check('sidecar review mark remains visible and archived item returns from the Archive filter', reviewVisible && archivedHidden && !!(await page.$('#f2-s1-1')));

    await page.evaluate(() => document.querySelector('[data-act="notebook"]')?.click());
    await page.waitForFunction(() => document.querySelector('#nbPanel')?.classList.contains('open') && document.querySelector('#nbTitle')?.value === 'یادداشت از فایل کناری', { timeout: 15000 });
    check('Notebook resumes the sidecar Last Note with its Persian title', await page.$eval('#nbTitle', e => e.value === 'یادداشت از فایل کناری'));

    await page.evaluate(() => document.querySelector('[data-act="file-connect"]')?.click());
    await page.waitForFunction(() => Array.isArray(window.__fakeWrites) && window.__fakeWrites.length > 0, { timeout: 12000 });
    const connectedPayload = await page.evaluate(() => JSON.parse(window.__fakeFileText));
    check('connected answers file writes the imported sidecar payload including note and Notebook directions', connectedPayload.kind === 'answers' && connectedPayload.nbNotes?.[0]?.id === 'nb-sidecar-v13' && connectedPayload.nbFolders?.[0]?.name === 'فولدر آزمایش' && connectedPayload.noteDirections?.['n:f2-s1'] === 'rtl' && connectedPayload.nbNotes?.[0]?.direction === 'ltr');

    const client = await page.createCDPSession();
    await client.send('Page.setDownloadBehavior', { behavior: 'allow', downloadPath: DOWNLOADS });
    await page.evaluate(() => document.querySelector('[data-act="export-answers"]')?.click());
    let exportFile = '';
    for (let i = 0; i < 60 && !exportFile; i++) {
      const found = fs.readdirSync(DOWNLOADS).find(n => /^answers-roadmap-.*\.json$/.test(n));
      if (found && !found.endsWith('.crdownload')) exportFile = path.join(DOWNLOADS, found);
      else await wait(150);
    }
    let exportCheck = null;
    if (exportFile) {
      const d = JSON.parse(fs.readFileSync(exportFile, 'utf8'));
      exportCheck = { kind: d.kind, review: !!d.marks?.review?.['f2-s1'], archived: !!d.marks?.archived?.['f2-s1-1'], note: d.nbNotes?.[0]?.title, folder: d.nbFolders?.[0]?.name, tag: d.nbTags?.[0], category: d.nbCategories?.[0], noteDirection: d.noteDirections?.['n:f2-s1'], notebookDirection: d.nbNotes?.[0]?.direction };
    }
    check('JSON answers export downloads a round-trippable sidecar payload including both direction settings', !!exportFile && exportCheck?.kind === 'answers' && exportCheck.review && exportCheck.archived && exportCheck.note === 'یادداشت از فایل کناری' && exportCheck.folder === 'فولدر آزمایش' && exportCheck.tag === 'sidecar-tag' && exportCheck.category === 'مهم' && exportCheck.noteDirection === 'rtl' && exportCheck.notebookDirection === 'ltr', exportCheck || { downloadFound: !!exportFile });

    const fakeWriteCountBeforeClean = await page.evaluate(() => window.__fakeWrites.length);
    await page.evaluate(() => { window.scrollTo(0, 0); document.querySelector('[data-act="clean-all"]')?.click(); });
    await page.waitForSelector('.inline-confirm [data-confirm-yes]', { timeout: 10000 });
    await page.evaluate(() => document.querySelector('.inline-confirm [data-confirm-yes]')?.click());
    await page.waitForFunction(() => {
      const s = JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2') || '{}');
      return !s.nbNotes?.length && !Object.keys(s.marks?.archived || {}).length && !Object.keys(s.marks?.review || {}).length;
    }, { timeout: 15000 });
    const clean = await page.evaluate(() => {
      const s = JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2') || '{}');
      return { notes: s.nbNotes?.length || 0, archived: Object.keys(s.marks?.archived || {}).length, review: Object.keys(s.marks?.review || {}).length, inlineConfirm: !!document.querySelector('.inline-confirm') };
    });
    check('Clean All confirms inline and clears Notebook/Review/Archive local state', clean.notes === 0 && clean.archived === 0 && clean.review === 0 && !clean.inlineConfirm, clean);
    await page.waitForFunction(n => window.__fakeWrites.length > n, { timeout: 15000 }, fakeWriteCountBeforeClean);
    const clearedFile = await page.evaluate(() => JSON.parse(window.__fakeFileText));
    check('Clean All also clears the connected answers file', !(clearedFile.nbNotes||[]).length && !Object.keys(clearedFile.marks?.archived||{}).length && !Object.keys(clearedFile.marks?.review||{}).length && !Object.keys(clearedFile.checks||{}).length, { notes:clearedFile.nbNotes?.length||0, archived:Object.keys(clearedFile.marks?.archived||{}).length, review:Object.keys(clearedFile.marks?.review||{}).length, checks:Object.keys(clearedFile.checks||{}).length });
    check('sidecar import/export and Clean All produce no JS errors or browser popups', errors.length === 0 && dialogs.length === 0, { errors, dialogs });
  } catch (e) {
    console.error('FATAL', e);
    failures.push('fatal test error');
  } finally {
    if (browser) { try { await browser.close(); } catch (_) {} }
    if (server) { try { await new Promise(resolve => server.close(resolve)); } catch (_) {} }
    if (originalSidecar !== null) { try { fs.writeFileSync(SIDECAR, originalSidecar); } catch (_) {} }
    try { fs.rmSync(DOWNLOADS, { recursive: true, force: true }); } catch (_) {}
  }
  console.log(failures.length ? `SUMMARY | FAIL | ${failures.length} failure(s)` : 'SUMMARY | PASS | sidecar and JSON export round-trip');
  if (failures.length) process.exit(1);
})().catch(e => { console.error('UNCAUGHT', e); process.exit(2); });
