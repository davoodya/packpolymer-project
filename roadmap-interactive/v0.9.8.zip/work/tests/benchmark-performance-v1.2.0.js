const puppeteer=require('puppeteer');
const chromium=require('@sparticuz/chromium');
const fs=require('fs');
const path=require('path');
const http=require('http');
const BASE='/home/user';
const HTML='/packpolymer-marketplace-roadmap.html';
const PORT=8900;
const wait=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
  const appHtml=fs.readFileSync(path.join(BASE,HTML),'utf8');
  const needle="case 'expand-all': state.plan.forEach(p => state.open[p.id] = true); save(); renderSearchResults(); break;";
  if(!appHtml.includes(needle))throw new Error('Expand All handler not found; rebuild before benchmarking.');
  const baselineHtml=appHtml.replace(needle,needle.replace('renderSearchResults();','render();'));
  const server=http.createServer((req,res)=>{
    const pathname=decodeURIComponent((req.url||'/').split('?')[0]);
    if(pathname==='/baseline.html'){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});return res.end(baselineHtml);}
    const rel=pathname==='/'?HTML:pathname;
    const file=path.resolve(BASE,'.'+rel);
    if(!file.startsWith(BASE)){res.writeHead(403);return res.end('forbidden');}
    fs.readFile(file,(err,data)=>{if(err){res.writeHead(404);return res.end('not found');}
      const type=file.endsWith('.json')?'application/json; charset=utf-8':file.endsWith('.html')?'text/html; charset=utf-8':'text/plain; charset=utf-8';
      res.writeHead(200,{'Content-Type':type,'Cache-Control':'no-store'});res.end(data);
    });
  });
  await new Promise(r=>server.listen(PORT,'127.0.0.1',r));
  const browser=await puppeteer.launch({executablePath:await chromium.executablePath(),headless:true,args:[...chromium.args,'--no-sandbox','--disable-dev-shm-usage']});
  const page=await browser.newPage();
  await page.evaluateOnNewDocument(()=>{window.__longTasks=[];try{new PerformanceObserver(l=>window.__longTasks.push(...l.getEntries().map(x=>x.duration))).observe({type:'longtask',buffered:true});}catch(e){}});
  const run=async(pathname,clearStorage=false)=>{
    if(clearStorage&&page.url()!=='about:blank')await page.evaluate(()=>localStorage.clear());
    await page.setViewport({width:1920,height:950});
    await page.goto(`http://127.0.0.1:${PORT}${pathname}`,{waitUntil:'load',timeout:60000});
    await wait(850);
    const dispatchMs=await page.evaluate(()=>{window.__longTasks=[];window.__benchStart=performance.now();const t=performance.now();document.querySelector('[data-act="expand-all"]').click();return performance.now()-t;});
    await page.waitForFunction(()=>document.querySelectorAll('#phases .step').length===122&&document.querySelectorAll('#phases .sub').length===749,{timeout:20000});
    await wait(80);
    return page.evaluate(dispatchMs=>({dispatchMs,totalMs:performance.now()-window.__benchStart,steps:document.querySelectorAll('#phases .step').length,substeps:document.querySelectorAll('#phases .sub').length,maxLongTaskMs:Math.max(0,...window.__longTasks)}),dispatchMs);
  };
  const baseline=await run('/baseline.html');
  const optimized=await run(HTML,true);
  await browser.close();await new Promise(r=>server.close(r));
  console.log(JSON.stringify({environment:'Headless Chromium, 1920x950, identical V1.3.0 HTML/data; benchmark-only synchronous render reference',baseline,optimized},null,2));
  if(baseline.steps!==optimized.steps||baseline.substeps!==optimized.substeps)process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1;});
