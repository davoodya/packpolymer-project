const puppeteer = require('puppeteer');
const chromium = require('@sparticuz/chromium');
const http = require('http');
const fs = require('fs');
let testServer=null;
const failures = [];
const wait = (ms=120) => new Promise(resolve => setTimeout(resolve, ms));
function check(name, ok, detail) {
  console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}${detail === undefined ? '' : ' | ' + JSON.stringify(detail)}`);
  if (!ok) failures.push(name);
}
async function click(page, selector) {
  await page.evaluate(sel => {
    const el=document.querySelector(sel); if(!el)throw new Error('Missing element: '+sel); el.click();
  }, selector);
}
async function setValue(page, selector, value) {
  await page.$eval(selector,(el,v)=>{el.value=v;el.dispatchEvent(new Event('input',{bubbles:true}));},value);
}

(async()=>{
  const browser=await puppeteer.launch({executablePath:await chromium.executablePath(),args:[...chromium.args,'--no-sandbox','--disable-dev-shm-usage'],headless:true});
  const page=await browser.newPage();
  const errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  page.on('console',m=>{if(m.type()==='error'&&!/scrollTo|not implemented/i.test(m.text()))errors.push(m.text());});
  await page.evaluateOnNewDocument(()=>{
    window.__copiedText='';
    try{Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:async text=>{window.__copiedText=String(text);}}});}catch(_){}
  });
  const html=fs.readFileSync('/home/user/packpolymer-marketplace-roadmap.html');
  const sidecar=fs.readFileSync('/home/user/answers-roadmap.json');
  testServer=http.createServer((req,res)=>{
    const path=(req.url||'/').split('?')[0];
    if(path==='/seed.html'){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});res.end('<!doctype html><html><body>test seed</body></html>');}
    else if(path==='/'||path==='/packpolymer-marketplace-roadmap.html'){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});res.end(html);}
    else if(path==='/answers-roadmap.json'){res.writeHead(200,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(sidecar);}
    else{res.writeHead(404);res.end('Not found');}
  });
  await new Promise(resolve=>testServer.listen(0,'127.0.0.1',resolve));
  const origin='http://127.0.0.1:'+testServer.address().port;
  await page.setViewport({width:1440,height:900});
  await page.goto(origin+'/seed.html',{waitUntil:'load',timeout:60000});
  await page.evaluate(()=>{
    const now=new Date().toISOString(),key='packpolymer-marketplace-roadmap-v2';
    const folders=Array.from({length:34},(_,i)=>({id:'folder-'+i,name:'Folder '+String(i+1).padStart(2,'0'),createdAt:now}));
    const tags=Array.from({length:70},(_,i)=>'tag-'+String(i+1).padStart(2,'0'));
    const categories=Array.from({length:34},(_,i)=>'Category '+String(i+1).padStart(2,'0'));
    const longBody=Array.from({length:260},(_,i)=>`Paragraph ${i+1}: Text scrolling is isolated for each Notebook surface. https://example.com/docs.`).join('\n\n');
    const notes=Array.from({length:34},(_,i)=>({
      id:'seed-note-'+i,title:'Reference Note '+String(i+1).padStart(2,'0'),body:i===0?longBody:`A short note ${i+1}.`,folderId:folders[i].id,category:categories[i],tags:[tags[i],tags[(i+7)%tags.length]],createdAt:now,updatedAt:new Date(Date.now()+i).toISOString()
    }));
    localStorage.setItem(key,JSON.stringify({nbNotes:notes,nbFolders:folders,nbTags:tags,nbCategories:categories,nbBrowseMode:'all',nbSort:'created',nbView:'list',nbMode:'edit',nbSplit:false,ui:{nbOpen:false}}));
  });
  await page.goto(origin+'/packpolymer-marketplace-roadmap.html',{waitUntil:'load',timeout:60000}); await wait(550);
  const seedProbe=await page.evaluate(()=>{let d={};try{d=JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')||'{}')}catch(_){}return {origin:location.origin,storageCount:Array.isArray(d.nbNotes)?d.nbNotes.length:-1,storageFolders:Array.isArray(d.nbFolders)?d.nbFolders.length:-1,cardCount:document.querySelectorAll('#nbList .nb-card').length,notebookCount:document.querySelector('[data-nb-total]')?.textContent};});
  check('Notebook stress test loads its isolated seed notes and facets',seedProbe.storageCount===34&&seedProbe.storageFolders===34&&seedProbe.cardCount===34,seedProbe);
  await click(page,'#fabNote'); await wait(220);
  await click(page,'[data-nb="back-list"]'); await wait(100);

  await click(page,'[data-nb="browse-mode"][data-mode="folders"]'); await wait(80);
  const listAreas=await page.evaluate(()=>{
    const list=document.querySelector('#nbList'),side=document.querySelector('.nb-browse-items'),explorer=document.querySelector('.nb-explorer');
    return {columns:getComputedStyle(explorer).gridTemplateColumns.split(' ').length,listClient:list.clientHeight,listScroll:list.scrollHeight,sideClient:side.clientHeight,sideScroll:side.scrollHeight};
  });
  check('Notebook list, facet explorer and note list each have their own bounded scroll region',listAreas.columns===2&&listAreas.listScroll>listAreas.listClient&&listAreas.sideScroll>listAreas.sideClient,listAreas);
  const independentListScroll=await page.evaluate(()=>{
    const list=document.querySelector('#nbList'),side=document.querySelector('.nb-browse-items');list.scrollTop=0;side.scrollTop=0;side.scrollTop=90;
    const first={list:list.scrollTop,side:side.scrollTop};list.scrollTop=120;return {first,afterList:{list:list.scrollTop,side:side.scrollTop}};
  });
  check('Explorer facet navigation and note results scroll independently',independentListScroll.first.side>0&&independentListScroll.first.list===0&&independentListScroll.afterList.list>0&&independentListScroll.afterList.side===independentListScroll.first.side,independentListScroll);

  await click(page,'[data-nb="new"]'); await wait(120);
  const newNoteDefault=await page.evaluate(()=>({
    propertiesHidden:document.querySelector('[data-nb-properties="primary"]').hidden,
    bodyVisible:getComputedStyle(document.querySelector('.nb-pane-primary .nb-body')).display!=='none',
    editorHeight:document.querySelector('#nbEdit').getBoundingClientRect().height,
    mode:document.querySelector('.nb-pane-primary .nb-body').dataset.mode,
    formatHidden:document.querySelector('[data-nb-formatbar="primary"]').hidden,
    formatIcons:document.querySelectorAll('[data-nb-formatbar="primary"] .nb-format-button').length,
    actions:[...document.querySelectorAll('[data-nb-tools="primary"] .nb-actions [data-nb]')].map(e=>e.dataset.nb),
    textless:[...document.querySelectorAll('[data-nb-tools="primary"] .nb-format-button,[data-nb-tools="primary"] .nb-action-button')].every(e=>!e.textContent.trim())
  }));
  const veryLong=Array.from({length:500},(_,i)=>`Line ${i+1}: Long Markdown text to verify that the editor scrolls independently inside the note.`).join('\n')+'\n\nRaw URL: https://example.com/raw?q=1&y=2. Markdown: [Vendor docs](https://docs.example.com/guide). Another URL: (https://packpolymer.com/start).';
  await setValue(page,'#nbTitle','Mobile scroll and properties test'); await setValue(page,'#nbEdit',veryLong); await wait(160);
  const editorScroll=await page.evaluate(()=>{const ta=document.querySelector('#nbEdit');ta.scrollTop=ta.scrollHeight;return {scrollHeight:ta.scrollHeight,clientHeight:ta.clientHeight,scrollTop:ta.scrollTop,propertiesHidden:document.querySelector('[data-nb-properties="primary"]').hidden};});
  check('new Note opens in raw Edit with compact Markdown tools, seven icon actions and an independently scrolling Editor',newNoteDefault.propertiesHidden&&newNoteDefault.bodyVisible&&newNoteDefault.editorHeight>130&&newNoteDefault.mode==='edit'&&!newNoteDefault.formatHidden&&newNoteDefault.formatIcons>=13&&newNoteDefault.textless&&newNoteDefault.actions.join(',')==='copy,share,download,duplicate,new2,delete,typewriter'&&editorScroll.scrollHeight>editorScroll.clientHeight&&editorScroll.scrollTop>0, {newNoteDefault,editorScroll});

  await click(page,'[data-nb="toggle-mode"][data-side="primary"]'); await page.waitForSelector('#nbPreview:not([hidden])');
  const readState=await page.evaluate(()=>{const actions=[...document.querySelectorAll('[data-nb-tools="primary"] .nb-actions [data-nb]')],typewriter=document.querySelector('[data-nb="typewriter"][data-side="primary"]');return {mode:document.querySelector('.nb-pane-primary .nb-body').dataset.mode,editorHidden:document.querySelector('#nbEdit').hidden,previewVisible:!document.querySelector('#nbPreview').hidden,formatHidden:document.querySelector('[data-nb-formatbar="primary"]').hidden,syncHidden:document.querySelector('[data-nb="scroll-sync"][data-side="primary"]').hidden,actionCount:actions.length,visibleActionCount:actions.filter(x=>!x.hidden&&getComputedStyle(x).display!=='none').length,typewriterHidden:typewriter.hidden};});
  const readerScroll=await page.evaluate(()=>{const el=document.querySelector('#nbPreview');el.scrollTop=el.scrollHeight;return {scrollHeight:el.scrollHeight,clientHeight:el.clientHeight,scrollTop:el.scrollTop,links:[...el.querySelectorAll('a')].slice(0,3).map(a=>({href:a.href,target:a.target,rel:a.rel}))};});
  check('Read mode keeps six ordinary actions and hides the editor-only Auto Scroll toggle',readState.mode==='read'&&readState.editorHidden&&readState.previewVisible&&readState.formatHidden&&readState.syncHidden&&readState.actionCount===7&&readState.visibleActionCount===6&&readState.typewriterHidden,readState);
  check('Reader content scrolls independently and plain URLs are real secure clickable anchors',readerScroll.scrollHeight>readerScroll.clientHeight&&readerScroll.scrollTop>0&&readerScroll.links.length===3&&readerScroll.links.every(x=>x.href.startsWith('https://')&&x.target==='_blank'&&x.rel.includes('noopener')&&x.rel.includes('noreferrer')),readerScroll);
  await click(page,'[data-nb="copy"][data-side="primary"]'); await wait(80);
  const readableCopy=await page.evaluate(()=>window.__copiedText);
  check('Copy action copies rendered readable text, not raw Markdown or code-copy controls',readableCopy.includes('Line 500')&&!readableCopy.includes('[Vendor')&&!readableCopy.includes('کپی'),{length:readableCopy.length,snippet:readableCopy.slice(-90)});
  await click(page,'[data-nb="toggle-mode"][data-side="primary"]'); await wait(80);
  const bothState=await page.evaluate(()=>({mode:document.querySelector('.nb-pane-primary .nb-body').dataset.mode,editorHidden:document.querySelector('#nbEdit').hidden,previewHidden:document.querySelector('#nbPreview').hidden,formatHidden:document.querySelector('[data-nb-formatbar="primary"]').hidden,syncHidden:document.querySelector('[data-nb="scroll-sync"][data-side="primary"]').hidden,editWidth:document.querySelector('#nbEdit').getBoundingClientRect().width,previewWidth:document.querySelector('#nbPreview').getBoundingClientRect().width}));
  check('Second mode toggle shows raw Markdown on the right and rendered preview on the left',bothState.mode==='both'&&!bothState.editorHidden&&!bothState.previewHidden&&!bothState.formatHidden&&!bothState.syncHidden&&bothState.editWidth>80&&bothState.previewWidth>80,bothState);
  const independentBothScroll=await page.evaluate(()=>{const edit=document.querySelector('#nbEdit'),preview=document.querySelector('#nbPreview');edit.scrollTop=0;preview.scrollTop=0;edit.scrollTop=edit.scrollHeight*.45;edit.dispatchEvent(new Event('scroll',{bubbles:true}));return {editTop:edit.scrollTop,previewTop:preview.scrollTop,previewMax:preview.scrollHeight-preview.clientHeight};});
  check('raw and rendered surfaces initially keep independent scroll positions in combined view',independentBothScroll.editTop>0&&independentBothScroll.previewTop===0,independentBothScroll);
  await click(page,'[data-nb="scroll-sync"][data-side="primary"]'); await wait(80);
  const syncedForward=await page.evaluate(()=>{const edit=document.querySelector('#nbEdit'),preview=document.querySelector('#nbPreview');edit.scrollTop=edit.scrollHeight*.65;edit.dispatchEvent(new Event('scroll',{bubbles:true}));return new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve({enabled:document.querySelector('[data-nb="scroll-sync"][data-side="primary"]').getAttribute('aria-pressed'),editRatio:edit.scrollTop/(edit.scrollHeight-edit.clientHeight),previewRatio:preview.scrollTop/(preview.scrollHeight-preview.clientHeight)}))));});
  check('Scroll Sync maps Editor position proportionally to the rendered Preview',syncedForward.enabled==='true'&&Math.abs(syncedForward.editRatio-syncedForward.previewRatio)<.08,syncedForward);
  const syncedReverse=await page.evaluate(()=>{const edit=document.querySelector('#nbEdit'),preview=document.querySelector('#nbPreview');preview.scrollTop=preview.scrollHeight*.82;preview.dispatchEvent(new Event('scroll',{bubbles:true}));return new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve({editRatio:edit.scrollTop/(edit.scrollHeight-edit.clientHeight),previewRatio:preview.scrollTop/(preview.scrollHeight-preview.clientHeight)}))));});
  check('Scroll Sync also maps rendered Preview scrolling back to the raw Editor',Math.abs(syncedReverse.editRatio-syncedReverse.previewRatio)<.08,syncedReverse);
  await click(page,'[data-nb="scroll-sync"][data-side="primary"]');
  await click(page,'[data-nb="split-toggle"]'); await wait(140);
  const splitInitialModes=await page.evaluate(()=>({primary:document.querySelector('.nb-pane-primary .nb-body').dataset.mode,secondary:document.querySelector('.nb-pane-secondary .nb-body').dataset.mode,secondarySyncHidden:document.querySelector('[data-nb="scroll-sync"][data-side="secondary"]').hidden}));
  check('Split View initializes each independently opened note in Edit and keeps secondary Sync hidden',splitInitialModes.primary==='both'&&splitInitialModes.secondary==='edit'&&splitInitialModes.secondarySyncHidden,splitInitialModes);
  await click(page,'[data-nb="new2"][data-side="secondary"]'); await wait(100);
  await setValue(page,'#nbTitleSecondary','Secondary long note'); await setValue(page,'#nbEditSecondary',veryLong.replace(/Line/g,'Secondary line')); await wait(300);
  const secondaryDefault=await page.evaluate(()=>({mode:document.querySelector('.nb-pane-secondary .nb-body').dataset.mode,primary:document.querySelector('.nb-pane-primary .nb-body').dataset.mode}));
  await click(page,'[data-nb="toggle-mode"][data-side="secondary"]'); await wait(70);
  const secondaryRead=await page.evaluate(()=>({secondary:document.querySelector('.nb-pane-secondary .nb-body').dataset.mode,primary:document.querySelector('.nb-pane-primary .nb-body').dataset.mode,editHidden:document.querySelector('#nbEditSecondary').hidden,previewVisible:!document.querySelector('#nbPreviewSecondary').hidden}));
  check('Secondary pane has its own Edit → Read cycle and cannot change the primary pane mode',secondaryDefault.mode==='edit'&&secondaryRead.secondary==='read'&&secondaryRead.primary==='both'&&secondaryRead.editHidden&&secondaryRead.previewVisible,{secondaryDefault,secondaryRead});
  await click(page,'[data-nb="toggle-mode"][data-side="secondary"]'); await wait(80);
  const bothPanes=await page.evaluate(()=>({primary:document.querySelector('.nb-pane-primary .nb-body').dataset.mode,secondary:document.querySelector('.nb-pane-secondary .nb-body').dataset.mode,primarySyncHidden:document.querySelector('[data-nb="scroll-sync"][data-side="primary"]').hidden,secondarySyncHidden:document.querySelector('[data-nb="scroll-sync"][data-side="secondary"]').hidden}));
  check('each split pane reaches combined raw/rendered mode with its own Sync control',bothPanes.primary==='both'&&bothPanes.secondary==='both'&&!bothPanes.primarySyncHidden&&!bothPanes.secondarySyncHidden,bothPanes);
  const desktopSplitBefore=await page.evaluate(()=>({
    orientation:document.querySelector('[data-nb-resize="split"]').getAttribute('aria-orientation'),
    primary:document.querySelector('[data-nb-pane="primary"]').getBoundingClientRect().width,
    secondary:document.querySelector('[data-nb-pane="secondary"]').getBoundingClientRect().width,
    handle:(()=>{const r=document.querySelector('[data-nb-resize="split"]').getBoundingClientRect();return{x:r.x+r.width/2,y:r.y+r.height/2};})()
  }));
  await page.mouse.move(desktopSplitBefore.handle.x,desktopSplitBefore.handle.y);await page.mouse.down();await page.mouse.move(desktopSplitBefore.handle.x-85,desktopSplitBefore.handle.y,{steps:8});await page.mouse.up();await wait(100);
  const desktopSplitAfter=await page.evaluate(()=>({primary:document.querySelector('[data-nb-pane="primary"]').getBoundingClientRect().width,secondary:document.querySelector('[data-nb-pane="secondary"]').getBoundingClientRect().width,ratio:document.querySelector('[data-nb-workspace]').style.getPropertyValue('--nb-split-ratio')}));
  check('Desktop Split View resizer changes the two note pane widths',desktopSplitBefore.orientation==='vertical'&&desktopSplitAfter.primary>desktopSplitBefore.primary+25&&desktopSplitAfter.secondary<desktopSplitBefore.secondary-25, {before:desktopSplitBefore,after:desktopSplitAfter});

  await page.setViewport({width:390,height:844});await wait(180);
  await page.waitForFunction(()=>document.querySelector('[data-nb-resize="split"]')?.getAttribute('aria-orientation')==='horizontal',{timeout:3000}).catch(()=>{});
  const mobileSplitBefore=await page.evaluate(()=>({
    orientation:document.querySelector('[data-nb-resize="split"]').getAttribute('aria-orientation'),
    primary:document.querySelector('[data-nb-pane="primary"]').getBoundingClientRect().height,
    secondary:document.querySelector('[data-nb-pane="secondary"]').getBoundingClientRect().height,
    columns:getComputedStyle(document.querySelector('.nb-explorer')).gridTemplateColumns,
    handle:(()=>{const r=document.querySelector('[data-nb-resize="split"]').getBoundingClientRect();return{x:r.x+r.width/2,y:r.y+r.height/2};})()
  }));
  await page.mouse.move(mobileSplitBefore.handle.x,mobileSplitBefore.handle.y);await page.mouse.down();await page.mouse.move(mobileSplitBefore.handle.x,mobileSplitBefore.handle.y+55,{steps:8});await page.mouse.up();await wait(100);
  const mobileSplitAfter=await page.evaluate(()=>({primary:document.querySelector('[data-nb-pane="primary"]').getBoundingClientRect().height,secondary:document.querySelector('[data-nb-pane="secondary"]').getBoundingClientRect().height,ratio:document.querySelector('[data-nb-workspace]').style.getPropertyValue('--nb-split-ratio'),panelWidth:document.querySelector('#nbPanel').getBoundingClientRect().width,scrollWidth:document.querySelector('#nbPanel').scrollWidth}));
  check('Mobile Split View uses a horizontal handle and correctly resizes vertically without overflow',mobileSplitBefore.orientation==='horizontal'&&mobileSplitAfter.primary>mobileSplitBefore.primary+20&&mobileSplitAfter.secondary<mobileSplitBefore.secondary-20&&mobileSplitAfter.panelWidth<=390&&mobileSplitAfter.scrollWidth<=392,{before:mobileSplitBefore,after:mobileSplitAfter});
  await click(page,'[data-nb="close-split"]');await wait(120);

  await page.setViewport({width:390,height:500});await wait(120);
  await click(page,'[data-nb="properties-toggle"][data-side="primary"]');await wait(80);
  const propertyScroll=await page.evaluate(()=>{
    const outer=document.querySelector('[data-nb-properties="primary"] .nb-properties-scroll'),tags=document.querySelector('.nb-tag-options'),workspace=document.querySelector('.nb-workspace'),pane=document.querySelector('.nb-pane-primary');
    const visible=(selector)=>{const el=document.querySelector(selector),r=el&&el.getBoundingClientRect(),o=outer.getBoundingClientRect();return !!el&&r.width>0&&r.height>0&&r.top>=o.top-1&&r.bottom<=o.bottom+1;};
    const before={outerClient:outer.clientHeight,outerScroll:outer.scrollHeight,tagClientWidth:tags.clientWidth,tagScrollWidth:tags.scrollWidth,workspace:workspace.scrollTop,paneHeight:pane.clientHeight,tagColumns:getComputedStyle(document.querySelector('.nb-tag-manager-row')).gridTemplateColumns};
    outer.scrollTop=outer.scrollHeight;tags.scrollLeft=-tags.scrollWidth;
    return {before,outerTop:outer.scrollTop,tagLeft:tags.scrollLeft,workspaceTop:workspace.scrollTop,closeVisible:!!document.querySelector('[data-nb="properties-close"][data-side="primary"]'),
      toolbarHidden:getComputedStyle(document.querySelector('[data-nb-tools="primary"]')).display==='none',paneHeadHidden:getComputedStyle(document.querySelector('.nb-pane-primary .nb-pane-head')).display==='none',
      folderVisible:visible('[data-nb-property="folder"]'),categoryVisible:visible('[data-nb-property="category"]'),searchVisible:visible('[data-nb-tag-filter]'),newTagVisible:visible('[data-nb-property-new="tag"]'),addVisible:visible('.nb-tag-add')};
  });
  check('Mobile Properties uses the full pane, keeps Folder/Category/Tag controls in the first viewport, and scrolls Tag chips horizontally',propertyScroll.before.outerScroll<=propertyScroll.before.outerClient+2&&propertyScroll.before.tagScrollWidth>propertyScroll.before.tagClientWidth&&Math.abs(propertyScroll.tagLeft)>0&&propertyScroll.workspaceTop===propertyScroll.before.workspace&&propertyScroll.closeVisible&&propertyScroll.toolbarHidden&&propertyScroll.paneHeadHidden&&propertyScroll.folderVisible&&propertyScroll.categoryVisible&&propertyScroll.searchVisible&&propertyScroll.newTagVisible&&propertyScroll.addVisible,propertyScroll);
  await click(page,'[data-nb="properties-close"][data-side="primary"]');await wait(70);
  const afterClose=await page.evaluate(()=>({hidden:document.querySelector('[data-nb-properties="primary"]').hidden,editorVisible:getComputedStyle(document.querySelector('.nb-pane-primary .nb-body')).display!=='none',textAreaHeight:document.querySelector('#nbEdit').getBoundingClientRect().height}));
  check('Closing the mobile properties page restores the same full-height editor',afterClose.hidden&&afterClose.editorVisible&&afterClose.textAreaHeight>80,afterClose);

  await click(page,'[data-nb="back-list"]');await wait(100);
  await click(page,'.nb-card[data-nb="open"]');await wait(100);
  const reopenedNote=await page.evaluate(()=>({mode:document.querySelector('.nb-pane-primary .nb-body').dataset.mode,formatHidden:document.querySelector('[data-nb-formatbar="primary"]').hidden,previewHidden:document.querySelector('#nbPreview').hidden}));
  check('reopening any saved Note always starts in Edit, regardless of its previous mode',reopenedNote.mode==='edit'&&!reopenedNote.formatHidden&&reopenedNote.previewHidden,reopenedNote);
  await click(page,'[data-nb="back-list"]');await wait(80);
  const responsive=[];
  for(const width of [390,768,1024,1280,1440]){
    await page.setViewport({width,height:width===390?500:850});await wait(90);
    responsive.push(await page.evaluate(()=>{
      const panel=document.querySelector('#nbPanel'),explorer=document.querySelector('.nb-explorer'),side=document.querySelector('.nb-explorer-side'),main=document.querySelector('.nb-explorer-main');
      return {width:innerWidth,panelWidth:panel.getBoundingClientRect().width,panelScroll:panel.scrollWidth,columns:getComputedStyle(explorer).gridTemplateColumns.split(' ').length,sideVisible:side.getBoundingClientRect().width>0,mainVisible:main.getBoundingClientRect().width>0};
    }));
  }
  check('File Explorer stays two-pane and viewport-safe on mobile, tablet, laptop and desktop',responsive.every(x=>x.panelWidth<=x.width+1&&x.panelScroll<=x.width+2&&x.columns===2&&x.sideVisible&&x.mainVisible),responsive);

  const responsiveNotebook=[];
  for(const width of [390,768,1024,1280,1440]){
    await page.setViewport({width,height:width===390?500:850});await wait(80);
    await click(page,'.nb-card[data-nb="open"]');await wait(90);
    responsiveNotebook.push(await page.evaluate(()=>{
      const pane=document.querySelector('.nb-pane-primary'),tools=document.querySelector('[data-nb-tools="primary"]'),format=document.querySelector('[data-nb-formatbar="primary"]'),actions=tools.querySelector('.nb-actions'),panel=document.querySelector('#nbPanel');
      const toolbar={paneWidth:pane.clientWidth,panelWidth:panel.clientWidth,panelScroll:panel.scrollWidth,formatClient:format.clientWidth,formatScroll:format.scrollWidth,actionClient:actions.clientWidth,actionScroll:actions.scrollWidth,actionCount:actions.querySelectorAll('[data-nb]').length,mode:pane.querySelector('.nb-body').dataset.mode};
      document.querySelector('[data-nb="properties-toggle"][data-side="primary"]').click();
      const outer=pane.querySelector('.nb-properties-scroll'),row=pane.querySelector('.nb-tag-manager-row'),tagOptions=pane.querySelector('.nb-tag-options');
      const inside=selector=>{const el=pane.querySelector(selector),r=el.getBoundingClientRect(),o=outer.getBoundingClientRect();return r.width>0&&r.height>0&&r.top>=o.top-1&&r.bottom<=o.bottom+1};
      return {width:innerWidth,toolbar,property:{outerClient:outer.clientHeight,outerScroll:outer.scrollHeight,rowClient:row.clientWidth,rowScroll:row.scrollWidth,tagClient:tagOptions.clientWidth,tagScroll:tagOptions.scrollWidth,toolbarHidden:getComputedStyle(tools).display==='none',fields:[inside('[data-nb-property="folder"]'),inside('[data-nb-property="category"]'),inside('[data-nb-tag-filter]'),inside('[data-nb-property-new="tag"]'),inside('.nb-tag-add')]}};
    }));
    await click(page,'[data-nb="properties-close"][data-side="primary"]');await wait(45);await click(page,'[data-nb="back-list"]');await wait(55);
  }
  check('Icon Toolbar and one-row Tag Property management remain responsive from mobile through desktop',responsiveNotebook.every(x=>x.toolbar.mode==='edit'&&x.toolbar.actionCount===7&&x.toolbar.actionScroll<=x.toolbar.actionClient+1&&x.toolbar.panelScroll<=x.toolbar.panelWidth+2&&x.property.toolbarHidden&&x.property.rowScroll<=x.property.rowClient+2&&x.property.outerScroll<=x.property.outerClient+2&&x.property.fields.every(Boolean)),responsiveNotebook);

  check('Notebook fix run finishes without JavaScript or console errors',errors.length===0,errors);
  await browser.close();
  await new Promise(resolve=>testServer.close(resolve));
  console.log(`SUMMARY | ${failures.length?'FAIL':'PASS'} | ${failures.length} failure(s) | ${errors.length} runtime error(s)`);
  if(failures.length||errors.length)process.exit(1);
})().catch(error=>{console.error(error);if(testServer&&testServer.listening)testServer.close();process.exit(1);});
