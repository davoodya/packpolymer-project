const puppeteer = require('puppeteer');
const chromium = require('@sparticuz/chromium');
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

const failures = [], errors = [];
let server = null;
const wait = (ms = 120) => new Promise(resolve => setTimeout(resolve, ms));
function check(name, ok, detail) {
  console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}${detail === undefined ? '' : ' | ' + JSON.stringify(detail)}`);
  if (!ok) failures.push(name);
}
async function click(page, selector) {
  await page.evaluate(sel => {
    const el = document.querySelector(sel);
    if (!el) throw new Error('Missing element: ' + sel);
    el.click();
  }, selector);
}
async function setValue(page, selector, value, start, end) {
  await page.$eval(selector, (el, arg) => {
    el.focus(); el.value = arg.value;
    const a = Number.isInteger(arg.start) ? arg.start : el.value.length;
    const b = Number.isInteger(arg.end) ? arg.end : a;
    if (el.setSelectionRange) el.setSelectionRange(a, b);
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }, { value, start, end });
}
async function key(page, value) { await page.keyboard.press(value); }
function tinyPng() {
  return Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p7cAAAAASUVORK5CYII=', 'base64');
}
async function pasteFile(page, selector, name, type, buffer) {
  return page.$eval(selector, (el, arg) => {
    el.focus();
    const transfer = new DataTransfer();
    transfer.items.add(new File([new Uint8Array(arg.bytes)], arg.name, { type: arg.type }));
    const event = new ClipboardEvent('paste', { clipboardData: transfer, bubbles: true, cancelable: true });
    return { uncanceled: el.dispatchEvent(event), size: transfer.files[0].size };
  }, { name, type, bytes: Array.from(buffer) });
}

(async () => {
  const browser = await puppeteer.launch({
    executablePath: await chromium.executablePath(),
    args: [...chromium.args, '--no-sandbox', '--disable-dev-shm-usage'],
    headless: true
  });
  try {
    const page = await browser.newPage();
    await page.evaluateOnNewDocument(() => { try { delete window.showDirectoryPicker; } catch (_) { window.showDirectoryPicker = undefined; } });
    page.on('pageerror', error => errors.push(error.message));
    page.on('console', message => {
      if (message.type() === 'error' && !/scrollTo|not implemented|media/i.test(message.text())) errors.push(message.text());
    });
    await page.setViewport({ width: 1280, height: 900 });
    const html = fs.readFileSync('/home/user/packpolymer-marketplace-roadmap.html');
    server = http.createServer((req, res) => {
      const route = (req.url || '/').split('?')[0];
      if (route === '/seed.html') { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); res.end('<!doctype html><html><body>seed</body></html>'); }
      else if (route === '/answers-roadmap.json') { res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' }); res.end('{}'); }
      else { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(html); }
    });
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
    const origin = 'http://127.0.0.1:' + server.address().port;
    await page.goto(origin + '/seed.html', { waitUntil: 'load' });
    await page.evaluate(() => {
      const now = new Date().toISOString();
      const note = (id, title) => ({ id, title, body: '', folderId: '', category: '', tags: [], createdAt: now, updatedAt: now });
      localStorage.setItem('packpolymer-marketplace-roadmap-v2', JSON.stringify({
        nbNotes: [note('enter-note', 'Enter note'), note('secondary-note', 'Second note')],
        nbActiveId: 'enter-note', nbSecondaryId: 'secondary-note', nbFolders: [], nbTags: [], nbCategories: [],
        nbBrowseMode: 'all', nbBrowseValue: '', nbSort: 'updated', nbView: 'note', nbMode: 'edit', nbSecondaryMode: 'edit', nbSplit: false,
        nbSplitRatio: .5, nbWidthPct: 75, nbBodyRatio: .5, nbBodyRatioSecondary: .5,
        openNotes: {}, noteModes: {}, notes: {}, ui: { nbOpen: false }
      }));
    });
    await page.goto(origin + '/packpolymer-marketplace-roadmap.html', { waitUntil: 'load', timeout: 60000 });
    await wait(450);
    await click(page, '#fabNote');
    await page.waitForFunction(() => document.querySelector('#nbPanel')?.classList.contains('open'));

    const initialAutoScroll = await page.$eval('[data-nb="typewriter"][data-side="primary"]', button => ({ pressed: button.getAttribute('aria-pressed'), hidden: button.hidden, label: button.title }));
    check('Auto Scroll by follow Text is available in the Notebook toolbar and starts disabled', initialAutoScroll.pressed === 'false' && !initialAutoScroll.hidden && initialAutoScroll.label.includes('Auto Scroll by follow Text'), initialAutoScroll);
    const longText = Array.from({ length: 150 }, (_, i) => `Line ${String(i + 1).padStart(3, '0')} — text for centered caret scrolling.`).join('\n');
    await page.$eval('#nbEdit', (ta, text) => {
      ta.focus(); ta.value = text;
      const pos = text.indexOf('Line 075') + 'Line 075 —'.length;
      ta.setSelectionRange(pos, pos); ta.scrollTop = 0; ta.dispatchEvent(new Event('input', { bubbles: true }));
    }, longText);
    await wait(140);
    const autoOff = await page.$eval('#nbEdit', ta => ({ top: ta.scrollTop, max: ta.scrollHeight - ta.clientHeight }));
    await click(page, '[data-nb="typewriter"][data-side="primary"]');
    await wait(120);
    const autoOn = await page.evaluate(() => {
      const ta = document.querySelector('#nbEdit'), button = document.querySelector('[data-nb="typewriter"][data-side="primary"]');
      return { top: ta.scrollTop, max: ta.scrollHeight - ta.clientHeight, pressed: button.getAttribute('aria-pressed'), active: document.activeElement === ta };
    });
    check('Auto Scroll centers the active caret only after the user turns it on', autoOff.top === 0 && autoOn.pressed === 'true' && autoOn.active && autoOn.top > 250 && autoOn.top < autoOn.max - 100, { autoOff, autoOn });
    await click(page, '[data-nb="typewriter"][data-side="primary"]');
    const autoDisabled = await page.evaluate(() => {
      const ta = document.querySelector('#nbEdit'), button = document.querySelector('[data-nb="typewriter"][data-side="primary"]');
      ta.scrollTop = 0; ta.dispatchEvent(new Event('input', { bubbles: true }));
      return new Promise(resolve => setTimeout(() => resolve({ top: ta.scrollTop, pressed: button.getAttribute('aria-pressed') }), 100));
    });
    check('Auto Scroll can be toggled back off without moving the editor viewport', autoDisabled.top === 0 && autoDisabled.pressed === 'false', autoDisabled);

    await click(page, '[data-nb="split-toggle"]');
    await page.waitForFunction(() => !document.querySelector('[data-nb-pane="secondary"]')?.hidden);
    const secondaryAuto = await page.$eval('[data-nb="typewriter"][data-side="secondary"]', button => ({ pressed: button.getAttribute('aria-pressed'), hidden: button.hidden }));
    await page.$eval('#nbEditSecondary', ta => {
      const value = Array.from({ length: 90 }, (_, i) => `Second line ${i + 1}`).join('\n');
      ta.focus(); ta.value = value; const pos = value.indexOf('Second line 45') + 10; ta.setSelectionRange(pos, pos); ta.scrollTop = 0; ta.dispatchEvent(new Event('input', { bubbles: true }));
    });
    await click(page, '[data-nb="typewriter"][data-side="secondary"]'); await wait(120);
    const secondaryAfter = await page.$eval('#nbEditSecondary', ta => ta.scrollTop);
    check('Split Notebook panes have independent Auto Scroll switches, both defaulting off', secondaryAuto.pressed === 'false' && !secondaryAuto.hidden && secondaryAfter > 150, { secondaryAuto, secondaryAfter });

    // Enter in each create-value control should run the matching create action.
    await click(page, '[data-nb="back-list"]');
    await page.waitForFunction(() => !document.querySelector('[data-nb-listview]')?.hidden);
    async function enterCreate(selector, value) {
      await page.$eval(selector, (el, text) => { el.focus(); el.value = text; el.dispatchEvent(new Event('input', { bubbles: true })); }, value);
      await key(page, 'Enter'); await wait(90);
    }
    await click(page, '[data-nb="browse-mode"][data-mode="folders"]');
    await enterCreate('[data-nb-facet-input="folders"]', 'Enter-created folder');
    await click(page, '[data-nb="browse-mode"][data-mode="categories"]');
    await enterCreate('[data-nb-facet-input="categories"]', 'Enter-created category');
    await click(page, '[data-nb="browse-mode"][data-mode="tags"]');
    await enterCreate('[data-nb-facet-input="tags"]', 'Enter-created tag');
    const facetEnter = await page.evaluate(() => {
      const d = JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2') || '{}');
      return { folders: d.nbFolders?.map(x => x.name), categories: d.nbCategories, tags: d.nbTags };
    });
    check('Enter creates folders, categories, and tags in the Notebook list sidebar', facetEnter.folders?.includes('Enter-created folder') && facetEnter.categories?.includes('Enter-created category') && facetEnter.tags?.includes('Enter-created tag'), facetEnter);
    await click(page, '[data-nb="browse-mode"][data-mode="all"]');

    await click(page, '[data-nb="open"][data-id="enter-note"]');
    await page.waitForFunction(() => document.querySelector('[data-nb-title="primary"]')?.value === 'Enter note');
    await click(page, '[data-nb="properties-toggle"][data-side="primary"]');
    await enterCreate('[data-nb-property-new="folder"][data-side="primary"]', 'Properties folder');
    await enterCreate('[data-nb-property-new="category"][data-side="primary"]', 'Properties category');
    await enterCreate('[data-nb-property-new="tag"][data-side="primary"]', 'Properties tag');
    const propertiesEnter = await page.evaluate(() => {
      const d = JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2') || '{}'), n = d.nbNotes?.find(x => x.id === 'enter-note');
      return { folder: d.nbFolders?.find(x => x.id === n?.folderId)?.name, category: n?.category, tags: n?.tags };
    });
    check('Enter creates and assigns folder/category/tag from the Notebook Properties page', propertiesEnter.folder === 'Properties folder' && propertiesEnter.category === 'Properties category' && propertiesEnter.tags?.includes('Properties tag'), propertiesEnter);

    await click(page, '[data-nb="properties-close"][data-side="primary"]');
    await click(page, '[data-nb="back-list"]');
    await click(page, '.nb-card[data-id="enter-note"] [data-nb="metadata-edit"]');
    await enterCreate('[data-nb-card-new="folder"]', 'Sidebar card folder');
    await enterCreate('[data-nb-card-field="category"]', 'Sidebar card category');
    await enterCreate('[data-nb-card-new="tag"]', 'Sidebar card tag');
    await click(page, '[data-nb="metadata-save"][data-id="enter-note"]');
    const cardEnter = await page.evaluate(() => {
      const d = JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2') || '{}'), n = d.nbNotes?.find(x => x.id === 'enter-note');
      return { folder: d.nbFolders?.find(x => x.id === n?.folderId)?.name, category: n?.category, tags: n?.tags };
    });
    check('Enter creates values from the Sidebar card editor and Save commits them to the note', cardEnter.folder === 'Sidebar card folder' && cardEnter.category === 'Sidebar card category' && cardEnter.tags?.includes('Sidebar card tag'), cardEnter);
    await click(page, '[data-nb="browse-mode"][data-mode="all"]');

    // Notebook Read padding: mixed-direction list markers should remain inside the pane.
    await click(page, '[data-nb="open"][data-id="enter-note"]');
    const listBody = '- English bullet with a long sentence that wraps on narrow screens and stays inside the editor pane.\n- فارسی: متن مورد دوم با نشانه گلوله\n  - Nested English line inside the RTL list\n- Final item';
    await setValue(page, '#nbEdit', listBody);
    await click(page, '[data-nb="toggle-mode"][data-side="primary"]');
    await page.waitForFunction(() => document.querySelector('#nbPreview') && !document.querySelector('#nbPreview').hidden);
    const notebookPadding = [];
    for (const width of [1600, 1280, 1024, 768, 390, 320]) {
      await page.setViewport({ width, height: width <= 390 ? 844 : 900 }); await wait(90);
      notebookPadding.push(await page.evaluate(() => {
        const root = document.querySelector('#nbPreview'), list = root?.querySelector('ul'), li = list?.querySelector('li');
        const rr = root?.getBoundingClientRect(), lr = list?.getBoundingClientRect(), item = li?.getBoundingClientRect();
        return { width: innerWidth, overflow: root ? root.scrollWidth - root.clientWidth : 999, listLeft: lr?.left, listRight: lr?.right, rootLeft: rr?.left, rootRight: rr?.right, itemLeft: item?.left, itemRight: item?.right, paddingLeft: list ? parseFloat(getComputedStyle(list).paddingLeft) : 0 };
      }));
    }
    check('Notebook Reading Mode keeps mixed RTL/LTR bullets and text within the Read pane at desktop through mobile widths', notebookPadding.every(x => x.overflow <= 2 && x.listLeft >= x.rootLeft - 1 && x.listRight <= x.rootRight + 1 && x.itemLeft >= x.rootLeft - 1 && x.itemRight <= x.rootRight + 1 && x.paddingLeft >= 18), notebookPadding);

    await click(page, '#nbPanel [data-nb="close"]');
    await wait(120);
    await click(page, '.phase-note-toggle');
    await page.waitForFunction(() => !!document.querySelector('.note-wrap.show textarea[data-note]'));
    const noteEditor = '.note-wrap.show textarea[data-note]';
    await setValue(page, noteEditor, listBody);
    await click(page, '.note-wrap.show .note-mode-btn');
    await page.waitForFunction(() => !!document.querySelector('.note-wrap.show .note-read:not([hidden])'));
    const notePadding = [];
    for (const width of [1600, 1280, 1024, 768, 390, 320]) {
      await page.setViewport({ width, height: width <= 390 ? 844 : 900 }); await wait(70);
      notePadding.push(await page.evaluate(() => {
        const root = document.querySelector('.note-wrap.show .note-read'), list = root?.querySelector('ul'), li = list?.querySelector('li');
        const rr = root?.getBoundingClientRect(), lr = list?.getBoundingClientRect(), ir = li?.getBoundingClientRect();
        return { width: innerWidth, overflow: root ? root.scrollWidth - root.clientWidth : 999, listLeft: lr?.left, listRight: lr?.right, rootLeft: rr?.left, rootRight: rr?.right, itemLeft: ir?.left, itemRight: ir?.right, paddingLeft: root ? parseFloat(getComputedStyle(root).paddingLeft) : 0 };
      }));
    }
    check('Written-note Read pane adds safe physical left padding and avoids horizontal overflow at all target widths', notePadding.every(x => x.overflow <= 2 && x.listLeft >= x.rootLeft - 1 && x.listRight <= x.rootRight + 1 && x.itemLeft >= x.rootLeft - 1 && x.itemRight <= x.rootRight + 1 && x.paddingLeft >= 12), notePadding);

    // Unsupported browsers receive an explicit IndexedDB Blob fallback, never an inline Data URI.
    await click(page, '#nbPanel [data-nb="close"]');
    await click(page, '#fabNote'); await wait(100);
    await click(page, '[data-nb="open"][data-id="enter-note"]');
    if (await page.$eval('[data-nb="toggle-mode"][data-side="primary"]', b => document.querySelector('#nbEdit').hidden)) await click(page, '[data-nb="toggle-mode"][data-side="primary"]');
    await setValue(page, '#nbEdit', 'Fallback attachment: ');
    const pasteResult = await pasteFile(page, '#nbEdit', 'fallback.png', 'image/png', tinyPng());
    await page.waitForFunction(() => /!\[\[attachments\/[^\]]+\.png\]\]/.test(document.querySelector('#nbEdit')?.value || ''), { timeout: 8000 }).catch(() => {});
    const fallbackRef = await page.$eval('#nbEdit', ta => ta.value.match(/!\[\[(attachments\/[^\]]+)\]\]/)?.[1] || '');
    await wait(380);
    const fallbackData = await page.evaluate(async name => {
      const db = await new Promise(resolve => { const req = indexedDB.open('packpolymer-roadmap', 1); req.onsuccess = () => resolve(req.result); req.onerror = () => resolve(null); });
      if (!db) return { found: false, size: 0, indexed: false };
      const values = await new Promise(resolve => { const tx = db.transaction('kv', 'readonly'), store = tx.objectStore('kv'), req = store.get('roadmap-attachment:' + name); req.onsuccess = () => resolve({ blob: req.result, indexReq: store.get('attachmentIndex') }); req.onerror = () => resolve({}); });
      const index = await new Promise(resolve => { const tx = db.transaction('kv', 'readonly'), req = tx.objectStore('kv').get('attachmentIndex'); req.onsuccess = () => resolve(req.result || []); req.onerror = () => resolve([]); });
      return { found: values.blob instanceof Blob, size: values.blob?.size || 0, indexed: Array.isArray(index) && index.includes(name), toast: document.querySelector('#toast')?.textContent || '' };
    }, fallbackRef.slice('attachments/'.length));
    check('Browsers without directory-write support store the original Blob in IndexedDB and clearly announce the fallback', !pasteResult.uncanceled && !!fallbackRef && fallbackData.found && fallbackData.size === tinyPng().length && fallbackData.indexed && fallbackData.toast.includes('حافظه محلی مرورگر'), { pasteResult, fallbackRef, fallbackData });
    await click(page, '#nbPanel [data-nb="close"]'); await wait(350);
    await page.reload({ waitUntil: 'load', timeout: 60000 }); await wait(350);
    await page.waitForSelector('#nbPanel');
    if (!await page.$eval('#nbPanel', panel => panel.classList.contains('open'))) await click(page, '#fabNote');
    await page.waitForFunction(() => document.querySelector('#nbPanel')?.classList.contains('open'), { timeout: 5000 });
    await click(page, '[data-nb="toggle-mode"][data-side="primary"]'); await wait(350);
    const fallbackRender = await page.evaluate(() => { const img=document.querySelector('#nbPreview img.md-image'); return { src:img?.src||'', path:img?.dataset.attachmentPath||'' }; });
    check('IndexedDB fallback survives a page reload and renders the attachment from a Blob URL', fallbackRender.src.startsWith('blob:') && fallbackRender.path === fallbackRef, fallbackRender);

    check('Input, Auto Scroll, padding, and attachment fallback suite has no uncaught errors', errors.length === 0, errors);
    console.log(`SUMMARY | ${failures.length ? 'FAIL' : 'PASS'} | ${failures.length} failure(s) | ${errors.length} runtime error(s)`);
  } finally {
    if (server) await new Promise(resolve => server.close(resolve));
    await browser.close();
  }
  process.exitCode = failures.length ? 1 : 0;
})();
