const puppeteer = require('puppeteer');
const chromium = require('@sparticuz/chromium');
const http = require('http');
const fs = require('fs');

let testServer = null;
const failures = [];
const errors = [];
const wait = (ms = 100) => new Promise(resolve => setTimeout(resolve, ms));
function check(name, ok, detail) {
  console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}${detail === undefined ? '' : ' | ' + JSON.stringify(detail)}`);
  if (!ok) failures.push(name);
}
async function click(page, selector) {
  await page.evaluate(sel => {
    const el = document.querySelector(sel);
    if (!el) throw new Error('Missing element: ' + sel);
    el.click();
  }, selector);
}
async function setValue(page, selector, value) {
  await page.$eval(selector, (el, text) => {
    el.value = text;
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }, value);
}
async function drag(page, from, to) {
  await page.mouse.move(from.x, from.y);
  await page.mouse.down();
  await page.mouse.move(to.x, to.y, { steps: 10 });
  await page.mouse.up();
  await wait(120);
}

(async () => {
  const browser = await puppeteer.launch({
    executablePath: await chromium.executablePath(),
    args: [...chromium.args, '--no-sandbox', '--disable-dev-shm-usage'],
    headless: true
  });
  try {
    const page = await browser.newPage();
    page.on('pageerror', e => errors.push(e.message));
    page.on('console', m => {
      if (m.type() === 'error' && !/scrollTo|not implemented/i.test(m.text())) errors.push(m.text());
    });
    await page.setViewport({ width: 1440, height: 900 });
    const html = fs.readFileSync('/home/user/packpolymer-marketplace-roadmap.html');
    const sidecar = fs.readFileSync('/home/user/answers-roadmap.json');
    testServer = http.createServer((req, res) => {
      const path = (req.url || '/').split('?')[0];
      if (path === '/seed.html') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
        res.end('<!doctype html><html><body>seed</body></html>');
      } else if (path === '/' || path === '/packpolymer-marketplace-roadmap.html') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
        res.end(html);
      } else if (path === '/answers-roadmap.json') {
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
        res.end(sidecar);
      } else {
        res.writeHead(404); res.end('Not found');
      }
    });
    await new Promise(resolve => testServer.listen(0, '127.0.0.1', resolve));
    const origin = 'http://127.0.0.1:' + testServer.address().port;
    await page.goto(origin + '/seed.html', { waitUntil: 'load', timeout: 60000 });
    await page.evaluate(() => {
      const now = new Date().toISOString();
      const many = n => Array.from({ length: n }, (_, i) => `Paragraph ${i + 1}: Long text for checking independent edit, read, and synchronized scrolling.`).join('\n\n');
      const notes = [
        { id: 'enh-note-a', title: 'Markdown verification', body: many(260), folderId: '', category: '', tags: ['alpha', 'beta'], createdAt: now, updatedAt: now },
        { id: 'enh-note-b', title: 'Second pane', body: many(180), folderId: '', category: '', tags: ['gamma'], createdAt: now, updatedAt: now },
        { id: 'enh-note-c', title: 'Third note', body: 'A short saved note.', folderId: '', category: '', tags: ['delta'], createdAt: now, updatedAt: now }
      ];
      localStorage.setItem('packpolymer-marketplace-roadmap-v2', JSON.stringify({
        nbNotes: notes, nbActiveId: notes[0].id, nbSecondaryId: notes[1].id,
        nbFolders: [], nbTags: ['alpha', 'beta', 'gamma', 'delta'], nbCategories: [],
        nbView: 'list', nbMode: 'edit', nbSecondaryMode: 'edit', nbSplit: false,
        nbSplitRatio: .5, ui: { nbOpen: false }
      }));
    });
    await page.goto(origin + '/packpolymer-marketplace-roadmap.html', { waitUntil: 'load', timeout: 60000 });
    await wait(550);
    await click(page, '#fabNote');
    await page.waitForFunction(() => document.querySelector('#nbPanel')?.classList.contains('open'), { timeout: 5000 });
    await wait(380);

    const initialDesktop = await page.evaluate(() => {
      const panel = document.querySelector('#nbPanel'), handle = document.querySelector('[data-nb-resize="width"]');
      const pr = panel.getBoundingClientRect(), hr = handle.getBoundingClientRect();
      return {
        width: innerWidth, scrollX, docWidth: document.documentElement.scrollWidth, bodyWidth: document.body.scrollWidth, panelWidth: pr.width, left: pr.left, right: pr.right,
        active: document.activeElement && (document.activeElement.id || document.activeElement.tagName), styleWidth: panel.style.width, handleHidden: handle.hidden,
        handleLeft: hr.left, mode: document.querySelector('.nb-pane-primary .nb-body').dataset.mode,
        formatCount: document.querySelectorAll('[data-nb-formatbar="primary"] .nb-format-button').length,
        actionNames: [...document.querySelectorAll('[data-nb-tools="primary"] .nb-actions [data-nb]')].map(x => x.dataset.nb),
        buttonSizes: [...document.querySelectorAll('[data-nb-tools="primary"] .nb-format-button,[data-nb-tools="primary"] .nb-action-button')].map(x => {
          const r = x.getBoundingClientRect(); return [Math.round(r.width), Math.round(r.height)];
        }),
        toolY: document.querySelector('[data-nb-formatbar="primary"]').getBoundingClientRect().top,
        actionY: document.querySelector('[data-nb-tools="primary"] .nb-actions').getBoundingClientRect().top,
        groupDivider: getComputedStyle(document.querySelector('[data-nb-tools="primary"] .nb-toolbar-split')).display
      };
    });
    check('Desktop opens at exactly 75vw and puts the Notebook resize handle on the left edge', initialDesktop.panelWidth === 1080 && Math.abs(initialDesktop.left - 360) < 1 && Math.abs(initialDesktop.right - 1440) < 1 && Math.abs(initialDesktop.handleLeft - initialDesktop.left) < 2 && !initialDesktop.handleHidden, initialDesktop);
    check('Markdown toolbar has all 22 tools and seven separate actions on one desktop row, with equal 30px icons', initialDesktop.formatCount === 22 && initialDesktop.actionNames.join(',') === 'copy,share,download,duplicate,new2,delete,typewriter' && Math.abs(initialDesktop.toolY - initialDesktop.actionY) < 2 && initialDesktop.groupDivider !== 'none' && initialDesktop.buttonSizes.every(x => x[0] === 30 && x[1] === 30), initialDesktop);

    const widthHandle = await page.evaluate(() => {
      const r = document.querySelector('[data-nb-resize="width"]').getBoundingClientRect();
      return { x: r.x + r.width / 2, y: r.y + r.height / 2 };
    });
    await drag(page, widthHandle, { x: 576, y: widthHandle.y });
    const width60 = await page.evaluate(() => ({ width: document.querySelector('#nbPanel').getBoundingClientRect().width, saved: JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2') || '{}').nbWidthPct }));
    check('Desktop left-edge drag resizes Notebook to 60% and saves the chosen width', Math.abs(width60.width - 864) < 2 && width60.saved === 60, width60);
    await page.$eval('[data-nb-resize="width"]', el => {
      el.focus();
      for (let i = 0; i < 30; i++) el.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true }));
    });
    const widthMin = await page.evaluate(() => ({ width: document.querySelector('#nbPanel').getBoundingClientRect().width, aria: document.querySelector('[data-nb-resize="width"]').getAttribute('aria-valuenow') }));
    await page.$eval('[data-nb-resize="width"]', el => {
      for (let i = 0; i < 30; i++) el.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowLeft', bubbles: true }));
    });
    const widthMax = await page.evaluate(() => ({ width: document.querySelector('#nbPanel').getBoundingClientRect().width, aria: document.querySelector('[data-nb-resize="width"]').getAttribute('aria-valuenow') }));
    check('Notebook resize is clamped to 50% minimum and 100% maximum', widthMin.aria === '50' && Math.abs(widthMin.width - 720) < 2 && widthMax.aria === '100' && Math.abs(widthMax.width - 1440) < 2, { widthMin, widthMax });
    const handleAt100 = await page.evaluate(() => { const r = document.querySelector('[data-nb-resize="width"]').getBoundingClientRect(); return { x: r.x + r.width / 2, y: r.y + r.height / 2 }; });
    await drag(page, handleAt100, { x: 360, y: handleAt100.y });

    const widthProfiles = [];
    for (const width of [1440, 1280, 1024, 768, 390]) {
      await page.setViewport({ width, height: width === 390 ? 844 : 850 });
      await page.waitForFunction(({ expected, desktop }) => {
        const panel=document.querySelector('#nbPanel'),handle=document.querySelector('[data-nb-resize="width"]');
        return panel&&handle&&Math.abs(panel.getBoundingClientRect().width-expected)<2&&handle.hidden===!desktop;
      }, { timeout: 5000 }, { expected: width >= 1440 ? width * .75 : width, desktop: width >= 1440 });
      await wait(100);
      widthProfiles.push(await page.evaluate(() => {
        const panel = document.querySelector('#nbPanel'), handle = document.querySelector('[data-nb-resize="width"]');
        const format = document.querySelector('[data-nb-formatbar="primary"]'), actions = document.querySelector('[data-nb-tools="primary"] .nb-actions');
        const split = document.querySelector('[data-nb-tools="primary"] .nb-toolbar-split');
        const p = panel.getBoundingClientRect();
        return {
          width: innerWidth, panelWidth: p.width, panelScroll: panel.scrollWidth,
          resizeHidden: handle.hidden, formatY: format.getBoundingClientRect().top, actionsY: actions.getBoundingClientRect().top,
          separator: getComputedStyle(split).display,
          formatCount: format.querySelectorAll('.nb-format-button').length,
          actionCount: actions.querySelectorAll('[data-nb]').length,
          iconSizes: [...document.querySelectorAll('[data-nb-tools="primary"] .nb-format-button,[data-nb-tools="primary"] .nb-action-button')].map(x => Math.round(x.getBoundingClientRect().width))
        };
      }));
    }
    check('Laptop/desktop retain the single-row toolbar; tablet/mobile use responsive rows, and only desktop exposes width resize', widthProfiles.every(x => {
      const desktop = x.width >= 1440, row = x.width >= 1024;
      return x.panelWidth <= x.width + 1 && x.panelScroll <= x.width + 2 && x.resizeHidden === !desktop && x.formatCount === 22 && x.actionCount === 7 && x.iconSizes.every(n => n === 30) && (row ? Math.abs(x.formatY - x.actionsY) < 2 && x.separator !== 'none' : x.actionsY > x.formatY + 20 && x.separator === 'none');
    }), widthProfiles);

    await page.setViewport({ width: 1440, height: 900 }); await wait(150);
    const property = await page.evaluate(() => {
      document.querySelector('[data-nb="properties-toggle"][data-side="primary"]').click();
      const select = document.querySelector('[data-nb-properties="primary"] select');
      const input = document.querySelector('[data-nb-properties="primary"] input');
      return { font: parseFloat(getComputedStyle(select).fontSize), selectHeight: select.getBoundingClientRect().height, inputHeight: input.getBoundingClientRect().height };
    });
    check('Properties controls in a Note use a modestly larger, standard size', property.font >= 12 && property.selectHeight >= 36 && property.inputHeight >= 36, property);
    await click(page, '[data-nb="properties-close"][data-side="primary"]'); await wait(80);

    await click(page, '[data-nb="toggle-mode"][data-side="primary"]');
    await click(page, '[data-nb="toggle-mode"][data-side="primary"]');
    await page.waitForFunction(() => document.querySelector('.nb-pane-primary .nb-body')?.dataset.mode === 'both', { timeout: 4000 });
    const markdown = [
      '#### Heading Four', '##### Heading Five', '###### Heading Six', '',
      '**bold** *italic* ***bold italic*** ~~removed~~ ==highlighted==', '',
      '`inline code` and ``code with `tick` inside``', '',
      '```js', 'const total = 3;', '```', '',
      '> [!NOTE] Title', '> Contents with **detail**.', '',
      'Setext level one', '================', '', 'Setext level two', '----------------', '',
      '- parent', '  - child', '- sibling', '',
      '[Documentation][docs]', '', '[docs]: https://example.com/docs "Reference title"', '',
      '| Left | Right |', '|:---|---:|', '| Alpha | Beta |', '',
      '<script>not executable</script>'
    ].join('\n');
    await setValue(page, '#nbEdit', markdown);
    const render = await page.evaluate(() => {
      const preview = document.querySelector('#nbPreview');
      const callout = preview.querySelector('.md-callout');
      const ref = [...preview.querySelectorAll('a')].find(a => a.textContent.includes('Documentation'));
      const nested = [...preview.querySelectorAll('ul li ul li')].map(x => x.textContent.trim());
      return {
        immediate: preview.innerText.includes('Heading Four') && preview.innerText.includes('not executable'),
        headings: ['h4','h5','h6'].map(sel => !!preview.querySelector(sel)),
        strongItalic: [...preview.querySelectorAll('strong em')].some(x => x.textContent === 'bold italic'),
        highlight: [...preview.querySelectorAll('mark')].some(x => x.textContent === 'highlighted'),
        inlineCode: [...preview.querySelectorAll('code')].some(x => x.textContent === 'inline code') && [...preview.querySelectorAll('code')].some(x => x.textContent === 'code with `tick` inside'),
        fenced: !!preview.querySelector('.md-pre code.language-js') && preview.querySelector('.md-pre').textContent.includes('const total = 3;'),
        callout: !!callout && callout.classList.contains('md-callout-note') && callout.querySelector('.md-callout-title')?.textContent === 'Title' && callout.querySelector('.md-callout-body')?.textContent.includes('Contents with detail.'),
        setext: !!preview.querySelector('h1') && [...preview.querySelectorAll('h2')].some(x => x.textContent.includes('Setext level two')),
        nested: nested.includes('child'),
        reference: !!ref && ref.href === 'https://example.com/docs' && ref.title === 'Reference title',
        table: preview.querySelectorAll('.md-table th').length === 2 && preview.querySelector('.md-table th[style*="left"]') !== null && preview.querySelector('.md-table th[style*="right"]') !== null,
        rawHtmlSafe: preview.querySelector('script') === null && preview.innerText.includes('<script>not executable</script>')
      };
    });
    check('Raw Markdown updates the Read pane immediately and renders headings, emphasis, highlight, code, callout, lists, references and tables', render.immediate && render.headings.every(Boolean) && render.strongItalic && render.highlight && render.inlineCode && render.fenced && render.callout && render.setext && render.nested && render.reference && render.table && render.rawHtmlSafe, render);

    const toolbarOutputs = [];
    await setValue(page, '#nbEdit', 'Text');
    await page.$eval('#nbEdit', el => el.setSelectionRange(0, el.value.length));
    await click(page, '[data-nb="fmt"][data-v="bolditalic"][data-side="primary"]');
    toolbarOutputs.push(await page.$eval('#nbEdit', el => el.value === '***Text***'));
    await setValue(page, '#nbEdit', 'Text');
    await page.$eval('#nbEdit', el => el.setSelectionRange(0, el.value.length));
    await click(page, '[data-nb="fmt"][data-v="highlight"][data-side="primary"]');
    toolbarOutputs.push(await page.$eval('#nbEdit', el => el.value === '==Text=='));
    await setValue(page, '#nbEdit', 'A heading');
    await click(page, '[data-nb="fmt"][data-v="h6"][data-side="primary"]');
    toolbarOutputs.push(await page.$eval('#nbEdit', el => el.value === '###### A heading'));
    await setValue(page, '#nbEdit', 'const n = 1;');
    await page.$eval('#nbEdit', el => el.setSelectionRange(0, el.value.length));
    await click(page, '[data-nb="fmt"][data-v="codeblock"][data-side="primary"]');
    toolbarOutputs.push(await page.$eval('#nbEdit', el => el.value === '```\nconst n = 1;\n```'));
    await setValue(page, '#nbEdit', 'Contents');
    await page.$eval('#nbEdit', el => el.setSelectionRange(0, el.value.length));
    await click(page, '[data-nb="fmt"][data-v="callout"][data-side="primary"]');
    toolbarOutputs.push(await page.$eval('#nbEdit', el => el.value === '> [!NOTE] Title\n> Contents'));
    check('Bold Italic, Highlight, H6, Code Block, and Callout toolbar buttons insert the requested Markdown syntax', toolbarOutputs.every(Boolean), toolbarOutputs);

    const long = Array.from({ length: 300 }, (_, i) => `Sync paragraph ${i + 1}: comparison text for editor and preview scrolling.`).join('\n\n');
    await setValue(page, '#nbEdit', long);
    await click(page, '[data-nb="scroll-sync"][data-side="primary"]');
    const syncForward = await page.evaluate(() => {
      const edit = document.querySelector('#nbEdit'), preview = document.querySelector('#nbPreview');
      edit.scrollTop = edit.scrollHeight * .72; edit.dispatchEvent(new Event('scroll', { bubbles: true }));
      return new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve({
        enabled: document.querySelector('[data-nb="scroll-sync"][data-side="primary"]').getAttribute('aria-pressed'),
        edit: edit.scrollTop / (edit.scrollHeight - edit.clientHeight),
        preview: preview.scrollTop / (preview.scrollHeight - preview.clientHeight)
      }))));
    });
    await page.evaluate(() => {
      const edit = document.querySelector('#nbEdit');
      edit.value += '\n\nImmediate marker after input';
      edit.dispatchEvent(new Event('input', { bubbles: true }));
    });
    await wait(120);
    const live = await page.evaluate(() => {
      const edit = document.querySelector('#nbEdit'), preview = document.querySelector('#nbPreview');
      return { marker: preview.innerText.includes('Immediate marker after input'), editRatio: edit.scrollTop / Math.max(1, edit.scrollHeight - edit.clientHeight), previewRatio: preview.scrollTop / Math.max(1, preview.scrollHeight - preview.clientHeight) };
    });
    check('Sync Scrolling stays proportional and re-aligns the Read pane after live Edit changes', syncForward.enabled === 'true' && Math.abs(syncForward.edit - syncForward.preview) < .04 && live.marker && Math.abs(live.editRatio - live.previewRatio) < .06, { syncForward, live });

    const editPaneBefore = await page.evaluate(() => {
      const edit = document.querySelector('#nbEdit'), preview = document.querySelector('#nbPreview'), divider = document.querySelector('[data-nb-resize="body-primary"]');
      const r = divider.getBoundingClientRect();
      return { orientation: divider.getAttribute('aria-orientation'), edit: edit.getBoundingClientRect().width, preview: preview.getBoundingClientRect().width, handle: { x: r.x + r.width / 2, y: r.y + r.height / 2 }, ratio: divider.getAttribute('aria-valuenow') };
    });
    await drag(page, editPaneBefore.handle, { x: editPaneBefore.handle.x - 50, y: editPaneBefore.handle.y });
    const editPaneAfter = await page.evaluate(() => ({
      edit: document.querySelector('#nbEdit').getBoundingClientRect().width,
      preview: document.querySelector('#nbPreview').getBoundingClientRect().width,
      ratio: document.querySelector('[data-nb-resize="body-primary"]').getAttribute('aria-valuenow')
    }));
    check('Edit and Read panes have an accessible Desktop resizer that changes their widths', editPaneBefore.orientation === 'vertical' && editPaneAfter.edit > editPaneBefore.edit + 25 && editPaneAfter.preview < editPaneBefore.preview - 25 && Number(editPaneAfter.ratio) > 50, { before: editPaneBefore, after: editPaneAfter });

    await click(page, '[data-nb="split-toggle"]'); await wait(120);
    await click(page, '[data-nb="toggle-mode"][data-side="secondary"]');
    await click(page, '[data-nb="toggle-mode"][data-side="secondary"]'); await wait(100);
    const secondaryBefore = await page.evaluate(() => ({
      primary: document.querySelector('[data-nb-resize="body-primary"]').getAttribute('aria-valuenow'),
      secondary: document.querySelector('[data-nb-resize="body-secondary"]').getAttribute('aria-valuenow'),
      orientation: document.querySelector('[data-nb-resize="body-secondary"]').getAttribute('aria-orientation')
    }));
    const secondaryHandle = await page.evaluate(() => { const r = document.querySelector('[data-nb-resize="body-secondary"]').getBoundingClientRect(); return { x: r.x + r.width / 2, y: r.y + r.height / 2 }; });
    await drag(page, secondaryHandle, { x: secondaryHandle.x - 40, y: secondaryHandle.y });
    const secondaryAfter = await page.evaluate(() => ({
      primary: document.querySelector('[data-nb-resize="body-primary"]').getAttribute('aria-valuenow'),
      secondary: document.querySelector('[data-nb-resize="body-secondary"]').getAttribute('aria-valuenow')
    }));
    check('Split note panes keep independent Edit/Read resize ratios', secondaryBefore.orientation === 'vertical' && Number(secondaryAfter.secondary) > Number(secondaryBefore.secondary) && secondaryAfter.primary === secondaryBefore.primary, { secondaryBefore, secondaryAfter });

    await page.setViewport({ width: 390, height: 844 });
    await page.waitForFunction(() => document.querySelector('[data-nb-resize="body-primary"]')?.getAttribute('aria-orientation') === 'horizontal', { timeout: 5000 });
    await wait(100);
    const mobileDivider = await page.evaluate(() => {
      const edit = document.querySelector('#nbEdit'), preview = document.querySelector('#nbPreview'), divider = document.querySelector('[data-nb-resize="body-primary"]'), r = divider.getBoundingClientRect();
      return { orientation: divider.getAttribute('aria-orientation'), edit: edit.getBoundingClientRect().height, preview: preview.getBoundingClientRect().height, ratio: Number(divider.getAttribute('aria-valuenow')), handle: { x: r.x + r.width / 2, y: r.y + r.height / 2 } };
    });
    await drag(page, mobileDivider.handle, { x: mobileDivider.handle.x, y: mobileDivider.handle.y + 25 });
    const mobileDividerAfter = await page.evaluate(() => ({ edit: document.querySelector('#nbEdit').getBoundingClientRect().height, preview: document.querySelector('#nbPreview').getBoundingClientRect().height, ratio: Number(document.querySelector('[data-nb-resize="body-primary"]').getAttribute('aria-valuenow')) }));
    check('Mobile Edit/Read panes switch to a horizontal, keyboard-accessible row divider and remain resizable', mobileDivider.orientation === 'horizontal' && mobileDividerAfter.ratio > mobileDivider.ratio && mobileDividerAfter.edit > 20 && mobileDividerAfter.preview > 20, { before: mobileDivider, after: mobileDividerAfter });

    const listMode = await page.evaluate(() => {
      document.querySelector('[data-nb="back-list"]').click();
      const card = document.querySelector('.nb-card-main p');
      return { cardFont: card ? parseFloat(getComputedStyle(card).fontSize) : 0, cardVisible: !!card };
    });
    check('Properties sizing stays scoped to Note Properties and does not enlarge Note Lists', listMode.cardVisible && listMode.cardFont <= 12, listMode);

    check('Notebook enhancement suite completes without JavaScript or console errors', errors.length === 0, errors);
    console.log(`SUMMARY | ${failures.length ? 'FAIL' : 'PASS'} | ${failures.length} failure(s) | ${errors.length} runtime error(s)`);
    if (failures.length || errors.length) process.exitCode = 1;
  } finally {
    await browser.close();
    if (testServer && testServer.listening) await new Promise(resolve => testServer.close(resolve));
  }
})().catch(error => {
  console.error(error);
  if (testServer && testServer.listening) testServer.close();
  process.exit(1);
});
