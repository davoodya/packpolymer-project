const puppeteer = require('puppeteer');
const chromium = require('@sparticuz/chromium');
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

let testServer = null;
const failures = [];
const errors = [];
const wait = (ms = 120) => new Promise(resolve => setTimeout(resolve, ms));
function check(name, ok, detail) {
  console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}${detail === undefined ? '' : ' | ' + JSON.stringify(detail)}`);
  if (!ok) failures.push(name);
}
async function click(page, selector) {
  await page.evaluate(sel => {
    const el = document.querySelector(sel);
    if (!el) throw new Error('Missing element: ' + sel);
    el.click();
  }, selector);
}
async function setEditor(page, selector, value, start, end) {
  await page.$eval(selector, (el, arg) => {
    el.focus(); el.value = arg.value;
    const a = Number.isInteger(arg.start) ? arg.start : el.value.length;
    const b = Number.isInteger(arg.end) ? arg.end : a;
    el.setSelectionRange(a, b);
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }, { value, start, end });
}
async function key(page, key, mods = []) {
  for (const mod of mods) await page.keyboard.down(mod);
  await page.keyboard.press(key);
  for (const mod of [...mods].reverse()) await page.keyboard.up(mod);
}
function tinyPng() {
  return Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p7cAAAAASUVORK5CYII=', 'base64');
}
function tinyWav() {
  const sampleRate = 8000, samples = 80, data = Buffer.alloc(samples * 2);
  const out = Buffer.alloc(44 + data.length);
  out.write('RIFF', 0); out.writeUInt32LE(36 + data.length, 4); out.write('WAVE', 8);
  out.write('fmt ', 12); out.writeUInt32LE(16, 16); out.writeUInt16LE(1, 20);
  out.writeUInt16LE(1, 22); out.writeUInt32LE(sampleRate, 24); out.writeUInt32LE(sampleRate * 2, 28);
  out.writeUInt16LE(2, 32); out.writeUInt16LE(16, 34); out.write('data', 36); out.writeUInt32LE(data.length, 40); data.copy(out, 44);
  return out;
}
function tinyWebm() { return Buffer.from([0x1a, 0x45, 0xdf, 0xa3, 0x93, 0x42, 0x86, 0x81, 0x01, 0x42, 0xf7, 0x81, 0x01]); }
async function pasteFile(page, selector, fileName, mimeType, buffer, text = '') {
  return page.$eval(selector, (el, arg) => {
    el.focus();
    const transfer = new DataTransfer();
    transfer.items.add(new File([new Uint8Array(arg.buffer)], arg.name, { type: arg.type }));
    if (arg.text) transfer.setData('text/plain', arg.text);
    const event = new ClipboardEvent('paste', { clipboardData: transfer, bubbles: true, cancelable: true });
    const uncanceled = el.dispatchEvent(event);
    return { uncanceled, count: transfer.files.length };
  }, { name: fileName, type: mimeType, buffer: Array.from(buffer), text });
}

(async () => {
  const uploadDir = path.join(os.tmpdir(), 'arena-editor-' + process.pid);
  const uploadPng = path.join(uploadDir, 'tiny.png');
  const uploadWav = path.join(uploadDir, 'sound.wav');
  const uploadVideo = path.join(uploadDir, 'clip.webm');
  fs.mkdirSync(uploadDir, { recursive: true });
  fs.writeFileSync(uploadPng, tinyPng()); fs.writeFileSync(uploadWav, tinyWav()); fs.writeFileSync(uploadVideo, tinyWebm());
  const browser = await puppeteer.launch({
    executablePath: await chromium.executablePath(),
    args: [...chromium.args, '--no-sandbox', '--disable-dev-shm-usage'],
    headless: true
  });
  try {
    const page = await browser.newPage();
    page.on('pageerror', error => errors.push(error.message));
    page.on('console', message => {
      if (message.type() === 'error' && !/scrollTo|not implemented|media/i.test(message.text())) errors.push(message.text());
    });
    await page.setViewport({ width: 1600, height: 1000 });
    const html = fs.readFileSync('/home/user/packpolymer-marketplace-roadmap.html');
    testServer = http.createServer((req, res) => {
      const path = (req.url || '/').split('?')[0];
      if (path === '/seed.html') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
        res.end('<!doctype html><html><body>seed</body></html>');
      } else if (path === '/answers-roadmap.json') {
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' }); res.end('{}');
      } else {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
        res.end(html);
      }
    });
    await new Promise(resolve => testServer.listen(0, '127.0.0.1', resolve));
    const origin = 'http://127.0.0.1:' + testServer.address().port;
    await page.goto(origin + '/seed.html', { waitUntil: 'load' });
    await page.evaluate(() => {
      const now = new Date().toISOString();
      const notes = [
        { id: 'editor-primary', title: 'Primary editor', body: '', folderId: '', category: '', tags: [], createdAt: now, updatedAt: now },
        { id: 'editor-secondary', title: 'Secondary editor', body: '', folderId: '', category: '', tags: [], createdAt: now, updatedAt: now }
      ];
      localStorage.setItem('packpolymer-marketplace-roadmap-v2', JSON.stringify({
        nbNotes: notes, nbActiveId: notes[0].id, nbSecondaryId: notes[1].id,
        nbFolders: [], nbTags: [], nbCategories: [], nbView: 'note', nbMode: 'edit', nbSecondaryMode: 'edit',
        nbSplit: false, nbSplitRatio: .5, nbWidthPct: 75, nbBodyRatio: .5, nbBodyRatioSecondary: .5,
        openNotes: {}, noteModes: {}, ui: { nbOpen: false }
      }));
    });
    await page.goto(origin + '/packpolymer-marketplace-roadmap.html', { waitUntil: 'load', timeout: 60000 });
    await wait(520);
    const headingDigits = await page.evaluate(() => ({
      symbols: [4,5,6].map(n => document.querySelector('#i-h' + n)?.textContent.trim()),
      tools: [4,5,6].map(n => document.querySelector('[data-v="h' + n + '"][data-side="primary"] use')?.getAttribute('href'))
    }));
    check('H4, H5, and H6 toolbar symbols show clear digits 4, 5, and 6', headingDigits.symbols.join('') === '456' && headingDigits.tools.join(',') === '#i-h4,#i-h5,#i-h6', headingDigits);

    await click(page, '.phase-note-toggle');
    await page.waitForFunction(() => !!document.querySelector('.note-wrap.show textarea[data-note]'));
    const noteSelector = '.note-wrap.show textarea[data-note]';
    await page.$eval(noteSelector, el => el.focus());
    await page.keyboard.type('Note');
    await key(page, 'z', ['Control']);
    const noteUndo = await page.$eval(noteSelector, el => el.value);
    await key(page, 'z', ['Control', 'Shift']);
    const noteRedo = await page.$eval(noteSelector, el => el.value);
    check('Written-note editor supports Ctrl+Z undo and Ctrl+Shift+Z redo', noteUndo === '' && noteRedo === 'Note', { noteUndo, noteRedo });

    await setEditor(page, noteSelector, '9. first');
    await page.$eval(noteSelector, el => el.setSelectionRange(el.value.length, el.value.length));
    await key(page, 'Enter');
    const orderedContinue = await page.$eval(noteSelector, el => el.value);
    await key(page, 'Enter');
    const orderedExit = await page.$eval(noteSelector, el => el.value);
    await setEditor(page, noteSelector, '  - parent');
    await page.$eval(noteSelector, el => el.setSelectionRange(el.value.length, el.value.length));
    await key(page, 'Enter');
    const bulletContinue = await page.$eval(noteSelector, el => el.value);
    await key(page, 'Enter');
    const bulletExit = await page.$eval(noteSelector, el => el.value);
    check('Written-note editor continues numbered and bullet lists, then exits when Enter is pressed on an empty item', orderedContinue === '9. first\n10. ' && orderedExit === '9. first\n' && bulletContinue === '  - parent\n  - ' && bulletExit === '  - parent\n', { orderedContinue, orderedExit, bulletContinue, bulletExit });

    await setEditor(page, noteSelector, 'LEFT-RIGHT', 5, 5);
    const [noteChooser] = await Promise.all([
      page.waitForFileChooser({ timeout: 10000 }),
      click(page, '.note-wrap.show .note-media-btn:not([hidden])')
    ]);
    await noteChooser.accept([uploadPng, uploadWav, uploadVideo]);
    await page.waitForFunction(selector => document.querySelector(selector)?.value.includes('data:image/png;base64,'), { timeout: 8000 }, noteSelector).catch(() => {});
    const noteMedia = await page.$eval(noteSelector, el => ({ value: el.value, connected: el.isConnected }));
    check('Written-note Toolbar selects image, audio, and video files and inserts them at the cursor', noteMedia.connected && noteMedia.value.startsWith('LEFT-![tiny.png](data:image/png;base64,') && noteMedia.value.includes('![sound.wav](data:audio/wav;base64,') && noteMedia.value.includes('![clip.webm](data:video/webm;base64,') && noteMedia.value.endsWith(')RIGHT'), { connected: noteMedia.connected, image: noteMedia.value.includes('data:image/png'), audio: noteMedia.value.includes('data:audio/wav'), video: noteMedia.value.includes('data:video/webm') });
    await key(page, 'z', ['Control']); const noteMediaUndo = await page.$eval(noteSelector, el => el.value);
    await key(page, 'z', ['Control', 'Shift']); const noteMediaRedo = await page.$eval(noteSelector, el => el.value);
    check('Undo/Redo also covers Toolbar-inserted media in a written note', noteMediaUndo === 'LEFT-RIGHT' && noteMediaRedo === noteMedia.value, { noteMediaUndo, restored: noteMediaRedo === noteMedia.value });
    await click(page, '.note-wrap.show .note-mode-btn');
    await page.waitForFunction(() => !!document.querySelector('.note-wrap.show [data-note-preview] img.md-image'), { timeout: 5000 }).catch(() => {});
    const noteRendered = await page.evaluate(() => ({ read: !!document.querySelector('.note-wrap.show textarea[data-note]')?.hidden, images: document.querySelectorAll('.note-wrap.show [data-note-preview] img.md-image').length, audio: document.querySelectorAll('.note-wrap.show [data-note-preview] audio.md-audio').length, video: document.querySelectorAll('.note-wrap.show [data-note-preview] video.md-video').length }));
    check('Attached image, audio, and video render safely in the written-note Read view', noteRendered.images === 1 && noteRendered.audio === 1 && noteRendered.video === 1, noteRendered);

    await click(page, '.note-wrap.show .note-mode-btn');
    await page.waitForFunction(() => document.querySelector('.note-wrap.show textarea[data-note]') && !document.querySelector('.note-wrap.show textarea[data-note]').hidden);
    await setEditor(page, noteSelector, 'AB', 1, 1);
    const pasteResult = await pasteFile(page, noteSelector, 'clipboard.png', 'image/png', tinyPng());
    await page.waitForFunction(selector => document.querySelector(selector)?.value.includes('clipboard.png](data:image/png;base64,'), { timeout: 8000 }, noteSelector).catch(() => {});
    const pastedNote = await page.$eval(noteSelector, el => el.value);
    check('Written-note editor accepts a direct image paste from the clipboard at the caret', !pasteResult.uncanceled && pastedNote.startsWith('A![clipboard.png](data:image/png;base64,') && pastedNote.endsWith(')B'), { pasteResult, pastedNote: pastedNote.slice(0, 80) + '…' });
    await wait(420);
    const persistedNote = await page.evaluate(() => {
      const editor=document.querySelector('.note-wrap.show textarea[data-note]');
      const saved=JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')||'{}');
      return !!(editor&&saved.notes&&String(saved.notes[editor.dataset.note]||'').includes('clipboard.png](data:image/png;base64,'));
    });
    check('Embedded media in a written note is committed to browser-local storage for offline reopening', persistedNote, { persistedNote });

    await click(page, '#fabNote');
    await page.waitForFunction(() => document.querySelector('#nbPanel')?.classList.contains('open'), { timeout: 5000 });
    await wait(250);
    const notebookSelector = '#nbEdit';
    await page.$eval(notebookSelector, el => el.focus());
    await page.keyboard.type('Notebook');
    await key(page, 'z', ['Control']);
    const nbUndo = await page.$eval(notebookSelector, el => el.value);
    await key(page, 'z', ['Control', 'Shift']);
    const nbRedo = await page.$eval(notebookSelector, el => el.value);
    check('Notebook editor supports Ctrl+Z undo and Ctrl+Shift+Z redo', nbUndo === '' && nbRedo === 'Notebook', { nbUndo, nbRedo });

    await setEditor(page, notebookSelector, '2. first');
    await page.$eval(notebookSelector, el => el.setSelectionRange(el.value.length, el.value.length));
    await key(page, 'Enter');
    const nbOrderedContinue = await page.$eval(notebookSelector, el => el.value);
    await key(page, 'Enter');
    const nbOrderedExit = await page.$eval(notebookSelector, el => el.value);
    await setEditor(page, notebookSelector, '- bullet');
    await page.$eval(notebookSelector, el => el.setSelectionRange(el.value.length, el.value.length));
    await key(page, 'Enter');
    const nbBulletContinue = await page.$eval(notebookSelector, el => el.value);
    await key(page, 'Enter');
    const nbBulletExit = await page.$eval(notebookSelector, el => el.value);
    check('Notebook editor continues numbered and bullet lists and exits empty items', nbOrderedContinue === '2. first\n3. ' && nbOrderedExit === '2. first\n' && nbBulletContinue === '- bullet\n- ' && nbBulletExit === '- bullet\n', { nbOrderedContinue, nbOrderedExit, nbBulletContinue, nbBulletExit });

    await setEditor(page, notebookSelector, 'Notebook attachment: ', 21, 21);
    const [nbChooser] = await Promise.all([
      page.waitForFileChooser({ timeout: 10000 }),
      click(page, '[data-nb="fmt"][data-v="media"][data-side="primary"]')
    ]);
    await nbChooser.accept([uploadWav, uploadVideo]);
    await page.waitForFunction(selector => document.querySelector(selector)?.value.includes('data:audio/wav;base64,'), { timeout: 8000 }, notebookSelector).catch(() => {});
    const nbMediaText = await page.$eval(notebookSelector, el => el.value);
    check('Notebook Toolbar selects audio and video and inserts portable data URIs at the cursor', nbMediaText.startsWith('Notebook attachment: ![sound.wav](data:audio/wav;base64,') && nbMediaText.includes('![clip.webm](data:video/webm;base64,'), nbMediaText.slice(0, 135));
    await key(page, 'z', ['Control']); const nbMediaUndo = await page.$eval(notebookSelector, el => el.value);
    await key(page, 'z', ['Control', 'Shift']); const nbMediaRedo = await page.$eval(notebookSelector, el => el.value);
    check('Undo/Redo covers Toolbar-inserted audio/video in the Notebook', nbMediaUndo === 'Notebook attachment: ' && nbMediaRedo === nbMediaText, { nbMediaUndo, restored: nbMediaRedo === nbMediaText });
    await click(page, '[data-nb="toggle-mode"][data-side="primary"]');
    await click(page, '[data-nb="toggle-mode"][data-side="primary"]');
    await page.waitForFunction(() => !!document.querySelector('#nbPreview audio.md-audio') && !!document.querySelector('#nbPreview video.md-video'), { timeout: 5000 }).catch(() => {});
    const nbMediaRendered = await page.evaluate(() => ({ mode: document.querySelector('.nb-pane-primary .nb-body')?.dataset.mode, audio: !!document.querySelector('#nbPreview audio.md-audio'), video: !!document.querySelector('#nbPreview video.md-video'), sourceTypes: [...document.querySelectorAll('#nbPreview source')].map(x => x.type) }));
    check('Notebook Markdown preview renders attached audio and video with native controls', nbMediaRendered.audio && nbMediaRendered.video && nbMediaRendered.mode === 'both', nbMediaRendered);

    await click(page, '[data-nb="toggle-mode"][data-side="primary"]');
    await setEditor(page, notebookSelector, 'AB', 1, 1);
    const nbPasteResult = await pasteFile(page, notebookSelector, 'notebook-clipboard.png', 'image/png', tinyPng());
    await page.waitForFunction(selector => document.querySelector(selector)?.value.includes('notebook-clipboard.png](data:image/png;base64,'), { timeout: 8000 }, notebookSelector).catch(() => {});
    const nbPasted = await page.$eval(notebookSelector, el => el.value);
    check('Notebook editor accepts a direct screenshot/image paste at the caret', !nbPasteResult.uncanceled && nbPasted.startsWith('A![notebook-clipboard.png](data:image/png;base64,') && nbPasted.endsWith(')B'), { nbPasteResult, value: nbPasted.slice(0, 85) + '…' });
    await key(page, 'z', ['Control']); const nbPasteUndo = await page.$eval(notebookSelector, el => el.value);
    await key(page, 'z', ['Control', 'Shift']); const nbPasteRedo = await page.$eval(notebookSelector, el => el.value);
    check('Undo/Redo also covers directly pasted media in the Notebook', nbPasteUndo === 'AB' && nbPasteRedo === nbPasted, { nbPasteUndo, restored: nbPasteRedo === nbPasted });

    await click(page, '[data-nb="properties-toggle"][data-side="primary"]');
    await wait(120);
    const desktopProps = await page.evaluate(() => {
      const root = document.querySelector('[data-nb-properties="primary"]');
      const select = root.querySelector('select'), input = root.querySelector('input');
      return { font: parseFloat(getComputedStyle(select).fontSize), selectHeight: select.getBoundingClientRect().height, inputHeight: input.getBoundingClientRect().height, heading: parseFloat(getComputedStyle(root.querySelector('.nb-properties-heading b')).fontSize) };
    });
    check('Desktop Properties controls in an open Note are distinctly larger', desktopProps.font >= 14 && desktopProps.selectHeight >= 42 && desktopProps.inputHeight >= 42 && desktopProps.heading >= 16, desktopProps);
    await click(page, '[data-nb="properties-close"][data-side="primary"]'); await wait(150);

    const responsive = [];
    for (const width of [1920, 1600, 1440, 1280, 1024, 768, 390, 320]) {
      await page.setViewport({ width, height: width <= 390 ? 844 : 900 });
      await wait(300);
      responsive.push(await page.evaluate(() => {
        const panel = document.querySelector('#nbPanel'), props = document.querySelector('[data-nb-properties="primary"]');
        const media = document.querySelector('[data-nb="fmt"][data-v="media"][data-side="primary"]');
        const edit = document.querySelector('#nbEdit');
        return { width: innerWidth, documentWidth: document.documentElement.scrollWidth, panel: panel.getBoundingClientRect().width, toolbarButton: !!media && media.getBoundingClientRect().width >= 26, propsScroll: props.scrollWidth, propsClient: props.clientWidth, editWidth: edit.getBoundingClientRect().width };
      }));
    }
    check('Desktop/laptop/tablet/mobile layouts keep the media tool visible and avoid document-wide horizontal overflow', responsive.every(x => x.documentWidth <= x.width + 2 && x.panel <= x.width + 1 && x.toolbarButton && x.propsScroll <= x.propsClient + 2 && x.editWidth <= x.width + 1), responsive);

    check('Editor enhancement suite finishes without uncaught runtime errors', errors.length === 0, errors);
    console.log(`SUMMARY | ${failures.length ? 'FAIL' : 'PASS'} | ${failures.length} failure(s) | ${errors.length} runtime error(s)`);
  } finally {
    if (testServer) await new Promise(resolve => testServer.close(resolve));
    await browser.close();
    fs.rmSync(uploadDir, { recursive: true, force: true });
  }
  process.exitCode = failures.length ? 1 : 0;
})();
