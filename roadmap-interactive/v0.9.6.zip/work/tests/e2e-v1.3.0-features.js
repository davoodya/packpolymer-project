const puppeteer = require('puppeteer');
const chromium = require('@sparticuz/chromium');
const failures = [];
const wait = (ms=150) => new Promise(resolve => setTimeout(resolve, ms));
function check(name, ok, detail) {
  console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}${detail === undefined ? '' : ' | ' + JSON.stringify(detail)}`);
  if (!ok) failures.push(name);
}
async function clickInPage(page, selector) {
  return page.evaluate(sel => {
    const el = document.querySelector(sel);
    if (!el) throw new Error('Missing element for click: ' + sel);
    el.click();
  }, selector);
}
async function setValue(page, selector, value) {
  return page.$eval(selector, (el, v) => {
    el.value = v;
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }, value);
}

(async () => {
  const browser = await puppeteer.launch({
    executablePath: await chromium.executablePath(),
    args: [...chromium.args, '--no-sandbox', '--disable-dev-shm-usage'],
    headless: true
  });
  const page = await browser.newPage();
  const errors = [];
  const dialogs = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error' && !/scrollTo|not implemented/i.test(m.text())) errors.push(m.text()); });
  page.on('dialog', async dialog => { dialogs.push(dialog.type()); try { await dialog.dismiss(); } catch (_) {} });
  await page.evaluateOnNewDocument(() => {
    window.__copiedText = '';
    try { Object.defineProperty(navigator, 'clipboard', { configurable:true, value:{ writeText: async text => { window.__copiedText = String(text); } } }); } catch (_) {}
  });
  await page.setViewport({ width: 1440, height: 1000 });
  await page.goto('file:///home/user/packpolymer-marketplace-roadmap.html', { waitUntil:'load', timeout:60000 });
  await wait(550);

  const initial = await page.evaluate(() => ({
    title: document.title,
    version: document.querySelector('.foot')?.textContent.match(/V[0-9.]+/)?.[0] || '',
    phaseCount: document.querySelectorAll('.phase').length,
    externalScripts: [...document.scripts].filter(s => s.src).map(s => s.src),
    vazirEmbedded: [...document.styleSheets].some(s => { try { return [...s.cssRules].some(r => /font-face/i.test(r.cssText) && /data:font\/woff2;base64/.test(r.cssText)); } catch (_) { return false; } })
  }));
  check('V1.3.0 is built as a self-contained offline HTML with embedded Vazir', initial.version === 'V1.3.0' && initial.phaseCount === 13 && initial.externalScripts.length === 0 && initial.vazirEmbedded, initial);

  // The compact sticky search must remain visually centered with controls on both sides.
  await page.evaluate(() => { document.documentElement.style.scrollBehavior='auto'; window.scrollTo(0, 1000); });
  await wait(220);
  const desktopSearch = await page.evaluate(() => {
    const r = s => document.querySelector(s).getBoundingClientRect();
    const left=r('.header-actions-left'), search=r('.topbar .search'), right=r('.header-actions-right');
    return { compact:document.querySelector('.topbar').classList.contains('compact'),
      center:search.left+search.width/2, viewport:innerWidth/2, width:search.width,
      leftGap:search.left-left.right, rightGap:right.left-search.right,
      controlsVisible:getComputedStyle(document.querySelector('.header-actions-left')).display!=='none'&&getComputedStyle(document.querySelector('.header-actions-right')).display!=='none' };
  });
  check('desktop compact sticky Search is wider, centered, and flanked by controls', desktopSearch.compact && Math.abs(desktopSearch.center-desktopSearch.viewport)<2 && desktopSearch.width>=500 && desktopSearch.leftGap>=0 && desktopSearch.rightGap>=0 && desktopSearch.controlsVisible, desktopSearch);

  // Notebook: rich multi-note library, metadata, query, facets, management and sorting.
  await clickInPage(page, '[data-act="notebook"]');
  await wait(650);
  await page.click('[data-nb="new"]');
  await wait(100);
  const strayMark = await page.evaluate(() => {
    const root=document.querySelector('.nb-pane-primary');
    const standalone=[...root.querySelectorAll('*')].some(e=>e.childNodes.length===1&&e.firstChild.nodeType===3&&e.textContent.trim()==='M');
    const placeholder=document.querySelector('#nbEdit').placeholder.trim();
    return standalone || placeholder==='M' || placeholder.startsWith('M ');
  });
  check('New-note toolbar has no stray standalone M character', !strayMark);
  const richBody = [
    '# Main heading',
    '## Supplier reference',
    '### Blue heading',
    '#### Yellow heading',
    '##### Red heading',
    '###### Gray heading',
    '**Bold pink** and *Italic pink*.',
    '',
    'Unique bodyterm: procurement alpha.',
    'Raw URL: https://example.com/path?q=1&x=two. Markdown: [Vendor Docs](https://docs.example.com/guide).',
    'Parenthesized URL: (https://packpolymer.com/start). Code URL: `https://not-a-link.example`.',
    'HTTP URL: http://legacy.example/resource;',
    '',
    '> [!warning] هشدار',
    '> callout-term remains readable.',
    '',
    '```javascript',
    'const answer = 42;',
    'console.log(answer);',
    '```',
    '',
    '```kotlin',
    'fun greet(name: String) = "Hello, $name"',
    '```',
    '',
    '```dockerfile',
    'FROM node:20',
    'RUN npm install',
    '```',
    '',
    '```diff',
    '+const added = true;',
    '-const removed = false;',
    '@@ changed block',
    '```',
    '',
    '```python',
    'def greet(name):',
    '    return f"hello {name}"',
    '```'
  ].join('\n');
  await setValue(page, '#nbTitle', 'Vendor Atlas');
  await setValue(page, '#nbEdit', richBody);
  const initialProperties = await page.evaluate(() => {
    const slot=document.querySelector('[data-nb-properties="primary"]'),body=document.querySelector('.nb-pane-primary .nb-body'),toggle=document.querySelector('[data-nb="properties-toggle"][data-side="primary"]'),format=document.querySelector('[data-nb-formatbar="primary"]'),actions=document.querySelectorAll('[data-nb-tools="primary"] .nb-actions [data-nb]');
    return {hidden:!!slot?.hidden,editorVisible:!!body&&getComputedStyle(body).display!=='none',toggleVisible:!!toggle&&toggle.getBoundingClientRect().width>0,editorHeight:document.querySelector('#nbEdit')?.getBoundingClientRect().height||0,formatHidden:!!format?.hidden,actionNames:[...actions].map(x=>x.dataset.nb)};
  });
  check('new Notes open directly in a usable Edit view with properties hidden, Markdown tools and six action buttons', initialProperties.hidden && initialProperties.editorVisible && initialProperties.toggleVisible && initialProperties.editorHeight>160 && !initialProperties.formatHidden && initialProperties.actionNames.join(',')==='copy,share,download,duplicate,new2,delete', initialProperties);
  await clickInPage(page, '[data-nb="properties-toggle"][data-side="primary"]');
  await page.waitForSelector('[data-nb-properties="primary"] .nb-properties-page');
  const hasInlineProperties = await page.$eval('[data-nb-properties="primary"] .nb-properties-page', e => !!(e.querySelector('[data-nb-property="folder"]') && e.querySelector('[data-nb-property="category"]') && e.querySelector('[data-nb-tag-filter]') && e.querySelector('[data-nb="properties-close"]')));
  const propertyPageScroll = await page.evaluate(() => {const e=document.querySelector('[data-nb-properties="primary"] .nb-properties-scroll');return e?getComputedStyle(e).overflowY:'';});
  await setValue(page, '[data-nb-property-new="folder"]', 'Drafts');
  await clickInPage(page, '[data-nb="property-create"][data-kind="folder"]');
  await setValue(page, '[data-nb-property-new="category"]', 'Reference');
  await clickInPage(page, '[data-nb="property-create"][data-kind="category"]');
  await setValue(page, '[data-nb-property-new="tag"]', 'polymer');
  await clickInPage(page, '[data-nb="property-create"][data-kind="tag"]');
  check('Properties open as a dedicated scrollable page with in-place Folder/Category/Tag controls and a Close button', hasInlineProperties && ['auto','scroll'].includes(propertyPageScroll) && (await page.$eval('[data-nb-property="folder"]', e => e.value !== '')) && (await page.$eval('[data-nb-property="category"]', e => e.value === 'Reference')) && (await page.$$eval('.nb-tag-option.on', es => es.length === 1)), {hasInlineProperties,propertyPageScroll});
  await clickInPage(page, '[data-nb="properties-close"][data-side="primary"]');
  check('Properties Close returns to the same Note Editor', (await page.$eval('[data-nb-properties="primary"]', e => e.hidden)) && (await page.$eval('.nb-pane-primary .nb-body', e => getComputedStyle(e).display!=='none')));
  await page.click('[data-nb="back-list"]');
  await wait(200);
  const explorerLayout = await page.evaluate(() => {
    const x=document.querySelector('.nb-explorer'), s=document.querySelector('.nb-explorer-side'), m=document.querySelector('.nb-explorer-main');
    const cols=x?getComputedStyle(x).gridTemplateColumns.split(' ').length:0;
    const body=document.querySelector('[data-nb-panel]')?.innerText||'';
    return {grid:x?getComputedStyle(x).display:'',columns:cols,side:!!s,main:!!m,back:document.querySelector('[data-nb="back-list"]')?.innerText||'',englishBack:body.includes('Back to Note List')};
  });
  check('Notebook tabs use a two-panel File Explorer and Persian بازگشت به لیست نوشته ها label', explorerLayout.grid==='grid' && explorerLayout.columns===2 && explorerLayout.side && explorerLayout.main && explorerLayout.back.includes('بازگشت به لیست نوشته ها') && !explorerLayout.englishBack, explorerLayout);

  await clickInPage(page, '[data-nb="browse-mode"][data-mode="folders"]');
  await setValue(page, '[data-nb-facet-input="folders"]', 'Vendor records');
  await clickInPage(page, '[data-nb="facet-create-submit"][data-mode="folders"]');
  await wait(100);
  const folderId = await page.$eval('.nb-facet.on[data-nb="browse-value"][data-mode="folders"][data-value]:not([data-value=""]):not([data-value="__none__"])', e => e.dataset.value);
  await clickInPage(page, '.nb-facet[data-nb="browse-value"][data-mode="folders"][data-value=""]');
  await clickInPage(page, '[data-nb="metadata-edit"]');
  await page.waitForSelector('.nb-card-editor');
  await setValue(page, '[data-nb-card-field="category"]', 'Reference');
  await clickInPage(page, '[data-nb="metadata-create-property"][data-kind="category"]');
  await setValue(page, '[data-nb-card-new="tag"]', 'polymer');
  await clickInPage(page, '[data-nb="metadata-create-property"][data-kind="tag"]');
  await setValue(page, '[data-nb-card-new="tag"]', 'b2b-procurement');
  await clickInPage(page, '[data-nb="metadata-create-property"][data-kind="tag"]');
  await setValue(page, '[data-nb-card-field="tags"]', 'polymer, b2b-procurement');
  await page.select('[data-nb-card-field="folder"]', folderId);
  await clickInPage(page, '[data-nb="metadata-save"]');
  await wait(100);
  const cardMeta = await page.$eval('.nb-card-tags', e => e.innerText);
  check('note cards visibly carry فولدر، دسته بندی and تگ metadata', cardMeta.includes('Vendor records') && cardMeta.includes('Reference') && cardMeta.includes('polymer') && cardMeta.includes('b2b-procurement'), cardMeta);

  const searchResults = {};
  for (const [label, query] of [['title','atlas'],['body','bodyterm'],['tag','b2b-procurement'],['folder','vendor records'],['category','reference']]) {
    await setValue(page, '#nbSearch', query);
    searchResults[label] = await page.$$eval('.nb-card', cards => cards.length);
  }
  await setValue(page, '#nbSearch', '');
  check('Notebook search covers title, body, تگ, فولدر and دسته بندی', Object.values(searchResults).every(n => n === 1), searchResults);

  await clickInPage(page, '[data-nb="browse-mode"][data-mode="tags"]');
  const tagValues = await page.$$eval('.nb-facet[data-nb="browse-value"][data-mode="tags"]', es => es.map(e => e.dataset.value));
  await clickInPage(page, '.nb-facet[data-nb="browse-value"][data-mode="tags"][data-value="b2b-procurement"]');
  check('Tag facet filters the note list and exposes inline management', (await page.$$eval('.nb-card', es => es.length)) === 1 && tagValues.includes('b2b-procurement') && !!(await page.$('[data-nb="facet-edit"][data-value="b2b-procurement"]')));

  await clickInPage(page, '[data-nb="facet-edit"][data-mode="tags"][data-value="b2b-procurement"]');
  await setValue(page, '[data-nb-manager-edit]', 'supplier-verified');
  await clickInPage(page, '[data-nb="facet-edit-save"][data-mode="tags"][data-value="b2b-procurement"]');
  const renamedTag = await page.$eval('.nb-card-tags', e => e.innerText);
  check('Tag can be renamed across related notes with an inline text field', renamedTag.includes('supplier-verified') && !renamedTag.includes('b2b-procurement'), renamedTag);
  await clickInPage(page, '[data-nb="facet-delete"][data-mode="tags"][data-value="polymer"]');
  await clickInPage(page, '[data-nb="facet-confirm-delete"][data-mode="tags"][data-value="polymer"]');
  const deletedTag = await page.$eval('.nb-card-tags', e => e.innerText);
  check('Tag can be removed with an inline confirmation without deleting the note', !deletedTag.includes('polymer') && deletedTag.includes('supplier-verified'), deletedTag);

  await clickInPage(page, '[data-nb="browse-mode"][data-mode="categories"]');
  await clickInPage(page, '[data-nb="facet-edit"][data-mode="categories"][data-value="Reference"]');
  await setValue(page, '[data-nb-manager-edit]', 'Planning');
  await clickInPage(page, '[data-nb="facet-edit-save"][data-mode="categories"][data-value="Reference"]');
  const renamedCategory = await page.$eval('.nb-card-tags', e => e.innerText);
  check('Category can be renamed across related notes with an inline text field', renamedCategory.includes('Planning') && !renamedCategory.includes('Reference'), renamedCategory);
  await clickInPage(page, '[data-nb="facet-delete"][data-mode="categories"][data-value="Planning"]');
  await clickInPage(page, '[data-nb="facet-confirm-delete"][data-mode="categories"][data-value="Planning"]');
  check('Category can be removed while preserving the note', !(await page.$eval('.nb-card-tags', e => e.innerText)).includes('Planning') && (await page.$$eval('.nb-card', es => es.length)) === 1);

  await clickInPage(page, '[data-nb="browse-mode"][data-mode="folders"]');
  await clickInPage(page, `[data-nb="facet-edit"][data-mode="folders"][data-value="${folderId}"]`);
  await setValue(page, '[data-nb-manager-edit]', 'Research library');
  await clickInPage(page, `[data-nb="facet-edit-save"][data-mode="folders"][data-value="${folderId}"]`);
  check('Folder can be renamed and its labels update inline', (await page.$eval('.nb-card-tags', e => e.innerText)).includes('Research library'));
  await clickInPage(page, `[data-nb="facet-delete"][data-mode="folders"][data-value="${folderId}"]`);
  await clickInPage(page, `[data-nb="facet-confirm-delete"][data-mode="folders"][data-value="${folderId}"]`);
  const afterFolderDelete = await page.$eval('.nb-card-tags', e => e.innerText);
  check('Folder deletion preserves notes and clears the فولدر label', (await page.$$eval('.nb-card', es => es.length) === 1) && !afterFolderDelete.includes('Research library'));

  await clickInPage(page, '[data-nb="browse-mode"][data-mode="tags"]');
  await setValue(page, '[data-nb-facet-input="tags"]', 'new-facet-tag');
  await clickInPage(page, '[data-nb="facet-create-submit"][data-mode="tags"]');
  await wait(120);
  const createdFacet = await page.evaluate(() => ({ noteView:document.querySelector('[data-nb-noteview]').hidden, tag:!![...document.querySelectorAll('.nb-facet[data-nb="browse-value"]')].find(e=>e.dataset.value==='new-facet-tag'), listCount:document.querySelectorAll('#nbList .nb-card').length }));
  check('new Tag is created inline in the File Explorer and stays available for note properties', createdFacet.noteView && createdFacet.tag && createdFacet.listCount>=0, createdFacet);

  // Create a second note to exercise the selected sort control.
  await clickInPage(page, '[data-nb="browse-mode"][data-mode="all"]');
  await page.click('[data-nb="new"]');
  await wait(80);
  await setValue(page, '#nbTitle', 'Aardvark Archive');
  await setValue(page, '#nbEdit', 'Short reference note.');
  await page.click('[data-nb="back-list"]');
  await wait(150);
  await page.select('[data-nb-sort]', 'title');
  await wait(80);
  const sortOrder = await page.$$eval('.nb-card-heading>b', es => es.map(e => e.textContent.trim()));
  check('Notebook sort selection updates the visible note order', sortOrder[0] === 'Aardvark Archive' && sortOrder.includes('Vendor Atlas'), sortOrder);

  // Open the Markdown note in Reader Mode; test Things styling, offline tokenization, and independent Copy.
  await clickInPage(page, '.nb-card[data-nb="open"]:has(.nb-card-heading>b)');
  // The previous selector chooses the first note; if it was not the supplier note, choose by title.
  await wait(100);
  const activeTitle = await page.$eval('#nbTitle', e => e.value);
  if (activeTitle !== 'Vendor Atlas') {
    await page.click('[data-nb="back-list"]');
    await wait(80);
    const vendorId = await page.$$eval('.nb-card', es => es.find(card => card.querySelector('.nb-card-heading>b')?.textContent.trim() === 'Vendor Atlas')?.dataset.id || '');
    await clickInPage(page, `.nb-card[data-id="${vendorId}"]`);
    await wait(80);
  }
  await page.click('[data-nb="toggle-mode"][data-side="primary"]');
  await page.waitForSelector('#nbPreview:not([hidden])');
  await clickInPage(page, '[data-nb="properties-toggle"][data-side="primary"]');
  await page.waitForSelector('[data-nb-properties="primary"] .nb-properties-page');
  const readProperties = await page.evaluate(() => ({mode:document.querySelector('[data-nb="toggle-mode"][data-side="primary"]').getAttribute('aria-pressed'),folder:!!document.querySelector('[data-nb-property="folder"]'),category:!!document.querySelector('[data-nb-property="category"]'),tags:!!document.querySelector('[data-nb-tag-filter]'),bodyHidden:getComputedStyle(document.querySelector('.nb-pane-primary .nb-body')).display==='none'}));
  check('Folder/Tag/Category controls remain available from the properties page in Read Mode',readProperties.mode==='true'&&readProperties.folder&&readProperties.category&&readProperties.tags&&readProperties.bodyHidden,readProperties);
  await clickInPage(page, '[data-nb="properties-close"][data-side="primary"]');
  await page.waitForSelector('#nbPreview:not([hidden])');
  const preview = await page.evaluate(() => {
    const box=document.querySelector('#nbPreview'), codes=[...box.querySelectorAll('.md-pre')],format=document.querySelector('[data-nb-formatbar="primary"]'),actions=document.querySelectorAll('[data-nb-tools="primary"] .nb-actions [data-nb]');
    const color=sel=>box.querySelector(sel)?getComputedStyle(box.querySelector(sel)).color:'';
    return { theme:box.classList.contains('things-markdown'), background:getComputedStyle(box).backgroundColor,formatVisible:!!format&&!format.hidden,actionCount:actions.length,
      blocks:codes.length, copyButtons:box.querySelectorAll('.md-code-copy').length,
      langs:codes.map(x=>x.dataset.lang), links:[...box.querySelectorAll('a')].map(a=>({text:a.textContent.trim(),href:a.href,target:a.target,rel:a.rel})), jsKeyword:!!box.querySelector('.language-javascript .hl-keyword'),
      kotlinKeyword:!!box.querySelector('.language-kotlin .hl-keyword'), dockerKeyword:!!box.querySelector('.language-dockerfile .hl-keyword'),
      pythonKeyword:!!box.querySelector('.language-python .hl-keyword'), diffAdded:!!box.querySelector('.language-diff .hl-string'),
      h1:color('h1'),h2:color('h2'),h3:color('h3'),h4:color('h4'),h5:color('h5'),h6:color('h6'),bold:color('strong'),italic:color('em'),
      callout:!!box.querySelector('.md-callout-warning'),codeBg:getComputedStyle(box.querySelector('.md-pre')).backgroundColor };
  });
  check('Reader Mode uses the requested pastel Things palette, Obsidian callouts, offline highlighting, and shows only the six action icons', preview.theme && !preview.formatVisible && preview.actionCount===6 && preview.background === 'rgba(7, 11, 20, 0.45)' && preview.blocks === 5 && preview.copyButtons === 5 && ['javascript','kotlin','dockerfile','diff','python'].every(x => preview.langs.includes(x)) && preview.jsKeyword && preview.kotlinKeyword && preview.dockerKeyword && preview.pythonKeyword && preview.diffAdded && preview.callout && preview.links.length===4 && preview.links[0].href==='https://example.com/path?q=1&x=two' && preview.links[1].href==='https://docs.example.com/guide' && preview.links[2].href==='https://packpolymer.com/start' && preview.links[3].href==='http://legacy.example/resource' && preview.links.every(a=>a.target==='_blank'&&a.rel.includes('noopener')&&a.rel.includes('noreferrer')) && preview.h1==='rgb(255, 255, 255)' && preview.h2==='rgb(167, 215, 174)' && preview.h3==='rgb(139, 190, 255)' && preview.h4==='rgb(232, 230, 163)' && preview.h5==='rgb(243, 160, 164)' && preview.h6==='rgb(198, 210, 209)' && preview.bold==='rgb(250, 153, 205)' && preview.italic==='rgb(250, 153, 205)' && preview.codeBg==='rgb(40, 44, 52)', preview);
  await clickInPage(page, '#nbPreview .md-code-copy');
  await wait(80);
  const copied = await page.evaluate(() => window.__copiedText);
  check('each Code Block Copy excludes visual line numbers and copies only its source', copied === 'const answer = 42;\nconsole.log(answer);', copied);
  await page.evaluate(() => document.querySelectorAll('#nbPreview .md-code-copy')[1].click());
  await wait(80);
  const copiedSecond = await page.evaluate(() => window.__copiedText);
  check('Copy buttons operate independently per Code Block', copiedSecond === 'fun greet(name: String) = "Hello, $name"', copiedSecond);
  await clickInPage(page, '[data-nb="download"][data-side="primary"]');
  await page.waitForSelector('#textModal.text-panel.show');
  const textOutput = await page.evaluate(() => {const m=document.querySelector('#textModal');return {visible:!!m&&getComputedStyle(m).display!=='none',position:m?getComputedStyle(m).position:'',inlineAfterHeader:!!m&&m.previousElementSibling?.classList.contains('topbar'),hasText:!!m?.querySelector('.modal-text')?.value,openTabButton:!!m?.querySelector('[data-modal="open-tab"]')};});
  check('Markdown export shows text in an inline page section (not popup or new tab)',textOutput.visible&&textOutput.inlineAfterHeader&&textOutput.position!=='fixed'&&textOutput.hasText&&!textOutput.openTabButton,textOutput);
  await clickInPage(page, '#textModal [data-modal="close"]');
  check('inline Markdown output section closes in place',!(await page.$('#textModal')));
  await page.click('[data-nb="back-list"]');
  await wait(100);

  // Phase/Step/Sub-step creation, completion propagation, overview navigation, and their Markdown readers.
  await clickInPage(page, '[data-nb="close"]');
  await wait(180);
  await page.evaluate(() => { document.documentElement.style.scrollBehavior='auto'; window.scrollTo(0,0); });
  await wait(160);
  await clickInPage(page, '[data-act="edit-mode"]');
  await wait(120);
  await page.evaluate(() => { const ph=document.querySelector('.phase'); if(ph&&!ph.classList.contains('open'))ph.querySelector('.ph-head').click(); });
  await wait(80);
  const oldPhaseIds = await page.$$eval('.phase', es => es.map(x => x.id));
  await clickInPage(page, '.phase.open [data-act="add-phase"]');
  await wait(180);
  const newPhaseId = await page.$$eval('.phase', (es, old) => es.map(x => x.id).find(id => !old.includes(id)), oldPhaseIds);
  await clickInPage(page, `.phase[data-phase="${newPhaseId}"] .ph-ck input`);
  await wait(80);
  const emptyPhaseDone = await page.evaluate(id => ({
    checked:document.querySelector(`.phase[data-phase="${id}"] .ph-ck input`).checked,
    card:document.querySelector(`.phase[data-phase="${id}"]`).classList.contains('done'),
    nav:document.querySelector(`.navitem[data-id="${id}"]`)?.classList.contains('done'),
    pct:document.querySelector(`[data-ppct="${id}"]`)?.textContent.trim()
  }), newPhaseId);
  check('an empty new Phase can be checked and completion propagates to progress and the phase overview', emptyPhaseDone.checked && emptyPhaseDone.card && emptyPhaseDone.nav && emptyPhaseDone.pct.includes('۱۰۰'), emptyPhaseDone);
  await clickInPage(page, `.phase[data-phase="${newPhaseId}"] .ph-head`);
  await wait(80);
  await clickInPage(page, `.phase[data-phase="${newPhaseId}"] [data-act="add-step"]`);
  await wait(180);
  const stepId = await page.$eval(`.phase[data-phase="${newPhaseId}"] .step`, e => e.id);
  await clickInPage(page, `#${stepId} .st-head input[data-ck]`);
  await wait(80);
  const newStepDone = await page.$eval(`#${stepId}`, e => e.classList.contains('done'));
  await clickInPage(page, `[data-act="side-phase-toggle"][data-id="${newPhaseId}"]`);
  await wait(80);
  const navStepExists = await page.evaluate(id => !!document.querySelector(`.navstep[data-id="${id}"]`), stepId);
  await clickInPage(page, `#${stepId} [data-act="add-sub"]`);
  await wait(150);
  const subId = await page.$eval(`#${stepId} .sub`, e => e.id);
  await clickInPage(page, `[data-act="side-step-toggle"][data-id="${stepId}"]`);
  await wait(80);
  const navSubExists = await page.evaluate(id => !!document.querySelector(`.navsub[data-id="${id}"]`), subId);
  await clickInPage(page, `#${stepId} .st-head input[data-ck]`);
  await wait(80);
  const cascade = await page.evaluate(id => ({
    sub:document.getElementById(id).classList.contains('done'),
    step:document.getElementById(id).closest('.step').classList.contains('done'),
    phase:document.getElementById(id).closest('.phase').classList.contains('done'),
    navSub:document.querySelector(`.navsub[data-id="${id}"]`)?.classList.contains('done')
  }), subId);
  check('new Step/Sub-step checkboxes work, cascade to parents, and appear in the expanded overview tree', newStepDone && navStepExists && navSubExists && cascade.sub && cascade.step && cascade.phase && cascade.navSub, {newStepDone,navStepExists,navSubExists,cascade});

  async function addEntityNote(key, text) {
    await clickInPage(page, `[data-act="note-toggle"][data-key="n:${key}"]`);
    await page.waitForSelector(`[data-note="n:${key}"]`);
    await setValue(page, `[data-note="n:${key}"]`, text);
    await clickInPage(page, `[data-act="note-mode"][data-key="n:${key}"]`);
    await wait(70);
    return page.evaluate(k => {
      const wrap=document.querySelector(`[data-note-wrap="n:${k}"]`),preview=wrap?.querySelector('.note-read');
      return {read:!!preview&&!preview.hidden,theme:preview?.classList.contains('things-markdown'),codeCopy:preview?.querySelectorAll('.md-code-copy').length||0,
        background:preview?getComputedStyle(preview).backgroundColor:'',toolbar:!!wrap?.querySelector('.nb-tools')};
    }, key);
  }
  const phaseNote = await addEntityNote(newPhaseId, '# Phase memo\n\n```python\nprint("phase")\n```');
  const stepNote = await addEntityNote(stepId, '## Step memo\n\n**Ready** and `offline`.');
  const subNote = await addEntityNote(subId, '### Sub-step memo\n\n```kotlin\nfun done() = true\n```');
  check('Phase/Step/Sub-step notes share Markdown, Things Reader styling and independent Read/Edit modes (without Notebook toolbar)',
    [phaseNote,stepNote,subNote].every(x=>x.read&&x.theme&&x.background==='rgba(7, 11, 20, 0.45)'&&!x.toolbar) && phaseNote.codeCopy===1 && subNote.codeCopy===1,
    {phaseNote,stepNote,subNote});

  // Mobile: compact header layout and the notebook library must stay within the viewport.
  await page.setViewport({ width:390, height:844 });
  await page.evaluate(() => { document.documentElement.style.scrollBehavior='auto'; window.scrollTo(0,document.documentElement.scrollHeight); window.dispatchEvent(new Event('scroll')); });
  await wait(260);
  const mobileHeader = await page.evaluate(() => {
    const r=s=>document.querySelector(s).getBoundingClientRect();const l=r('.header-actions-left'),q=r('.topbar .search'),a=r('.header-actions-right');
    return {compact:document.querySelector('.topbar').classList.contains('compact'),scrollY,center:q.left+q.width/2,mid:innerWidth/2,width:q.width,
      leftGap:q.left-l.right,rightGap:a.left-q.right,bodyClass:document.body.className,topClass:document.querySelector('.topbar').className};
  });
  check('mobile compact Search remains centered, usable and separated from controls', mobileHeader.compact && Math.abs(mobileHeader.center-mobileHeader.mid)<2 && mobileHeader.width>=140 && mobileHeader.leftGap>=0 && mobileHeader.rightGap>=0, mobileHeader);
  await clickInPage(page, '#fabNote');
  await wait(220);
  if (!(await page.$eval('[data-nb-noteview]', e => e.hidden))) { await clickInPage(page, '[data-nb="back-list"]'); await wait(100); }
  const mobileNotebook = await page.evaluate(() => ({width:document.querySelector('#nbPanel').getBoundingClientRect().width,
    viewport:innerWidth,scrollWidth:document.querySelector('#nbPanel').scrollWidth,bodyWidth:document.body.scrollWidth,
    list:!document.querySelector('[data-nb-listview]').hidden}));
  check('mobile Notebook list is responsive without horizontal overflow', mobileNotebook.width <= mobileNotebook.viewport+1 && mobileNotebook.scrollWidth <= mobileNotebook.viewport+2 && mobileNotebook.bodyWidth <= mobileNotebook.viewport+2 && mobileNotebook.list, mobileNotebook);

  check('Notebook and entity-note flows use no native browser popup/dialog', dialogs.length===0, dialogs);
  check('the feature run finishes without JavaScript or console errors', errors.length===0, errors);
  await browser.close();
  console.log(`SUMMARY | ${failures.length ? 'FAIL' : 'PASS'} | ${failures.length} failure(s) | ${errors.length} runtime error(s)`);
  if (failures.length || errors.length) process.exit(1);
})().catch(error => { console.error(error); process.exit(1); });
