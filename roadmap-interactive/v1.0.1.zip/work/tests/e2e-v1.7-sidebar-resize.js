const puppeteer = require('puppeteer');
const chromium = require('@sparticuz/chromium');
const http = require('http');
const fs = require('fs');
const path = require('path');

const HTML_PATH = '/home/user/packpolymer-marketplace-roadmap.html';
const failures = [], errors = [];
let server;
const wait = (ms = 120) => new Promise(resolve => setTimeout(resolve, ms));
function check(name, ok, detail) {
  console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}${detail === undefined ? '' : ' | ' + JSON.stringify(detail)}`);
  if (!ok) failures.push(name);
}
async function click(page, selector) {
  return page.evaluate(sel => {
    const el = document.querySelector(sel);
    if (!el) throw new Error('Missing element: ' + sel);
    el.click();
    return true;
  }, selector);
}
async function drag(page, selector, dx, dy = 0) {
  const start = await page.$eval(selector, (el, sel) => {
    const r = el.getBoundingClientRect();
    if (!r.width || !r.height || getComputedStyle(el).display === 'none') throw new Error('Not draggable/visible: ' + sel);
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  }, selector);
  await page.mouse.move(start.x, start.y);
  await page.mouse.down();
  await page.mouse.move(start.x + dx, start.y + dy, { steps: 8 });
  await page.mouse.up();
  await wait(140);
}
async function headerInfo(page) {
  return page.evaluate(() => {
    const header = document.querySelector('.topbar');
    const visible = el => {
      if (!el || !el.isConnected) return false;
      const s = getComputedStyle(el), r = el.getBoundingClientRect();
      return s.display !== 'none' && s.visibility !== 'hidden' && r.width > 0 && r.height > 0;
    };
    const btns = [...header.querySelectorAll('button')].filter(visible);
    const layout = [...header.querySelectorAll('.sidebar-layout-btn')].filter(visible);
    const visibleRect = el => {
      const r = el.getBoundingClientRect(), v = { left:r.left, right:r.right, top:r.top, bottom:r.bottom };
      for (let a = el.parentElement; a && a !== document.body; a = a.parentElement) {
        const s = getComputedStyle(a), ar = a.getBoundingClientRect();
        if (['auto','scroll','hidden','clip'].includes(s.overflowX)) { v.left=Math.max(v.left,ar.left); v.right=Math.min(v.right,ar.right); }
        if (['auto','scroll','hidden','clip'].includes(s.overflowY)) { v.top=Math.max(v.top,ar.top); v.bottom=Math.min(v.bottom,ar.bottom); }
      }
      return v;
    };
    const overlaps = [];
    for (let i = 0; i < btns.length; i++) for (let j = i + 1; j < btns.length; j++) {
      const a = visibleRect(btns[i]), b = visibleRect(btns[j]);
      const w = Math.min(a.right, b.right) - Math.max(a.left, b.left);
      const h = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
      if (w > 1 && h > 1) overlaps.push([btns[i].className, btns[j].className, Math.round(w), Math.round(h)]);
    }
    const button = layout[0], r = button?.getBoundingClientRect();
    return {
      compact: header.classList.contains('compact'), count: layout.length,
      parent: button?.parentElement?.className || '', group: button?.closest('.mobile-header-left') ? 'mobile-header-left' : (button?.closest('.header-actions-left') ? 'header-actions-left' : 'other'),
      rect: r ? { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) } : null,
      headerRect: (() => { const x = header.getBoundingClientRect(); return { x: Math.round(x.x), y: Math.round(x.y), w: Math.round(x.width), h: Math.round(x.height) }; })(),
      overlaps, buttonCount: btns.length
    };
  });
}
async function layoutInfo(page) {
  return page.evaluate(() => {
    const layout = document.querySelector('.layout'), main = layout?.querySelector(':scope > .phases');
    const left = layout?.querySelector(':scope > .side-left'), right = layout?.querySelector(':scope > .side-right'), single = layout?.querySelector(':scope > .side-single');
    const rect = el => el ? el.getBoundingClientRect().toJSON() : null;
    const visible = el => !!el && getComputedStyle(el).display !== 'none' && el.getBoundingClientRect().width > 0 && el.getBoundingClientRect().height > 0;
    const handles = [...(layout?.querySelectorAll('[data-sidebar-resize]') || [])].map(el => ({
      kind: el.dataset.sidebarResize, visible: visible(el), width: Math.round(el.getBoundingClientRect().width),
      label: el.getAttribute('aria-label'), value: el.getAttribute('aria-valuenow')
    }));
    const top = document.querySelector('.topbar'), tr = top?.getBoundingClientRect(), lr = layout?.getBoundingClientRect();
    return {
      mode: layout?.dataset.sidebarLayout, display: layout ? getComputedStyle(layout).display : '',
      documentWidth: document.documentElement.scrollWidth, viewportWidth: document.documentElement.clientWidth,
      layout: rect(layout), topbar: rect(top), main: rect(main), left: rect(left), right: rect(right), single: rect(single),
      leftWidth: left?.getBoundingClientRect().width || 0, rightWidth: right?.getBoundingClientRect().width || 0,
      headerLayoutButton: [...(top?.querySelectorAll('.sidebar-layout-btn') || [])].filter(visible).length,
      handles
    };
  });
}
async function setTop(page) {
  await page.evaluate(() => {
    const root = document.documentElement, old = root.style.scrollBehavior;
    root.style.scrollBehavior = 'auto'; window.scrollTo(0, 0); document.scrollingElement.scrollTop = 0;
    root.style.scrollBehavior = old; window.dispatchEvent(new Event('scroll'));
  });
  await wait(120);
}
async function setScroll(page, y) {
  if (y <= 0) {
    await page.evaluate(() => { document.documentElement.style.setProperty('scroll-behavior','auto','important'); window.scrollTo({top:0,behavior:'instant'}); });
    await wait(240); return;
  }
  // Use a real PageDown event and wait for the compact-header transition to settle before geometry assertions.
  for (let attempt=0; attempt<3; attempt++) {
    await page.evaluate(() => { if (document.activeElement && document.activeElement !== document.body) document.activeElement.blur(); });
    await page.keyboard.press('PageDown'); await wait(260);
    if (await page.evaluate(() => window.scrollY > 48 && document.querySelector('.topbar')?.classList.contains('compact'))) return;
  }
}
async function scrollHandleIntoView(page, selector) {
  await page.evaluate(sel => {
    const el = document.querySelector(sel); if (!el) throw new Error('Missing handle: ' + sel);
    const root = document.documentElement, old = root.style.scrollBehavior, r = el.getBoundingClientRect();
    const target = Math.max(0, Math.min(document.documentElement.scrollHeight - innerHeight, scrollY + r.top + (r.height - innerHeight) / 2));
    root.style.scrollBehavior = 'auto'; window.scrollTo(0, target); document.scrollingElement.scrollTop = target;
    root.style.scrollBehavior = old; window.dispatchEvent(new Event('scroll'));
  }, selector);
  await wait(160);
}

(async () => {
  const html = fs.readFileSync(HTML_PATH);
  server = http.createServer((req, res) => {
    const route = (req.url || '/').split('?')[0];
    if (route === '/seed.html') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end('<!doctype html><html><body>seed</body></html>');
    }
    if (route === '/answers-roadmap.json') {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end('{}');
    }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(html);
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const origin = 'http://127.0.0.1:' + server.address().port;
  let browser = await puppeteer.launch({
    executablePath: await chromium.executablePath(),
    args: [...chromium.args, '--no-sandbox', '--disable-dev-shm-usage'],
    headless: true
  });
  let nbBrowser = null;
  try {
    const page = await browser.newPage();
    page.on('pageerror', e => errors.push(e.message));
    page.on('console', m => { if (m.type() === 'error' && !/scrollTo|not implemented|media/i.test(m.text())) errors.push(m.text()); });
    page.on('requestfailed', r => { if (/^(https?:)/.test(r.url())) errors.push('request failed: ' + r.url()); });

    await page.setViewport({ width: 1920, height: 950 });
    await page.goto(origin + '/seed.html', { waitUntil: 'load' });
    await page.evaluate(() => {
      const now = new Date().toISOString();
      const note = (id, title) => ({ id, title, body: '# ' + title + '\n\nNotebook responsive resize smoke.', folderId: '', category: '', tags: [], direction: 'auto', createdAt: now, updatedAt: now });
      localStorage.setItem('packpolymer-marketplace-roadmap-v2', JSON.stringify({
        nbNotes: [note('sidebar-primary', 'Primary note'), note('sidebar-secondary', 'Secondary note')],
        nbActiveId: 'sidebar-primary', nbSecondaryId: 'sidebar-secondary', nbSplit: true,
        nbMode: 'both', nbSecondaryMode: 'both', nbView: 'note', nbSplitRatio: .5,
        nbBodyRatio: .5, nbBodyRatioSecondary: .5, nbWidthPct: 75,
        ui: { nbOpen: false, editing: false, phaseDrawerOpen: false, sidebarLayout: 'dual-right', sidebarLeftWidth: 300, sidebarRightWidth: 300, sidebarPairRatio: .5, reportMode: 'full' }
      }));
    });
    await page.goto(origin + '/packpolymer-marketplace-roadmap.html', { waitUntil: 'load', timeout: 60000 });
    await page.waitForFunction(() => !!document.querySelector('.layout .phases') && document.querySelectorAll('.phase').length > 0, { timeout: 60000 });
    await wait(500);

    // Desktop initial equality, center-column separation and alignment with the topbar.
    let info = await layoutInfo(page);
    const desktopAligned = Math.abs(info.layout.x - info.topbar.x) <= 1 && Math.abs(info.layout.width - info.topbar.width) <= 1;
    const desktopSeparated = !!info.left && !!info.right && info.left.right <= info.main.left + 1 && info.main.right <= info.right.left + 1;
    check('Desktop dual sidebars begin equal, with the content column between them and the layout aligned to the header', info.mode === 'dual-right' && Math.abs(info.leftWidth - info.rightWidth) <= 1 && desktopSeparated && desktopAligned, {
      mode: info.mode, leftWidth: Math.round(info.leftWidth), rightWidth: Math.round(info.rightWidth), mainWidth: Math.round(info.main.width), desktopAligned, desktopSeparated
    });
    check('Desktop exposes two edge splitters and hides the tablet-only splitter', info.handles.filter(h => h.visible).map(h => h.kind).sort().join(',') === 'left,right', info.handles);
    let hInfo = await headerInfo(page);
    check('Desktop header layout-cycle button remains visible and does not overlap another header button', hInfo.count === 1 && hInfo.overlaps.length === 0, hInfo);

    const initial = await page.evaluate(() => ({ left: document.querySelector('.side-left').getBoundingClientRect().width, right: document.querySelector('.side-right').getBoundingClientRect().width }));
    await drag(page, '.sidebar-resizer-left', 36);
    const afterLeft = await page.evaluate(() => ({ left: document.querySelector('.side-left').getBoundingClientRect().width, right: document.querySelector('.side-right').getBoundingClientRect().width, saved: JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')).ui.sidebarLeftWidth }));
    check('Dragging the left sidebar edge resizes only the left column and writes its width to saved UI state', afterLeft.left >= initial.left + 30 && Math.abs(afterLeft.right - initial.right) <= 1 && afterLeft.saved === Math.round(afterLeft.left), { initial, afterLeft });
    await drag(page, '.sidebar-resizer-right', -30);
    const afterRight = await page.evaluate(() => ({ left: document.querySelector('.side-left').getBoundingClientRect().width, right: document.querySelector('.side-right').getBoundingClientRect().width, saved: JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')).ui.sidebarRightWidth }));
    check('Dragging the right sidebar edge resizes only the right column', afterRight.right >= initial.right + 25 && Math.abs(afterRight.left - afterLeft.left) <= 1 && afterRight.saved === Math.round(afterRight.right), { afterLeft, afterRight });
    await page.focus('.sidebar-resizer-left');
    await page.keyboard.press('ArrowRight');
    await wait(100);
    const afterKey = await page.evaluate(() => ({ left: document.querySelector('.side-left').getBoundingClientRect().width, stored: JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')).ui.sidebarLeftWidth }));
    check('Sidebar splitter supports keyboard resizing and persists the changed width', afterKey.left >= afterLeft.left + 12 && afterKey.stored === Math.round(afterKey.left), afterKey);
    const persisted = await page.evaluate(() => ({ left: JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')).ui.sidebarLeftWidth, right: JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')).ui.sidebarRightWidth, ratio: JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')).ui.sidebarPairRatio }));
    check('Both custom widths and the tablet split ratio are persisted in the saved UI state', persisted.left === afterKey.stored && persisted.right === afterRight.saved && persisted.ratio === .5, persisted);

    // Single-sidebar mode retains a draggable left edge on the right sidebar.
    await click(page, '.topbar .sidebar-layout-btn'); await wait(180);
    info = await layoutInfo(page);
    check('Single-sidebar Desktop keeps the main area and one right sidebar with its own splitter', info.mode === 'single-right' && !info.left && !!info.single && info.main.right <= info.single.left + 1 && info.handles.filter(h => h.visible).map(h => h.kind).join(',') === 'right', info);
    const singleBefore = await page.evaluate(() => document.querySelector('.side-single').getBoundingClientRect().width);
    await drag(page, '.sidebar-resizer-single', -28);
    const singleAfter = await page.evaluate(() => ({ width: document.querySelector('.side-single').getBoundingClientRect().width, stored: JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')).ui.sidebarRightWidth }));
    check('Single right-sidebar splitter grows/shrinks the right sidebar from its left edge', singleAfter.width >= singleBefore + 24 && singleAfter.stored === Math.round(singleAfter.width), { singleBefore, singleAfter });
    await click(page, '.topbar .sidebar-layout-btn'); await wait(160);
    info = await layoutInfo(page);
    const swapped = await page.evaluate(() => ({ leftPhases: !!document.querySelector('.side-left .phases-card'), rightTools: !!document.querySelector('.side-right .side-card-overview') }));
    check('Returning to the third layout places the phase tree left and project tools right without breaking the grid', info.mode === 'dual-left' && swapped.leftPhases && swapped.rightTools && info.left.right <= info.main.left + 1 && info.main.right <= info.right.left + 1, { mode: info.mode, swapped, left: info.left, main: info.main, right: info.right });

    // Tablet dual mode uses one keyboard/pointer-accessible separator between the two equal starting columns.
    await page.setViewport({ width: 1024, height: 820 }); await setTop(page); await wait(180);
    info = await layoutInfo(page); hInfo = await headerInfo(page);
    const tabletOrder = info.display === 'grid' && info.main.bottom <= Math.min(info.left?.top ?? Infinity, info.right?.top ?? Infinity) + 2;
    check('Tablet dual layout keeps the main content above two sidebars and uses the shared center splitter', info.mode === 'dual-left' && tabletOrder && info.handles.filter(h => h.visible).map(h => h.kind).join(',') === 'pair' && info.documentWidth <= info.viewportWidth + 1, info);
    check('Tablet header layout control remains in its own header action group without button overlap', hInfo.count === 1 && hInfo.group === 'header-actions-left' && hInfo.overlaps.length === 0, hInfo);
    const tabletBefore = await page.evaluate(() => ({ left: document.querySelector('.side-left').getBoundingClientRect().width, right: document.querySelector('.side-right').getBoundingClientRect().width }));
    await scrollHandleIntoView(page, '.sidebar-resizer-pair');
    await drag(page, '.sidebar-resizer-pair', 38);
    const tabletAfter = await page.evaluate(() => ({ left: document.querySelector('.side-left').getBoundingClientRect().width, right: document.querySelector('.side-right').getBoundingClientRect().width, ratio: JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')).ui.sidebarPairRatio }));
    check('Tablet center splitter customizes the two lower sidebar columns and persists their ratio', tabletAfter.left >= tabletBefore.left + 30 && tabletAfter.right <= tabletBefore.right - 30 && tabletAfter.ratio > .5, { tabletBefore, tabletAfter });

    await click(page, '.topbar .sidebar-layout-btn'); await wait(120);
    await click(page, '.topbar .sidebar-layout-btn'); await wait(150);
    info = await layoutInfo(page);
    check('Tablet single-sidebar mode keeps the right-hand splitter and does not introduce horizontal page overflow', info.mode === 'single-right' && info.handles.filter(h => h.visible).map(h => h.kind).join(',') === 'right' && info.documentWidth <= info.viewportWidth + 1 && info.single && info.main.bottom <= info.single.top + 2, info);
    const tabletSingleBefore = info.single ? info.single.width : 0;
    await scrollHandleIntoView(page, '.sidebar-resizer-single');
    await drag(page, '.sidebar-resizer-single', -24);
    const tabletSingleAfter = await page.evaluate(() => document.querySelector('.side-single').getBoundingClientRect().width);
    check('Tablet single-sidebar splitter remains draggable', tabletSingleAfter >= tabletSingleBefore + 20, { tabletSingleBefore, tabletSingleAfter });

    // Responsive main page, layout-switch button and all three modes.
    for (const width of [1920, 1440, 1280, 1181, 1180, 1024, 768, 721, 720, 390, 320]) {
      await page.setViewport({ width, height: 820 }); await setTop(page); await wait(80);
      // Return to dual-right so the responsive row/order checks are comparable at every width.
      while ((await page.$eval('.layout', el => el.dataset.sidebarLayout)) !== 'dual-right') {
        await click(page, '.topbar .sidebar-layout-btn'); await wait(90);
      }
      let state = await layoutInfo(page);
      const noOverflow = state.documentWidth <= state.viewportWidth + 1;
      const responsiveOrder = width >= 1181
        ? state.display === 'grid' && !!state.left && !!state.right && state.main.left > state.left.right && state.main.right < state.right.left
        : width > 720
          ? state.display === 'grid' && state.main.bottom <= Math.min(state.left?.top ?? Infinity, state.right?.top ?? Infinity) + 2
          : state.display === 'flex' && state.main.top < Math.min(state.left?.top ?? Infinity, state.right?.top ?? Infinity);
      check(`Main page responsive layout ${width}px preserves content order and avoids viewport overflow`, noOverflow && responsiveOrder, {
        width, mode: state.mode, display: state.display, documentWidth: state.documentWidth, viewportWidth: state.viewportWidth,
        main: state.main && { x: Math.round(state.main.x), y: Math.round(state.main.y), w: Math.round(state.main.width), h: Math.round(state.main.height) },
        left: state.left && { x: Math.round(state.left.x), y: Math.round(state.left.y), w: Math.round(state.left.width) },
        right: state.right && { x: Math.round(state.right.x), y: Math.round(state.right.y), w: Math.round(state.right.width) }
      });
      const btn = await headerInfo(page);
      check(`Header layout-cycle control is visible and collision-free at ${width}px`, btn.count === 1 && btn.overlaps.length === 0, btn);
      await click(page, '.topbar .sidebar-layout-btn'); await wait(130);
      const afterCycle = await layoutInfo(page), afterCycleHeader = await headerInfo(page);
      check(`Layout-cycle control still works and remains collision-free after cycling at ${width}px`, afterCycle.mode === 'single-right' && afterCycle.headerLayoutButton === 1 && afterCycleHeader.count === 1 && afterCycleHeader.overlaps.length === 0, { mode: afterCycle.mode, button: afterCycleHeader });
      await click(page, '.topbar .sidebar-layout-btn'); await wait(120);
      await click(page, '.topbar .sidebar-layout-btn'); await wait(120);
    }

    // Compact sticky header at laptop/tablet/mobile widths; use fresh pages so prior resize/modal state cannot skew the scroll transition.
    for (const width of [1920, 1280, 1024, 768, 390, 320]) {
      const compactPage = await browser.newPage();
      compactPage.on('pageerror', e => errors.push(e.message));
      compactPage.on('console', m => { if (m.type() === 'error' && !/scrollTo|not implemented|media/i.test(m.text())) errors.push(m.text()); });
      await compactPage.setViewport({ width, height: 820 });
      await compactPage.goto(origin + '/packpolymer-marketplace-roadmap.html', { waitUntil:'load', timeout:60000 });
      await compactPage.waitForSelector('.layout .phases', { timeout:60000 }); await wait(250);
      await setScroll(compactPage, 180);
      hInfo = await headerInfo(compactPage);
      check(`Compact header ${width}px keeps exactly one visible layout-cycle control without overlap`, hInfo.compact && hInfo.count === 1 && hInfo.overlaps.length === 0, hInfo);
      await compactPage.close();
    }

    // Notebook is checked in a separate browser process and fresh viewports so its existing width/split mechanism is not affected by prior page scrolling or state.
    await browser.close(); browser = null;
    nbBrowser = await puppeteer.launch({
      executablePath: await chromium.executablePath(),
      args: [...chromium.args, '--no-sandbox', '--disable-dev-shm-usage'],
      headless: true
    });
    for (const width of [1920, 1280, 1024, 768, 720, 390, 320]) {
      const nbPage = await nbBrowser.newPage();
      nbPage.on('pageerror', e => errors.push(e.message));
      nbPage.on('console', m => { if (m.type() === 'error' && !/scrollTo|not implemented|media/i.test(m.text())) errors.push(m.text()); });
      await nbPage.setViewport({ width, height: 820 });
      await nbPage.goto(origin + '/seed.html', { waitUntil: 'load' });
      await nbPage.evaluate(() => {
        const key = 'packpolymer-marketplace-roadmap-v2', state = JSON.parse(localStorage.getItem(key) || '{}'), now = new Date().toISOString();
        const note = (id, title) => ({ id, title, body: '# ' + title + '\\n\\nResponsive Notebook smoke.', folderId: '', category: '', tags: [], direction: 'auto', createdAt: now, updatedAt: now });
        state.nbNotes = [note('sidebar-primary', 'Primary note'), note('sidebar-secondary', 'Secondary note')];
        state.nbActiveId = 'sidebar-primary'; state.nbSecondaryId = 'sidebar-secondary'; state.nbSplit = true;
        state.nbView = 'note'; state.nbMode = 'edit'; state.nbSecondaryMode = 'edit'; state.nbWidthPct = 75; state.nbSplitRatio = .5; state.nbBodyRatio = .5; state.nbBodyRatioSecondary = .5;
        state.ui = Object.assign({}, state.ui, { nbOpen: false, sidebarLayout: 'dual-right' });
        localStorage.setItem(key, JSON.stringify(state));
      });
      await nbPage.goto(origin + '/packpolymer-marketplace-roadmap.html', { waitUntil: 'load', timeout: 60000 });
      await nbPage.waitForSelector('.layout .phases', { timeout: 60000 }); await wait(250);
      await click(nbPage, '#fabNote'); await wait(600);
      await click(nbPage, '#nbPanel [data-nb="toggle-mode"][data-side="primary"]'); await wait(70);
      await click(nbPage, '#nbPanel [data-nb="toggle-mode"][data-side="primary"]'); await wait(120);
      const nb = await nbPage.evaluate(() => {
        const p = document.querySelector('#nbPanel'), r = p.getBoundingClientRect(), wh = document.querySelector('[data-nb-resize="width"]'), sh = document.querySelector('[data-nb-resize="split"]'), bd = document.querySelector('[data-nb-resize="body-primary"]');
        return {
          width: innerWidth, open: p.classList.contains('open'), panelWidth: Math.round(r.width), left: Math.round(r.left), right: Math.round(r.right),
          widthHandleHidden: wh.hidden, widthHandleWidth: Math.round(wh.getBoundingClientRect().width), splitOpen: p.classList.contains('split-open'),
          splitHidden: sh.hidden, splitOrientation: sh.getAttribute('aria-orientation'), bodyDividerHidden: bd.hidden, bodyOrientation: bd.getAttribute('aria-orientation'),
          documentWidth: document.documentElement.scrollWidth, viewportWidth: document.documentElement.clientWidth
        };
      });
      const widthMode = width >= 1440 ? !nb.widthHandleHidden && nb.widthHandleWidth > 0 && nb.panelWidth < width : nb.widthHandleHidden && Math.abs(nb.panelWidth - width) <= 1;
      const splitOrientation = width <= 720 ? nb.splitOrientation === 'horizontal' && nb.bodyOrientation === 'horizontal' : nb.splitOrientation === 'vertical' && nb.bodyOrientation === 'vertical';
      check(`Notebook responsive panel and Split/editor-preview dividers at ${width}px fit the viewport`, nb.open && nb.right <= width + 1 && nb.left >= -1 && nb.documentWidth <= nb.viewportWidth + 1 && widthMode && nb.splitOpen && !nb.splitHidden && !nb.bodyDividerHidden && splitOrientation, nb);
      if (width === 1920) {
        const widthBefore = await nbPage.evaluate(() => JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')).nbWidthPct);
        await drag(nbPage, '#nbPanel [data-nb-resize="width"]', -28);
        const widthAfter = await nbPage.evaluate(() => ({ value: JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')).nbWidthPct, panel: document.querySelector('#nbPanel').getBoundingClientRect().width }));
        check('Notebook Desktop width grip still changes and stores its width', widthAfter.value > widthBefore && widthAfter.panel > nb.panelWidth, { widthBefore, widthAfter });
        const splitBefore = await nbPage.evaluate(() => JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')).nbSplitRatio);
        await drag(nbPage, '#nbPanel [data-nb-resize="split"]', -28);
        const splitAfter = await nbPage.evaluate(() => JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')).nbSplitRatio);
        check('Notebook split pane resizer remains interactive and independent of sidebar sizing', splitAfter > splitBefore, { splitBefore, splitAfter });
        await nbPage.focus('#nbPanel [data-nb-resize="body-primary"]'); await nbPage.keyboard.press('ArrowLeft'); await wait(80);
        const bodyRatio = await nbPage.evaluate(() => JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')).nbBodyRatio);
        check('Notebook editor/preview divider retains keyboard resizing', bodyRatio > .5, bodyRatio);
      }
      await nbPage.close();
    }

    check('Sidebar/header/Notebook responsive resize suite produced no uncaught runtime or console errors', errors.length === 0, errors);
  } finally {
    if (nbBrowser) await nbBrowser.close();
    if (browser) await browser.close();
    await new Promise(resolve => server.close(resolve));
  }
  console.log(`SUMMARY | ${failures.length ? 'FAIL' : 'PASS'} | ${failures.length} failure(s) | ${errors.length} runtime error(s)`);
  if (failures.length) process.exitCode = 1;
})().catch(error => { console.error(error); if (server) server.close(); process.exitCode = 1; });
