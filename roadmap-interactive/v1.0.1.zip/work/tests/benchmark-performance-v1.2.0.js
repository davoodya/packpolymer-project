const puppeteer=require('puppeteer');
const chromium=require('@sparticuz/chromium');
const fs=require('fs');
const path=require('path');
const http=require('http');
const BASE='/home/user';
const HTML='/packpolymer-marketplace-roadmap.html';
const PORT=8900;
const wait=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
  const appHtml=fs.readFileSync(path.join(BASE,HTML),'utf8');
  const needle="case 'expand-all': state.plan.forEach(p => state.open[p.id] = true); save(); renderSearchResults(); break;";
  if(!appHtml.includes(needle))throw new Error('Expand All handler not found; rebuild before benchmarking.');
  let instrumentedHtml=appHtml;
  const diagnosticReplacements=[
    ['const ph=state.plan[i],data=phaseRenderData(ph,i,true);i++;count++;','const ph=state.plan[i];window.__renderStage="phase:"+ph.id;const data=phaseRenderData(ph,i,true);i++;count++;'],
    ['const step=item.steps[item.index++],ix=item.ph.steps.indexOf(step),t=document.createElement(\'template\');','const step=item.steps[item.index++],ix=item.ph.steps.indexOf(step),t=document.createElement(\'template\');window.__renderStage="step:"+item.ph.id+":"+step.id;'],
    ['const sub=item.subs[item.index++],t=document.createElement(\'template\');','const sub=item.subs[item.index++],t=document.createElement(\'template\');window.__renderStage="sub:"+item.ph.id+":"+item.step.id+":"+sub.index;']
  ];
  for(const [before,after] of diagnosticReplacements){if(!instrumentedHtml.includes(before))throw new Error('Render diagnostic hook not found: '+before.slice(0,70));instrumentedHtml=instrumentedHtml.replace(before,after);}
  const phaseRenderLine='const data=phaseRenderData(ph,i,true);i++;count++;';
  if(!instrumentedHtml.includes(phaseRenderLine))throw new Error('Phase duration hook not found.');
  instrumentedHtml=instrumentedHtml.replace(phaseRenderLine,'const __phaseStart=performance.now();const data=phaseRenderData(ph,i,true);const __phaseMs=performance.now()-__phaseStart;window.__renderMetrics.push({stage:window.__renderStage,phaseMs:+__phaseMs.toFixed(2)});i++;count++;');
  const stepRenderLine='t.innerHTML=stepHTML(item.ph,step,ix,true);const article=t.content.firstElementChild,subList=article&&article.querySelector(\'.subs\');';
  if(!instrumentedHtml.includes(stepRenderLine))throw new Error('Step duration hook not found.');
  instrumentedHtml=instrumentedHtml.replace(stepRenderLine,'const __stepHtmlStart=performance.now();t.innerHTML=stepHTML(item.ph,step,ix,true);const __stepHtmlMs=performance.now()-__stepHtmlStart;const article=t.content.firstElementChild,subList=article&&article.querySelector(\'.subs\');window.__renderMetrics.push({stage:window.__renderStage,stepHtmlMs:+__stepHtmlMs.toFixed(2)});');
  const stepAppendLine='item.container.appendChild(t.content);stepWork++;';
  if(!instrumentedHtml.includes(stepAppendLine))throw new Error('Step append duration hook not found.');
  instrumentedHtml=instrumentedHtml.replace(stepAppendLine,'const __stepAppendStart=performance.now();item.container.appendChild(t.content);const __stepAppendMs=performance.now()-__stepAppendStart;window.__renderMetrics.push({stage:window.__renderStage,stepAppendMs:+__stepAppendMs.toFixed(2)});stepWork++;');
  const subRenderLine='t.innerHTML=subHTML(item.ph,item.step,sub.x,sub.index,item.si);item.list.appendChild(t.content);subWork++;';
  if(!instrumentedHtml.includes(subRenderLine))throw new Error('Substep duration hook not found.');
  instrumentedHtml=instrumentedHtml.replace(subRenderLine,'const __subHtmlStart=performance.now();t.innerHTML=subHTML(item.ph,item.step,sub.x,sub.index,item.si);const __subHtmlMs=performance.now()-__subHtmlStart;const __subAppendStart=performance.now();item.list.appendChild(t.content);window.__renderMetrics.push({stage:window.__renderStage,htmlMs:+__subHtmlMs.toFixed(2),appendMs:+(performance.now()-__subAppendStart).toFixed(2)});subWork++;');
  instrumentedHtml=instrumentedHtml.replaceAll('item.slot.replaceWith(item.list);pendingSubs.shift();','const __attachStart=performance.now();item.slot.replaceWith(item.list);window.__renderMetrics.push({stage:window.__renderStage,replaceMs:+(performance.now()-__attachStart).toFixed(2)});pendingSubs.shift();');
  const baselineHtml=instrumentedHtml.replace(needle,needle.replace('renderSearchResults();','render();'));
  const server=http.createServer((req,res)=>{
    const pathname=decodeURIComponent((req.url||'/').split('?')[0]);
    if(pathname==='/baseline.html'){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});return res.end(baselineHtml);}
    if(pathname===HTML){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});return res.end(instrumentedHtml);}
    const rel=pathname==='/'?HTML:pathname;
    const file=path.resolve(BASE,'.'+rel);
    if(!file.startsWith(BASE)){res.writeHead(403);return res.end('forbidden');}
    fs.readFile(file,(err,data)=>{if(err){res.writeHead(404);return res.end('not found');}
      const type=file.endsWith('.json')?'application/json; charset=utf-8':file.endsWith('.html')?'text/html; charset=utf-8':'text/plain; charset=utf-8';
      res.writeHead(200,{'Content-Type':type,'Cache-Control':'no-store'});res.end(data);
    });
  });
  await new Promise(r=>server.listen(PORT,'127.0.0.1',r));
  const browser=await puppeteer.launch({executablePath:await chromium.executablePath(),headless:true,args:[...chromium.args,'--no-sandbox','--disable-dev-shm-usage']});
  const page=await browser.newPage();
  await page.evaluateOnNewDocument(()=>{window.__longTasks=[];window.__longTaskDetails=[];window.__renderMetrics=[];try{new PerformanceObserver(l=>{for(const x of l.getEntries()){window.__longTasks.push(x.duration);window.__longTaskDetails.push({durationMs:+x.duration.toFixed(2),startTimeMs:+x.startTime.toFixed(2),stage:window.__renderStage||'n/a'});}}).observe({type:'longtask',buffered:true});}catch(e){}});
  const run=async(pathname,clearStorage=false)=>{
    if(clearStorage&&page.url()!=='about:blank')await page.evaluate(()=>localStorage.clear());
    await page.setViewport({width:1920,height:950});
    await page.goto(`http://127.0.0.1:${PORT}${pathname}`,{waitUntil:'load',timeout:60000});
    await wait(850);
    const dispatchMs=await page.evaluate(()=>{window.__longTasks=[];window.__longTaskDetails=[];window.__renderMetrics=[];window.__renderStage='idle';window.__benchStart=performance.now();const t=performance.now();document.querySelector('[data-act="expand-all"]').click();return performance.now()-t;});
    await page.waitForFunction(()=>document.querySelectorAll('#phases .step').length===122&&document.querySelectorAll('#phases .sub').length===749,{timeout:20000});
    await wait(80);
    return page.evaluate(dispatchMs=>{const m=window.__renderMetrics||[],subs=m.filter(x=>x.htmlMs!=null),lists=m.filter(x=>x.replaceMs!=null),phases=m.filter(x=>x.phaseMs!=null),stepHtml=m.filter(x=>x.stepHtmlMs!=null),stepAppend=m.filter(x=>x.stepAppendMs!=null);return {dispatchMs,totalMs:performance.now()-window.__benchStart,steps:document.querySelectorAll('#phases .step').length,substeps:document.querySelectorAll('#phases .sub').length,maxLongTaskMs:Math.max(0,...window.__longTasks),longTasks:window.__longTaskDetails,phaseRenderTiming:{maxMs:Math.max(0,...phases.map(x=>x.phaseMs)),slowest:phases.slice().sort((a,b)=>b.phaseMs-a.phaseMs).slice(0,6)},stepRenderTiming:{maxHtmlMs:Math.max(0,...stepHtml.map(x=>x.stepHtmlMs)),maxAppendMs:Math.max(0,...stepAppend.map(x=>x.stepAppendMs)),slowest:stepHtml.slice().sort((a,b)=>b.stepHtmlMs-a.stepHtmlMs).slice(0,8),slowestAppend:stepAppend.slice().sort((a,b)=>b.stepAppendMs-a.stepAppendMs).slice(0,8)},subRenderTiming:{maxHtmlMs:Math.max(0,...subs.map(x=>x.htmlMs)),maxAppendMs:Math.max(0,...subs.map(x=>x.appendMs)),slowest:subs.slice().sort((a,b)=>Math.max(b.htmlMs,b.appendMs)-Math.max(a.htmlMs,a.appendMs)).slice(0,10),maxListReplaceMs:Math.max(0,...lists.map(x=>x.replaceMs)),slowestListReplaces:lists.slice().sort((a,b)=>b.replaceMs-a.replaceMs).slice(0,8)}};},dispatchMs);
  };
  const baseline=await run('/baseline.html');
  const optimized=await run(HTML,true);
  await browser.close();await new Promise(r=>server.close(r));
  console.log(JSON.stringify({environment:'Headless Chromium, 1920x950; stage-instrumented current build vs benchmark-only synchronous Expand All reference',baseline,optimized},null,2));
  if(baseline.steps!==optimized.steps||baseline.substeps!==optimized.substeps)process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1;});
