const puppeteer = require('puppeteer');
const chromium = require('@sparticuz/chromium');
const fs = require('fs');
const http = require('http');
const html = fs.readFileSync('/home/user/packpolymer-marketplace-roadmap.html');
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
(async () => {
  const server = http.createServer((req, res) => {
    const route = (req.url || '/').split('?')[0];
    if (route === '/seed.html') { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end('<!doctype html><html><body>seed</body></html>'); }
    if (route === '/answers-roadmap.json') { res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' }); return res.end('{}'); }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); res.end(html);
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await puppeteer.launch({ executablePath: await chromium.executablePath(), headless: true, args: [...chromium.args, '--no-sandbox', '--disable-dev-shm-usage'] });
  try {
    const page = await browser.newPage();
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    await page.setViewport({ width: 320, height: 844 });
    const origin = `http://127.0.0.1:${server.address().port}`;
    await page.goto(origin + '/seed.html', { waitUntil: 'load' });
    await page.evaluate(() => localStorage.removeItem('packpolymer-marketplace-roadmap-v2'));
    await page.goto(origin + '/packpolymer-marketplace-roadmap.html', { waitUntil: 'load', timeout: 60000 });
    await page.waitForSelector('.compact-report-menu [data-act="report-menu"]');
    await page.waitForFunction(() => document.querySelector('#q') && document.querySelector('#fabNote') && document.querySelector('.topbar'), { timeout: 10000 });
    await wait(350);
    await page.evaluate(() => { document.documentElement.style.scrollBehavior = 'auto'; window.scrollTo(0, 500); window.dispatchEvent(new Event('scroll')); });
    await page.$eval('.compact-report-menu [data-act="report-menu"]', button => button.scrollIntoView({ block: 'nearest', inline: 'center' }));
    await page.click('.compact-report-menu [data-act="report-menu"]');
    await wait(80);
    const result = await page.evaluate(() => {
      const menu = document.querySelector('.compact-report-menu .menu-pop'), rect = menu.getBoundingClientRect();
      const hit = document.elementFromPoint((rect.left + rect.right) / 2, (rect.top + rect.bottom) / 2);
      return { width: innerWidth, documentWidth: document.documentElement.scrollWidth, left: rect.left, right: rect.right, top: rect.top, bottom: rect.bottom, display: getComputedStyle(menu).display, interactive: !!hit && menu.contains(hit), choices: [...menu.querySelectorAll('[data-act="report"]')].map(button => button.dataset.id) };
    });
    const ok = result.width === 320 && result.documentWidth <= 322 && result.left >= 0 && result.right <= result.width && result.top >= 0 && result.bottom <= 844 && result.display === 'flex' && result.interactive && result.choices.length === 3 && errors.length === 0;
    console.log(`${ok ? 'PASS' : 'FAIL'} | Mobile report menu is viewport-safe and clickable at 320px | ${JSON.stringify({ ...result, errors })}`);
    if (!ok) process.exitCode = 1;
  } finally { await browser.close(); await new Promise(resolve => server.close(resolve)); }
})().catch(error => { console.error(error); process.exitCode = 1; });
