const puppeteer = require('puppeteer');
const chromium = require('@sparticuz/chromium');
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const failures = [];
const errors = [];
let server, fallbackServer;
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
function check(name, ok, detail) {
  console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}${detail === undefined ? '' : ' | ' + JSON.stringify(detail)}`);
  if (!ok) failures.push(name);
}
async function click(page, selector) {
  await page.evaluate(sel => {
    const el = document.querySelector(sel);
    if (!el) throw new Error('Missing element: ' + sel);
    el.click();
  }, selector);
}
function png() {
  return Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p7cAAAAASUVORK5CYII=', 'base64');
}
function pdf() { return Buffer.from('%PDF-1.4\nattachment archive test\n%%EOF\n', 'utf8'); }
async function pasteFiles(page, selector, files) {
  return page.$eval(selector, (el, args) => {
    el.focus();
    const transfer = new DataTransfer();
    for (const item of args) transfer.items.add(new File([new Uint8Array(item.bytes)], item.name, { type: item.type }));
    const event = new ClipboardEvent('paste', { clipboardData: transfer, bubbles: true, cancelable: true });
    const notCanceled = el.dispatchEvent(event);
    return { notCanceled, count: transfer.files.length };
  }, files.map(item => ({ name: item.name, type: item.type, bytes: Array.from(item.bytes) })));
}
async function waitForDownload(dir, ext, timeout = 15000) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const files = fs.readdirSync(dir).filter(name => name.toLowerCase().endsWith(ext) && !name.endsWith('.crdownload'));
    if (files.length) return path.join(dir, files.sort()[files.length - 1]);
    await wait(100);
  }
  throw new Error('Download not completed: ' + ext);
}
function readZip(zipPath) {
  const script = [
    'import zipfile,json,hashlib,sys',
    'z=zipfile.ZipFile(sys.argv[1])',
    'names=z.namelist()',
    'md=next((x for x in names if x.lower().endswith(".md")),"")',
    'text=z.read(md).decode("utf-8-sig") if md else ""',
    'assets={x:hashlib.sha256(z.read(x)).hexdigest() for x in names if x.startswith("attachment/") and not x.endswith("/")}',
    'print(json.dumps({"names":names,"markdownName":md,"markdown":text,"assets":assets},ensure_ascii=False))'
  ].join(';');
  return JSON.parse(execFileSync('python3', ['-c', script, zipPath], { encoding: 'utf8' }));
}
const hash = data => crypto.createHash('sha256').update(data).digest('hex');
async function installDownloadPath(page, dir) {
  const client = await page.target().createCDPSession();
  await client.send('Page.setDownloadBehavior', { behavior: 'allow', downloadPath: dir });
  return client;
}
async function seedAndOpen(page, origin, id, legacy = null) {
  await page.goto(origin + '/seed.html', { waitUntil: 'load' });
  await page.evaluate(async ({ noteId, legacyData }) => {
    const now = new Date().toISOString();
    const note = { id: noteId, title: 'ZIP attachment test', body: '', folderId: '', category: '', tags: [], direction: 'auto', createdAt: now, updatedAt: now };
    localStorage.setItem('packpolymer-marketplace-roadmap-v2', JSON.stringify({
      nbNotes: [note], nbActiveId: note.id, nbSecondaryId: '', nbFolders: [], nbTags: [], nbCategories: [],
      nbView: 'note', nbMode: 'edit', nbSecondaryMode: 'edit', nbSplit: false, nbSplitRatio: .5,
      nbWidthPct: 75, nbBodyRatio: .5, nbBodyRatioSecondary: .5, openNotes: {}, noteModes: {}, ui: { nbOpen: false }
    }));
    if (legacyData) {
      const db = await new Promise(resolve => {
        const request = indexedDB.open('packpolymer-roadmap', 1);
        request.onupgradeneeded = () => { try { request.result.createObjectStore('kv'); } catch (_) {} };
        request.onsuccess = () => resolve(request.result); request.onerror = () => resolve(null);
      });
      if (db) await new Promise(resolve => {
        const tx = db.transaction('kv', 'readwrite'), store = tx.objectStore('kv');
        store.put(new Blob([new Uint8Array(legacyData.bytes)], { type: legacyData.type }), 'roadmap-attachment:' + legacyData.name);
        store.put([legacyData.name], 'attachmentIndex');
        tx.oncomplete = resolve; tx.onerror = resolve;
      });
    }
  }, { noteId: id, legacyData: legacy ? { name: legacy.name, type: legacy.type, bytes: Array.from(legacy.bytes) } : null });
  await page.goto(origin + '/packpolymer-marketplace-roadmap.html', { waitUntil: 'load', timeout: 60000 });
  await page.waitForFunction(() => !!document.querySelector('#fabNote') && !!document.querySelector('#nbPanel'), { timeout: 10000 });
  await wait(250);
  await click(page, '#fabNote');
  await page.waitForFunction(() => document.querySelector('#nbPanel')?.classList.contains('open') && !document.querySelector('[data-nb-noteview]')?.hidden, { timeout: 8000 });
  await wait(120);
}

(async () => {
  const outputDir = fs.mkdtempSync(path.join(os.tmpdir(), 'arena-attachments-zip-'));
  let browser = await puppeteer.launch({
    executablePath: await chromium.executablePath(),
    args: [...chromium.args, '--no-sandbox', '--disable-dev-shm-usage'],
    headless: true
  });
  try {
    const html = fs.readFileSync('/home/user/packpolymer-marketplace-roadmap.html');
    server = http.createServer((req, res) => {
      const url = (req.url || '/').split('?')[0];
      if (url === '/seed.html') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
        return res.end('<!doctype html><html><body>seed</body></html>');
      }
      if (url === '/answers-roadmap.json') {
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
        return res.end('{}');
      }
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(html);
    });
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
    const origin = 'http://127.0.0.1:' + server.address().port;

    // Chromium/File System Access path: the selected parent is the folder beside the single HTML file.
    const page = await browser.newPage();
    const files = new Map();
    await page.evaluateOnNewDocument(() => {
      const files = new Map();
      const directory = {
        async getFileHandle(name, options) {
          if (!(options && options.create) && !files.has(name)) throw new DOMException('Missing test attachment', 'NotFoundError');
          return {
            async createWritable() {
              let next = null;
              return { async write(value) { next = value instanceof Blob ? value : new Blob([value]); }, async close() { if (next) files.set(name, next); }, async abort() { next = null; } };
            },
            async getFile() { const file = files.get(name); if (!file) throw new DOMException('Missing test attachment', 'NotFoundError'); return file; }
          };
        }
      };
      const parent = {
        name: 'project',
        async queryPermission() { return 'granted'; },
        async requestPermission() { return 'granted'; },
        async getDirectoryHandle(name) { if (name !== 'attachments') throw new Error('unexpected folder'); return directory; }
      };
      window.__testAttachmentFiles = files;
      window.showDirectoryPicker = async () => parent;
    });
    page.on('pageerror', error => errors.push(error.message));
    page.on('console', message => { if (message.type() === 'error' && !/scrollTo|not implemented/i.test(message.text())) errors.push(message.text()); });
    await page.setViewport({ width: 1280, height: 900 });
    const pData = png(), pdfData = pdf(), legacyName = 'legacy-migration.png';
    await seedAndOpen(page, origin, 'zip-fs-note', { name: legacyName, type: 'image/png', bytes: pData });
    await wait(250);
    const guideBefore = await page.$eval('[data-nb-noteview] [data-attachment-guidance]', el => ({ hidden: el.hidden, text: el.innerText, button: !!el.querySelector('[data-nb="attachment-connect"]') }));
    check('Notebook shows a responsive first-use disclaimer with an explicit folder-selection button', !guideBefore.hidden && guideBefore.button && /انتخاب پوشه/.test(guideBefore.text), guideBefore);
    await click(page, '[data-nb-noteview] [data-nb="attachment-connect"]');
    await page.waitForFunction(() => document.querySelector('[data-nb-noteview] [data-attachment-guidance]')?.hidden === true, { timeout: 6000 });
    const guideAfter = await page.$eval('[data-nb-noteview] [data-attachment-guidance]', el => el.hidden);
    check('Selecting the attachments directory hides the disclaimer for Notebook and all note editors', guideAfter, { hidden: guideAfter });
    const migration = await page.evaluate(async name => {
      const file = window.__testAttachmentFiles.get(name);
      const bytes = file ? Array.from(new Uint8Array(await file.arrayBuffer())) : null;
      const db = await new Promise(resolve => { const req=indexedDB.open('packpolymer-roadmap',1);req.onsuccess=()=>resolve(req.result);req.onerror=()=>resolve(null); });
      const get = key => db ? new Promise(resolve => { const tx=db.transaction('kv','readonly'),req=tx.objectStore('kv').get(key);req.onsuccess=()=>resolve(req.result||null);req.onerror=()=>resolve(null); }) : null;
      const source = await get('roadmap-attachment:' + name), index = await get('attachmentIndex');
      return { bytes, sourceStillInIndexedDB: !!source, index: index || [] };
    }, legacyName);
    check('Legacy IndexedDB attachment migrates to the selected folder and source data is removed only after successful write', migration.bytes && Buffer.from(migration.bytes).equals(pData) && !migration.sourceStillInIndexedDB && !migration.index.includes(legacyName), { filePresent: !!migration.bytes, sourceStillInIndexedDB: migration.sourceStillInIndexedDB, index: migration.index });

    await click(page, '#fabNote');
    await page.waitForFunction(() => !document.querySelector('#nbPanel')?.classList.contains('open'), { timeout: 6000 });
    const noteToggle = await page.$('.phase-note-toggle');
    if (noteToggle) {
      await page.evaluate(() => { const button=document.querySelector('.phase-note-toggle'),phase=button&&button.closest('.phase');if(phase&&!phase.classList.contains('open'))phase.querySelector('.ph-head')?.click(); });
      await page.waitForFunction(() => document.querySelector('.phase-note-toggle')?.closest('.phase')?.classList.contains('open'), { timeout: 6000 });
      await click(page, '.phase-note-toggle');
      await page.waitForFunction(() => !!document.querySelector('.note-wrap.show [data-attachment-guidance]'), { timeout: 6000 });
      const mainGuide = await page.$eval('.note-wrap.show [data-attachment-guidance]', el => el.hidden);
      check('Written-note guidance also stays hidden after the folder is connected', mainGuide, { hidden: mainGuide });
    } else check('Written-note guidance also stays hidden after the folder is connected', false, 'phase note control missing');

    const mainPaste = await pasteFiles(page, 'textarea.note-editor[data-note]', [
      { name: 'main-note-fixture.png', type: 'image/png', bytes: pData }
    ]);
    await page.waitForFunction(() => document.querySelector('textarea.note-editor[data-note]')?.value.includes('attachments/'), { timeout: 10000 });
    const mainNoteText = await page.$eval('textarea.note-editor[data-note]', el => el.value);
    const mainNoteFiles = await page.evaluate(() => [...window.__testAttachmentFiles.keys()]);
    check('Pasting media in a written-note editor saves the Blob and inserts a valid attachments/ reference', !mainPaste.notCanceled && mainPaste.count === 1 && mainNoteText.includes('attachments/') && mainNoteFiles.length === 2 && mainNoteFiles.includes(legacyName), { mainPaste, mainNoteText, files: mainNoteFiles });
    await click(page, '#fabNote');
    await page.waitForFunction(() => document.querySelector('#nbPanel')?.classList.contains('open') && !document.querySelector('[data-nb-noteview]')?.hidden, { timeout: 6000 });

    const pasted = await pasteFiles(page, '#nbEdit', [
      { name: 'clipboard-fixture.png', type: 'image/png', bytes: pData },
      { name: 'contract-fixture.pdf', type: 'application/pdf', bytes: pdfData }
    ]);
    await page.waitForFunction(() => {
      const text = document.querySelector('#nbEdit')?.value || '';
      return (text.match(/attachments\//g) || []).length === 2;
    }, { timeout: 10000 });
    const fsNote = await page.$eval('#nbEdit', el => el.value);
    const fsRefs = [...fsNote.matchAll(/!?\[\[(attachments\/[A-Za-z0-9._-]+)\]\]/g)].map(m => m[1]);
    const fsFiles = await page.evaluate(() => [...window.__testAttachmentFiles.entries()].map(([name, blob]) => ({ name, size: blob.size, type: blob.type })));
    check('Clipboard image and generic attachment save as real Blobs in attachments/ and insert only short Markdown paths', !pasted.notCanceled && pasted.count === 2 && fsRefs.length === 2 && fsFiles.length === 4 && fsFiles.some(x => x.name === legacyName) && fsFiles.every(x => x.size > 0), { pasted, refs: fsRefs, files: fsFiles });

    const fsDownloads = path.join(outputDir, 'filesystem'); fs.mkdirSync(fsDownloads);
    await installDownloadPath(page, fsDownloads);
    await click(page, '[data-nb="download"][data-side="primary"]');
    const fsZipPath = await waitForDownload(fsDownloads, '.zip');
    const fsZip = readZip(fsZipPath);
    const fsAssetEntries = Object.entries(fsZip.assets);
    const fsZipMatches = fsZip.markdownName.endsWith('.md') && fsZip.names.includes('attachment/') && fsZip.markdown.includes('![[attachment/') && fsZip.markdown.includes('[[attachment/') && !fsZip.markdown.includes('attachments/') && fsRefs.every(ref => fsZip.names.includes(ref.replace(/^attachments\//, 'attachment/'))) &&
      fsAssetEntries.length === 2 && fsAssetEntries.some(([name, digest]) => name.endsWith('.png') && digest === hash(pData)) &&
      fsAssetEntries.some(([name, digest]) => name.endsWith('.pdf') && digest === hash(pdfData));
    check('Notebook export with attachments is a valid ZIP containing BOM-readable Markdown and matching relative attachments/ paths', fsZipMatches, { file: path.basename(fsZipPath), names: fsZip.names, markdownName: fsZip.markdownName, assetNames: fsAssetEntries.map(([name]) => name) });
    const zipRedownload = await page.$eval('#textModal .modal-hint', el => el.textContent.includes('.zip'));
    check('ZIP export modal identifies the archive format for its redownload action', zipRedownload, { zipRedownload });

    await page.$eval('#nbEdit', el => { el.value = 'A note without any attachments.'; el.dispatchEvent(new Event('input', { bubbles: true })); });
    const directDir = path.join(outputDir, 'direct'); fs.mkdirSync(directDir);
    await installDownloadPath(page, directDir);
    await click(page, '[data-nb="download"][data-side="primary"]');
    const mdPath = await waitForDownload(directDir, '.md');
    check('A note with no attachment still downloads a plain Markdown file, not a ZIP', mdPath.endsWith('.md') && fs.readdirSync(directDir).every(name => name.endsWith('.md') || name.endsWith('.crdownload')), { file: path.basename(mdPath) });

    // Restart Chromium between paths to keep file-download sessions isolated in the headless runner.
    await browser.close().catch(() => {});
    browser = await puppeteer.launch({ executablePath: await chromium.executablePath(), args: [...chromium.args, '--no-sandbox', '--disable-dev-shm-usage'], headless: true });
    // Unsupported-browser path (Firefox behavior): keep paste functional using explicit IndexedDB fallback.
    fallbackServer = http.createServer((req,res) => {
      const url=(req.url||'/').split('?')[0];
      if(url==='/seed.html'){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});return res.end('<!doctype html><html><body>seed</body></html>');}
      if(url==='/answers-roadmap.json'){res.writeHead(200,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});return res.end('{}');}
      res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});res.end(html);
    });
    await new Promise(resolve => fallbackServer.listen(0, '127.0.0.1', resolve));
    const fallbackOrigin='http://127.0.0.1:'+fallbackServer.address().port;
    const fallback = await browser.newPage();
    await fallback.evaluateOnNewDocument(() => { try { window.showDirectoryPicker = undefined; } catch (_) { Object.defineProperty(window, 'showDirectoryPicker', { value: undefined, configurable: true }); } });
    fallback.on('pageerror', error => errors.push(error.message));
    fallback.on('console', message => { if (message.type() === 'error' && !/scrollTo|not implemented/i.test(message.text())) errors.push(message.text()); });
    await fallback.setViewport({ width: 390, height: 844 });
    await seedAndOpen(fallback, fallbackOrigin, 'zip-idb-note');
    await wait(250);
    const fallbackGuide = await fallback.$eval('[data-nb-noteview] [data-attachment-guidance]', el => ({ hidden: el.hidden, text: el.innerText, hasFolderButton: !!el.querySelector('button') }));
    check('Unsupported-browser disclaimer explains the IndexedDB fallback instead of presenting an unusable folder picker', !fallbackGuide.hidden && /IndexedDB/.test(fallbackGuide.text) && !fallbackGuide.hasFolderButton, fallbackGuide);
    const idbPaste = await pasteFiles(fallback, '#nbEdit', [
      { name: 'fallback-image.png', type: 'image/png', bytes: pData },
      { name: 'fallback-document.pdf', type: 'application/pdf', bytes: pdfData }
    ]);
    await fallback.waitForFunction(() => (document.querySelector('#nbEdit')?.value.match(/attachments\//g) || []).length === 2, { timeout: 10000 });
    const idbNote = await fallback.$eval('#nbEdit', el => el.value);
    const idbRefs = [...idbNote.matchAll(/!?\[\[(attachments\/[A-Za-z0-9._-]+)\]\]/g)].map(m => m[1]);
    const idbStored = await fallback.evaluate(async refs => {
      const db = await new Promise(resolve => { const req = indexedDB.open('packpolymer-roadmap', 1); req.onsuccess = () => resolve(req.result); req.onerror = () => resolve(null); });
      if (!db) return { index: [], blobs: [] };
      const get = key => new Promise(resolve => { const tx = db.transaction('kv', 'readonly'), req = tx.objectStore('kv').get(key); req.onsuccess = () => resolve(req.result || null); req.onerror = () => resolve(null); });
      const index = await get('attachmentIndex') || [];
      const blobs = await Promise.all(refs.map(async ref => { const name = ref.slice('attachments/'.length), blob = await get('roadmap-attachment:' + name); return { name, isBlob: blob instanceof Blob, size: blob?.size || 0 }; }));
      return { index, blobs };
    }, idbRefs);
    check('Firefox-style IndexedDB fallback accepts pasted media and stores Blob data plus an attachment index', !idbPaste.notCanceled && idbPaste.count === 2 && idbRefs.length === 2 && idbStored.blobs.length === 2 && idbStored.blobs.every(x => x.isBlob && x.size > 0) && idbRefs.every(ref => idbStored.index.includes(ref.slice('attachments/'.length))), { idbPaste, refs: idbRefs, stored: idbStored });

    const idbDownloads = path.join(outputDir, 'indexeddb'); fs.mkdirSync(idbDownloads);
    await installDownloadPath(fallback, idbDownloads);
    await click(fallback, '[data-nb="download"][data-side="primary"]');
    const idbZipPath = await waitForDownload(idbDownloads, '.zip');
    const idbZip = readZip(idbZipPath);
    const idbAssetEntries = Object.entries(idbZip.assets);
    const idbZipMatches = idbZip.names.includes('attachment/') && idbZip.markdown.includes('![[attachment/') && idbZip.markdown.includes('[[attachment/') && !idbZip.markdown.includes('attachments/') && idbRefs.every(ref => idbZip.names.includes(ref.replace(/^attachments\//, 'attachment/'))) && idbAssetEntries.length === 2 &&
      idbAssetEntries.some(([name, digest]) => name.endsWith('.png') && digest === hash(pData)) && idbAssetEntries.some(([name, digest]) => name.endsWith('.pdf') && digest === hash(pdfData));
    check('IndexedDB-backed Notebook attachments are included byte-for-byte in the Markdown ZIP', idbZipMatches, { file: path.basename(idbZipPath), names: idbZip.names, assetNames: idbAssetEntries.map(([name]) => name) });

    check('Attachment, paste, ZIP, disclaimer and fallback flows finish without JavaScript or console errors', errors.length === 0, errors);
  } finally {
    await browser.close().catch(() => {});
    if (server) await new Promise(resolve => server.close(resolve));
    if (fallbackServer) await new Promise(resolve => fallbackServer.close(resolve));
  }
  if (failures.length) process.exitCode = 1;
})();
