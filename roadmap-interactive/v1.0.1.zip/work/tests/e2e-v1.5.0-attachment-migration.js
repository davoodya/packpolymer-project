const puppeteer = require('puppeteer');
const chromium = require('@sparticuz/chromium');
const http = require('http');
const fs = require('fs');

const failures = [], errors = [];
let server = null;
const wait = (ms = 120) => new Promise(resolve => setTimeout(resolve, ms));
function check(name, ok, detail) {
  console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}${detail === undefined ? '' : ' | ' + JSON.stringify(detail)}`);
  if (!ok) failures.push(name);
}
async function click(page, selector) {
  await page.evaluate(sel => {
    const el = document.querySelector(sel);
    if (!el) throw new Error('Missing element: ' + sel);
    el.click();
  }, selector);
}

(async () => {
  const browser = await puppeteer.launch({
    executablePath: await chromium.executablePath(),
    args: [...chromium.args, '--no-sandbox', '--disable-dev-shm-usage'],
    headless: true
  });
  try {
    const page = await browser.newPage();
    await page.evaluateOnNewDocument(() => {
      const files = new Map(); let pickerCalls = 0;
      const directory = {
        async getFileHandle(name, options) {
          if (name === 'legacy-fail.png') throw new DOMException('Intentional migration failure', 'NotFoundError');
          if (!(options && options.create) && !files.has(name)) throw new DOMException('Missing test attachment', 'NotFoundError');
          return {
            async createWritable() {
              let next = null;
              return { async write(blob) { next = blob instanceof Blob ? blob : new Blob([blob]); }, async close() { if (next) files.set(name, next); }, async abort() { next = null; } };
            },
            async getFile() { const file = files.get(name); if (!file) throw new DOMException('Missing test attachment', 'NotFoundError'); return file; }
          };
        }
      };
      const parent = { async queryPermission() { return 'granted'; }, async requestPermission() { return 'granted'; }, async getDirectoryHandle(name) { if (name !== 'attachments') throw new Error('unexpected directory'); return directory; } };
      window.__migrationFiles = files;
      window.__pickerCalls = () => pickerCalls;
      window.showDirectoryPicker = async () => { pickerCalls++; return parent; };
    });
    page.on('pageerror', error => errors.push(error.message));
    page.on('console', message => {
      if (message.type() === 'error' && !/scrollTo|not implemented|media/i.test(message.text())) errors.push(message.text());
    });
    await page.setViewport({ width: 1280, height: 900 });
    const html = fs.readFileSync('/home/user/packpolymer-marketplace-roadmap.html');
    server = http.createServer((req, res) => {
      const route = (req.url || '/').split('?')[0];
      if (route === '/seed.html') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' }); res.end('<!doctype html><html><body>seed</body></html>');
      } else if (route === '/answers-roadmap.json') {
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' }); res.end('{}');
      } else {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(html);
      }
    });
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
    const origin = 'http://127.0.0.1:' + server.address().port;
    await page.goto(origin + '/seed.html', { waitUntil: 'load' });
    await page.evaluate(async () => {
      const now = new Date().toISOString();
      localStorage.setItem('packpolymer-marketplace-roadmap-v2', JSON.stringify({
        nbNotes: [{ id: 'migration-note', title: 'Migration test', body: '', folderId: '', category: '', tags: [], direction: 'auto', createdAt: now, updatedAt: now }],
        nbActiveId: 'migration-note', nbSecondaryId: '', nbFolders: [], nbTags: [], nbCategories: [], nbView: 'note', nbMode: 'edit', nbSecondaryMode: 'edit', nbSplit: false,
        openNotes: {}, noteModes: {}, noteDirections: {}, ui: { nbOpen: false, editing: false, phaseDrawerOpen: false }
      }));
      const db = await new Promise((resolve, reject) => {
        const req = indexedDB.open('packpolymer-roadmap', 1);
        req.onupgradeneeded = () => req.result.createObjectStore('kv');
        req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error);
      });
      await new Promise(resolve => {
        const tx = db.transaction('kv', 'readwrite'), store = tx.objectStore('kv');
        store.put(['legacy-good.png', 'legacy-fail.png'], 'attachmentIndex');
        store.put(new Blob([new Uint8Array([1,2,3,4])], { type: 'image/png' }), 'roadmap-attachment:legacy-good.png');
        store.put(new Blob([new Uint8Array([5,6,7])], { type: 'image/png' }), 'roadmap-attachment:legacy-fail.png');
        tx.oncomplete = resolve;
      });
    });
    await page.goto(origin + '/packpolymer-marketplace-roadmap.html', { waitUntil: 'load', timeout: 60000 }); await wait(650);
    await click(page, '#fabNote');
    await page.waitForFunction(() => document.querySelector('#nbPanel')?.classList.contains('open'));
    await click(page, '[data-nb-noteview] [data-nb="attachment-connect"]');
    await page.waitForFunction(() => document.querySelector('[data-nb-noteview] [data-attachment-guidance]')?.hidden === true, { timeout: 8000 });
    const migration = await page.evaluate(async () => {
      const db = await new Promise(resolve => { const req = indexedDB.open('packpolymer-roadmap', 1); req.onsuccess = () => resolve(req.result); req.onerror = () => resolve(null); });
      if (!db) return { goodInIdb: true, failedSize: 0, index: [], fileSize: 0, toast: document.querySelector('#toast')?.textContent || '', pickerCalls: window.__pickerCalls() };
      const get = key => new Promise(resolve => { const req = db.transaction('kv', 'readonly').objectStore('kv').get(key); req.onsuccess = () => resolve(req.result); req.onerror = () => resolve(null); });
      const good = await get('roadmap-attachment:legacy-good.png'), failed = await get('roadmap-attachment:legacy-fail.png'), index = await get('attachmentIndex');
      const file = window.__migrationFiles.get('legacy-good.png');
      return { goodInIdb: good instanceof Blob, failedSize: failed instanceof Blob ? failed.size : 0, index, fileSize: file?.size || 0, pickerCalls: window.__pickerCalls(), toast: document.querySelector('#toast')?.textContent || '' };
    });
    check('Connecting the attachments folder migrates the readable legacy Blob into a real file', !migration.goodInIdb && migration.fileSize === 4, migration);
    check('A failed legacy transfer keeps the old Blob and its index entry, and reports the preserved data', migration.failedSize === 3 && migration.index?.length === 1 && migration.index[0] === 'legacy-fail.png' && migration.toast.includes('IndexedDB حفظ شد') && migration.toast.includes('1 فایل قدیمی') && !migration.toast.endsWith('..'), migration);
    check('The migration is triggered only after the user explicitly chooses the directory', migration.pickerCalls === 1);
    check('Attachment migration completes without uncaught runtime errors', errors.length === 0, errors);
    console.log(`SUMMARY | ${failures.length ? 'FAIL' : 'PASS'} | ${failures.length} failure(s) | ${errors.length} runtime error(s)`);
  } catch (error) {
    errors.push(error.stack || error.message);
    console.error(error);
  } finally {
    if (server) await new Promise(resolve => server.close(resolve));
    await browser.close();
  }
  process.exitCode = failures.length || errors.length ? 1 : 0;
})();
