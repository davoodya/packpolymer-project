const puppeteer = require('puppeteer');
const chromium = require('@sparticuz/chromium');
const http = require('http');
const fs = require('fs');
const path = require('path');

const HTML_PATH = '/home/user/packpolymer-marketplace-roadmap.html';
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
function stats(values) {
  const sorted = values.filter(Number.isFinite).slice().sort((a, b) => a - b);
  if (!sorted.length) return { count: 0, medianMs: 0, p95Ms: 0, maxMs: 0 };
  const at = p => sorted[Math.min(sorted.length - 1, Math.floor((sorted.length - 1) * p))];
  return { count: sorted.length, medianMs: +at(.5).toFixed(2), p95Ms: +at(.95).toFixed(2), maxMs: +sorted.at(-1).toFixed(2) };
}
async function syntheticInputDispatch(page, selector, text) {
  const values = await page.$eval(selector, (el, value) => {
    el.focus();
    const times = [];
    for (const character of value) {
      const start = Number.isFinite(el.selectionStart) ? el.selectionStart : el.value.length;
      const end = Number.isFinite(el.selectionEnd) ? el.selectionEnd : start;
      el.value = el.value.slice(0, start) + character + el.value.slice(end);
      if (typeof el.setSelectionRange === 'function') el.setSelectionRange(start + character.length, start + character.length);
      const before = performance.now();
      el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: character }));
      times.push(performance.now() - before);
    }
    return times;
  }, text);
  return { method: 'synthetic DOM InputEvent dispatch; excludes keyboard automation and paint', typedChars: text.length, handlerDuration: stats(values) };
}
async function typeWithMetrics(page, selector, text, observerKind, delay = 5) {
  await page.evaluate(({ selector, observerKind }) => {
    const target = document.querySelector(selector);
    if (!target) throw new Error('Missing benchmark target: ' + selector);
    const ob = { lastInputAt: 0, frames: [], renderAt: 0, startedAt: performance.now() };
    target.addEventListener('input', () => {
      const stamp = performance.now(); ob.lastInputAt = stamp;
      requestAnimationFrame(() => ob.frames.push(performance.now() - stamp));
    });
    if (observerKind === 'main-search') {
      const root = document.querySelector('#phases');
      ob.observer = new MutationObserver(records => {
        const now = performance.now();
        if (!ob.renderAt && records.some(record => record.type === 'childList')) ob.renderAt = now;
        if (ob.lastInputAt && root.dataset.searchRendering === 'false' && records.some(record => record.type === 'attributes' && record.attributeName === 'data-search-rendering')) ob.completeAt = now;
      });
      ob.observer.observe(root, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-search-rendering'] });
    } else if (observerKind === 'notebook-preview') {
      const root = document.querySelector('#nbPreview');
      ob.observer = new MutationObserver(() => { if (!ob.renderAt) ob.renderAt = performance.now(); });
      ob.observer.observe(root, { childList: true, subtree: false });
    } else if (observerKind === 'notebook-search') {
      const root = document.querySelector('#nbList');
      ob.observer = new MutationObserver(() => { if (!ob.renderAt) ob.renderAt = performance.now(); });
      ob.observer.observe(root, { childList: true, subtree: true });
    }
    window.__interactionBench = ob;
    window.__longTasks = [];
  }, { selector, observerKind });
  const started = Date.now();
  await page.focus(selector);
  await page.keyboard.type(text, { delay });
  const wallMs = Date.now() - started;
  const rendered = await page.waitForFunction(kind => {
    const o = window.__interactionBench;
    return kind === 'main-search' ? !!o?.completeAt : !!o?.renderAt;
  }, { timeout: 20000 }, observerKind).catch(() => null);
  await wait(40);
  const result = await page.evaluate(() => {
    const o = window.__interactionBench || {};
    if (o.observer) o.observer.disconnect();
    const times = o.frames || [];
    return {
      chars: times.length,
      inputToNextFrame: times,
      finalDebounceToFirstDomMs: o.renderAt && o.lastInputAt ? +(o.renderAt - o.lastInputAt).toFixed(2) : null,
      renderCompleteAfterLastKeyMs: o.completeAt && o.lastInputAt ? +(o.completeAt - o.lastInputAt).toFixed(2) : null,
      inputCount: o.lastInputAt ? times.length : 0,
      maxLongTaskMs: Math.max(0, ...(window.__longTasks || []))
    };
  });
  return {
    typedChars: text.length,
    automationWallMs: +wallMs.toFixed(2),
    inputToNextFrame: stats(result.inputToNextFrame),
    finalDebounceToFirstDomMs: result.finalDebounceToFirstDomMs,
    renderCompleteAfterLastKeyMs: result.renderCompleteAfterLastKeyMs,
    maxLongTaskMs: +result.maxLongTaskMs.toFixed(2),
    domMutationObserved: !!rendered
  };
}

(async () => {
  const html = fs.readFileSync(HTML_PATH);
  const server = http.createServer((req, res) => {
    const pathname = (req.url || '/').split('?')[0];
    if (pathname === '/seed.html') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end('<!doctype html><html><body>benchmark seed</body></html>');
    }
    if (pathname === '/answers-roadmap.json') {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end('{}');
    }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(html);
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const origin = 'http://127.0.0.1:' + server.address().port;
  const browser = await puppeteer.launch({
    executablePath: await chromium.executablePath(),
    headless: true,
    args: [...chromium.args, '--no-sandbox', '--disable-dev-shm-usage']
  });
  try {
    const page = await browser.newPage();
    await page.evaluateOnNewDocument(() => {
      window.__longTasks = [];
      try { new PerformanceObserver(list => window.__longTasks.push(...list.getEntries().map(entry => entry.duration))).observe({ type: 'longtask', buffered: true }); } catch (_) {}
    });
    await page.setViewport({ width: 1440, height: 900 });
    await page.goto(origin + '/seed.html', { waitUntil: 'load' });
    const notebookNotes = [];
    const now = new Date().toISOString();
    const longBody = Array.from({ length: 115 }, (_, i) => `Paragraph ${i + 1}: This realistic Markdown draft includes supplier specification, technical note and procurement context for polymer materials.`).join('\n\n');
    for (let i = 0; i < 300; i++) {
      notebookNotes.push({
        id: `perf-note-${i}`, title: i === 299 ? 'Search target needle-299' : `Performance Note ${i}`,
        body: i === 0 ? longBody : `Benchmark searchable note body ${i}; category reference and tag data for performance profiling.`,
        folderId: `folder-${i % 4}`, category: `category-${i % 6}`, tags: [`tag-${i % 9}`], direction: 'auto', createdAt: now, updatedAt: now
      });
    }
    await page.evaluate(notes => {
      const folders = Array.from({ length: 4 }, (_, i) => ({ id: `folder-${i}`, name: `Folder ${i}` }));
      localStorage.setItem('packpolymer-marketplace-roadmap-v2', JSON.stringify({
        nbNotes: notes, nbActiveId: notes[0].id, nbSecondaryId: '', nbFolders: folders,
        nbTags: Array.from({ length: 9 }, (_, i) => `tag-${i}`), nbCategories: Array.from({ length: 6 }, (_, i) => `category-${i}`),
        nbBrowseMode: 'all', nbBrowseValue: '', nbSort: 'updated', nbQuery: '', nbView: 'note', nbMode: 'edit',
        nbSecondaryMode: 'edit', nbSplit: false, nbSplitRatio: .5, nbWidthPct: 75, nbBodyRatio: .5,
        nbBodyRatioSecondary: .5, openNotes: {}, noteModes: {}, noteDirections: {}, ui: { nbOpen: false }
      }));
    }, notebookNotes);
    const navStarted = Date.now();
    await page.goto(origin + '/packpolymer-marketplace-roadmap.html', { waitUntil: 'load', timeout: 60000 });
    const navWallMs = Date.now() - navStarted;
    await page.waitForFunction(() => !!document.querySelector('#q') && !!document.querySelector('#fabNote'), { timeout: 10000 });
    await wait(500);
    const pageMetrics = await page.evaluate(() => {
      const nav = performance.getEntriesByType('navigation')[0];
      const fcp = performance.getEntriesByName('first-contentful-paint')[0];
      return { navigationDomContentLoadedMs: +(nav?.domContentLoadedEventEnd || 0).toFixed(2), navigationLoadMs: +(nav?.loadEventEnd || 0).toFixed(2), firstContentfulPaintMs: fcp ? +fcp.startTime.toFixed(2) : null, phaseCount: document.querySelectorAll('#phases .phase').length };
    });
    const mainSearch = await typeWithMetrics(page, '#q', 'polymer', 'main-search', 8);

    const clearMainSearch = async () => {
      await page.evaluate(() => { document.querySelector('#q').value = ''; document.querySelector('#q').dispatchEvent(new Event('input', { bubbles: true })); });
      await page.waitForFunction(() => document.querySelector('#phases')?.dataset.searchRendering === 'queued', { timeout: 2000 });
      await page.waitForFunction(() => document.querySelector('#phases')?.dataset.searchRendering === 'false', { timeout: 20000 });
    };
    await clearMainSearch();
    const mainSearchInputHandler = await syntheticInputDispatch(page, '#q', 'WooCommerce');
    await page.waitForFunction(() => document.querySelector('#phases')?.dataset.searchRendering === 'queued', { timeout: 2000 });
    await page.waitForFunction(() => document.querySelector('#phases')?.dataset.searchRendering === 'false', { timeout: 20000 });
    await clearMainSearch();
    const mainSearchWarm = await typeWithMetrics(page, '#q', 'WooCommerce', 'main-search', 8);
    await clearMainSearch();
    await page.evaluate(() => document.querySelector('#fabNote').click());
    await page.waitForFunction(() => document.querySelector('#nbPanel')?.classList.contains('open') && !document.querySelector('[data-nb-noteview]')?.hidden, { timeout: 10000 });
    await page.evaluate(() => document.querySelector('[data-nb="toggle-mode"][data-side="primary"]').click());
    await page.waitForFunction(() => document.querySelector('#nbPreview') && !document.querySelector('#nbPreview').hidden, { timeout: 8000 });
    await page.evaluate(() => document.querySelector('[data-nb="toggle-mode"][data-side="primary"]').click());
    await page.waitForFunction(() => document.querySelector('#nbPreview') && !document.querySelector('#nbPreview').hidden && document.querySelector('#nbEdit') && !document.querySelector('#nbEdit').hidden, { timeout: 8000 });
    await wait(150);
    await page.$eval('#nbEdit', el => { el.focus(); el.setSelectionRange(el.value.length, el.value.length); });
    const typing = await typeWithMetrics(page, '#nbEdit', '\n\nPERF_MARKER_2026 notebook typing', 'notebook-preview', 4);
    await page.waitForFunction(() => document.querySelector('#nbPreview')?.innerText.includes('PERF_MARKER_2026'), { timeout: 8000 });
    const notebookInputHandler = await syntheticInputDispatch(page, '#nbEdit', ' SYNTHETIC_MARKER_2026');
    await page.waitForFunction(() => document.querySelector('#nbPreview')?.innerText.includes('SYNTHETIC_MARKER_2026'), { timeout: 8000 });
    const typingPreview = await page.evaluate(() => ({ mode: document.querySelector('.nb-pane-primary .nb-body')?.dataset.mode, editorChars: document.querySelector('#nbEdit')?.value.length, keyboardMarker: document.querySelector('#nbPreview')?.innerText.includes('PERF_MARKER_2026'), syntheticMarker: document.querySelector('#nbPreview')?.innerText.includes('SYNTHETIC_MARKER_2026') }));

    await page.evaluate(() => document.querySelector('[data-nb="back-list"]').click());
    await page.waitForFunction(() => document.querySelector('[data-nb-listview]')?.hidden === false && !!document.querySelector('#nbSearch'), { timeout: 8000 });
    const coldSearch = await typeWithMetrics(page, '#nbSearch', 'needle-299', 'notebook-search', 8);
    await page.waitForFunction(() => document.querySelectorAll('#nbList .nb-card').length === 1, { timeout: 8000 });
    await page.$eval('#nbSearch', el => { el.focus(); el.value = ''; el.dispatchEvent(new Event('input', { bubbles: true })); });
    await page.waitForFunction(() => document.querySelectorAll('#nbList .nb-card').length === 300, { timeout: 10000 });
    const warmSearch = await typeWithMetrics(page, '#nbSearch', 'needle-299', 'notebook-search', 8);
    await page.waitForFunction(() => document.querySelectorAll('#nbList .nb-card').length === 1, { timeout: 8000 });

    console.log(JSON.stringify({
      environment: 'Headless Chromium, 1440x900, 300 seeded Notebook notes; timing is local-only and not a real-user guarantee',
      page: { navigationWallMs: navWallMs, ...pageMetrics },
      mainSearchColdIndex: mainSearch,
      mainSearchWarmIndex: mainSearchWarm,
      mainSearchInputHandler,
      notebookTyping: { ...typing, preview: typingPreview },
      notebookInputHandler,
      notebookSearchColdIndex: coldSearch,
      notebookSearchWarmIndex: warmSearch
    }, null, 2));
  } finally {
    await browser.close().catch(() => {});
    await new Promise(resolve => server.close(resolve));
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
