const puppeteer = require('puppeteer');
const chromium = require('@sparticuz/chromium');
const fs = require('fs');
const http = require('http');
const HTML_PATH = '/home/user/packpolymer-marketplace-roadmap.html';
const HTML_ROUTE = '/packpolymer-marketplace-roadmap.html';
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
(async () => {
  const source = fs.readFileSync(HTML_PATH, 'utf8');
  const trigger = "case 'expand-all': state.plan.forEach(p => state.open[p.id] = true); save(); renderSearchResults(); break;";
  if (!source.includes(trigger)) throw new Error('Expand All handler not found.');
  const baselineHtml = source.replace(trigger, trigger.replace('renderSearchResults();', 'render();'));
  const server = http.createServer((req, res) => {
    const route = (req.url || '/').split('?')[0];
    const body = route === '/baseline.html' ? baselineHtml : source;
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(body);
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const origin = `http://127.0.0.1:${server.address().port}`;
  const browser = await puppeteer.launch({ executablePath: await chromium.executablePath(), headless: true, args: [...chromium.args, '--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  await page.evaluateOnNewDocument(() => {
    window.__longTasks = [];
    try { new PerformanceObserver(list => { window.__longTasks.push(...list.getEntries().map(entry => ({ startTimeMs: entry.startTime, durationMs: entry.duration }))); }).observe({ type: 'longtask', buffered: true }); } catch (_) {}
  });
  const run = async (route, clearStorage = false) => {
    if (clearStorage && page.url() !== 'about:blank') await page.evaluate(() => localStorage.clear());
    await page.setViewport({ width: 1920, height: 950 });
    await page.goto(origin + route, { waitUntil: 'load', timeout: 60000 });
    await wait(850);
    const dispatchMs = await page.evaluate(() => {
      window.__longTasks = []; window.__benchStart = performance.now();
      const start = performance.now(); document.querySelector('[data-act="expand-all"]').click();
      return performance.now() - start;
    });
    await page.waitForFunction(() => document.querySelectorAll('#phases .step').length === 122 && document.querySelectorAll('#phases .sub').length === 749, { timeout: 20000 });
    await wait(80);
    return page.evaluate(dispatch => {const tasks=(window.__longTasks||[]).filter(entry=>entry.startTimeMs>=window.__benchStart);return {
      dispatchMs: +dispatch.toFixed(2), totalMs: +(performance.now() - window.__benchStart).toFixed(2),
      steps: document.querySelectorAll('#phases .step').length, substeps: document.querySelectorAll('#phases .sub').length,
      maxLongTaskMs: +Math.max(0, ...tasks.map(entry=>entry.durationMs)).toFixed(2), longTasks:tasks.map(entry=>({startAfterClickMs:+(entry.startTimeMs-window.__benchStart).toFixed(2),durationMs:+entry.durationMs.toFixed(2)}))
    };}, dispatchMs);
  };
  try {
    const baseline = await run('/baseline.html');
    const optimized = await run(HTML_ROUTE, true);
    console.log(JSON.stringify({ environment: 'Headless Chromium, 1920x950; current build vs benchmark-only synchronous Expand All reference; 122 steps and 749 substeps expected', baseline, optimized }, null, 2));
    if (baseline.steps !== optimized.steps || baseline.substeps !== optimized.substeps) process.exitCode = 1;
  } finally {
    await browser.close(); await new Promise(resolve => server.close(resolve));
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
