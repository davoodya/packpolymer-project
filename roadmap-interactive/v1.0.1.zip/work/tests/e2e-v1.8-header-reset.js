const puppeteer = require('puppeteer');
const chromium = require('@sparticuz/chromium');
const http = require('http');
const fs = require('fs');

const HTML_PATH = '/home/user/packpolymer-marketplace-roadmap.html';
const STORE_KEY = 'packpolymer-marketplace-roadmap-v2';
const failures = [];
const runtimeErrors = [];
let server;
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
function check(name, ok, detail) {
  console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}${detail === undefined ? '' : ' | ' + JSON.stringify(detail)}`);
  if (!ok) failures.push(name);
}
function trackErrors(page) {
  page.on('pageerror', e => runtimeErrors.push(e.message));
  page.on('console', m => {
    if (m.type() === 'error' && !/scrollTo|not implemented|media|favicon/i.test(m.text())) runtimeErrors.push(m.text());
  });
  page.on('requestfailed', r => {
    if (/^https?:/.test(r.url()) && !/favicon\.ico/.test(r.url())) runtimeErrors.push('request failed: ' + r.url());
  });
}
function seedState(overrides = {}) {
  return {
    ui: Object.assign({
      sidebarLayout: 'dual-right', sidebarLeftWidth: 340, sidebarRightWidth: 360,
      sidebarPairRatio: .56, fontScale: 1, filter: 'todo', markFilters: [], stack: '',
      editing: false, nbOpen: false
    }, overrides)
  };
}
async function openApp(browser, origin, width, state = seedState(), height = 640) {
  const page = await browser.newPage();
  trackErrors(page);
  await page.setViewport({ width, height });
  await page.goto(origin + '/seed.html', { waitUntil: 'load' });
  await page.evaluate((key, value) => localStorage.setItem(key, JSON.stringify(value)), STORE_KEY, state);
  await page.goto(origin + '/packpolymer-marketplace-roadmap.html', { waitUntil: 'load', timeout: 60000 });
  await page.waitForSelector('.topbar .search #q', { timeout: 60000 });
  await page.waitForSelector('.layout .phases', { timeout: 60000 });
  await wait(100);
  return page;
}
async function compactHeader(page) {
  // Use real browser PageDown events so the sticky class is tested through the normal window scroll listener.
  let active = {y:0,compact:false};
  for (let attempt=0; attempt<3; attempt++) {
    await page.evaluate(() => { if (document.activeElement && document.activeElement !== document.body) document.activeElement.blur(); });
    await page.keyboard.press('PageDown');
    await wait(240);
    active = await page.evaluate(() => ({
      y: window.scrollY,
      compact: document.querySelector('.topbar')?.classList.contains('compact') && document.body.classList.contains('header-compact')
    }));
    if (active.y > 48 && active.compact) break;
  }
  return active;
}
async function headerMetrics(page, compact) {
  return page.evaluate(isCompact => {
    const h = document.querySelector('.topbar');
    const search = h.querySelector('.search');
    const left = h.querySelector(isCompact ? '.sticky-actions-left' : '.header-actions-left');
    const right = h.querySelector(isCompact ? '.sticky-actions-right' : '.header-actions-right');
    const mainFilters = isCompact ? h.querySelector('.sticky-filters-main') : h.querySelector(':scope > .filters-main');
    const markFilters = isCompact ? h.querySelector('.sticky-filters-marks') : h.querySelector(':scope > .filters-marks');
    const layout = [...h.querySelectorAll('.sidebar-layout-btn')].filter(visible)[0];
    function visible(el) {
      if (!el || !el.isConnected) return false;
      const s = getComputedStyle(el), r = el.getBoundingClientRect();
      return s.display !== 'none' && s.visibility !== 'hidden' && r.width > 0 && r.height > 0;
    }
    function clippedRect(el) {
      const r = el.getBoundingClientRect();
      const v = { left:r.left, right:r.right, top:r.top, bottom:r.bottom };
      for (let a = el.parentElement; a && a !== document.body; a = a.parentElement) {
        const s = getComputedStyle(a), ar = a.getBoundingClientRect();
        if (['auto','scroll','hidden','clip'].includes(s.overflowX)) { v.left = Math.max(v.left, ar.left); v.right = Math.min(v.right, ar.right); }
        if (['auto','scroll','hidden','clip'].includes(s.overflowY)) { v.top = Math.max(v.top, ar.top); v.bottom = Math.min(v.bottom, ar.bottom); }
      }
      return v;
    }
    const actionItems = [...right.children].filter(visible);
    const visibleButtons = [...h.querySelectorAll('button')].filter(visible);
    const rect = el => el ? el.getBoundingClientRect().toJSON() : null;
    const overlaps = [];
    for (let i = 0; i < visibleButtons.length; i++) for (let j = i + 1; j < visibleButtons.length; j++) {
      const a = clippedRect(visibleButtons[i]), b = clippedRect(visibleButtons[j]);
      const w = Math.min(a.right,b.right) - Math.max(a.left,b.left);
      const hh = Math.min(a.bottom,b.bottom) - Math.max(a.top,b.top);
      if (w > 1 && hh > 1) overlaps.push([visibleButtons[i].getAttribute('aria-label') || visibleButtons[i].title, visibleButtons[j].getAttribute('aria-label') || visibleButtons[j].title]);
    }
    const top = h.getBoundingClientRect();
    const sr = search.getBoundingClientRect();
    const rightActionsOrder = [...right.children].filter(visible).map(el => el.matches('button') ? el.dataset.act : el.querySelector('button')?.dataset.act).filter(Boolean);
    const responsive = innerWidth <= 1180;
    const leftTools = responsive && !isCompact ? h.querySelector('.font-controls:not([data-font-group="nb"])') : left;
    const filtersVisible = visible(mainFilters) || visible(markFilters);
    return {
      compact:isCompact, responsive, viewport:innerWidth, scrollWidth:document.documentElement.scrollWidth,
      header:{x:top.x,y:top.y,w:top.width,h:top.height,scroll:h.scrollWidth,client:h.clientWidth},
      search:rect(search), searchCenter:sr.left + sr.width/2, headerCenter:(top.left+top.right)/2,
      layout:rect(layout), mainFilters:rect(mainFilters), markFilters:rect(markFilters), leftTools:rect(leftTools), right:rect(right),
      leftScroll:left ? [left.scrollWidth,left.clientWidth,getComputedStyle(left).overflowX] : null,
      rightScroll:right ? [right.scrollWidth,right.clientWidth,getComputedStyle(right).overflowX] : null,
      mainFilterScroll:mainFilters ? [mainFilters.scrollWidth,mainFilters.clientWidth,getComputedStyle(mainFilters).overflowX] : null,
      markFilterScroll:markFilters ? [markFilters.scrollWidth,markFilters.clientWidth,getComputedStyle(markFilters).overflowX] : null,
      actionCount:actionItems.length, actionOrder:rightActionsOrder, visibleLayoutCount:[...h.querySelectorAll('.sidebar-layout-btn')].filter(visible).length,
      visibleFontControls:[...h.querySelectorAll('.sticky-side-tools .font-controls')].filter(visible).length,
      visibleMainReset:[...h.querySelectorAll('.main-sidebar-reset')].filter(visible).length,
      stickyReset:[...h.querySelectorAll('.sticky-reset')].filter(visible).length,
      stickyPrint:[...h.querySelectorAll('.sticky-print')].filter(visible).length,
      stickyClean:[...h.querySelectorAll('.sticky-clean')].filter(visible).length,
      stickyReport:[...h.querySelectorAll('.sticky-report-menu')].filter(visible).length,
      stickyFilters: isCompact ? getComputedStyle(h.querySelector('.sticky-filters')).display : '',
      compactExports:h.querySelectorAll('.compact-export').length,
      overlaps
    };
  }, compact);
}
async function stateUi(page) {
  return page.evaluate(key => JSON.parse(localStorage.getItem(key) || '{}').ui || {}, STORE_KEY);
}

(async () => {
  const html = fs.readFileSync(HTML_PATH);
  server = http.createServer((req,res) => {
    const route = (req.url || '/').split('?')[0];
    if (route === '/seed.html') {
      res.writeHead(200, {'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});
      return res.end('<!doctype html><html><body>seed</body></html>');
    }
    if (route === '/favicon.ico') { res.writeHead(204); return res.end(); }
    res.writeHead(200, {'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});
    res.end(html);
  });
  await new Promise(resolve => server.listen(0,'127.0.0.1',resolve));
  const origin = 'http://127.0.0.1:' + server.address().port;
  const browser = await puppeteer.launch({
    executablePath: await chromium.executablePath(),
    args: [...chromium.args, '--no-sandbox', '--disable-dev-shm-usage'],
    headless: true
  });
  try {
    for (const width of [320,390,720,721,768,1024,1180,1181,1279,1280,1366,1920]) {
      const page = await openApp(browser, origin, width);
      const responsive = width <= 1180;
      const normal = await headerMetrics(page, false);
      const mainLayoutCenter = normal.layout ? normal.layout.x + normal.layout.width/2 : NaN;
      const row2BelowSearch = normal.mainFilters && normal.markFilters && normal.layout &&
        normal.mainFilters.y > normal.search.y && normal.markFilters.y > normal.search.y;
      const row3BelowFilters = normal.leftTools && normal.right &&
        normal.right.y >= Math.max(normal.mainFilters?.bottom || 0, normal.markFilters?.bottom || 0, normal.layout?.bottom || 0) - 1;
      const row3NoScroll = !responsive || (normal.rightScroll && normal.rightScroll[0] <= normal.rightScroll[1] + 1 && !['auto','scroll'].includes(normal.rightScroll[2]));
      const filtersNoScroll = !responsive || (normal.mainFilterScroll && normal.markFilterScroll &&
        normal.mainFilterScroll[0] <= normal.mainFilterScroll[1] + 1 && normal.markFilterScroll[0] <= normal.markFilterScroll[1] + 1 &&
        !['auto','scroll'].includes(normal.mainFilterScroll[2]) && !['auto','scroll'].includes(normal.markFilterScroll[2]));
      const groupsStayOnSides = !responsive || (
        normal.markFilters.right <= normal.layout.x + 1 && normal.mainFilters.x >= normal.layout.x + normal.layout.width - 1 &&
        normal.leftTools.left < normal.right.x
      );
      check(`Main header groups are correctly placed without changing the standard desktop/laptop layout at ${width}px`,
        normal.visibleLayoutCount === 1 && normal.visibleMainReset === 1 && normal.actionCount === 10 &&
        normal.compactExports === 0 && normal.overlaps.length === 0 && normal.scrollWidth <= width + 1 &&
        (!responsive || (Math.abs(normal.searchCenter-normal.headerCenter) <= 1.5 && Math.abs(mainLayoutCenter-normal.headerCenter) <= 1.5 && row2BelowSearch && row3BelowFilters && row3NoScroll && filtersNoScroll && groupsStayOnSides)),
        {header:normal.header,searchCenter:normal.searchCenter,headerCenter:normal.headerCenter,layoutCenter:mainLayoutCenter,filters:normal.mainFilters,marks:normal.markFilters,font:normal.leftTools,actions:normal.right,actionCount:normal.actionCount,actionScroll:normal.rightScroll,filterScroll:[normal.mainFilterScroll,normal.markFilterScroll],overlaps:normal.overlaps,documentWidth:normal.scrollWidth});

      const actualScroll = await compactHeader(page);
      const sticky = await headerMetrics(page, true);
      const desktopSticky = width >= 1181;
      const expectedOrder = desktopSticky
        ? ['edit-mode','export','import','report-menu','sidebar-size-reset','expand-all','collapse-all','print','clean-all']
        : ['edit-mode','export','import','report-menu','expand-all','collapse-all','clean-all'];
      const stickyHeaderOk = actualScroll.y > 48 && actualScroll.compact && sticky.visibleLayoutCount === 1 && sticky.visibleFontControls === 1 &&
        Math.abs(sticky.searchCenter-sticky.headerCenter) <= 1.5 && sticky.compactExports === 0 &&
        sticky.actionOrder.join('|') === expectedOrder.join('|') && sticky.overlaps.length === 0 &&
        sticky.header.scroll <= sticky.header.client + 1 && sticky.scrollWidth <= width + 1 &&
        sticky.leftScroll[0] <= sticky.leftScroll[1] + 1 && sticky.rightScroll[0] <= sticky.rightScroll[1] + 1 &&
        (desktopSticky ? sticky.stickyFilters === 'flex' && sticky.stickyReset === 1 && sticky.stickyPrint === 1 && sticky.stickyReport === 1 :
          (sticky.stickyFilters === 'none' && sticky.stickyReset === 0 && sticky.stickyPrint === 0 && sticky.stickyReport === 1)) &&
        sticky.stickyClean === 1;
      check(`Minimum sticky header is centered, ordered, device-specific, and has no horizontal overflow at ${width}px`, stickyHeaderOk,
        {scrollActivation:actualScroll,searchCenter:sticky.searchCenter,headerCenter:sticky.headerCenter,header:sticky.header,left:sticky.leftScroll,right:sticky.rightScroll,filters:sticky.stickyFilters,order:sticky.actionOrder,reset:sticky.stickyReset,print:sticky.stickyPrint,report:sticky.stickyReport,clean:sticky.stickyClean,overlaps:sticky.overlaps,documentWidth:sticky.scrollWidth});

      if (width === 1280) {
        await page.evaluate(() => document.querySelector('.sticky-filters-main [data-id="done"]')?.click()); await wait(330);
        const stickyFilter=await page.evaluate(key=>{
          const ui=JSON.parse(localStorage.getItem(key)||'{}').ui||{},b=document.querySelector('.sticky-filters-main [data-id="done"]');
          return {value:ui.filter,selected:b?.classList.contains('on'),normalSelected:document.querySelector('.topbar > .filters-main [data-id="done"]')?.classList.contains('on'),text:b?.textContent.trim(),title:b?.title,aria:b?.getAttribute('aria-label'),compact:document.querySelector('.topbar')?.classList.contains('compact')};
        },STORE_KEY);
        check('Desktop sticky status filter keeps its abbreviated label accessible and applies the selected state',stickyFilter.selected&&stickyFilter.normalSelected&&stickyFilter.text==='انجام'&&stickyFilter.title==='انجام شده'&&stickyFilter.aria==='فیلتر انجام شده'&&stickyFilter.compact,stickyFilter);
        await page.evaluate(() => document.querySelector('.sticky-filters-marks [data-id="review"]')?.click()); await wait(330);
        const stickyMark=await page.evaluate(key=>{
          const ui=JSON.parse(localStorage.getItem(key)||'{}').ui||{},b=document.querySelector('.sticky-filters-marks [data-id="review"]');
          return {selected:ui.markFilters?.includes('review')&&b?.classList.contains('on'),text:b?.textContent.trim(),title:b?.title,aria:b?.getAttribute('aria-label'),compact:document.querySelector('.topbar')?.classList.contains('compact')};
        },STORE_KEY);
        check('Desktop sticky review-mark filter is actionable and retains a full tooltip/accessibility name',stickyMark.selected&&stickyMark.text.includes('بررسی')&&stickyMark.title.includes('نیازمند بررسی')&&stickyMark.aria==='فیلتر نیازمند بررسی'&&stickyMark.compact,stickyMark);
        await page.evaluate(() => document.querySelector('.sticky-layout-slot .sidebar-layout-btn')?.click()); await wait(100);
        const stickyLayout=await page.evaluate(key=>({mode:JSON.parse(localStorage.getItem(key)||'{}').ui?.sidebarLayout,compact:document.querySelector('.topbar')?.classList.contains('compact'),visible:document.querySelectorAll('.topbar.compact .sticky-layout-slot .sidebar-layout-btn').length}),STORE_KEY);
        check('Sticky sidebar layout control cycles the sidebar layout without losing the compact header',stickyLayout.mode==='single-right'&&stickyLayout.compact&&stickyLayout.visible===1,stickyLayout);
        await page.evaluate(() => document.querySelector('.sticky-side-tools .font-controls [data-dir="1"]')?.click()); await wait(330);
        const stickyFont=await page.evaluate(key=>({scale:JSON.parse(localStorage.getItem(key)||'{}').ui?.fontScale,compact:document.querySelector('.topbar')?.classList.contains('compact'),controls:document.querySelectorAll('.topbar.compact .sticky-side-tools .font-controls').length}),STORE_KEY);
        check('Sticky font-size control remains actionable and visible beside layout controls',stickyFont.scale>1&&stickyFont.compact&&stickyFont.controls===1,stickyFont);
        await page.evaluate(() => document.querySelector('.sticky-report-menu > button')?.click());
        await wait(80);
        const menu = await page.evaluate(() => {
          const w=document.querySelector('.sticky-report-menu'),p=w?.querySelector('.menu-pop');
          return {open:!!w?.classList.contains('open'),options:[...(p?.querySelectorAll('button[data-act="report"]')||[])].map(b=>b.dataset.id),separateFull:[...document.querySelectorAll('.sticky-actions-right > button[data-act="report"][data-id="full"]')].length,scroll:document.documentElement.scrollWidth};
        });
        check('Sticky Markdown export is one status menu, with no separate duplicate full-Markdown button',menu.open && menu.options.join('|')==='done|todo|full' && menu.separateFull===0 && menu.scroll<=width+1,menu);
        await page.evaluate(() => document.querySelector('.sticky-report-menu .menu-pop [data-act="report"][data-id="done"]')?.click());
        await wait(360);
        const selectedReport = await page.evaluate(key => {
          const ui=JSON.parse(localStorage.getItem(key)||'{}').ui||{},modal=document.querySelector('#textModal');
          return {mode:ui.reportMode,modal:!!modal&&modal.classList.contains('show'),title:modal?.querySelector('.modal-head b')?.textContent||'',filename:modal?.querySelector('.modal-hint')?.textContent||'',width:document.documentElement.scrollWidth};
        },STORE_KEY);
        check('Choosing a Markdown report status saves that choice and opens its matching report',selectedReport.mode==='done'&&selectedReport.modal&&selectedReport.filename.includes('report-done-')&&selectedReport.width<=width+1,selectedReport);
        await page.evaluate(() => document.querySelector('#textModal [data-modal="close"]')?.click());
      }
      await page.close();
    }

    // Reset from the Tablet/Mini-Laptop main header resets both stored widths and the shared split ratio, without touching other UI state.
    const tablet = await openApp(browser, origin, 1024, seedState({sidebarLeftWidth:420,sidebarRightWidth:380,sidebarPairRatio:.58,filter:'todo',fontScale:1.1}));
    await tablet.evaluate(() => document.querySelector('.topbar:not(.compact) .filters-main [data-id="done"]')?.click()); await wait(80);
    await tablet.evaluate(() => document.querySelector('.main-sidebar-reset')?.click()); await wait(140);
    const tabletReset = await tablet.evaluate(key => {
      const s=JSON.parse(localStorage.getItem(key)||'{}'),ui=s.ui||{},l=document.querySelector('.side-left')?.getBoundingClientRect(),r=document.querySelector('.side-right')?.getBoundingClientRect();
      return {widths:[ui.sidebarLeftWidth,ui.sidebarRightWidth],ratio:ui.sidebarPairRatio,filter:ui.filter,fontScale:ui.fontScale,layout:ui.sidebarLayout,actual:l&&r?[Math.round(l.width),Math.round(r.width)]:null};
    }, STORE_KEY);
    const tabletResetOk = tabletReset.widths[0]===300 && tabletReset.widths[1]===300 && tabletReset.ratio===.5 && tabletReset.filter==='done' && tabletReset.fontScale===1.1 && tabletReset.layout==='dual-right' && tabletReset.actual && Math.abs(tabletReset.actual[0]-tabletReset.actual[1])<=1;
    check('Main-header reset restores both default sidebar widths and tablet split ratio without resetting unrelated settings',tabletResetOk,tabletReset);
    await tablet.reload({waitUntil:'load',timeout:60000}); await tablet.waitForSelector('.layout .phases'); await wait(120);
    const tabletReload=await stateUi(tablet);
    check('Sidebar size reset remains saved after reload',tabletReload.sidebarLeftWidth===300 && tabletReload.sidebarRightWidth===300 && tabletReload.sidebarPairRatio===.5,{widths:[tabletReload.sidebarLeftWidth,tabletReload.sidebarRightWidth],ratio:tabletReload.sidebarPairRatio});
    await tablet.close();

    // Reset from the Desktop/Laptop compact sticky header is also actionable and restores the rendered grid immediately.
    const desktop = await openApp(browser, origin, 1366, seedState({sidebarLeftWidth:420,sidebarRightWidth:380,sidebarPairRatio:.58,filter:'todo',fontScale:1}));
    await compactHeader(desktop);
    const beforeStickyReset = await desktop.evaluate(() => [Math.round(document.querySelector('.side-left').getBoundingClientRect().width),Math.round(document.querySelector('.side-right').getBoundingClientRect().width)]);
    await desktop.evaluate(() => document.querySelector('.sticky-reset')?.click()); await wait(140);
    const stickyReset=await desktop.evaluate(key=>{
      const s=JSON.parse(localStorage.getItem(key)||'{}'),ui=s.ui||{},l=document.querySelector('.side-left')?.getBoundingClientRect(),r=document.querySelector('.side-right')?.getBoundingClientRect();
      return {widths:[ui.sidebarLeftWidth,ui.sidebarRightWidth],ratio:ui.sidebarPairRatio,actual:l&&r?[Math.round(l.width),Math.round(r.width)]:null,compact:document.querySelector('.topbar')?.classList.contains('compact')};
    },STORE_KEY);
    check('Desktop/Laptop sticky reset restores custom sidebar sizes to defaults and keeps the sticky header usable',
      beforeStickyReset[0]!==300 && beforeStickyReset[1]!==300 && stickyReset.widths[0]===300 && stickyReset.widths[1]===300 && stickyReset.ratio===.5 && stickyReset.actual?.[0]===300 && stickyReset.actual?.[1]===300 && stickyReset.compact,
      {before:beforeStickyReset,after:stickyReset});
    await desktop.close();

    check('Header and sidebar reset suite has no uncaught runtime, console, or request errors',runtimeErrors.length===0,runtimeErrors);
  } finally {
    await browser.close();
    await new Promise(resolve => server.close(resolve));
  }
  console.log(`SUMMARY | ${failures.length ? 'FAIL' : 'PASS'} | ${failures.length} failure(s) | ${runtimeErrors.length} runtime error(s)`);
  if (failures.length) process.exitCode = 1;
})().catch(error => { console.error(error); if (server) server.close(); process.exitCode = 1; });
