from pathlib import Path
p = Path('/home/user/uploads/packpolymer-marketplace-roadmap-v1.0.3.html')
s = p.read_text(encoding='utf-8')
ops = [
(
"""  let saveTimer = null;
  function saveNow() {""",
"""  let saveTimer = null;
  // Scroll work is batched to one animation frame; the header only recomputes once per painted frame.
  let headerCompactFrame = 0;
  function scheduleHeaderCompact() {
    if (headerCompactFrame) return;
    headerCompactFrame = requestAnimationFrame(() => {
      headerCompactFrame = 0;
      updateHeaderCompact();
    });
  }
  function saveNow() {"""
),
(
"""  window.addEventListener('beforeunload', saveNow);
  window.addEventListener('scroll', updateHeaderCompact, { passive: true });""",
"""  window.addEventListener('beforeunload', saveNow);
  window.addEventListener('scroll', scheduleHeaderCompact, { passive: true });"""
),
(
"""          toTop.classList.toggle('show', window.scrollY > 700);
          updateHeaderCompact();
          ticking = false;""",
"""          toTop.classList.toggle('show', window.scrollY > 700);
          ticking = false;"""
),
(
"""        case 'notebook': nbToggle(); break;""",
"""        // The desktop header control is labelled “open notebook”; force an open so its first click
        // cannot be interpreted as a close by an already-pending state transition.
        case 'notebook': nbToggle(btn.classList.contains('notebook-btn') && window.innerWidth > 1180 ? true : undefined); break;"""
),
(
""".mobile-tabbar{position:fixed;left:0;right:0;bottom:0;z-index:88;display:none;align-items:stretch;justify-content:space-around;gap:2px;min-height:54px;padding:5px 6px calc(5px + env(safe-area-inset-bottom));background:rgba(10,16,29,.985);border-top:1px solid var(--line-strong);box-shadow:0 -12px 30px -18px rgba(0,0,0,.9)}""",
""".mobile-tabbar{position:fixed;left:0;right:0;bottom:0;z-index:88;display:none;align-items:stretch;justify-content:space-around;gap:2px;min-height:50px;padding:3px 6px calc(3px + env(safe-area-inset-bottom));background:rgba(10,16,29,.985);border-top:1px solid var(--line-strong);box-shadow:0 -12px 30px -18px rgba(0,0,0,.9)}"""
),
(
"""  body{padding-bottom:calc(64px + env(safe-area-inset-bottom))}
  .nb{bottom:calc(64px + env(safe-area-inset-bottom));height:calc(100dvh - 64px - env(safe-area-inset-bottom));max-height:calc(100dvh - 64px - env(safe-area-inset-bottom))}
  .menu-drawer-list{padding-bottom:calc(70px + env(safe-area-inset-bottom))}
  .phase-drawer-list .navlist{padding-bottom:calc(68px + env(safe-area-inset-bottom))}""",
"""  body{padding-bottom:calc(58px + env(safe-area-inset-bottom))}
  .nb{bottom:calc(58px + env(safe-area-inset-bottom));height:calc(100dvh - 58px - env(safe-area-inset-bottom));max-height:calc(100dvh - 58px - env(safe-area-inset-bottom))}
  .menu-drawer-list{padding-bottom:calc(64px + env(safe-area-inset-bottom))}
  .phase-drawer-list .navlist{padding-bottom:calc(62px + env(safe-area-inset-bottom))}"""
),
(
"""  .topbar:not(.compact)>.header-actions-left>.sidebar-layout-slot{order:7;flex:0 0 auto}
  .topbar:not(.compact)>.topbar-break.brk-b{order:8}""",
"""  .topbar:not(.compact)>.header-actions-left>.sidebar-layout-slot{order:7;flex:0 0 auto}
  /* Standard 8px separation between the two related desktop sidebar controls. */
  .topbar:not(.compact)>.header-actions-left>.sidebar-layout-slot>.sidebar-size-reset{margin-inline-start:8px}
  .topbar:not(.compact)>.topbar-break.brk-b{order:8}"""
),
(
"""  .topbar.compact>.topbar-break{display:none!important}
  /* 2.1 — compact header: reset sidebar size = icon square exactly like the layout-mode button */""",
"""  .topbar.compact>.topbar-break{display:none!important}
  /* Prevent the sticky header’s compact transition from becoming the scroll anchor on desktop. */
  html{overflow-anchor:none}
  /* 2.1 — compact header: reset sidebar size = icon square exactly like the layout-mode button */"""
),
]
for n, (old, new) in enumerate(ops, 1):
    count = s.count(old)
    assert count == 1, f'op {n}: expected exactly 1 match, got {count}'
    s = s.replace(old, new, 1)
p.write_text(s, encoding='utf-8')
print(f'Applied {len(ops)} exact scoped changes to {p.name}')
