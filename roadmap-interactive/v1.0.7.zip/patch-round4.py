from pathlib import Path
p = Path('/home/user/uploads/packpolymer-marketplace-roadmap-v1.0.3.html')
s = p.read_text(encoding='utf-8')
ops = [
(
""".ph-caret{transition:.25s;color:var(--tx-3);font-size:calc(12px * var(--font-scale,1))}
.phase.open .ph-caret{transform:rotate(180deg)}""",
""".ph-caret{transition:.25s;color:var(--tx-3);font-size:calc(12px * var(--font-scale,1))}
.phase.open .ph-caret{transform:rotate(180deg)}
/* Main-page edit mode: phase deletion stays visible in the phase header, even while the phase is collapsed. */
.phase-edit-actions{display:inline-flex;align-items:center;flex:0 0 auto}
.phase-delete-btn{white-space:nowrap;color:#ffd7dd}
.phase-delete-btn .ic{width:13px;height:13px}"""
),
(
""".mobile-tabbar{position:fixed;left:0;right:0;bottom:0;z-index:88;display:none;align-items:stretch;justify-content:space-around;gap:2px;min-height:50px;padding:3px 6px calc(3px + env(safe-area-inset-bottom));background:rgba(10,16,29,.985);border-top:1px solid var(--line-strong);box-shadow:0 -12px 30px -18px rgba(0,0,0,.9)}""",
""".mobile-tabbar{position:fixed;left:0;right:0;bottom:0;z-index:88;display:none;align-items:stretch;justify-content:space-around;gap:2px;min-height:46px;padding:1px 6px calc(1px + env(safe-area-inset-bottom));background:rgba(10,16,29,.985);border-top:1px solid var(--line-strong);box-shadow:0 -12px 30px -18px rgba(0,0,0,.9)}"""
),
(
"""  body{padding-bottom:calc(58px + env(safe-area-inset-bottom))}
  .nb{bottom:calc(58px + env(safe-area-inset-bottom));height:calc(100dvh - 58px - env(safe-area-inset-bottom));max-height:calc(100dvh - 58px - env(safe-area-inset-bottom))}
  .menu-drawer-list{padding-bottom:calc(64px + env(safe-area-inset-bottom))}
  .phase-drawer-list .navlist{padding-bottom:calc(62px + env(safe-area-inset-bottom))}""",
"""  body{padding-bottom:calc(54px + env(safe-area-inset-bottom))}
  .nb{bottom:calc(54px + env(safe-area-inset-bottom));height:calc(100dvh - 54px - env(safe-area-inset-bottom));max-height:calc(100dvh - 54px - env(safe-area-inset-bottom))}
  .menu-drawer-list{padding-bottom:calc(60px + env(safe-area-inset-bottom))}
  .phase-drawer-list .navlist{padding-bottom:calc(58px + env(safe-area-inset-bottom))}"""
),
(
"""  .ph-side .ph-caret{margin-inline-start:auto}
  .ph-body{padding:4px 8px 12px}""",
"""  .ph-side .ph-caret{margin-inline-start:auto}
  .ph-side .phase-delete-btn{width:30px;height:28px;min-width:30px;min-height:28px;padding:0;justify-content:center;gap:0}
  .ph-side .phase-delete-label{display:none}
  .ph-body{padding:4px 8px 12px}"""
),
(
"""      entityBtn('phase', ph.id) +
      '<span class="ph-caret">' + I('chev', 'caret') + '</span>' +""",
"""      entityBtn('phase', ph.id) +
      (state.ui.editing ? '<span class="phase-edit-actions"><button type="button" class="iact tiny d phase-delete-btn" data-act="del-phase" data-id="' + esc(ph.id) + '" title="حذف کامل این فاز و همه مراحل آن" aria-label="حذف کامل ' + esc(phaseNumLabel(ph)) + '">' + I('trash') + '<span class="phase-delete-label">حذف فاز</span></button></span>' : '') +
      '<span class="ph-caret">' + I('chev', 'caret') + '</span>' +"""
),
(
"""      '<button class="iact" data-act="move-phase" data-id="' + esc(ph.id) + '" data-dir="1">' + I('down') + ' فاز</button>' +
      '<button class="iact d" data-act="del-phase" data-id="' + esc(ph.id) + '">' + I('trash') + ' حذف این فاز</button>' +
      '</div>' : '') +""",
"""      '<button class="iact" data-act="move-phase" data-id="' + esc(ph.id) + '" data-dir="1">' + I('down') + ' فاز</button>' +
      '</div>' : '') +"""
),
(
"""    }
    touch(); render(); flash(ph.id);
    toast('فاز جدید در جایگاه ' + fa(state.plan.indexOf(ph) + 1) + ' درج شد؛ شماره همه فازها خودکار به روز شد.');
  }
  async function delPhase(id) {
    const ph = findPhase(id); if (!ph) return;
    if (!await showInlineConfirm('فاز «' + ph.title + '» با همه مراحلش حذف شود؟','حذف فاز')) return;
    state.plan = state.plan.filter(p => p.id !== id); touch(); render(); toast('فاز حذف شد');
  }""",
"""    }
    // A new phase opens immediately, so the next Step and Sub Step can be added without an extra click.
    state.open[ph.id] = true;
    touch(); render(); flash(ph.id);
    toast('فاز جدید در جایگاه ' + fa(state.plan.indexOf(ph) + 1) + ' درج شد؛ شماره همه فازها خودکار به روز شد.');
  }
  function clearRemovedPhaseState(ph) {
    const ids = [ph.id];
    (ph.steps || []).forEach(step => {
      ids.push(step.id);
      (step.subs || []).forEach(sub => ids.push(sub.id));
    });
    ids.forEach(entityId => {
      const noteKey = 'n:' + entityId;
      delete state.checks[entityId];
      delete state.notes[noteKey];
      delete state.openNotes[noteKey];
      delete state.noteModes[noteKey];
      delete state.noteDirections[noteKey];
      if (state.marks && state.marks.archived) delete state.marks.archived[entityId];
      if (state.marks && state.marks.review) delete state.marks.review[entityId];
      if (state.ui.sideOpen) delete state.ui.sideOpen[entityId];
      if (state.ui.sideStepOpen) delete state.ui.sideStepOpen[entityId];
    });
    delete state.open[ph.id];
  }
  async function delPhase(id) {
    const ph = findPhase(id); if (!ph) return;
    const stepTotal = ph.steps.length;
    const subTotal = ph.steps.reduce((total, step) => total + step.subs.length, 0);
    const message = 'فاز «' + stripPhasePrefix(ph.title) + '» همراه با ' + fa(stepTotal) + ' مرحله و ' + fa(subTotal) + ' زیرمرحله حذف شود؟\nاین کار قابل بازگشت نیست.';
    if (!await showInlineConfirm(message,'حذف کامل فاز')) return;
    clearRemovedPhaseState(ph);
    state.plan = state.plan.filter(p => p.id !== id);
    touch(); render();
    toast('فاز و همه مراحل و زیرمرحله های آن حذف شد.');
  }"""
)
]
for n, (old, new) in enumerate(ops, 1):
    count = s.count(old)
    assert count == 1, f'op {n}: expected exactly 1 match, got {count}'
    s = s.replace(old, new, 1)
p.write_text(s, encoding='utf-8')
print(f'Applied {len(ops)} narrowly-scoped phase-edit and tabbar changes.')
