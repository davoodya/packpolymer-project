const { chromium } = require('playwright');
const URL = 'file:///home/user/uploads/packpolymer-marketplace-roadmap-v1.0.3.html';
let pass = 0, fail = 0;
function check(name, ok, data) { if (ok) pass++; else fail++; console.log(ok ? '  ✅' : '  ❌', name, data ? '— ' + JSON.stringify(data) : ''); }
async function fresh(browser, width, height) {
  const context = await browser.newContext({ viewport:{ width, height } });
  await context.addInitScript(() => { try { localStorage.clear(); } catch (_) {} });
  const page = await context.newPage(), errors=[];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto(URL); await page.waitForTimeout(650);
  return { context, page, errors };
}
(async() => {
  const browser = await chromium.launch();
  console.log('══ desktop scroll, header spacing, notebook first-click ══');
  {
    const { context, page, errors } = await fresh(browser,1440,900);
    // Starts at the top and crosses the compact-header threshold in small, natural wheel increments.
    const scroll = [];
    for (let i=0; i<8; i++) {
      await page.mouse.wheel(0,25); await page.waitForTimeout(110);
      scroll.push(await page.evaluate(() => ({
        y:Math.round(window.scrollY), compact:document.querySelector('.topbar').classList.contains('compact'),
        headerH:Math.round(document.querySelector('.topbar').getBoundingClientRect().height)
      })));
    }
    const monotonic = scroll.every((v,i) => i === 0 || v.y >= scroll[i-1].y);
    check('initial desktop wheel scroll crosses compact-header threshold without reset', monotonic && scroll[0].y > 0 && scroll.at(-1).y > 150 && scroll.some(x => x.compact), scroll);
    await page.evaluate(() => window.scrollTo(0,0)); await page.waitForTimeout(180);
    const controls = await page.evaluate(() => {
      const layout = document.querySelector('.topbar:not(.compact) .sidebar-layout-slot > .sidebar-layout-btn');
      const reset = document.querySelector('.topbar:not(.compact) .sidebar-layout-slot > .sidebar-size-reset');
      const lr=layout && layout.getBoundingClientRect(), rr=reset && reset.getBoundingClientRect();
      return { exists:!!(lr&&rr), gap:lr&&rr ? Math.round(lr.left-rr.right) : null, resetMargin:reset ? getComputedStyle(reset).marginInlineStart : null };
    });
    check('desktop header layout/reset controls have a standard 8px separation', controls.exists && controls.gap === 8 && controls.resetMargin === '8px', controls);
    // Verify that each fresh normal-header click opens the notebook immediately.
    await page.click('.notebook-btn'); await page.waitForTimeout(80);
    const first = await page.evaluate(() => ({open:document.querySelector('#nbPanel').classList.contains('open'),body:document.body.classList.contains('nb-open'),aria:document.querySelector('#nbPanel').getAttribute('aria-hidden')}));
    check('desktop header notebook opens on FIRST click', first.open && first.body && first.aria === 'false', first);
    await page.click('#nbPanel [data-nb="close"]'); await page.waitForTimeout(360);
    await page.click('.notebook-btn'); await page.waitForTimeout(80);
    const second = await page.evaluate(() => ({open:document.querySelector('#nbPanel').classList.contains('open'),body:document.body.classList.contains('nb-open')}));
    check('desktop header notebook opens again on its next first click', second.open && second.body, second);
    check('desktop: no runtime errors', errors.length === 0, errors);
    await context.close();
  }
  console.log('══ mobile/tablet bottom bar geometry ══');
  for (const [w,h,name] of [[390,844,'mobile'],[820,1180,'tablet']]) {
    const { context, page, errors } = await fresh(browser,w,h);
    const before = await page.evaluate(() => {
      const b=document.querySelector('#mobileTabbar').getBoundingClientRect();
      const item=document.querySelector('#mobileTabbar .tab-item').getBoundingClientRect();
      return {barH:Math.round(b.height),itemH:Math.round(item.height),bodyPad:getComputedStyle(document.body).paddingBottom};
    });
    check(`${name}: bottom bar is reduced yet retains ≥42px button targets`, before.barH === 50 && before.itemH >= 42 && /58px/.test(before.bodyPad), before);
    await page.click('#mobileTabbar [data-tab="notebook"]'); await page.waitForTimeout(250);
    const pos = await page.evaluate(() => { const nb=document.querySelector('#nbPanel').getBoundingClientRect(), bar=document.querySelector('#mobileTabbar').getBoundingClientRect(); return {open:document.body.classList.contains('nb-open'), panelBottom:Math.round(nb.bottom), barTop:Math.round(bar.top), gap:Math.round(bar.top-nb.bottom)}; });
    check(`${name}: notebook remains above the shorter tab bar`, pos.open && pos.panelBottom <= pos.barTop && pos.gap >= 0, pos);
    check(`${name}: no runtime errors`, errors.length === 0, errors);
    await context.close();
  }
  await browser.close();
  console.log('\n══════════════════════════════════'); console.log(`TOTAL: ${pass+fail} — PASS: ${pass} — FAIL: ${fail}`); process.exit(fail ? 1 : 0);
})().catch(e=>{console.error('FATAL',e);process.exit(1);});
