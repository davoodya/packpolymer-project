const {chromium}=require('playwright'); const URL='file:///home/user/uploads/packpolymer-marketplace-roadmap-v1.0.3.html';
(async()=>{const b=await chromium.launch();
  let c=await b.newContext({viewport:{width:1440,height:900}});await c.addInitScript(()=>localStorage.clear());let p=await c.newPage();await p.goto(URL);await p.waitForTimeout(700);await p.screenshot({path:'round3-desktop-header.png',clip:{x:0,y:0,width:1440,height:290}});await p.mouse.wheel(0,100);await p.waitForTimeout(250);await p.screenshot({path:'round3-desktop-scroll.png',clip:{x:0,y:0,width:1440,height:260}});await c.close();
  c=await b.newContext({viewport:{width:390,height:844}});await c.addInitScript(()=>localStorage.clear());p=await c.newPage();await p.goto(URL);await p.waitForTimeout(700);await p.screenshot({path:'round3-mobile-tabbar.png'});await c.close();await b.close();
})().catch(e=>{console.error(e);process.exit(1)});
