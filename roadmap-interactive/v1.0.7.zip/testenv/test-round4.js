const { chromium } = require('playwright');
const URL = 'file:///home/user/uploads/packpolymer-marketplace-roadmap-v1.0.3.html';
let pass=0, fail=0;
function check(name, ok, data) { if(ok) pass++; else fail++; console.log(ok?'  ✅':'  ❌',name,data?'— '+JSON.stringify(data):''); }
async function fresh(browser,w,h){
  const context=await browser.newContext({viewport:{width:w,height:h}});
  await context.addInitScript(()=>{try{localStorage.clear()}catch(_){}});
  const page=await context.newPage(), errors=[]; page.on('pageerror',e=>errors.push(String(e)));
  await page.goto(URL); await page.waitForTimeout(700); return {context,page,errors};
}
async function editCrud(page,label){
  await page.locator('[data-act="edit-mode"]').first().click(); await page.waitForTimeout(350);
  const initial=await page.evaluate(()=>({
    editing:document.body.classList.contains('editing'), phases:document.querySelectorAll('.phase').length,
    phaseDeleteCount:document.querySelectorAll('.ph-head [data-act="del-phase"]').length,
    firstDeleteVisible:(()=>{const b=document.querySelector('.ph-head [data-act="del-phase"]'); const r=b&&b.getBoundingClientRect(); return !!(r&&r.width>0&&r.height>0&&getComputedStyle(b).display!=='none')})(),
    oldBodyDeleteCount:document.querySelectorAll('.editbar [data-act="del-phase"]').length
  }));
  check(`${label}: edit mode exposes one visible phase-delete action in every phase header`,initial.editing&&initial.phases===13&&initial.phaseDeleteCount===13&&initial.firstDeleteVisible&&initial.oldBodyDeleteCount===0,initial);

  const removal=await page.evaluate(()=>{const ph=document.querySelector('#f0');const ids=[ph.id];ph.querySelectorAll('.step,.sub').forEach(el=>ids.push(el.id));ph.querySelector('.ph-ck input').click();return {ids, steps:ph.querySelectorAll('.step').length, subs:ph.querySelectorAll('.sub').length};});
  await page.click('#f0 .ph-head [data-act="del-phase"]'); await page.waitForSelector('.inline-confirm');
  const confirm=await page.evaluate(()=>document.querySelector('.inline-confirm')?.innerText||'');
  const faDigits = value => String(value).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
  check(`${label}: full-phase deletion asks for confirmation including its descendants`,/حذف کامل فاز/.test(confirm)&&confirm.includes(faDigits(removal.steps))&&confirm.includes(faDigits(removal.subs)),{confirm,removal});
  await page.click('.inline-confirm [data-confirm-yes]'); await page.waitForFunction(()=>!document.getElementById('f0'));
  await page.waitForTimeout(360);
  const deleted=await page.evaluate((removed)=>{
    const stored=JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')||'{}');
    const hasId=(obj,id)=>obj&&Object.prototype.hasOwnProperty.call(obj,id);
    const clear=removed.every(id=>!hasId(stored.checks,id)&&!hasId(stored.open,id)&&!hasId(stored.marks&&stored.marks.archived,id)&&!hasId(stored.marks&&stored.marks.review,id)&&!hasId(stored.openNotes,'n:'+id)&&!hasId(stored.notes,'n:'+id)&&!hasId(stored.noteModes,'n:'+id)&&!hasId(stored.noteDirections,'n:'+id)&&!hasId(stored.ui&&stored.ui.sideOpen,id)&&!hasId(stored.ui&&stored.ui.sideStepOpen,id));
    return {phases:document.querySelectorAll('.phase').length, phaseAbsent:!document.getElementById('f0'), clear};
  },removal.ids);
  check(`${label}: deleting a phase removes it, all Step/Sub Step descendants, and their stored state`,deleted.phases===12&&deleted.phaseAbsent&&deleted.clear,deleted);

  const hostId=await page.evaluate(()=>document.querySelector('.phase').id);
  await page.click(`#${hostId} [data-act="add-phase"]`); await page.waitForTimeout(260);
  const created=await page.evaluate((hostId)=>{const a=[...document.querySelectorAll('.phase')],i=a.findIndex(x=>x.id===hostId),el=a[i+1];return {id:el&&el.id,phases:a.length,open:!!(el&&el.classList.contains('open')),body:el?getComputedStyle(el.querySelector('.ph-body')).display:null,steps:el?el.querySelectorAll('.step').length:-1};},hostId);
  check(`${label}: a new phase is inserted and automatically opened for immediate editing`,created.phases===13&&!!created.id&&created.open&&created.body==='block'&&created.steps===0,created);

  await page.click(`#${created.id} [data-act="add-step"]`); await page.waitForTimeout(220);
  const firstStep=await page.evaluate(id=>{const ph=document.getElementById(id),step=ph&&ph.querySelector('.step');return {id:step&&step.id,steps:ph&&ph.querySelectorAll('.step').length,subAction:!!(step&&step.querySelector('[data-act="add-sub"]'))};},created.id);
  check(`${label}: a Step can be added to the newly-created phase`,firstStep.steps===1&&!!firstStep.id&&firstStep.subAction,firstStep);

  await page.click(`#${firstStep.id} [data-act="add-sub"]`); await page.waitForTimeout(180);
  let sub=await page.evaluate(id=>{const step=document.getElementById(id);return {subs:step&&step.querySelectorAll('.sub').length,hasDelete:!!(step&&step.querySelector('[data-act="del-sub"]'))};},firstStep.id);
  check(`${label}: a Sub Step can be added to the new Step`,sub.subs===1&&sub.hasDelete,sub);
  await page.click(`#${firstStep.id} [data-act="del-sub"]`); await page.waitForTimeout(160);
  await page.click(`#${firstStep.id} [data-act="add-sub"]`); await page.waitForTimeout(160);
  sub=await page.evaluate(id=>document.getElementById(id)?.querySelectorAll('.sub').length||0,firstStep.id);
  check(`${label}: Sub Step can be re-added after deletion`,sub===1,{subs:sub});

  await page.click(`#${firstStep.id} [data-act="del-step"]`); await page.waitForSelector('.inline-confirm'); await page.click('.inline-confirm [data-confirm-yes]'); await page.waitForTimeout(220);
  const afterStepDelete=await page.evaluate(id=>({steps:document.getElementById(id)?.querySelectorAll('.step').length||0}),created.id);
  check(`${label}: Step can be deleted cleanly`,afterStepDelete.steps===0,afterStepDelete);
  await page.click(`#${created.id} [data-act="add-step"]`); await page.waitForTimeout(180);
  const readded=await page.evaluate(id=>document.getElementById(id)?.querySelectorAll('.step').length||0,created.id);
  check(`${label}: Step can be re-added after deletion`,readded===1,{steps:readded});
}
(async()=>{
 const browser=await chromium.launch();
 for(const [w,h,label] of [[1440,900,'desktop'],[820,1180,'tablet'],[390,844,'mobile']]){
   console.log(`══ Main-page edit CRUD — ${label} ══`);
   const {context,page,errors}=await fresh(browser,w,h);
   await editCrud(page,label); check(`${label}: no runtime errors`,errors.length===0,errors); await context.close();
 }
 console.log('══ compact bottom bar ══');
 for(const [w,h,label] of [[390,844,'mobile'],[820,1180,'tablet'],[1440,900,'desktop']]){
  const {context,page,errors}=await fresh(browser,w,h);
  const bar=await page.evaluate(()=>{const e=document.querySelector('#mobileTabbar'),r=e.getBoundingClientRect(),item=e.querySelector('.tab-item').getBoundingClientRect();return {display:getComputedStyle(e).display,h:Math.round(r.height),itemH:Math.round(item.height),bodyPad:getComputedStyle(document.body).paddingBottom};});
  const ok=label==='desktop'?bar.display==='none':bar.display==='flex'&&bar.h===46&&bar.itemH>=42&&/54px/.test(bar.bodyPad);
  check(`${label}: bottom bar has the requested compact geometry only on mobile/tablet`,ok,bar);check(`${label}: no runtime errors`,errors.length===0,errors);await context.close();
 }
 await browser.close(); console.log('\n══════════════════════════════════');console.log(`TOTAL: ${pass+fail} — PASS: ${pass} — FAIL: ${fail}`);process.exit(fail?1:0);
})().catch(e=>{console.error('FATAL',e);process.exit(1)});
