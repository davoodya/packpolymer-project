const puppeteer = require('puppeteer');
const chromium = require('@sparticuz/chromium');
const http = require('http');
const fs = require('fs');

const HTML_PATH = '/home/user/packpolymer-marketplace-roadmap.html';
const STORE_KEY = 'packpolymer-marketplace-roadmap-v2';
const widths = [320,390,720,721,1024,1180,1181,1280,1920];
const failures = [];
const runtimeErrors = [];
let server;
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
function check(name, ok, detail) {
  console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}${detail === undefined ? '' : ' | ' + JSON.stringify(detail)}`);
  if (!ok) failures.push(name);
}
function seedState() {
  return {ui:{
    sidebarLayout:'dual-right',sidebarLeftWidth:340,sidebarRightWidth:360,sidebarPairRatio:.56,
    fontScale:1,filter:'todo',markFilters:[],stack:'',editing:false,nbOpen:false
  }};
}
function watch(page) {
  page.on('pageerror', e => runtimeErrors.push(e.message));
  page.on('console', m => {
    if (m.type()==='error' && !/scrollTo|not implemented|media|favicon/i.test(m.text())) runtimeErrors.push(m.text());
  });
  page.on('requestfailed', r => {
    if (/^https?:/.test(r.url()) && !/favicon\.ico/.test(r.url())) runtimeErrors.push('request failed: '+r.url());
  });
}
async function openApp(browser, origin, width) {
  const page = await browser.newPage();
  watch(page);
  await page.setViewport({width,height:800});
  await page.goto(origin+'/seed.html',{waitUntil:'load'});
  await page.evaluate((key,value)=>localStorage.setItem(key,JSON.stringify(value)),STORE_KEY,seedState());
  await page.goto(origin+'/packpolymer-marketplace-roadmap.html',{waitUntil:'load',timeout:60000});
  await page.waitForSelector('.topbar .search #q',{timeout:60000});
  await page.waitForSelector('.layout .phases',{timeout:60000});
  await wait(100);
  return page;
}
async function activateSticky(page) {
  let state={y:0,compact:false};
  for(let n=0;n<3;n++){
    await page.evaluate(()=>{if(document.activeElement&&document.activeElement!==document.body)document.activeElement.blur()});
    await page.keyboard.press('PageDown');
    await wait(230);
    state=await page.evaluate(()=>({y:scrollY,compact:document.querySelector('.topbar')?.classList.contains('compact')&&document.body.classList.contains('header-compact')}));
    if(state.y>48&&state.compact)break;
  }
  return state;
}
async function normalMetrics(page) {
  return page.evaluate(()=>{
    const h=document.querySelector('.topbar');
    const visible=e=>{if(!e)return false;const s=getComputedStyle(e),r=e.getBoundingClientRect();return s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0};
    const rect=e=>{if(!e)return null;const r=e.getBoundingClientRect();return {x:r.x,y:r.y,right:r.right,bottom:r.bottom,width:r.width,height:r.height}};
    const layout=[...h.querySelectorAll('.sidebar-layout-btn')].find(visible);
    const badge=layout?.querySelector('.layout-step'),icon=layout?.querySelector('.ic');
    const font=[...h.querySelectorAll('.font-controls:not([data-font-group="nb"])')].find(visible);
    const left=h.querySelector('.header-actions-left'),right=h.querySelector('.header-actions-right');
    const actions=[...right.children].filter(visible).map(e=>({act:e.matches('button')?e.dataset.act:(e.querySelector('button')?.dataset.act||'report-menu'),...rect(e)}));
    const mainFilters=h.querySelector(':scope > .filters-main'),markFilters=h.querySelector(':scope > .filters-marks');
    const floats=['#phaseFab','#fabNote','#totop'].map(sel=>{const e=document.querySelector(sel);return {id:e?.id,rect:rect(e),opacity:e&&getComputedStyle(e).opacity}});
    const actionOverflow=right?{scroll:right.scrollWidth,client:right.clientWidth,overflow:getComputedStyle(right).overflowX}:null;
    return {
      viewport:innerWidth,documentWidth:document.documentElement.scrollWidth,header:{...rect(h),scroll:h.scrollWidth,client:h.clientWidth},
      search:rect(h.querySelector('.search')),layout:rect(layout),badge:rect(badge),icon:rect(icon),layoutText:badge?.textContent.trim()||'',
      layoutPosition:badge&&getComputedStyle(badge).position,font:rect(font),left:rect(left),right:rect(right),actions,
      mainFilters:rect(mainFilters),markFilters:rect(markFilters),mainReset:rect(h.querySelector('.main-sidebar-reset')),
      mainResetVisible:visible(h.querySelector('.main-sidebar-reset')),actionOverflow,floats
    };
  });
}
async function stickyMetrics(page) {
  return page.evaluate(()=>{
    const h=document.querySelector('.topbar');
    const visible=e=>{if(!e)return false;const s=getComputedStyle(e),r=e.getBoundingClientRect();return s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0};
    const rect=e=>{if(!e)return null;const r=e.getBoundingClientRect();return {x:r.x,y:r.y,right:r.right,bottom:r.bottom,width:r.width,height:r.height}};
    const layout=[...h.querySelectorAll('.sidebar-layout-btn')].find(visible);
    const badge=layout?.querySelector('.layout-step'),icon=layout?.querySelector('.ic');
    const font=[...h.querySelectorAll('.sticky-side-tools .font-controls')].find(visible);
    const report=h.querySelector('.sticky-report-menu>.sticky-action');
    const caret=report?.querySelector('.caret'),reportIcon=report?.querySelector('.ic');
    const right=h.querySelector('.sticky-actions-right');
    const actions=[...right.children].filter(visible).map(e=>({act:e.matches('button')?e.dataset.act:(e.querySelector('button')?.dataset.act||'report-menu'),...rect(e)}));
    const reset=h.querySelector('.sticky-reset'),search=h.querySelector('.search');
    return {
      viewport:innerWidth,documentWidth:document.documentElement.scrollWidth,header:{...rect(h),scroll:h.scrollWidth,client:h.clientWidth},
      compact:h.classList.contains('compact'),search:rect(search),layout:rect(layout),badge:rect(badge),icon:rect(icon),layoutText:badge?.textContent.trim()||'',
      layoutPosition:badge&&getComputedStyle(badge).position,font:rect(font),right:rect(right),actions,
      reset:rect(reset),resetVisible:visible(reset),report:rect(report),reportIcon:rect(reportIcon),caret:rect(caret),
      caretDisplay:caret&&getComputedStyle(caret).display,actionOverflow:right?{scroll:right.scrollWidth,client:right.clientWidth,overflow:getComputedStyle(right).overflowX}:null
    };
  });
}
function contained(child,parent,tol=1){return !!child&&!!parent&&child.x>=parent.x-tol&&child.y>=parent.y-tol&&child.right<=parent.right+tol&&child.bottom<=parent.bottom+tol}
function overlaps(a,b,tol=1){return !!a&&!!b&&Math.min(a.right,b.right)-Math.max(a.x,b.x)>tol&&Math.min(a.bottom,b.bottom)-Math.max(a.y,b.y)>tol}
function itemRows(items){return items.length?Math.max(...items.map(x=>x.y))-Math.min(...items.map(x=>x.y)):Infinity}
function overlapsRect(a,b,tol=1){return !!a&&!!b&&Math.min(a.right,b.right)-Math.max(a.x,b.x)>tol&&Math.min(a.bottom,b.bottom)-Math.max(a.y,b.y)>tol}

(async()=>{
  const html=fs.readFileSync(HTML_PATH);
  server=http.createServer((req,res)=>{
    const route=(req.url||'/').split('?')[0];
    if(route==='/seed.html'){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});return res.end('<!doctype html><html><body>seed</body></html>')}
    if(route==='/favicon.ico'){res.writeHead(204);return res.end()}
    res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});res.end(html);
  });
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const origin='http://127.0.0.1:'+server.address().port;
  const browser=await puppeteer.launch({executablePath:await chromium.executablePath(),args:[...chromium.args,'--no-sandbox','--disable-dev-shm-usage'],headless:true});
  try{
    const floatingWidths=[];
    for(const width of widths){
      const page=await openApp(browser,origin,width);
      const normal=await normalMetrics(page);
      const responsive=width<=1180;
      const mainRowCenters=[normal.left,normal.layout,normal.font,normal.right].filter(Boolean).map(r=>r.y+r.height/2);
      const sameMainControlRow=responsive&&mainRowCenters.length===4&&Math.max(...mainRowCenters)-Math.min(...mainRowCenters)<=3;
      const actionsSingleLine=responsive&&normal.actions.length===10&&itemRows(normal.actions)<=1.25;
      const belowFilters=responsive&&Math.min(normal.layout?.y??Infinity,normal.font?.y??Infinity,normal.right?.y??Infinity)>=Math.max(normal.mainFilters?.bottom??0,normal.markFilters?.bottom??0)-1;
      const mainNoOverflow=normal.documentWidth<=width+1&&normal.header.scroll<=normal.header.client+1&&
        (!responsive||(normal.actionOverflow.scroll<=normal.actionOverflow.client+1&&!['auto','scroll'].includes(normal.actionOverflow.overflow)));
      check(`Mobile/Tablet/Laptop main controls stay together on one row with no horizontal scrolling at ${width}px`,!responsive||(sameMainControlRow&&actionsSingleLine&&belowFilters&&mainNoOverflow),
        {centers:mainRowCenters,actionYspread:itemRows(normal.actions),actionCount:normal.actions.length,belowFilters,actionOverflow:normal.actionOverflow,documentWidth:normal.documentWidth});
      check(`Main header layout marker is fully inside its button and clear of the icon at ${width}px`,
        contained(normal.badge,normal.layout)&&contained(normal.icon,normal.layout)&&!overlaps(normal.badge,normal.icon)&&!!normal.layoutText,
        {button:normal.layout,badge:normal.badge,icon:normal.icon,text:normal.layoutText,position:normal.layoutPosition});
      check(`Sidebar-size Reset stays in the main header at ${width}px`,normal.mainResetVisible&&normal.actions.some(a=>a.act==='sidebar-size-reset'),
        {visible:normal.mainResetVisible,reset:normal.mainReset});
      if(responsive){
        const fs=normal.floats;floatingWidths.push({width,items:fs});
        const allInside=fs.every(x=>x.rect&&x.rect.x>=-1&&x.rect.right<=width+1&&x.rect.width<=width);
        const noFloatOverlap=!overlaps(fs[0].rect,fs[1].rect)&&!overlaps(fs[0].rect,fs[2].rect)&&!overlaps(fs[1].rect,fs[2].rect);
        check(`Floating phase list, notebook, and top controls fit and remain separate at ${width}px`,allInside&&noFloatOverlap,
          fs.map(x=>({id:x.id,rect:x.rect,opacity:x.opacity})));
      }

      const scroll=await activateSticky(page);
      const sticky=await stickyMetrics(page);
      const expectedOrder=width>=1181
        ?['edit-mode','export','import','report-menu','sidebar-size-reset','expand-all','collapse-all','print','clean-all']
        :['edit-mode','export','import','report-menu','expand-all','collapse-all','clean-all'];
      const actionOrderOk=sticky.actions.map(a=>a.act).join('|')===expectedOrder.join('|');
      const stickyNoOverflow=sticky.documentWidth<=width+1&&sticky.header.scroll<=sticky.header.client+1&&
        sticky.actionOverflow.scroll<=sticky.actionOverflow.client+1&&!['auto','scroll'].includes(sticky.actionOverflow.overflow);
      check(`Minimum Sticky Header has no horizontal overflow and keeps its expected controls at ${width}px`,
        scroll.compact&&scroll.y>48&&sticky.compact&&actionOrderOk&&stickyNoOverflow,
        {scroll,order:sticky.actions.map(a=>a.act),expectedOrder,header:sticky.header,actions:sticky.actionOverflow,documentWidth:sticky.documentWidth});
      check(`Sticky layout marker is fully inside its button and does not cover the icon at ${width}px`,
        contained(sticky.badge,sticky.layout)&&contained(sticky.icon,sticky.layout)&&!overlaps(sticky.badge,sticky.icon)&&!!sticky.layoutText,
        {button:sticky.layout,badge:sticky.badge,icon:sticky.icon,text:sticky.layoutText,position:sticky.layoutPosition});
      const caretContained=contained(sticky.caret,sticky.report)&&!overlaps(sticky.caret,sticky.reportIcon);
      check(`Sticky Markdown status-menu caret is visible, inside the button, and beside the icon at ${width}px`,
        sticky.caretDisplay!=='none'&&sticky.caret?.width>0&&caretContained,
        {button:sticky.report,icon:sticky.reportIcon,caret:sticky.caret,display:sticky.caretDisplay});
      const expectStickyReset=width>=1181;
      const resetOnRight=expectStickyReset?sticky.resetVisible&&sticky.reset.x>=sticky.search.right-1:!sticky.resetVisible;
      check(`Sticky Reset appears only on Desktop/Laptop, immediately to the right of Search, at ${width}px`,resetOnRight,
        {visible:sticky.resetVisible,reset:sticky.reset,search:sticky.search});
      await page.close();
    }
    // An active stack adds one extra main-header control; the same compact rail must still fit without overlaps.
    for(const width of [320,390]){
      const stackPage=await openApp(browser,origin,width);
      const stackName=await stackPage.evaluate(()=>{const b=[...document.querySelectorAll('[data-act="stack-filter"]')].find(x=>x.dataset.id);if(!b)return '';const id=b.dataset.id;b.click();return id;});
      await wait(160);
      const m=await normalMetrics(stackPage);
      const centers=[m.left,m.layout,m.font,m.right].filter(Boolean).map(r=>r.y+r.height/2);
      const sameRow=centers.length===4&&Math.max(...centers)-Math.min(...centers)<=3;
      const actionSpread=itemRows(m.actions);
      const controlRects=[{name:'layout',...m.layout},{name:'font',...m.font},...m.actions.map(a=>({name:a.act,...a}))];
      const overlaps=[];
      for(let i=0;i<controlRects.length;i++)for(let j=i+1;j<controlRects.length;j++)if(overlapsRect(controlRects[i],controlRects[j]))overlaps.push([controlRects[i].name,controlRects[j].name]);
      check(`Mobile main controls still fit in one row with the active stack-clear button at ${width}px`,
        !!stackName&&m.actions.length===11&&sameRow&&actionSpread<=1.25&&overlaps.length===0&&m.actionOverflow.scroll<=m.actionOverflow.client+1&&m.documentWidth<=width+1,
        {stack:stackName,actions:m.actions.length,centers,actionYspread:actionSpread,overlaps,actionOverflow:m.actionOverflow,documentWidth:m.documentWidth});
      await stackPage.close();
    }
    const get=(w,id)=>floatingWidths.find(x=>x.width===w)?.items.find(x=>x.id===id)?.rect;
    const sizesGrowWithViewport=['phaseFab','fabNote','totop'].every(id=>{
      const small=get(320,id),large=get(1024,id);return small&&large&&small.width<large.width&&small.height<large.height;
    });
    check('Floating controls scale up from Mobile to Tablet rather than keeping oversized fixed dimensions',sizesGrowWithViewport,
      ['phaseFab','fabNote','totop'].map(id=>({id,mobile:get(320,id),tablet:get(1024,id)})));
    check('Focused responsive-header suite has no uncaught runtime, console, or request errors',runtimeErrors.length===0,runtimeErrors);
  }finally{
    await browser.close();
    await new Promise(resolve=>server.close(resolve));
  }
  console.log(`SUMMARY | ${failures.length?'FAIL':'PASS'} | ${failures.length} failure(s) | ${runtimeErrors.length} runtime error(s)`);
  if(failures.length)process.exitCode=1;
})().catch(error=>{console.error(error);if(server)server.close();process.exitCode=1});
