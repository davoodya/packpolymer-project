const puppeteer = require('puppeteer');
const chromium = require('@sparticuz/chromium');
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');

const failures = [], errors = [];
let server = null;
const wait = (ms = 120) => new Promise(resolve => setTimeout(resolve, ms));
function check(name, ok, detail) {
  console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}${detail === undefined ? '' : ' | ' + JSON.stringify(detail)}`);
  if (!ok) failures.push(name);
}
async function click(page, selector) {
  await page.evaluate(sel => {
    const el = document.querySelector(sel);
    if (!el) throw new Error('Missing element: ' + sel);
    el.click();
  }, selector);
}
async function setValue(page, selector, value) {
  await page.$eval(selector, (el, text) => {
    el.focus(); el.value = text;
    if (el.setSelectionRange) el.setSelectionRange(el.value.length, el.value.length);
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }, value);
}
async function setTop(page) {
  await page.evaluate(() => {
    const root = document.documentElement, previous = root.style.scrollBehavior;
    root.style.scrollBehavior = 'auto'; window.scrollTo(0, 0); root.style.scrollBehavior = previous;
  });
  await wait(120);
}

(async () => {
  const importPath = path.join(os.tmpdir(), 'arena-roadmap-import-' + process.pid + '.json');
  fs.writeFileSync(importPath, JSON.stringify({ checks: {}, notes: {}, noteDirections: {} }));
  const browser = await puppeteer.launch({
    executablePath: await chromium.executablePath(),
    args: [...chromium.args, '--no-sandbox', '--disable-dev-shm-usage'],
    headless: true
  });
  try {
    const page = await browser.newPage();
    page.on('pageerror', error => errors.push(error.message));
    page.on('console', message => {
      if (message.type() === 'error' && !/scrollTo|not implemented|media/i.test(message.text())) errors.push(message.text());
    });
    await page.setViewport({ width: 1280, height: 900 });
    const html = fs.readFileSync('/home/user/packpolymer-marketplace-roadmap.html');
    server = http.createServer((req, res) => {
      const route = (req.url || '/').split('?')[0];
      if (route === '/seed.html') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
        res.end('<!doctype html><html><body>seed</body></html>');
      } else if (route === '/answers-roadmap.json') {
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' }); res.end('{}');
      } else {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(html);
      }
    });
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
    const origin = 'http://127.0.0.1:' + server.address().port;
    await page.goto(origin + '/seed.html', { waitUntil: 'load' });
    await page.evaluate(() => {
      const now = new Date().toISOString();
      const note = (id, title) => ({ id, title, body: '', folderId: '', category: '', tags: [], direction: 'auto', createdAt: now, updatedAt: now });
      localStorage.setItem('packpolymer-marketplace-roadmap-v2', JSON.stringify({
        nbNotes: [note('direction-primary', 'Primary direction'), note('direction-secondary', 'Secondary direction')],
        nbActiveId: 'direction-primary', nbSecondaryId: 'direction-secondary',
        nbFolders: [], nbTags: [], nbCategories: [], nbBrowseMode: 'all', nbBrowseValue: '', nbSort: 'updated',
        nbView: 'note', nbMode: 'edit', nbSecondaryMode: 'edit', nbSplit: false,
        nbSplitRatio: .5, nbWidthPct: 75, nbBodyRatio: .5, nbBodyRatioSecondary: .5,
        noteDirections: {}, noteModes: {}, openNotes: {},
        ui: { nbOpen: false, editing: false, phaseDrawerOpen: false, sidebarLayout: 'dual-right', reportMode: 'full' }
      }));
    });
    await page.goto(origin + '/packpolymer-marketplace-roadmap.html', { waitUntil: 'load', timeout: 60000 });
    await wait(550);
    const initialSubNote = await page.evaluate(() => { const b=document.querySelector('.note-ind');return b?{text:b.innerText.trim(),label:b.getAttribute('aria-label'),svg:!!b.querySelector('svg'),labelNode:!!b.querySelector('.note-label')}:null; });
    check('Sub-step Note action is icon-only while retaining an accessible name', !!initialSubNote && initialSubNote.text === '' && !!initialSubNote.label && initialSubNote.svg && !initialSubNote.labelNode, initialSubNote);

    // Regression check: one real wheel event must scroll the document in both modes.
    await setTop(page);
    await page.mouse.move(790, 450);
    await page.mouse.wheel({ deltaY: 420 });
    await wait(150);
    const normalScroll = await page.evaluate(() => ({ y: scrollY, height: document.documentElement.scrollHeight, viewport: innerHeight, editing: document.body.classList.contains('editing') }));
    check('A single wheel event scrolls the main page in normal mode', normalScroll.y > 40 && !normalScroll.editing && normalScroll.height > normalScroll.viewport, normalScroll);

    await setTop(page);
    await click(page, '.edit-mode-btn');
    await page.waitForFunction(() => document.body.classList.contains('editing'));
    await page.mouse.move(790, 450);
    await page.mouse.wheel({ deltaY: 320 });
    await wait(160);
    const editingScroll = await page.evaluate(() => ({ y: scrollY, height: document.documentElement.scrollHeight, viewport: innerHeight, editing: document.body.classList.contains('editing') }));
    check('The first wheel event scrolls the main page in edit mode without a second wheel', editingScroll.y > 35 && editingScroll.editing && editingScroll.height > editingScroll.viewport, editingScroll);
    await click(page, '.edit-mode-btn');
    await setTop(page);

    // The compact sticky rail must expose all requested quick actions and retain their behavior.
    await page.evaluate(() => { document.documentElement.style.scrollBehavior = 'auto'; window.scrollTo(0, 500); });
    await wait(180);
    const compact = await page.evaluate(() => {
      const header = document.querySelector('.topbar'), group = document.querySelector('.compact-actions');
      return {
        scrollY, compact: header?.classList.contains('compact'), display: group ? getComputedStyle(group).display : 'missing',
        actions: [...(group?.querySelectorAll('[data-act]') || [])].map(x => x.dataset.act),
        reportChoices: [...(group?.querySelectorAll('[data-act="report"]') || [])].map(x => x.dataset.id)
      };
    });
    check('Compact sticky header contains Open All, Close All, Import JSON, three Markdown reports, and Clear', compact.compact && compact.display !== 'none' && ['expand-all','collapse-all','import','report-menu','clean-all'].every(x => compact.actions.includes(x)) && ['full','done','todo'].every(x => compact.reportChoices.includes(x)), compact);

    await click(page, '.compact-report-menu [data-act="report-menu"]');
    const reportMenu = await page.evaluate(() => {
      const menu = document.querySelector('.compact-report-menu .menu-pop');
      return { open: document.querySelector('.compact-report-menu').classList.contains('open'), display: menu && getComputedStyle(menu).display, choices: [...(menu?.querySelectorAll('[data-act="report"]') || [])].map(x => x.dataset.id) };
    });
    check('Compact Markdown report menu opens with Full, Completed, and Remaining choices', reportMenu.open && reportMenu.display === 'flex' && ['full','done','todo'].every(x => reportMenu.choices.includes(x)), reportMenu);
    await click(page, '.compact-report-menu [data-act="report-menu"]');

    await click(page, '.compact-actions [data-act="expand-all"]'); await wait(550);
    const expanded = await page.evaluate(() => {
      const s = JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2') || '{}');
      return { count: Object.keys(s.open || {}).length, all: Object.values(s.open || {}).length > 0 && Object.values(s.open || {}).every(Boolean) };
    });
    check('Compact Open All opens every phase', expanded.all, expanded);
    await click(page, '.compact-actions [data-act="collapse-all"]'); await wait(550);
    const collapsed = await page.evaluate(() => {
      const s = JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2') || '{}');
      return Object.values(s.open || {}).every(x => !x);
    });
    check('Compact Close All collapses every phase', collapsed);

    await click(page, '.compact-actions [data-act="clean-all"]');
    await page.waitForSelector('.inline-confirm');
    const clearPrompt = await page.$eval('.inline-confirm', el => el.innerText.includes('پاکسازی همه پاسخ ها'));
    await click(page, '.inline-confirm [data-confirm-no]');
    check('Compact Clear opens the existing confirmation instead of deleting data immediately', clearPrompt && !await page.$('.inline-confirm'));

    const [importChooser] = await Promise.all([
      page.waitForFileChooser({ timeout: 10000 }),
      click(page, '.compact-actions [data-act="import"]')
    ]);
    await importChooser.accept([importPath]);
    await page.waitForSelector('.inline-confirm');
    await click(page, '.inline-confirm [data-confirm-yes]');
    await wait(350);
    const imported = await page.evaluate(() => !document.querySelector('.inline-confirm') && document.querySelector('.topbar'));
    check('Compact Import JSON opens a file chooser and applies a confirmed JSON file', !!imported);

    // Direction cycle on a phase note: Auto → RTL → LTR → Auto, with Markdown exceptions.
    await setTop(page);
    if (!await page.$eval('.phase', el => el.classList.contains('open'))) await click(page, '.phase .ph-head');
    await wait(160);
    await click(page, '.phase-note-toggle');
    await page.waitForFunction(() => !!document.querySelector('.note-wrap.show textarea[data-note]'));
    const noteSelector = '.note-wrap.show textarea[data-note]';
    const noteMarkdown = 'English starts here.\n\nفارسی باید RTL نمایش داده شود.\n\n> English quote.\n\n> [!NOTE] English callout\n> body فارسی.\n\n```js\nconst value = "ok";\n```';
    await setValue(page, noteSelector, noteMarkdown);
    await click(page, '.note-wrap.show .note-mode-btn');
    await page.waitForFunction(() => !!document.querySelector('.note-wrap.show .note-read:not([hidden])'));
    const noteDirectionButton = '.note-wrap.show .note-direction-btn';
    const noteAuto = await page.evaluate(() => {
      const root = document.querySelector('.note-wrap.show .note-read'), ps = [...(root?.querySelectorAll(':scope > p') || [])];
      return { mode: document.querySelector('.note-wrap.show .note-direction-btn')?.dataset.directionMode, root: root?.dataset.textDirection, p: ps.map(x => x.getAttribute('dir')), attr: document.querySelector('.note-wrap.show textarea[data-note]')?.dataset.textDirection };
    });
    check('Written-note direction starts in Auto and preserves the current first-strong behavior', noteAuto.mode === 'auto' && noteAuto.root === 'auto' && noteAuto.p[0] === 'ltr' && noteAuto.p[1] === 'rtl' && noteAuto.attr === 'auto', noteAuto);

    await click(page, noteDirectionButton);
    const noteRtl = await page.evaluate(() => {
      const root = document.querySelector('.note-wrap.show .note-read'), ps = [...(root?.querySelectorAll(':scope > p') || [])];
      return { mode: document.querySelector('.note-wrap.show .note-direction-btn')?.dataset.directionMode, root: root?.getAttribute('dir'), p: ps.map(x => x.getAttribute('dir')), quote: root?.querySelector('blockquote')?.getAttribute('dir'), callout: root?.querySelector('.md-callout')?.getAttribute('dir'), code: root?.querySelector('pre.md-pre')?.getAttribute('dir'), css: ps.map(x => getComputedStyle(x).direction) };
    });
    check('Forced RTL overrides even English-first paragraphs while Markdown quotes, callouts, and fenced code stay LTR', noteRtl.mode === 'rtl' && noteRtl.root === 'rtl' && noteRtl.p.length >= 2 && noteRtl.p[0] === 'rtl' && noteRtl.p[1] === 'rtl' && noteRtl.quote === 'ltr' && noteRtl.callout === 'ltr' && noteRtl.code === 'ltr' && noteRtl.css[0] === 'rtl', noteRtl);
    await wait(350);
    const noteKey = await page.$eval(noteSelector, el => el.dataset.note);
    const noteSavedRtl = await page.evaluate(key => JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2') || '{}').noteDirections?.[key], noteKey);
    check('Forced note direction is persisted in the local answer state', noteSavedRtl === 'rtl', { noteKey, noteSavedRtl });

    await click(page, noteDirectionButton);
    const noteLtr = await page.evaluate(() => {
      const root = document.querySelector('.note-wrap.show .note-read'), ps = [...(root?.querySelectorAll(':scope > p') || [])];
      return { mode: document.querySelector('.note-wrap.show .note-direction-btn')?.dataset.directionMode, root: root?.getAttribute('dir'), p: ps.map(x => x.getAttribute('dir')), quote: root?.querySelector('blockquote')?.getAttribute('dir'), callout: root?.querySelector('.md-callout')?.getAttribute('dir'), code: root?.querySelector('pre.md-pre')?.getAttribute('dir'), editor: document.querySelector('.note-wrap.show textarea[data-note]')?.getAttribute('dir') };
    });
    check('Forced LTR also applies to Persian text and all Markdown blocks', noteLtr.mode === 'ltr' && noteLtr.root === 'ltr' && noteLtr.p.length >= 2 && noteLtr.p.every(x => x === 'ltr') && noteLtr.quote === 'ltr' && noteLtr.callout === 'ltr' && noteLtr.code === 'ltr' && noteLtr.editor === 'ltr', noteLtr);
    await click(page, noteDirectionButton);
    const noteAutoAgain = await page.evaluate(() => ({ mode: document.querySelector('.note-wrap.show .note-direction-btn')?.dataset.directionMode, label: document.querySelector('.note-wrap.show .note-direction-btn [data-direction-label]')?.textContent, p: [...(document.querySelector('.note-wrap.show .note-read')?.querySelectorAll(':scope > p') || [])].map(x => x.getAttribute('dir')) }));
    check('Third direction click returns the written note to Auto, completing the exact three-state cycle', noteAutoAgain.mode === 'auto' && noteAutoAgain.label === 'AUTO' && noteAutoAgain.p[0] === 'ltr' && noteAutoAgain.p[1] === 'rtl', noteAutoAgain);

    // Notebook direction cycles independently in each split pane and survives reload.
    await click(page, '#fabNote');
    await page.waitForFunction(() => document.querySelector('#nbPanel')?.classList.contains('open'));
    const nbText = 'Notebook English starts here.\n\nفارسی در دفترچه.\n\n> English quote.\n\n> [!TIP] English callout\n> callout فارسی.\n\n```js\nconst n = 1;\n```';
    await setValue(page, '#nbEdit', nbText);
    const nbDirectionButton = '[data-nb="direction"][data-side="primary"]';
    const nbAuto = await page.$eval(nbDirectionButton, b => ({ mode: b.dataset.directionMode, label: b.querySelector('[data-direction-label]')?.textContent, editor: document.querySelector('#nbEdit').dataset.textDirection }));
    check('Notebook primary direction toolbar starts in Auto', nbAuto.mode === 'auto' && nbAuto.label === 'AUTO' && nbAuto.editor === 'auto', nbAuto);
    await click(page, nbDirectionButton);
    const nbRtl = await page.evaluate(() => {
      const root = document.querySelector('#nbPreview'), ps = [...(root?.querySelectorAll(':scope > p') || [])];
      return { mode: document.querySelector('[data-nb="direction"][data-side="primary"]')?.dataset.directionMode, editorDir: document.querySelector('#nbEdit')?.getAttribute('dir'), preview: root?.dataset.textDirection, p: ps.map(x => x.getAttribute('dir')), quote: root?.querySelector('blockquote')?.getAttribute('dir'), callout: root?.querySelector('.md-callout')?.getAttribute('dir'), code: root?.querySelector('pre.md-pre')?.getAttribute('dir') };
    });
    check('Notebook forced RTL applies to English-first text and keeps Quote, Callout, and fenced code LTR', nbRtl.mode === 'rtl' && nbRtl.editorDir === 'rtl' && nbRtl.preview === 'rtl' && nbRtl.p[0] === 'rtl' && nbRtl.p[1] === 'rtl' && nbRtl.quote === 'ltr' && nbRtl.callout === 'ltr' && nbRtl.code === 'ltr', nbRtl);
    await click(page, nbDirectionButton);
    const nbLtr = await page.evaluate(() => ({ mode: document.querySelector('[data-nb="direction"][data-side="primary"]')?.dataset.directionMode, p: [...(document.querySelector('#nbPreview')?.querySelectorAll(':scope > p') || [])].map(x => x.getAttribute('dir')), editorDirection: getComputedStyle(document.querySelector('#nbEdit')).direction }));
    check('Notebook LTR mode forces Persian paragraphs and its editor to LTR', nbLtr.mode === 'ltr' && nbLtr.p.length >= 2 && nbLtr.p.every(x => x === 'ltr') && nbLtr.editorDirection === 'ltr', nbLtr);
    await click(page, nbDirectionButton); // primary returns to Auto
    await click(page, '[data-nb="split-toggle"]');
    await page.waitForFunction(() => !document.querySelector('[data-nb-pane="secondary"]')?.hidden);
    const secondarySelector = '[data-nb="direction"][data-side="secondary"]';
    await setValue(page, '#nbEditSecondary', 'English secondary.\n\nفارسی ثانویه.');
    await click(page, secondarySelector);
    await wait(700);
    const splitDirections = await page.evaluate(() => {
      const d = JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2') || '{}');
      const primary = d.nbNotes?.find(n => n.id === d.nbActiveId), secondary = d.nbNotes?.find(n => n.id === d.nbSecondaryId);
      return { primary: primary?.direction, secondary: secondary?.direction, primaryButton: document.querySelector('[data-nb="direction"][data-side="primary"]')?.dataset.directionMode, secondaryButton: document.querySelector('[data-nb="direction"][data-side="secondary"]')?.dataset.directionMode };
    });
    check('Notebook split panes keep independent direction controls', splitDirections.primaryButton === 'auto' && splitDirections.secondaryButton === 'rtl', splitDirections);
    await page.reload({ waitUntil: 'load', timeout: 60000 }); await wait(500);
    if (!await page.$eval('#nbPanel', panel => panel.classList.contains('open'))) {
      await click(page, '#fabNote'); await wait(100);
      if (!await page.$eval('#nbPanel', panel => panel.classList.contains('open'))) await click(page, '#fabNote');
    }
    await page.waitForFunction(() => document.querySelector('#nbPanel')?.classList.contains('open'));
    const persistedNb = await page.evaluate(() => ({
      primary: document.querySelector('[data-nb="direction"][data-side="primary"]')?.dataset.directionMode,
      secondary: document.querySelector('[data-nb="direction"][data-side="secondary"]')?.dataset.directionMode,
      editor: document.querySelector('#nbEditSecondary')?.dataset.textDirection,
      noteDirection: Object.values(JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2') || '{}').noteDirections || {})[0]
    }));
    check('Notebook pane direction settings survive reload; phase note settings return to Auto', persistedNb.primary === 'auto' && persistedNb.secondary === 'rtl' && persistedNb.editor === 'rtl' && persistedNb.noteDirection === 'auto', persistedNb);

    // Verify all quick actions remain available, compact, and reachable without document overflow at six widths.
    const responsive = [];
    for (const width of [1920, 1600, 1280, 1024, 768, 390, 320]) {
      await page.setViewport({ width, height: width <= 390 ? 844 : 900 });
      await page.evaluate(() => { document.documentElement.style.scrollBehavior = 'auto'; window.scrollTo(0, 500); });
      await wait(180);
      responsive.push(await page.evaluate(() => {
        const header = document.querySelector('.topbar'), rail = document.querySelector('.topbar .header-actions-right'), group = document.querySelector('.compact-actions');
        const buttons = [...(group?.querySelectorAll('.compact-mini-action') || [])];
        const first = buttons[0], last = buttons[buttons.length - 1];
        const nbDirections = [...document.querySelectorAll('#nbPanel .nb-pane-head-actions .nb-direction-toggle')].map(button => {
          const rect = button.getBoundingClientRect(), pane = button.closest('.nb-pane')?.getBoundingClientRect();
          return { display: getComputedStyle(button).display, width: rect.width, insidePane: !!pane && rect.left >= pane.left - 1 && rect.right <= pane.right + 1 };
        });
        return { width: innerWidth, documentWidth: document.documentElement.scrollWidth, compact: header?.classList.contains('compact'), groupDisplay: group ? getComputedStyle(group).display : 'missing', actionCount: buttons.length, firstWidth: first?.getBoundingClientRect().width, lastWidth: last?.getBoundingClientRect().width, railClient: rail?.clientWidth, railScroll: rail?.scrollWidth, nbDirections };
      }));
    }
    check('Responsive sticky-header and Notebook direction controls remain present without document-wide overflow from desktop through mobile', responsive.every(x => x.documentWidth <= x.width + 2 && x.compact && x.groupDisplay !== 'none' && x.actionCount === 5 && x.firstWidth > 0 && x.lastWidth > 0 && x.nbDirections.length === 2 && x.nbDirections.every(b => b.display !== 'none' && b.width >= 46 && b.insidePane)), responsive);
    // The standalone e2e-mobile-report-menu-smoke.js covers the final mobile menu hit-test in a fresh browser context.

    check('Direction, header, scrolling, and responsive suite has no uncaught runtime errors', errors.length === 0, errors);
    console.log(`SUMMARY | ${failures.length ? 'FAIL' : 'PASS'} | ${failures.length} failure(s) | ${errors.length} runtime error(s)`);
  } catch (error) {
    errors.push(error.stack || error.message);
    console.error(error);
  } finally {
    if (server) await new Promise(resolve => server.close(resolve));
    await browser.close();
    try { fs.unlinkSync(importPath); } catch (_) { }
  }
  process.exitCode = failures.length || errors.length ? 1 : 0;
})();
