const puppeteer=require('puppeteer');
const fs=require('fs');
const path=require('path');
const http=require('http');
const BASE='/home/user';
const HTML='/packpolymer-marketplace-roadmap.html';
const PORT=8898;
const failures=[];
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function check(name,ok,detail){console.log(`${ok?'PASS':'FAIL'} | ${name}${detail===undefined?'':' | '+JSON.stringify(detail)}`);if(!ok)failures.push(name);}
(async()=>{
  const server=http.createServer((req,res)=>{
    const pathname=decodeURIComponent((req.url||'/').split('?')[0]);
    const rel=pathname==='/'?HTML:pathname;
    const file=path.resolve(BASE,'.'+rel);
    if(!file.startsWith(BASE)){res.writeHead(403);return res.end('forbidden');}
    fs.readFile(file,(err,data)=>{if(err){res.writeHead(404);return res.end('not found');}
      const type=file.endsWith('.json')?'application/json; charset=utf-8':file.endsWith('.html')?'text/html; charset=utf-8':'text/plain; charset=utf-8';
      res.writeHead(200,{'Content-Type':type,'Cache-Control':'no-store'});res.end(data);
    });
  });
  await new Promise(r=>server.listen(PORT,'127.0.0.1',r));
  const browser=await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-dev-shm-usage']});
  const context=await browser.createBrowserContext();
  const page=await context.newPage();
  const errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  page.on('console',m=>{if(m.type()==='error'&&!/scrollTo|not implemented/i.test(m.text()))errors.push(m.text());});
  await page.evaluateOnNewDocument(()=>{window.__longTasks=[];try{new PerformanceObserver(l=>window.__longTasks.push(...l.getEntries().map(x=>x.duration))).observe({type:'longtask',buffered:true});}catch(e){}});
  await page.setViewport({width:1920,height:950});
  await page.goto('http://127.0.0.1:'+PORT+HTML,{waitUntil:'load',timeout:60000});
  await wait(850);

  const initial=await page.evaluate(()=>({version:document.querySelector('meta[name="version"]')?.content,phases:document.querySelectorAll('.phase').length,
    steps:document.querySelectorAll('.step').length,notebookWidth:parseFloat(getComputedStyle(document.querySelector('#nbPanel')).width)/innerWidth,
    titleDir:document.querySelector('#f2 [data-field="ptitle"]')?.getAttribute('dir'),
    goalDir:[...document.querySelectorAll('.phase .ph-goal .md-line')].slice(0,8).map(x=>x.dir),
    widthHandleHidden:document.querySelector('#nbPanel [data-nb-resize="width"]')?.hidden}));
  check('lazy startup renders 13 phase headers but not the full 122-step tree',initial.version==='1.2.0'&&initial.phases===13&&initial.steps<122,initial);
  check('Phase heading direction is set dynamically and Notebook opens at 75–80% on Desktop',!!initial.titleDir&&initial.notebookWidth>=.75&&initial.notebookWidth<=.80&&!initial.widthHandleHidden,initial);

  // Completion styling must propagate immediately into the nested Sidebar tree.
  await page.evaluate(()=>{
    const f=document.querySelector('#f0');
    f.querySelector('.ph-ck input').click();
    document.querySelector('#sideNavList [data-act="side-phase-toggle"][data-id="f0"]').click();
    document.querySelector('#sideNavList [data-act="side-step-toggle"][data-id="f0-s1"]').click();
  });
  await wait(100);
  const treeDone=await page.evaluate(()=>({phase:document.querySelector('#sideNavList [data-nav-role="phase"][data-id="f0"]')?.classList.contains('done'),
    step:document.querySelector('#sideNavList [data-nav-role="step"][data-id="f0-s1"]')?.classList.contains('done'),
    sub:document.querySelector('#sideNavList [data-nav-role="sub"][data-id="f0-s1-1"]')?.classList.contains('done')}));
  check('Phase, Step and Sub-step tree colors update immediately after completion',treeDone.phase&&treeDone.step&&treeDone.sub,treeDone);
  await page.evaluate(()=>document.querySelector('#f0 .ph-ck input').click());

  // Editable Phase/Step/Sub-step text uses auto direction per line; code fences stay LTR while typing.
  await page.evaluate(()=>document.querySelector('#f2 .ph-head').click());await wait(100);
  await page.click('.topbar .edit-mode-btn');await wait(140);
  const editText=async(selector,text)=>page.evaluate(({selector,text})=>{const e=document.querySelector(selector);if(!e)return false;e.focus();e.innerText=text;e.dispatchEvent(new Event('input',{bubbles:true}));e.blur();return true;},{selector,text});
  const mixedLines='English starts first; فارسی in the middle.\nفارسی starts this line; English comes later.\n```bash\necho سلام\n```';
  await editText('#f2 [data-field="ptitle"]','WooCommerce begins فارسی later');
  await editText('#f2 .ph-goal[data-field="goal"]',mixedLines);
  if(!await page.evaluate(()=>!!document.querySelector('#f2-s1 .tip-content[data-field="tip"]'))){await page.evaluate(()=>document.querySelector('#f2-s1 [data-act="add-tip"]')?.click());await wait(120);}
  await editText('#f2-s1 .tip-content[data-field="tip"]',mixedLines);
  await editText('#f2-s1-1 .sub-t[data-field="sub"]','فارسی زیرمرحله با English در میانه');
  await wait(320);await page.click('.topbar .edit-mode-btn');await wait(160);
  const directions=await page.evaluate(()=>({phaseTitle:document.querySelector('#f2 [data-field="ptitle"]')?.getAttribute('dir'),
    goal:[...document.querySelectorAll('#f2 .ph-goal .md-line')].map(x=>({t:x.textContent.trim(),dir:x.dir})),
    step:[...document.querySelectorAll('#f2-s1 .tip-content .md-line')].map(x=>({t:x.textContent.trim(),dir:x.dir})),
    sub:[...document.querySelectorAll('#f2-s1-1 .sub-t .md-line')].map(x=>({t:x.textContent.trim(),dir:x.dir})),
    code:[...document.querySelectorAll('#f2 .ph-goal pre.md-pre')].map(x=>x.getAttribute('dir'))}));
  check('Phase, Step and Sub-step read previews follow the first strong character on each line and keep fenced code LTR',directions.phaseTitle==='ltr'&&directions.goal[0]?.dir==='ltr'&&directions.goal[1]?.dir==='rtl'&&directions.step[0]?.dir==='ltr'&&directions.step[1]?.dir==='rtl'&&directions.sub[0]?.dir==='rtl'&&directions.code.every(x=>x==='ltr'),directions);
  await page.click('.topbar .edit-mode-btn');await wait(120);
  const directionsWhileTyping=await page.evaluate(()=>({editing:document.body.classList.contains('editing'),goal:document.querySelector('#f2 .ph-goal')?.getAttribute('dir'),step:document.querySelector('#f2-s1 .tip-content')?.getAttribute('dir'),sub:document.querySelector('#f2-s1-1 .sub-t')?.getAttribute('dir'),lineDirs:[...document.querySelectorAll('#f2 .ph-goal .edit-md-line')].map(x=>x.dir)}));
  check('Edit-mode fields keep auto/paragraph direction while typing',directionsWhileTyping.editing&&directionsWhileTyping.goal==='auto'&&directionsWhileTyping.step==='auto'&&directionsWhileTyping.sub==='auto'&&directionsWhileTyping.lineDirs[0]==='ltr'&&directionsWhileTyping.lineDirs[1]==='rtl',directionsWhileTyping);
  await page.click('.topbar .edit-mode-btn');await wait(650);

  // Main search is debounced and incremental; the Drawer is rendered once and independently.
  const searchSync=await page.evaluate(()=>{window.__longTasks=[];const q=document.querySelector('#q');q.value='Dokan Pro';const t=performance.now();q.dispatchEvent(new Event('input',{bubbles:true}));return performance.now()-t;});
  await wait(900);
  const search=await page.evaluate(()=>({phases:document.querySelectorAll('#phases .phase').length,steps:document.querySelectorAll('#phases .step').length,
    maxLong:Math.max(0,...window.__longTasks)}));
  check('search input handler returns immediately and incremental results complete',searchSync<20&&search.phases>0&&search.steps>0, {syncMs:searchSync,...search});
  check('incremental search avoids a 100ms+ long task',search.maxLong<100,search);
  await page.evaluate(()=>{const q=document.querySelector('#q');q.value='';q.dispatchEvent(new Event('input',{bubbles:true}));});await wait(700);
  await page.evaluate(()=>document.querySelector('#phaseFab').click());await wait(150);
  const drawer=await page.evaluate(()=>({drawers:document.querySelectorAll('#phaseNavDrawer').length,lists:document.querySelectorAll('#phaseDrawerNavList').length,open:document.querySelector('#phaseNavDrawer')?.classList.contains('open')}));
  check('Phase Drawer opens without duplicate Drawer/tree IDs',drawer.drawers===1&&drawer.lists===1&&drawer.open,drawer);
  await page.evaluate(()=>document.querySelector('#phaseNavDrawer [data-act="phase-drawer-close"]').click());await wait(80);

  // Full expansion is scheduled in frame-budgeted chunks instead of one blocking render.
  await page.evaluate(()=>{window.__longTasks=[];window.__expandStart=performance.now();const t=performance.now();document.querySelector('[data-act="expand-all"]').click();window.__expandDispatch=performance.now()-t;});
  await page.waitForFunction(()=>document.querySelectorAll('#phases .step').length===122&&document.querySelectorAll('#phases .sub').length===749,{timeout:8000});
  const expansion=await page.evaluate(()=>({ms:performance.now()-window.__expandStart,syncMs:window.__expandDispatch,maxLong:Math.max(0,...window.__longTasks),steps:document.querySelectorAll('#phases .step').length,subs:document.querySelectorAll('#phases .sub').length}));
  check('Expand All starts immediately and completes in frame-budgeted chunks',expansion.steps===122&&expansion.subs===749&&expansion.syncMs<50&&expansion.maxLong<100,expansion);

  // Editing controls keep the two insertion actions grouped.
  await page.click('.topbar .edit-mode-btn');await wait(150);
  const addGroup=await page.evaluate(()=>{const e=document.querySelector('#f0 .phase-add-actions'),r=e?.getBoundingClientRect();return{display:e?getComputedStyle(e).display:'',buttons:e?.querySelectorAll('.phase-add-btn').length||0,rect:r?.toJSON()};});
  check('Add Phase and Add Step stay in one compact edit-mode group',(['flex','inline-flex'].includes(addGroup.display))&&addGroup.buttons===2,addGroup);
  await page.click('.topbar .edit-mode-btn');await wait(120);

  // The compact sticky Header retains compact Markdown/JSON controls beside a narrower search.
  await page.evaluate(()=>window.scrollTo(0,700));await wait(250);
  const compact=await page.evaluate(()=>({compact:document.querySelector('.topbar')?.classList.contains('compact'),
    md:getComputedStyle(document.querySelector('.topbar .compact-export[data-id="full"]')).display,
    json:getComputedStyle(document.querySelector('.topbar .compact-export[data-act="export"]')).display,
    searchWidth:Math.round(document.querySelector('.topbar .search').getBoundingClientRect().width),scrollY:scrollY}));
  check('Compact Header keeps Markdown and JSON exports accessible beside the smaller Search',compact.compact&&compact.md!=='none'&&compact.json!=='none'&&compact.searchWidth<=260,compact);

  // Notebook fenced-code language profiles, fence boundaries and line-by-line direction.
  await page.click('#fabNote');await wait(100);await page.click('#nbPanel [data-nb="new"]');await wait(180);
  const markdown=[
    'English begins first; فارسی later in the same line must not change direction.',
    'فارسی شروع این خط است و English وسط آن جهت را عوض نمی کند.',
    '',
    '# English heading starts LTR و فارسی در ادامه',
    '# عنوان فارسی شروع می شود و English ادامه دارد',
    '',
    '```python',
    'def greet(name):',
    '    print("سلام", name) # greeting',
    '```',
    '',
    '```bash',
    'echo $HOME && printf "%s\\n" "سلام" # shell comment',
    '```',
    '',
    '```powershell',
    'Get-ChildItem -Path "C:\\Projects" -Force',
    'Write-Output "سلام"',
    '```',
    '',
    '```rust',
    'fn main() { let answer: i32 = 42; println!("سلام {}", answer); }',
    '```',
    '',
    '```c++',
    '#include <iostream>',
    'int main() { std::cout << "Hello"; return 0; }',
    '```',
    '',
    'English after every closing fence stays a normal paragraph.'
  ].join('\n');
  await page.evaluate(txt=>{const t=document.querySelector('#nbTitle');t.value='Offline language and direction test';t.dispatchEvent(new Event('input',{bubbles:true}));const e=document.querySelector('#nbEdit');e.value=txt;e.dispatchEvent(new Event('input',{bubbles:true}));},markdown);
  await wait(500);await page.evaluate(()=>document.querySelector('#nbPanel [data-nb="toggle-mode"][data-side="primary"]').click());await wait(220);
  const markdownResult=await page.evaluate(()=>{
    const preview=document.querySelector('#nbPreview'),pres=[...preview.querySelectorAll('pre.md-pre')],lines=[...preview.querySelectorAll('.md-line')];
    const line=text=>lines.find(x=>x.textContent.includes(text));
    return {langs:pres.map(x=>x.dataset.lang),allLtr:pres.every(x=>x.getAttribute('dir')==='ltr'&&x.querySelector('code')?.getAttribute('dir')==='ltr'),
      python:!!pres[0]?.querySelector('.hl-keyword')&&!!pres[0]?.querySelector('.hl-function')&&!!pres[0]?.querySelector('.hl-string')&&!!pres[0]?.querySelector('.hl-comment'),
      bash:!!pres[1]?.querySelector('.hl-function')&&!!pres[1]?.querySelector('.hl-property')&&!!pres[1]?.querySelector('.hl-comment'),
      powershell:!!pres[2]?.querySelector('.hl-function')&&!!pres[2]?.querySelector('.hl-string'),
      rust:!!pres[3]?.querySelector('.hl-keyword')&&!!pres[3]?.querySelector('.hl-number')&&!!pres[3]?.querySelector('.hl-string'),
      cpp:!!pres[4]?.querySelector('.hl-keyword')&&!!pres[4]?.querySelector('.hl-number')&&!!pres[4]?.querySelector('.hl-string'),
      englishDir:line('English begins first')?.dir,persianDir:line('فارسی شروع این خط')?.dir,
      englishHeadingDir:line('English heading starts')?.dir,persianHeadingDir:line('عنوان فارسی شروع')?.dir,
      afterFence:line('English after every closing fence')?.dir,afterNotCode:!pres.some(x=>x.textContent.includes('English after every')),
      textarea:{dir:document.querySelector('#nbEdit').getAttribute('dir'),unicode:getComputedStyle(document.querySelector('#nbEdit')).unicodeBidi},
      previewHidden:preview.hidden,editHidden:document.querySelector('#nbEdit').hidden,bodyLen:document.querySelector('#nbEdit').value.length,
      noteBodyLen:(JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')||'{}').nbNotes||[]).map(n=>(n.body||'').length),
      inlineScript:!!preview.querySelector('script,iframe,img')};
  });
  check('fenced Python, Bash, PowerShell, Rust and C++ select the correct offline highlighter',markdownResult.langs.join('|')==='python|bash|powershell|rust|c++'&&markdownResult.allLtr&&markdownResult.python&&markdownResult.bash&&markdownResult.powershell&&markdownResult.rust&&markdownResult.cpp,markdownResult);
  check('Preview sets direction from each line start, keeps code fences LTR, and stops highlighting at the closing fence',markdownResult.englishDir==='ltr'&&markdownResult.persianDir==='rtl'&&markdownResult.englishHeadingDir==='ltr'&&markdownResult.persianHeadingDir==='rtl'&&markdownResult.afterFence==='ltr'&&markdownResult.afterNotCode&&markdownResult.textarea.dir==='auto'&&markdownResult.textarea.unicode==='plaintext'&&!markdownResult.inlineScript,markdownResult);

  // Outer Notebook drag: mouse, keyboard and touch-pointer; Split drag: mouse, keyboard and touch-pointer.
  const widthStart=await page.evaluate(()=>({w:Math.round(document.querySelector('#nbPanel').getBoundingClientRect().width),left:Math.round(document.querySelector('#nbPanel').getBoundingClientRect().left),hidden:document.querySelector('[data-nb-resize="width"]').hidden}));
  let grip=await page.$('#nbPanel [data-nb-resize="width"]');let gr=await grip.boundingBox();
  await page.mouse.move(gr.x+5,gr.y+Math.min(gr.height/2,400));await page.mouse.down();await page.mouse.move(576,gr.y+Math.min(gr.height/2,400),{steps:8});await page.mouse.up();await wait(100);
  const widthMouse=await page.evaluate(()=>parseFloat(getComputedStyle(document.querySelector('#nbPanel')).width)/innerWidth);
  await grip.focus();await page.keyboard.press('ArrowLeft');await wait(80);
  const widthKey=await page.evaluate(()=>parseFloat(getComputedStyle(document.querySelector('#nbPanel')).width)/innerWidth);
  await page.keyboard.press('ArrowRight');
  const widthTouch=await page.evaluate(()=>{
    const e=document.querySelector('#nbPanel [data-nb-resize="width"]'),r=e.getBoundingClientRect(),y=Math.min(innerHeight*.5,r.bottom-2);
    e.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,cancelable:true,pointerId:7,pointerType:'touch',button:0,clientX:r.left+5,clientY:y}));
    window.dispatchEvent(new PointerEvent('pointermove',{bubbles:true,cancelable:true,pointerId:7,pointerType:'touch',button:-1,clientX:0,clientY:y}));
    window.dispatchEvent(new PointerEvent('pointerup',{bubbles:true,cancelable:true,pointerId:7,pointerType:'touch',button:-1,clientX:0,clientY:y}));
    return parseFloat(getComputedStyle(document.querySelector('#nbPanel')).width)/innerWidth;
  });
  const widthFull=await page.evaluate(()=>({ratio:parseFloat(getComputedStyle(document.querySelector('#nbPanel')).width)/innerWidth,left:Math.round(document.querySelector('#nbPanel').getBoundingClientRect().left),state:JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')||'{}').nbWidthPct}));
  check('Notebook outer width resizes with the mouse, keyboard and touch-pointer (including Full Screen)',!widthStart.hidden&&widthStart.w/1920>=.75&&widthStart.w/1920<=.80&&Math.abs(widthMouse-.70)<.015&&widthKey>widthMouse&&widthTouch>.98&&widthFull.ratio>.98&&widthFull.left<=2&&widthFull.state===100,{widthStart,widthMouse,widthKey,widthTouch,widthFull});

  // Create a second note and expose the draggable Split divider.
  await page.evaluate(()=>document.querySelector('#nbPanel [data-nb-noteview] [data-nb="new"]').click());await wait(180);
  await page.evaluate(()=>{const t=document.querySelector('#nbTitle');t.value='Second resize note';t.dispatchEvent(new Event('input',{bubbles:true}));});await wait(260);
  await page.evaluate(()=>document.querySelector('#nbPanel [data-nb="split-toggle"]').click());await page.waitForFunction(()=>!document.querySelector('[data-nb-resize="split"]').hidden,{timeout:5000});
  const splitInitial=await page.evaluate(()=>({split:document.querySelector('[data-nb-workspace]').classList.contains('split-open'),ratio:JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')||'{}').nbSplitRatio,
    handleHidden:document.querySelector('[data-nb-resize="split"]').hidden,columns:getComputedStyle(document.querySelector('[data-nb-workspace]')).gridTemplateColumns}));
  const splitHandle=await page.$('[data-nb-resize="split"]');let sr=await splitHandle.boundingBox();
  const targetX=await page.evaluate(()=>{const w=document.querySelector('[data-nb-workspace]').getBoundingClientRect();return w.right-18-.64*(w.width-36)});
  await page.mouse.move(sr.x+sr.width/2,sr.y+sr.height/2);await page.mouse.down();await page.mouse.move(targetX,sr.y+sr.height/2,{steps:8});await page.mouse.up();await wait(90);
  const splitMouse=await page.evaluate(()=>JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')||'{}').nbSplitRatio);
  await splitHandle.focus();await page.keyboard.press('ArrowLeft');const splitKey=await page.evaluate(()=>JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')||'{}').nbSplitRatio);
  const splitTouch=await page.evaluate(()=>{
    const e=document.querySelector('[data-nb-resize="split"]'),r=e.getBoundingClientRect(),w=document.querySelector('[data-nb-workspace]').getBoundingClientRect();
    const x=w.right-18-.58*(w.width-36),y=r.top+r.height/2;
    e.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,cancelable:true,pointerId:9,pointerType:'touch',button:0,clientX:r.left+r.width/2,clientY:y}));
    window.dispatchEvent(new PointerEvent('pointermove',{bubbles:true,cancelable:true,pointerId:9,pointerType:'touch',button:-1,clientX:x,clientY:y}));
    window.dispatchEvent(new PointerEvent('pointerup',{bubbles:true,cancelable:true,pointerId:9,pointerType:'touch',button:-1,clientX:x,clientY:y}));
    return JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')||'{}').nbSplitRatio;
  });
  check('Split divider adjusts the two panes independently by mouse, keyboard and touch-pointer',splitInitial.split&&!splitInitial.handleHidden&&Math.abs(splitInitial.ratio-.5)<.03&&splitMouse>.60&&splitKey>splitMouse&&Math.abs(splitTouch-.58)<.04,{splitInitial,splitMouse,splitKey,splitTouch});

  // Tablet stays side by side; phone becomes a vertically resizable stacked split.
  await page.setViewport({width:768,height:900});await wait(120);
  const tablet=await page.evaluate(()=>({w:Math.round(document.querySelector('#nbPanel').getBoundingClientRect().width),cols:getComputedStyle(document.querySelector('[data-nb-workspace]')).gridTemplateColumns.split(' ').length,overflow:document.documentElement.scrollWidth>innerWidth}));
  await page.setViewport({width:414,height:850});await wait(120);
  const mobileBefore=await page.evaluate(()=>({w:Math.round(document.querySelector('#nbPanel').getBoundingClientRect().width),rows:getComputedStyle(document.querySelector('[data-nb-workspace]')).gridTemplateRows.split(' ').length,hidden:document.querySelector('[data-nb-resize="width"]').hidden,overflow:document.documentElement.scrollWidth>innerWidth}));
  const mobileRatio=await page.evaluate(()=>{const e=document.querySelector('[data-nb-resize="split"]'),r=e.getBoundingClientRect(),w=document.querySelector('[data-nb-workspace]').getBoundingClientRect(),y=w.top+18+.67*(w.height-36),x=r.left+r.width/2;
    e.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,cancelable:true,pointerId:11,pointerType:'touch',button:0,clientX:x,clientY:y}));
    window.dispatchEvent(new PointerEvent('pointermove',{bubbles:true,cancelable:true,pointerId:11,pointerType:'touch',button:-1,clientX:x,clientY:y}));
    window.dispatchEvent(new PointerEvent('pointerup',{bubbles:true,cancelable:true,pointerId:11,pointerType:'touch',button:-1,clientX:x,clientY:y}));
    return JSON.parse(localStorage.getItem('packpolymer-marketplace-roadmap-v2')||'{}').nbSplitRatio;});
  check('Tablet Split stays side by side and Mobile Split stacks with a touch-draggable vertical divider',tablet.w>=650&&tablet.cols===3&&!tablet.overflow&&mobileBefore.w===414&&mobileBefore.rows===3&&mobileBefore.hidden&&!mobileBefore.overflow&&mobileRatio>.63,{tablet,mobileBefore,mobileRatio});

  check('no JavaScript errors across performance, direction, highlighting and resizing tests',errors.length===0,errors.slice(0,10));
  await context.close();await browser.close();server.close();
  if(failures.length){console.log(`\nFAILED ${failures.length}: ${failures.join(' ; ')}`);process.exitCode=1;}else console.log('\nALL NEW REQUIREMENT TESTS PASSED');
})().catch(e=>{console.error('FATAL',e);process.exit(2);});
